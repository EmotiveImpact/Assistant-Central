// open-agent-bridge start [path] [--port N] [--mcp] [--registry]
import type { Command } from "commander";
import chalk from "chalk";
import { AgentServer } from "../../agent/server.js";
import { RegistryServer } from "../../registry/server.js";
import { McpAgentBridge } from "../../mcp/adapter.js";

export function registerStartCommand(program: Command): void {
  program
    .command("start [path]")
    .description("Start an agent server for a project directory")
    .option("-p, --port <number>", "Port to listen on (default: auto from 5001)", parseInt)
    .option("--registry", "Start the registry server instead of an agent")
    .option("--mcp", "Start MCP adapter for Claude Code / Codex integration")
    .option("--registry-url <url>", "Registry URL", "http://localhost:4999")
    .option("--claude", "Enable Claude Code AI backend for intelligent agent skills")
    .action(async (projectPath: string | undefined, options) => {
      if (options.registry) {
        const registry = new RegistryServer();
        await registry.start();
        console.log(chalk.green("✓") + " Registry started on http://localhost:4999");
        const stopRegistry = async () => { await registry.stop(); process.exit(0); };
        process.on("SIGINT", () => void stopRegistry());
        process.on("SIGTERM", () => void stopRegistry());
        process.on("SIGHUP", () => void stopRegistry());
        return;
      }

      if (options.mcp) {
        const bridge = new McpAgentBridge({ registryUrl: options.registryUrl });
        await bridge.start("stdio");
        return;
      }

      const agent = new AgentServer({
        port: options.port,
        projectPath: projectPath ?? process.cwd(),
        registryUrl: options.registryUrl,
        useClaudeCode: options.claude ?? false,
      });

      const result = await agent.start();
      console.log(chalk.green("✓") + ` Agent started`);
      console.log(`  ID:      ${chalk.cyan(result.agentId)}`);
      console.log(`  HTTP:    ${chalk.blue(result.url)}`);
      console.log(`  WS:      ${chalk.blue(result.wsUrl)}`);
      console.log(`  Project: ${result.card.name}`);
      console.log(`  Skills:  ${result.card.skills.map((s) => s.id).join(", ")}`);

      const stopAgent = async () => {
        console.log("\n" + chalk.yellow("Shutting down..."));
        await agent.stop();
        process.exit(0);
      };
      process.on("SIGINT", () => void stopAgent());
      process.on("SIGTERM", () => void stopAgent());
      process.on("SIGHUP", () => void stopAgent());
    });
}
