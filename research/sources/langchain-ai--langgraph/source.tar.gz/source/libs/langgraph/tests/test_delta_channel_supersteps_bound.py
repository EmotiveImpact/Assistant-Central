"""Tests for the supersteps-since-last-snapshot bound on DeltaChannel.

Validates that a delta channel which stops receiving writes is still
force-snapshotted after DELTA_MAX_SUPERSTEPS_SINCE_SNAPSHOT supersteps,
preventing unbounded ancestor walks.
"""

from typing import Annotated, Any
from unittest.mock import patch

import pytest
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.serde.types import _DeltaSnapshot
from typing_extensions import TypedDict

from langgraph.channels.delta import DeltaChannel
from langgraph.graph import END, START, StateGraph
from langgraph.pregel._checkpoint import delta_channels_to_snapshot
from langgraph.types import Command, interrupt

pytestmark = pytest.mark.anyio


def _simple_reducer(current: list, updates: list) -> list:
    """Flatten updates into current list (each update is itself a list)."""
    result = list(current)
    for u in updates:
        if isinstance(u, list):
            result.extend(u)
        else:
            result.append(u)
    return result


def _build_two_channel_graph(
    checkpointer: InMemorySaver,
    *,
    freq_a: int = 10_000,
    freq_b: int = 10_000,
    n_loops: int = 1,
) -> Any:
    """Graph with two delta channels A and B.

    The node only writes to channel A; B is never written by the node.
    `n_loops` controls how many supersteps the graph runs (via chained nodes).
    """
    ch_a = DeltaChannel(_simple_reducer, list, snapshot_frequency=freq_a)
    ch_b = DeltaChannel(_simple_reducer, list, snapshot_frequency=freq_b)
    State = TypedDict(  # noqa: UP013
        "State",
        {"a": Annotated[list, ch_a], "b": Annotated[list, ch_b]},
    )  # type: ignore[call-overload]

    builder = StateGraph(State)

    for i in range(n_loops):
        name = f"step_{i}"

        def node_fn(state: dict, _i: int = i) -> dict:
            return {"a": [f"a-val-{_i}"]}

        builder.add_node(name, node_fn)
        if i == 0:
            builder.add_edge(START, name)
        else:
            builder.add_edge(f"step_{i - 1}", name)
        if i == n_loops - 1:
            builder.add_edge(name, END)

    return builder.compile(checkpointer=checkpointer)


async def test_forced_snapshot_single_run() -> None:
    """A single invoke with enough supersteps triggers snapshot on the
    unwritten channel B via the supersteps bound."""
    max_ss = 3
    with patch(
        "langgraph.pregel._checkpoint.DELTA_MAX_SUPERSTEPS_SINCE_SNAPSHOT",
        max_ss,
    ):
        saver = InMemorySaver()
        graph = _build_two_channel_graph(saver, n_loops=4)
        config = {"configurable": {"thread_id": "single-run-ss"}}

        graph.invoke({"a": ["seed-a"], "b": ["seed-b"]}, config)

        head = saver.get_tuple(config)
        assert head is not None
        assert isinstance(head.checkpoint["channel_values"].get("b"), _DeltaSnapshot), (
            "Channel B should have been force-snapshotted via supersteps bound"
        )

        state = graph.get_state(config)
        assert state.values["b"] == ["seed-b"]
        assert "seed-a" in state.values["a"]


async def test_supersteps_bound_skips_a_channel_never_written() -> None:
    with patch(
        "langgraph.pregel._checkpoint.DELTA_MAX_SUPERSTEPS_SINCE_SNAPSHOT",
        3,
    ):
        saver = InMemorySaver()
        graph = _build_two_channel_graph(saver, n_loops=4)
        config = {"configurable": {"thread_id": "never-written"}}

        graph.invoke({"a": ["seed-a"]}, config)

        minted = [
            t.config["configurable"]["checkpoint_id"]
            for t in saver.list(config)
            if "b" in t.checkpoint["channel_versions"]
        ]
        assert not minted, (
            f"b was never written, but {len(minted)} checkpoints minted it a version"
        )
        assert graph.get_state(config).values["b"] == []


async def test_forced_snapshot_accumulates_across_runs() -> None:
    """Supersteps counter for an unwritten channel persists across separate
    invoke() calls. After enough runs, the channel is force-snapshotted."""
    max_ss = 5
    with patch(
        "langgraph.pregel._checkpoint.DELTA_MAX_SUPERSTEPS_SINCE_SNAPSHOT",
        max_ss,
    ):
        saver = InMemorySaver()
        graph = _build_two_channel_graph(saver, n_loops=1)
        config = {"configurable": {"thread_id": "multi-run-ss"}}

        graph.invoke({"a": ["init-a"], "b": ["init-b"]}, config)

        for i in range(1, 6):
            graph.invoke({"a": [f"run-{i}"]}, config)

            head = saver.get_tuple(config)
            assert head is not None
            counters = head.metadata.get("counters_since_delta_snapshot", {})
            b_counters = counters.get("b", (0, 0))

            if b_counters == (0, 0):
                assert isinstance(
                    head.checkpoint["channel_values"].get("b"), _DeltaSnapshot
                ), f"Run {i}: counter reset but no snapshot blob for B"
                break
        else:
            pytest.fail("Channel B was never force-snapshotted after multiple runs")

        state = graph.get_state(config)
        assert state.values["b"] == ["init-b"]
        assert "init-a" in state.values["a"]


async def test_predicate_fires_on_supersteps_overflow() -> None:
    """Unit test: delta_channels_to_snapshot fires when supersteps >= MAX
    even when updates == 0."""
    ch = DeltaChannel(_simple_reducer, list, snapshot_frequency=10_000)
    ch.key = "x"
    ch_instance = ch.from_checkpoint(None)

    channels = {"x": ch_instance}
    counters: dict[str, tuple[int, int]] = {"x": (0, 5000)}

    result = delta_channels_to_snapshot(channels, counters, {"x": 1})
    assert "x" in result

    counters_below: dict[str, tuple[int, int]] = {"x": (0, 4999)}
    result2 = delta_channels_to_snapshot(channels, counters_below, {"x": 1})
    assert "x" not in result2

    assert not delta_channels_to_snapshot(channels, counters, {}), (
        "a channel with no version was never written, so it has nothing to snapshot"
    )


def _delta_counters(saver: InMemorySaver, config: Any) -> dict[str, list[int]]:
    tup = saver.get_tuple(config)
    assert tup is not None
    counters = tup.metadata.get("counters_since_delta_snapshot") or {}
    return {ch: list(c) for ch, c in counters.items()}


_CLEAR_COPY_AND_INPUT_UPDATES = pytest.mark.parametrize(
    ("values", "as_node", "supersteps"),
    [
        (None, END, 1),
        (None, "__copy__", 0),
        ({"a": []}, "__input__", 1),
    ],
    ids=["clear as END", "copy", "update as input"],
)


@_CLEAR_COPY_AND_INPUT_UPDATES
def test_update_state_path_keeps_delta_counters(
    values: Any, as_node: str, supersteps: int
) -> None:
    saver = InMemorySaver()
    graph = _build_two_channel_graph(saver)
    config = {"configurable": {"thread_id": "counters"}}
    graph.invoke({"a": ["seed-a"], "b": ["seed-b"]}, config)
    before = _delta_counters(saver, config)
    assert set(before) == {"a", "b"}, f"both channels need live counters: {before}"

    updated = graph.update_state(config, values, as_node=as_node)

    assert _delta_counters(saver, updated) == {
        ch: [u, s + supersteps] for ch, (u, s) in before.items()
    }


@_CLEAR_COPY_AND_INPUT_UPDATES
async def test_aupdate_state_path_keeps_delta_counters(
    values: Any, as_node: str, supersteps: int
) -> None:
    saver = InMemorySaver()
    graph = _build_two_channel_graph(saver)
    config = {"configurable": {"thread_id": "counters"}}
    await graph.ainvoke({"a": ["seed-a"], "b": ["seed-b"]}, config)
    before = _delta_counters(saver, config)
    assert set(before) == {"a", "b"}, f"both channels need live counters: {before}"

    updated = await graph.aupdate_state(config, values, as_node=as_node)

    assert _delta_counters(saver, updated) == {
        ch: [u, s + supersteps] for ch, (u, s) in before.items()
    }


_UPDATES_THAT_ADD_A_SUPERSTEP = pytest.mark.parametrize(
    ("values", "as_node"),
    [(None, END), ({"a": []}, "__input__")],
    ids=["clear as END", "update as input"],
)


@_UPDATES_THAT_ADD_A_SUPERSTEP
def test_update_state_path_snapshots_at_the_supersteps_bound(
    values: Any, as_node: str
) -> None:
    saver = InMemorySaver()
    graph = _build_two_channel_graph(saver)
    config = {"configurable": {"thread_id": "bound"}}
    graph.invoke({"a": ["seed-a"], "b": ["seed-b"]}, config)
    expected = graph.get_state(config).values
    supersteps = _delta_counters(saver, config)["b"][1]

    with patch(
        "langgraph.pregel._checkpoint.DELTA_MAX_SUPERSTEPS_SINCE_SNAPSHOT",
        supersteps + 1,
    ):
        updated = graph.update_state(config, values, as_node=as_node)

    head = saver.get_tuple(updated)
    assert head is not None
    assert isinstance(head.checkpoint["channel_values"].get("b"), _DeltaSnapshot)
    assert "b" not in _delta_counters(saver, updated)
    assert graph.get_state(updated).values == expected


@_UPDATES_THAT_ADD_A_SUPERSTEP
async def test_aupdate_state_path_snapshots_at_the_supersteps_bound(
    values: Any, as_node: str
) -> None:
    saver = InMemorySaver()
    graph = _build_two_channel_graph(saver)
    config = {"configurable": {"thread_id": "bound"}}
    await graph.ainvoke({"a": ["seed-a"], "b": ["seed-b"]}, config)
    expected = (await graph.aget_state(config)).values
    supersteps = _delta_counters(saver, config)["b"][1]

    with patch(
        "langgraph.pregel._checkpoint.DELTA_MAX_SUPERSTEPS_SINCE_SNAPSHOT",
        supersteps + 1,
    ):
        updated = await graph.aupdate_state(config, values, as_node=as_node)

    head = saver.get_tuple(updated)
    assert head is not None
    assert isinstance(head.checkpoint["channel_values"].get("b"), _DeltaSnapshot)
    assert "b" not in _delta_counters(saver, updated)
    assert (await graph.aget_state(updated)).values == expected


async def test_counter_reset_after_supersteps_snapshot() -> None:
    """After the supersteps bound triggers a snapshot, the counters for
    that channel reset. Verify by using a bound higher than one run's
    supersteps so we can see the counter in an intermediate state."""
    max_ss = 15
    with patch(
        "langgraph.pregel._checkpoint.DELTA_MAX_SUPERSTEPS_SINCE_SNAPSHOT",
        max_ss,
    ):
        saver = InMemorySaver()
        graph = _build_two_channel_graph(saver, n_loops=4)
        config = {"configurable": {"thread_id": "counter-reset"}}

        graph.invoke({"a": ["seed-a"], "b": ["seed-b"]}, config)

        head = saver.get_tuple(config)
        assert head is not None
        counters = head.metadata.get("counters_since_delta_snapshot", {})
        b_counters = counters.get("b", (0, 0))
        run1_supersteps = b_counters[1]
        assert run1_supersteps > 0, "Should have some supersteps"
        assert b_counters[0] == 1, "B written once (input step)"

        graph.invoke({"a": ["more-a"]}, config)
        head2 = saver.get_tuple(config)
        assert head2 is not None
        counters2 = head2.metadata.get("counters_since_delta_snapshot", {})
        b_counters2 = counters2.get("b", (0, 0))
        run2_supersteps = b_counters2[1]
        assert run2_supersteps > run1_supersteps, "Supersteps should accumulate"
        assert b_counters2[0] == 1, "B written once total (only original input)"

        graph.invoke({"a": ["even-more"]}, config)
        head3 = saver.get_tuple(config)
        assert head3 is not None
        assert isinstance(
            head3.checkpoint["channel_values"].get("b"), _DeltaSnapshot
        ), "B should have snapshotted at supersteps >= max_ss"
        counters3 = head3.metadata.get("counters_since_delta_snapshot", {})
        b_counters3 = counters3.get("b", (0, 0))
        assert b_counters3[1] < max_ss, (
            f"After snapshot, supersteps should have reset, got {b_counters3}"
        )

        state = graph.get_state(config)
        assert state.values["b"] == ["seed-b"]


class _HistoryRequestSaver(InMemorySaver):
    def __init__(self) -> None:
        super().__init__()
        self.requested: list[list[str]] = []

    def get_delta_channel_history(self, *, config: Any, channels: Any) -> Any:
        self.requested.append(sorted(channels))
        return super().get_delta_channel_history(config=config, channels=channels)


def test_never_written_channel_is_not_walked() -> None:
    saver = _HistoryRequestSaver()
    graph = _build_two_channel_graph(saver, n_loops=3)
    config = {"configurable": {"thread_id": "never-written"}}
    graph.invoke({"a": ["seed-a"]}, config)
    saver.requested.clear()

    graph.invoke({"a": ["more-a"]}, config)
    state = graph.get_state(config)

    assert state.values["b"] == []
    assert saver.requested and all(r == ["a"] for r in saver.requested), (
        f"only the written channel needs a walk; asked for {saver.requested}"
    )


async def test_anever_written_channel_is_not_walked() -> None:
    saver = _HistoryRequestSaver()
    graph = _build_two_channel_graph(saver, n_loops=3)
    config = {"configurable": {"thread_id": "never-written"}}
    await graph.ainvoke({"a": ["seed-a"]}, config)
    saver.requested.clear()

    await graph.ainvoke({"a": ["more-a"]}, config)
    state = await graph.aget_state(config)

    assert state.values["b"] == []
    assert saver.requested and all(r == ["a"] for r in saver.requested), (
        f"only the written channel needs a walk; asked for {saver.requested}"
    )


@pytest.mark.parametrize("durability", ["sync", "async"])
def test_first_write_pending_at_an_interrupt_is_applied_once_on_resume(
    durability: Any,
) -> None:
    class State(TypedDict):
        x: list
        first: Annotated[list, DeltaChannel(_simple_reducer)]

    def ask(state: State) -> dict:
        interrupt("ok?")
        return {"x": ["asked"]}

    saver = InMemorySaver()
    graph = (
        StateGraph(State)
        .add_node("p", lambda state: {"first": ["p"]})
        .add_node("ask", ask)
        .add_edge(START, "p")
        .add_edge(START, "ask")
        .compile(checkpointer=saver)
    )
    config = {"configurable": {"thread_id": "pending-first-write"}}
    graph.invoke({"x": ["in"]}, config, durability=durability)
    head = saver.get_tuple(config)
    assert head is not None
    assert "first" not in head.checkpoint["channel_versions"]
    assert ("first", ["p"]) in [w[1:] for w in head.pending_writes or []]

    graph.invoke(Command(resume="yes"), config, durability=durability)

    assert graph.get_state(config).values["first"] == ["p"]
