import { validDirectMessageParticipants } from "../src/features/relay/direct-message-policy.ts";
import { randomUUID } from "node:crypto";
import { finalizeEvent } from "nostr-tools";

/** Idempotent participant-set command. Keys stay in the broker. */
export function directMessageEvent(input, viewer, key) {
  if (
    !input ||
    !Array.isArray(input.pubkeys) ||
    input.pubkeys.some((value) => typeof value !== "string") ||
    !validDirectMessageParticipants(input.pubkeys, viewer)
  )
    throw new Error("Choose between one and eight other people.");
  return finalizeEvent(
    {
      kind: 41010,
      content: "",
      created_at: Math.floor(Date.now() / 1000),
      tags: [
        ...input.pubkeys.map((pubkey) => ["p", pubkey]),
        ["client", randomUUID()],
      ],
    },
    key,
  );
}

export function directMessageReceipt(text, eventId) {
  const receipt = JSON.parse(text);
  if (
    receipt?.event_id !== eventId ||
    receipt.accepted !== true ||
    typeof receipt.message !== "string" ||
    !receipt.message.startsWith("response:")
  )
    throw new Error("The direct message could not be opened. Try again.");
  const result = JSON.parse(receipt.message.slice(9));
  if (
    typeof result?.channel_id !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(
      result.channel_id,
    )
  )
    throw new Error("The relay returned an invalid direct message.");
  return { channelId: result.channel_id };
}
