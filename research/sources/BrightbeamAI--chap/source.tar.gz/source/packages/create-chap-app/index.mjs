#!/usr/bin/env node
// create-chap-app: generate a CHAP project from a template, bring one up to
// this release (lib/upgrade.mjs), or put CHAP into a project you have
// (lib/add.mjs).
//
//   npx create-chap-app my-gate
//   npx create-chap-app my-gate --template mcp-gate --profiles core/1.0,review/1.0 --yes
//   npx create-chap-app upgrade my-gate
//   npx create-chap-app add
//
// Three questions: the template, the profiles and the project name. Each has
// a default, and the flags answer them without a prompt. The generator
// copies the template, fills in the placeholders and prints how to run the
// project. It installs nothing.

import { readFile, readdir, mkdir, copyFile, writeFile, stat, access, chmod } from "node:fs/promises";
import { readFileSync, realpathSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";
import { dirname, join, resolve, basename } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
export const TEMPLATES_DIR = join(here, "templates");
/** This package's version, which a generated project's stamp records. */
export const VERSION = JSON.parse(readFileSync(join(here, "package.json"), "utf8")).version;
/** The template generated when none is named. */
export const DEFAULT_TEMPLATE = "code-gate";

/** What a template needs installed, from its manifest's language. */
export const LANGUAGES = { typescript: "Node.js", python: "Python" };

/**
 * What each profile a template offers adds to the workspace, one line each,
 * for the prompt. profiles/PROFILES.md is the catalogue.
 */
export const PROFILE_NOTES = {
  "core/1.0": "workspaces, members, tasks and the audit log; always on",
  "review/1.0": "a person approves, rejects or overrides the agent's work",
  "modes/1.0": "shadow, trial and production: a new agent's work reviewed until it is trusted",
  "control/1.0": "pause, resume, snapshot, supersede and roll back",
  "whisper/1.0": "the agent asks a person a question with a deadline and a default answer",
  "deliberation/1.0": "several people vote, with a quorum, weights and vetoes",
  "handoff/1.0": "a task passed from one participant to another, who accepts or declines it",
  "routing/1.0": "who takes a task and how deep its review goes, from the task's hints",
  "audit-scitt/1.0": "the hash chain over the log, and receipts from a SCITT transparency service",
  "identity-oidc/1.0": "a person joins with a token from your identity provider",
  "security-signed/1.0": "calls signed with each participant's Ed25519 key",
};

/** A template as one line: its name, what it needs installed and what it is. */
function templateLine(t) {
  return `${t.name.padEnd(20)} ${(LANGUAGES[t.language] ?? t.language).padEnd(8)} ${t.description}`;
}

export async function listTemplates(dir = TEMPLATES_DIR) {
  const names = (await readdir(dir, { withFileTypes: true }))
    .filter((d) => d.isDirectory() && !d.name.startsWith("_"))
    .map((d) => d.name)
    .sort();
  const out = [];
  for (const name of names) out.push(JSON.parse(await readFile(join(dir, name, "template.json"), "utf8")));
  return out;
}

export function parseArgs(argv) {
  const args = { name: null, template: null, profiles: null, yes: false, help: false, list: false, dir: null, human: null, agent: null, humanName: null, humanEmail: null, reviewAt: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const value = () => {
      const v = argv[++i];
      if (v === undefined || v.startsWith("-")) throw new Error(`${a} needs a value`);
      return v;
    };
    if (a === "--template" || a === "-t") args.template = value();
    else if (a === "--profiles" || a === "-p") args.profiles = value().split(",").map((s) => s.trim()).filter(Boolean);
    else if (a === "--yes" || a === "-y") args.yes = true;
    else if (a === "--help" || a === "-h") args.help = true;
    else if (a === "--list") args.list = true;
    else if (a === "--dir") args.dir = value();
    else if (a === "--human") args.human = uri(value());
    else if (a === "--agent") args.agent = uri(value());
    else if (a === "--human-name") args.humanName = personName(value());
    else if (a === "--human-email") args.humanEmail = email(value());
    else if (a === "--review-at") { args.reviewAt = value(); if (!["commit", "push"].includes(args.reviewAt)) throw new Error("--review-at is commit or push"); }
    else if (a.startsWith("-")) throw new Error(`Unknown option ${a}`);
    else if (!args.name) args.name = a;
    else throw new Error(`Unexpected argument ${a}`);
  }
  return args;
}

const NAME_RE = /^[a-z][a-z0-9-]{0,63}$/;
// A participant URI: a scheme, a colon, then printable characters with no
// quote, backslash or whitespace, so it is safe inside the generated JSON.
const URI_RE = /^[a-z][a-z0-9+.-]*:[\x21\x23-\x5b\x5d-\x7e]+$/;

function uri(value) {
  if (!URI_RE.test(value)) throw new Error(`Not a participant URI: ${value}. Use the form human:name@example.org or agent:name.`);
  return value;
}

// A person's name and email go into JSON and into commit trailers, so they
// hold no quote, backslash, angle bracket or control character.
const PERSON_RE = /^[^"\\<>\x00-\x1f\x7f]{1,120}$/;
const EMAIL_RE = /^(?=.{3,254}$)[^\s"\\<>@]+@[^\s"\\<>@]+$/;

function personName(value) {
  if (!PERSON_RE.test(value) || !value.trim()) throw new Error(`Not a name that can go in a commit trailer: ${value}`);
  return value.trim();
}

function email(value) {
  if (!EMAIL_RE.test(value)) throw new Error(`Not an email address: ${value}`);
  return value;
}

/** The developer's own name and email from git config, each where it is set and usable; null for either otherwise. */
export function gitIdentity(cwd = process.cwd()) {
  const read = (key) => { try { return execFileSync("git", ["config", "--get", key], { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim(); } catch { return ""; } };
  const name = read("user.name");
  const mail = read("user.email");
  return { name: PERSON_RE.test(name) && name.trim() ? name.trim() : null, email: EMAIL_RE.test(mail) ? mail : null };
}

function slug(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}

/** Walk a directory, yielding relative file paths. */
async function walk(dir, prefix = "") {
  const out = [];
  for (const d of await readdir(dir, { withFileTypes: true })) {
    const rel = prefix ? `${prefix}/${d.name}` : d.name;
    if (d.isDirectory()) out.push(...(await walk(join(dir, d.name), rel)));
    else out.push(rel);
  }
  return out;
}

const TEXT = /\.(mjs|js|json|py|md|html|css|txt|csv|yml|yaml|toml|cfg|sh|gitignore)$|^\.gitignore$|(^|\/)(pre-commit|commit-msg|post-commit|pre-push)$/;

/**
 * npm leaves .gitignore files out of a published package, so a template
 * ships its ignore list as `gitignore`, its Docker one as `dockerignore` and
 * its workflows under `github/`, and they are renamed here.
 */
export function dotted(rel) {
  if (/(^|\/)(gitignore|dockerignore)$/.test(rel)) return rel.replace(/(gitignore|dockerignore)$/, ".$1");
  if (rel.startsWith("github/")) return "." + rel;
  return rel;
}

/**
 * Generate a project. Returns { target, written, manifest, fill, config }:
 * the directory, the files written, the template's manifest, the
 * placeholders' values and the project's chap.config.json as generated.
 *
 * `answers`: { name, template, profiles, workspace, human_uri, human_name,
 * human_email, agent_uri, review_at, project_dir }. Placeholders replaced in
 * text files: __PROJECT_NAME__, __PROJECT_DIR__ (project_dir, or else the
 * absolute path written to), __WORKSPACE__, __PROFILES_JSON__,
 * __PROFILES_CSV__, __HUMAN_URI__, __HUMAN_NAME__, __HUMAN_EMAIL__,
 * __AGENT_URI__, __REVIEW_AT__, and the stamp chap.config.json carries,
 * __TEMPLATE_NAME__ and __TEMPLATE_VERSION__, this package's version.
 */
export async function generate(answers, { templatesDir = TEMPLATES_DIR, targetDir } = {}) {
  const manifest = JSON.parse(await readFile(join(templatesDir, answers.template, "template.json"), "utf8"));
  const target = resolve(targetDir ?? answers.name);
  if (await exists(target)) {
    const entries = await readdir(target);
    if (entries.length) throw new Error(`${target} exists and is not empty.`);
  }
  const defaults = manifest.defaults ?? {};
  const fill = {
    __TEMPLATE_NAME__: answers.template,
    __TEMPLATE_VERSION__: VERSION,
    __PROJECT_NAME__: answers.name,
    __PROJECT_DIR__: answers.project_dir ?? target,
    __WORKSPACE__: (answers.workspace ?? defaults.workspace ?? "wsp_{name}").replace("{name}", slug(answers.name)),
    __PROFILES_JSON__: JSON.stringify(answers.profiles),
    __PROFILES_CSV__: answers.profiles.join(","),
    __HUMAN_URI__: answers.human_uri ?? defaults.human_uri ?? "human:you@local",
    __HUMAN_NAME__: answers.human_name ?? defaults.human_name ?? "You",
    __HUMAN_EMAIL__: answers.human_email ?? defaults.human_email ?? "you@localhost",
    __AGENT_URI__: answers.agent_uri ?? defaults.agent_uri ?? "agent:drafter",
    __REVIEW_AT__: answers.review_at ?? defaults.review_at ?? "commit",
  };

  // Source files: the template's own, then the shared files it names.
  const sources = [];
  const own = join(templatesDir, answers.template);
  for (const rel of await walk(own)) {
    if (rel === "template.json") continue;
    sources.push({ from: join(own, rel), to: rel });
  }
  for (const [sharedPath, dest] of Object.entries(manifest.shared ?? {})) {
    const from = join(templatesDir, "_shared", sharedPath);
    if ((await stat(from)).isDirectory()) {
      for (const rel of await walk(from)) sources.push({ from: join(from, rel), to: `${dest}/${rel}` });
    } else {
      sources.push({ from, to: dest });
    }
  }

  const written = [];
  for (const { from, to: rel } of sources) {
    const to = dotted(rel);
    const dest = join(target, to);
    await mkdir(dirname(dest), { recursive: true });
    if (TEXT.test(to)) {
      let text = await readFile(from, "utf8");
      for (const [k, v] of Object.entries(fill)) text = text.split(k).join(v);
      await writeFile(dest, text);
    } else {
      await copyFile(from, dest);
    }
    // A git hook has to stay executable, so the template file's mode is kept.
    const mode = (await stat(from)).mode & 0o777;
    if (mode & 0o111) await chmod(dest, mode);
    written.push(to);
  }
  let config = null;
  try { config = JSON.parse(await readFile(join(target, "chap.config.json"), "utf8")); } catch { config = null; }
  return { target, written, manifest, fill, config };
}

async function exists(p) {
  try { await access(p); return true; } catch { return false; }
}

function usage(templates) {
  const lines = [
    "Usage: npx create-chap-app <name> [--template <name>] [--profiles a,b] [--yes]",
    "       npx create-chap-app upgrade [<dir>] [--dry-run] [--diff]   bring a project up to this release",
    "       npx create-chap-app add [<dir>] [--template <name>]       put CHAP into a project you have",
    "",
    "Templates, with what each needs installed:",
    ...templates.map((t) => `  ${templateLine(t)}`),
    "",
    "Options:",
    "  --template, -t   the template (asked for when missing)",
    "  --profiles, -p   comma-separated profiles the workspace advertises (the template's default when missing)",
    "  --human          the reviewer's participant URI (default human:you@local)",
    "  --human-name     the reviewer's name, as a reviewed commit names them (default: git config user.name)",
    "  --human-email    the reviewer's email, likewise (default: git config user.email)",
    "  --review-at      code gate: commit (each change before it is committed) or push (a branch before it is pushed)",
    "  --agent          the agent's participant URI (the template's default when missing)",
    "  --dir            where to write (default: ./<name>)",
    "  --yes, -y        take every default without asking",
    "  --list           print the templates and exit",
  ];
  return lines.join("\n");
}

/**
 * What to run next, in commands that work in a POSIX shell, PowerShell and
 * cmd alike: the cd, the template's run steps, and the desk's address as a
 * sentence, since opening a page has no command common to all three.
 */
export function nextSteps({ target, manifest, config }, { relative = true } = {}) {
  const dir = relative ? basename(target) : target;
  const lines = ["Next:", `  cd ${/^[\w./:\\-]+$/.test(dir) ? dir : `"${dir}"`}`, ...(manifest.run ?? []).map((step) => `  ${step}`)];
  if (config?.port) lines.push("", `The desk is at http://localhost:${config.port}/ once it runs; open it in a browser.`);
  lines.push("", "README.md says what each profile changes in this project and how to attach your own agent and data.");
  return lines.join("\n");
}

async function ask(rl, question, fallback) {
  const answer = (await rl.question(`${question} [${fallback}] `)).trim();
  return answer || fallback;
}

/**
 * The command. It asks on `input` and writes to `output`, the terminal by
 * default, and asks nothing where `input` is not a terminal or --yes is given.
 */
export async function main(argv = process.argv.slice(2), { input = stdin, output = stdout, interactive = !!input.isTTY } = {}) {
  const say = (text = "") => output.write(`${text}\n`);
  if (argv[0] === "upgrade") return (await import("./lib/upgrade.mjs")).runUpgrade(argv.slice(1), { say });
  if (argv[0] === "add") return (await import("./lib/add.mjs")).runAdd(argv.slice(1), { say });
  const args = parseArgs(argv);
  const templates = await listTemplates();
  if (args.help) { say(usage(templates)); return 0; }
  if (args.list) { for (const t of templates) say(templateLine(t)); return 0; }

  const rl = interactive && !args.yes ? createInterface({ input, output }) : null;
  try {
    let template = args.template;
    if (!template) {
      const fallback = templates.find((t) => t.name === DEFAULT_TEMPLATE) ?? templates[0];
      if (!rl) template = fallback.name;
      else {
        say("Which template? Each runs on Node.js or on Python, as it says.");
        templates.forEach((t, i) => say(`  ${i + 1}. ${templateLine(t)}`));
        const pick = await ask(rl, "Template (number or name)", String(templates.indexOf(fallback) + 1));
        template = /^\d+$/.test(pick) ? templates[Number(pick) - 1]?.name : pick;
      }
    }
    const manifest = templates.find((t) => t.name === template);
    if (!manifest) throw new Error(`No template named ${template}. Templates: ${templates.map((t) => t.name).join(", ")}`);

    let profiles = args.profiles;
    if (!profiles) {
      if (!rl) profiles = manifest.default_profiles;
      else {
        say("Profiles the workspace advertises. Each turns on a part of CHAP, and the coordinator enforces it:");
        for (const id of manifest.profile_choices) say(`  ${id.padEnd(20)} ${PROFILE_NOTES[id] ?? ""}`.trimEnd());
        profiles = (await ask(rl, "Profiles (comma separated)", manifest.default_profiles.join(","))).split(",").map((s) => s.trim()).filter(Boolean);
      }
    }
    const unknown = profiles.filter((p) => !manifest.profile_choices.includes(p));
    if (unknown.length) throw new Error(`Unknown profile ${unknown.join(", ")}. Choices: ${manifest.profile_choices.join(", ")}`);
    if (!profiles.includes("core/1.0")) profiles = ["core/1.0", ...profiles];

    let name = args.name;
    if (!name) {
      if (!rl) name = `my-${template}`;
      else name = await ask(rl, "Project name", `my-${template}`);
    }
    if (!NAME_RE.test(name)) throw new Error(`The project name must be lower case letters, digits and hyphens, starting with a letter: ${name}`);

    const me = gitIdentity();
    const result = await generate(
      {
        name, template, profiles, human_uri: args.human ?? undefined, agent_uri: args.agent ?? undefined,
        human_name: args.humanName ?? me.name ?? undefined, human_email: args.humanEmail ?? me.email ?? undefined, review_at: args.reviewAt ?? undefined,
      },
      { targetDir: args.dir ?? undefined },
    );
    say(`\nCreated ${result.target} from the ${manifest.title} template with ${profiles.join(", ")}.`);
    say(`The reviewer is ${result.fill.__HUMAN_NAME__} <${result.fill.__HUMAN_EMAIL__}> as ${result.fill.__HUMAN_URI__}; change it in chap.config.json.\n`);
    say(nextSteps(result, { relative: !args.dir }));
    return 0;
  } finally {
    rl?.close();
  }
}

function runDirectly() {
  try { return !!process.argv[1] && realpathSync(fileURLToPath(import.meta.url)) === realpathSync(process.argv[1]); } catch { return false; }
}

if (runDirectly()) {
  main().then((code) => process.exit(code)).catch((e) => { console.error(e.message); process.exit(1); });
}
