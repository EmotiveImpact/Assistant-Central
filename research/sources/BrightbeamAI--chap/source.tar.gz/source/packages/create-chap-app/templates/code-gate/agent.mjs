// The built-in coding agent: `node agent.mjs [tasks.csv] [options]`.
//
//   --repo <path>     the repository to work in (default: ./demo-repo)
//   --branch <name>   the branch to commit on (default: agent/<date>), made from HEAD when missing
//   --once            take the rows in the file through the gate, then exit
//   --poll <ms>       how often to look for a decision (default 2000)
//
// Each row of the CSV (columns title, brief and an optional files hint) is
// one task. The agent drafts the change with the model the environment
// names, or with a scripted drafter when none is set, writes it into the
// working tree, proposes it as a patch, waits for the decision at the
// desk, and commits an approved change through the gate's hooks, so the
// commit carries the trailers and the evidence note. An override is
// applied before the commit, so what lands is what the reviewer approved.
// A rejection that asks for a revision has the agent draft again with the
// reviewer's note. A rejection takes the change back out of the working
// tree. A restarted agent finds its tasks by their idempotency keys,
// commits what was approved and not yet committed, and carries on with a
// draft it made and had not yet submitted, which it records in the
// repository's git directory until it does.
//
// The agent works one task at a time on one branch, since a working tree
// holds one change at a time. Claude Code, Cursor and other agents work in
// the repository themselves and use propose.mjs; this one shows the whole
// path with nothing else installed.

import { lstat, readFile, mkdir, rm, writeFile } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { isMain, usage, wantsHelp } from "@brightbeamai/chap-server";
import { makeProvider, modelName } from "@brightbeamai/chap-server/providers";
import { agentClient, commitSigning, api, deskLink, describeChange, gateEnv, lastDecision, loadGate, propose, reviewersReady, reviewRule, sha256, task as readTask, waitForDecision } from "@brightbeamai/chap-code-gate/gate";
import { applyToWorkingTree, commitAll, commitsWithApproval, currentBranch, git, head, patchApplies, repoRoot, workingTreePatch } from "@brightbeamai/chap-code-gate/git";
import { syncOverride } from "@brightbeamai/chap-code-gate/propose";

const here = dirname(fileURLToPath(import.meta.url));
const MAX_CONTEXT_BYTES = 60_000;

// -- tasks.csv ----------------------------------------------------------------

/** RFC 4180 rows as objects keyed by the header line. */
export function parseCsv(text) {
  const rows = [];
  let row = [], field = "", quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else quoted = false; } else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ",") { row.push(field); field = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field); field = "";
      if (row.some((f) => f !== "")) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some((f) => f !== "")) rows.push(row);
  const [header, ...body] = rows;
  if (!header) return [];
  return body.map((r) => Object.fromEntries(header.map((h, i) => [h.trim(), (r[i] ?? "").trim()])));
}

export async function readTasks(path) {
  return parseCsv(await readFile(path, "utf8")).filter((t) => t.title && t.brief).map((t) => ({
    title: t.title, brief: t.brief, files: (t.files ?? "").split(";").map((s) => s.trim()).filter(Boolean),
    key: "task-" + sha256(`${t.title}\n${t.brief}`).slice(0, 16),
  }));
}

// -- the prompt and what comes back ------------------------------------------

/** The files to show the model: the hinted ones, then the ones whose path matches a word of the task, within a byte budget. */
export async function contextFiles(repo, task) {
  const all = (await git(repo, ["ls-files"])).split("\n").filter(Boolean);
  const words = `${task.title} ${task.brief}`.toLowerCase().match(/[a-z][a-z0-9_.-]{2,}/g) ?? [];
  const score = (path) => (task.files.includes(path) ? 100 : 0) + words.filter((w) => path.toLowerCase().includes(w)).length;
  const ranked = all.map((p) => [p, score(p)]).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  const out = [];
  let used = 0;
  for (const [path] of ranked) {
    let content;
    try { content = await readFile(join(repo, path), "utf8"); } catch { continue; }
    if (content.includes("\u0000")) continue;
    if (used + content.length > MAX_CONTEXT_BYTES) continue;
    used += content.length;
    out.push({ path, content });
  }
  return { all, shown: out };
}

export function buildPrompt(task, context, { revision = null, previousPatch = null } = {}) {
  const lines = [
    "You are a coding agent working in a git repository. Make exactly the change the task asks for, and nothing else.",
    `Task: ${task.title}`,
    `Brief: ${task.brief}`,
    "",
    "Repository files:",
    ...context.all.map((p) => `  ${p}`),
    "",
    "Current contents of the files most likely involved:",
  ];
  for (const f of context.shown) lines.push(`--- ${f.path} ---`, f.content, `--- end of ${f.path} ---`);
  if (revision) {
    lines.push("", `Revision requested by the reviewer: ${revision}`);
    if (previousPatch) lines.push("The previous attempt, as a diff:", previousPatch);
  }
  lines.push(
    "",
    "Answer with JSON only, no prose and no code fences:",
    '{"summary": "one line on what changed", "files": [{"path": "relative/path", "content": "the whole new content of the file"}], "delete": ["relative/path"]}',
    "Include a file only when its content changes. Keep every other file as it is. Tests live beside the code they test.",
  );
  return lines.join("\n");
}

/**
 * Whether a path the model gave is one the agent may write: relative,
 * inside the repository, and nowhere under .git in any letter case (a
 * file there would change git's own configuration).
 */
export function safePath(path) {
  if (typeof path !== "string" || !path || path.includes("\0") || path.includes("\\") || path.includes(":") || path.startsWith("/")) return false;
  const parts = path.split("/");
  return parts.every((s) => {
    if (!s || s === "." || s === "..") return false;
    // .git in any letter case, and the names a Windows or macOS file system
    // takes for it: trailing dots or spaces, and the 8.3 short name.
    const bare = s.replace(/[. ]+$/, "").toLowerCase();
    return bare !== ".git" && !/^git~\d+$/i.test(s);
  });
}

/** The JSON object in a model's answer, with or without code fences. */
export function parseAnswer(text) {
  const trimmed = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start < 0 || end < 0) throw new Error("the answer holds no JSON object");
  const answer = JSON.parse(trimmed.slice(start, end + 1));
  if (!Array.isArray(answer.files)) throw new Error("the answer has no files list");
  for (const f of answer.files) {
    if (typeof f.path !== "string" || typeof f.content !== "string") throw new Error("each file needs a path and a content string");
    if (!safePath(f.path)) throw new Error(`a path the agent may not write: ${f.path}`);
  }
  const removals = Array.isArray(answer.delete) ? answer.delete : [];
  for (const p of removals) if (!safePath(p)) throw new Error(`a path the agent may not delete: ${p}`);
  return { summary: String(answer.summary ?? ""), files: answer.files, delete: removals };
}

/** Refuse a path that passes through a symbolic link, which could point outside the repository. */
async function noLinkOnTheWay(repo, path) {
  const parts = path.split("/");
  for (let i = 1; i <= parts.length; i++) {
    let st;
    try { st = await lstat(join(repo, ...parts.slice(0, i))); } catch { return; }
    if (st.isSymbolicLink()) throw new Error(`${path} passes through a symbolic link; the agent writes real files only`);
  }
}

/** Refuse a path inside the gate project, when it lives in the repository: the hooks run from it. */
function outsideGate(repo, path) {
  const gateDir = relative(repo, here);
  if (!gateDir || gateDir.startsWith("..") || isAbsolute(gateDir)) return;
  if (path === gateDir || path.startsWith(`${gateDir}/`)) throw new Error(`${path} is inside the gate project at ${gateDir}; the agent does not change the gate`);
}

/** Write the answer into the working tree. */
export async function applyAnswer(repo, answer) {
  for (const f of [...answer.files.map((x) => x.path), ...answer.delete]) outsideGate(repo, f);
  for (const f of answer.files) {
    await noLinkOnTheWay(repo, f.path);
    await mkdir(dirname(join(repo, f.path)), { recursive: true });
    await writeFile(join(repo, f.path), f.content);
  }
  for (const p of answer.delete) { await noLinkOnTheWay(repo, p); await rm(join(repo, p), { force: true }); }
}

// -- the scripted drafter -----------------------------------------------------

const field = (prompt, name) => (prompt.match(new RegExp(`^${name}: (.*)$`, "m")) ?? [])[1] ?? "";
const shownFile = (prompt, path) => {
  const m = prompt.match(new RegExp(`^--- ${path.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")} ---\\n([\\s\\S]*?)\\n--- end of ${path.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")} ---$`, "m"));
  return m ? m[1] : null;
};

const VALIDATION = `function assertNumber(value, name) {
  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new TypeError(\`\${name} must be a finite number\`);
  }
}
`;

/**
 * The drafter used when no model is named. It knows the three sample tasks
 * for the demo repository and, for any other task, leaves a note in
 * NOTES.md, so the gate's path can be walked with nothing configured.
 */
export function scriptedDraft(prompt) {
  const title = field(prompt, "Task").toLowerCase();
  const revision = field(prompt, "Revision requested by the reviewer");
  const calc = shownFile(prompt, "lib/calc.mjs") ?? "";
  const tests = shownFile(prompt, "test/calc.test.mjs") ?? "";
  const readme = shownFile(prompt, "README.md") ?? "";
  const stamp = revision ? `// Revision: ${revision}\n` : "";
  const answer = { summary: "", files: [], delete: [] };
  if (title.includes("validat")) {
    const body = calc.includes("assertNumber") ? calc : calc.replace("export function add(a, b) {\n", `${VALIDATION}\nexport function add(a, b) {\n  assertNumber(a, "a");\n  assertNumber(b, "b");\n`);
    answer.summary = "add() refuses anything that is not a finite number";
    answer.files.push({ path: "lib/calc.mjs", content: stamp + body.replace(/^\/\/ Revision: .*\n/, "") });
    if (!tests.includes("rejects")) {
      answer.files.push({ path: "test/calc.test.mjs", content: tests + `
test("add rejects what is not a finite number", () => {
  assert.throws(() => add("2", 3), TypeError);
  assert.throws(() => add(2, Infinity), TypeError);
});
` });
    }
  } else if (title.includes("subtract")) {
    let body = calc;
    if (!body.includes("assertNumber")) body = body.replace("export function add(a, b) {\n", `${VALIDATION}\nexport function add(a, b) {\n`);
    if (!body.includes("export function subtract")) body += `
export function subtract(a, b) {
  assertNumber(a, "a");
  assertNumber(b, "b");
  return a - b;
}
`;
    answer.summary = "subtract(a, b) with the same validation as add";
    answer.files.push({ path: "lib/calc.mjs", content: stamp + body.replace(/^\/\/ Revision: .*\n/, "") });
    if (!tests.includes("subtract")) {
      answer.files.push({ path: "test/calc.test.mjs", content: tests.replace('import { add, multiply } from "../lib/calc.mjs";', 'import { add, multiply, subtract } from "../lib/calc.mjs";') + `
test("subtract subtracts", () => {
  assert.equal(subtract(5, 3), 2);
});
` });
    }
    if (!readme.includes("subtract")) answer.files.push({ path: "README.md", content: readme.replace("- `multiply(a, b)`\n", "- `multiply(a, b)`\n- `subtract(a, b)`\n") });
  } else if (title.includes("document")) {
    const names = [...calc.matchAll(/^export function (\w+)\(/gm)].map((m) => m[1]);
    const examples = names.map((n) => `### \`${n}(a, b)\`\n\n\`\`\`js\nimport { ${n} } from "./lib/calc.mjs";\n${n}(6, 3);\n\`\`\`\n`).join("\n");
    answer.summary = "README shows how to install and use every function";
    answer.files.push({ path: "README.md", content: `# calc\n\nA small calculator library used to show the CHAP code gate.\n${revision ? `\n<!-- Revision: ${revision} -->\n` : ""}\n## Install\n\n\`\`\`bash\nnpm install\nnpm test\n\`\`\`\n\n## Use\n\n${examples}` });
  } else {
    answer.summary = `Note on: ${field(prompt, "Task")}`;
    const notes = shownFile(prompt, "NOTES.md") ?? "# Notes\n";
    answer.files.push({ path: "NOTES.md", content: `${notes}\n- ${field(prompt, "Task")}: ${field(prompt, "Brief")}${revision ? ` (revision: ${revision})` : ""}\n` });
  }
  return JSON.stringify(answer);
}

// -- the loop -------------------------------------------------------------------

// A draft the agent made and has not submitted yet: the task's key and the
// patch the working tree held, kept in the repository's git directory, so a
// restarted agent knows the change in the working tree is its own.
const draftFile = async (repo) => join((await git(repo, ["rev-parse", "--absolute-git-dir"])).trim(), "chap-agent-draft.json");

async function keptDraft(repo) {
  try { return JSON.parse(await readFile(await draftFile(repo), "utf8")); } catch { return null; }
}

async function keepDraft(repo, key) {
  await writeFile(await draftFile(repo), JSON.stringify({ key, patch: await workingTreePatch(repo) }));
}

async function forgetDraft(repo) {
  await rm(await draftFile(repo), { force: true });
}

/** Whether the working tree holds the draft the agent kept for `key`. */
async function holdsDraft(repo, key) {
  const kept = await keptDraft(repo);
  return !!kept && kept.key === key && kept.patch === await workingTreePatch(repo);
}

/** The artefact for the change the working tree holds, as the agent proposes it. */
const artefactOf = (repo, provider, task) => describeChange(repo, { summary: task.title, drafted_by: "the built-in agent", model: modelName(provider.model_id), requested_by: "tasks.csv" });

/** Draft the task into the working tree and return the artefact, or null when nothing changed. */
async function draft(repo, provider, task, { revision = null, previousPatch = null, log } = {}) {
  const context = await contextFiles(repo, task);
  const { text } = await provider.complete(buildPrompt(task, context, { revision, previousPatch }));
  let answer;
  try { answer = parseAnswer(text); } catch (e) { log(`${task.key}: the model's answer could not be used (${e.message})`); return null; }
  await applyAnswer(repo, answer);
  await keepDraft(repo, task.key);
  return artefactOf(repo, provider, task);
}

/** Take back whatever the working tree holds beyond HEAD. */
async function discardWorkingTree(repo) {
  const patch = await workingTreePatch(repo);
  if (patch.trim() && (await patchApplies(repo, patch, { reverse: true }))) await applyToWorkingTree(repo, patch, { reverse: true });
  await forgetDraft(repo);
}

/**
 * One task, start to finish: its outcome is approve, override, reject, or
 * the state the task was left in. `item` keeps the attempt count.
 */
export async function handleTask({ gate, client, provider, repo, task, log, pollMs, signingKey = null, noSign = false }) {
  const base = await head(repo);
  const branch = await currentBranch(repo);
  const created = await client.call("task.create", {
    kind: "code_change", assignee: client.from, review_required: true, idempotency_key: task.key,
    input: { summary: task.title, brief: task.brief, repo: repo.split("/").pop(), branch, base, files: task.files, requested_by: "tasks.csv" },
  });
  const id = created.task_id;
  let view = await readTask(gate, id);
  let attempts = 0;
  for (;;) {
    const decision = lastDecision(view);
    if (view.state === "completed") {
      const committed = await commitsWithApproval(repo, id);
      if (committed.length) { log(`${task.key}: committed earlier as ${committed[0].slice(0, 12)}`); return decision?.kind ?? "approve"; }
      if ((view.output.base ?? null) !== (await head(repo))) { log(`${task.key}: approved against ${String(view.output.base).slice(0, 12)}, and ${branch} has moved on; nothing committed, propose it again`); return "stale"; }
      await discardWorkingTree(repo);
      if (!(await patchApplies(repo, view.output.patch))) { log(`${task.key}: the approved patch no longer applies to ${branch}; nothing committed`); return "stale"; }
      await applyToWorkingTree(repo, view.output.patch);
      const sha = await commitAll(repo, `${view.output.summary ?? task.title}\n`, { signingKey, noSign, env: gateEnv(gate) });
      log(`${task.key}: ${decision?.kind === "override" ? "approved with an edit" : "approved"} by ${decision?.reviewer}; committed as ${sha.slice(0, 12)} on ${branch}${signingKey ? ", signed" : ""}`);
      return decision?.kind ?? "approve";
    }
    if (view.state === "declined") {
      await discardWorkingTree(repo);
      log(`${task.key}: rejected by ${decision?.reviewer}${decision?.comment ? `: ${decision.comment}` : ""}; nothing committed`);
      return "reject";
    }
    if (view.state === "review_requested") {
      log(`${task.key}: waiting for the decision at ${gate.base}/`);
      view = await waitForDecision(gate, id, { pollMs });
      continue;
    }
    if (view.state !== "created" && view.state !== "in_progress") { log(`${task.key}: the task is ${view.state}; nothing more to do`); return view.state; }
    // created, or in_progress after a rejection that asked for a revision
    const revision = view.state === "in_progress" && decision?.kind === "reject" ? decision.comment ?? "no note" : null;
    const previousPatch = revision ? await workingTreePatch(repo) : null;
    if (++attempts > 3) { log(`${task.key}: no usable change after three attempts; the task stays open for a person`); return view.state; }
    // A draft made before a restart, and never submitted, is proposed as it stands.
    const resumed = await holdsDraft(repo, task.key);
    if (resumed) log(`${task.key}: the working tree holds the draft made before the restart; proposing it`);
    const artefact = resumed ? await artefactOf(repo, provider, task) : await draft(repo, provider, task, { revision, previousPatch, log });
    if (!artefact) { log(`${task.key}: the draft changed nothing; trying again`); continue; }
    // The review is addressed to the human members, so until enough have
    // joined for the rule the submission would be refused and the refusal
    // recorded, or the review could never close. The agent waits on
    // workspace.describe, a read, and says so once.
    const review = reviewRule(gate);
    let ready = await reviewersReady(client, review);
    if (!ready.ok) {
      log(`${task.key}: drafted, and waiting for reviewers to join (${review.rule} needs ${ready.need}, ${ready.have} so far). Open the desk at ${await deskLink(gate)} and the draft goes in then`);
      while (!(ready = await reviewersReady(client, review)).ok) await new Promise((r) => setTimeout(r, pollMs));
    }
    const r = await propose(client, artefact, { taskId: id, review });
    await forgetDraft(repo);
    log(`${task.key}: ${revision ? "revised" : "drafted"} with ${provider.model_id}, ${artefact.files.length} file${artefact.files.length === 1 ? "" : "s"}, ${r.state} as ${id}`);
    view = await readTask(gate, id);
  }
}

export async function run({ source, repo: repoPath, branch, once = false, pollMs = 2000, log = console.log, gateDir = here, keyPath, gate: given = null } = {}) {
  const gate = given ?? await loadGate(gateDir);
  const repo = await repoRoot(repoPath);
  if (!repo) throw new Error(`${repoPath} is not inside a git repository. Make one with: npm run demo-repo`);
  const client = await agentClient(gate, { keyPath });
  // A working tree with changes in it is one the agent left while a change
  // waited for review: carry on when it holds exactly the patch of one of
  // this agent's open changes, and refuse anything else.
  const dirty = await workingTreePatch(repo);
  if (dirty.trim() && (await keptDraft(repo))?.patch !== dirty) {
    const open = (await api(gate, "/api/tasks?kind=code_change&state=review_requested,in_progress,completed"))?.tasks ?? [];
    if (!open.some((t) => t.assignee === client.from && (t.artefact?.patch === dirty || t.output?.patch === dirty))) {
      throw new Error(`${repo} has uncommitted changes that are not a change waiting for review and not a draft of this agent's; commit, stash or remove them, or start the demo again with npm run demo -- --fresh`);
    }
  }
  const provider = makeProvider(scriptedDraft);
  const probe = await provider.probe();
  if (!probe.ok) throw new Error(probe.detail);
  branch ??= `agent/${new Date().toISOString().slice(0, 10)}`;
  try { await git(repo, ["rev-parse", "--verify", "--quiet", `refs/heads/${branch}`]); await git(repo, ["switch", "--quiet", branch]); }
  catch { await git(repo, ["switch", "--quiet", "-c", branch]); }
  const signing = await commitSigning(gate, repo, { keyPath });
  log(`agent ${client.from} on ${repo} (${branch}), drafting with ${probe.detail}; commits ${signing.describe}`);
  const done = new Set();
  const outcomes = {};
  for (;;) {
    for (const task of await readTasks(source)) {
      if (done.has(task.key)) continue;
      done.add(task.key);
      try {
        outcomes[task.key] = await handleTask({ gate, client, provider, repo, task, log, pollMs, signingKey: signing.key, noSign: signing.noSign });
      } catch (e) {
        log(`${task.key}: ${e instanceof Error ? e.message : String(e)}`);
        outcomes[task.key] = "error";
      }
    }
    if (once) return outcomes;
    await new Promise((r) => setTimeout(r, pollMs));
  }
}

export function parseArgs(argv) {
  const out = { source: join(here, "tasks.csv"), repo: join(here, "demo-repo"), branch: undefined, once: false, pollMs: 2000 };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--repo") out.repo = argv[++i];
    else if (a === "--branch") out.branch = argv[++i];
    else if (a === "--poll") out.pollMs = Number(argv[++i]);
    else if (a === "--once") out.once = true;
    else if (a.startsWith("-")) throw new Error(`Unknown option ${a}. --help lists the options.`);
    else out.source = resolve(a);
  }
  return out;
}

if (isMain(import.meta.url)) {
  if (wantsHelp()) console.log(usage(import.meta.url));
  else Promise.resolve().then(() => run(parseArgs(process.argv.slice(2)))).catch((e) => { console.error(e instanceof Error ? e.message : String(e)); process.exit(1); });
}
