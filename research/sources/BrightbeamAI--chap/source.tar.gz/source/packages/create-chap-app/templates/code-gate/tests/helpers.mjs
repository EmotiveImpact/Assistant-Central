// Shared by the tests: a gate in-process on an in-memory store, an agent key,
// reviewers who sign in the test as the desk would, and a demo repository.
// The decisions here are scripted because these are tests; in the project
// the decision is made in the desk.
import { execFile } from "node:child_process";
import { createHash, generateKeyPairSync, sign as cryptoSign } from "node:crypto";
import { mkdtemp, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { loadConfig, makeCoordinator, makeServer } from "@brightbeamai/chap-server";
import { canonicalize, generateSigner, thumbprint } from "@brightbeamai/chap-server/client";
import { generateKeyFile } from "@brightbeamai/chap-server/keys";
import { createDemoRepo } from "@brightbeamai/chap-code-gate/demo-repo";
import { agentClient, contentHash, reviewerClient } from "@brightbeamai/chap-code-gate/gate";

export const run = promisify(execFile);
// The enrolment code every gate in these tests takes, as the printed link
// carries it: a person's first join needs it.
process.env.CHAP_ENROLMENT_CODE ??= "TESTS-ENROL";

export const projectDir = fileURLToPath(new URL("..", import.meta.url));
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function until(read, timeoutMs = 10000) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const value = await read();
    if (value) return value;
    if (Date.now() > deadline) throw new Error("timed out waiting");
    await sleep(50);
  }
}

/**
 * A gate on a free port. `humans` are the reviewer URIs chap.config.json
 * names; `review` is its review rule; `extra` sets other configuration. Returns the server, the gate handle
 * the libraries take, an agent client with a key on disk, and `reviewer(uri)`
 * to make a signing reviewer who has joined.
 */
export async function startGate({ suffix = "", humans = null, review = null, extra = {} } = {}) {
  const config = await loadConfig(join(projectDir, "chap.config.json"));
  config.store = ":memory:";
  if (suffix) config.workspace = `${config.workspace}_${suffix}`;
  if (humans) config.humans = humans.map((uri) => ({ uri, display_name: uri, role: "reviewer" }));
  if (review) config.review = review;
  Object.assign(config, extra);
  const coord = await makeCoordinator(config);
  const server = await makeServer(config, coord);
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const gate = { dir: projectDir, config, url: `${base}/chap`, base };
  const keyDir = await mkdtemp(join(tmpdir(), "chap-keys-"));
  const { path: keyPath } = await generateKeyFile(config.agent.uri, keyDir);
  const agent = await agentClient(gate, { keyPath });
  const reviewer = async (uri) => {
    const c = reviewerClient(gate, uri, await generateSigner(uri), process.env.CHAP_ENROLMENT_CODE);
    await c.call("participant.join", { type: "human", role: "reviewer", jwks: { keys: [c.signer.publicJwk] } });
    return c;
  };
  const close = () => new Promise((r) => server.close(r));
  // The hooks run in their own process and read the configuration from
  // CHAP_CONFIG, so each gate here writes its own, with the port it took.
  const configPath = join(keyDir, "chap.config.json");
  await writeFile(configPath, JSON.stringify({ ...config, port: server.address().port }, null, 2));
  gate.configPath = configPath;
  return { config, coord, server, base, gate, keyPath, configPath, agent, reviewer, close };
}

/**
 * A passkey as the desk at `origin` would make and use one: a P-256 key, its
 * JWK as the desk registers it, and a signer whose every signature is the
 * assertion an authenticator gives once the person is verified, its
 * challenge the SHA-256 of the envelope's canonical form without sig.
 */
export async function passkeySigner(uri, origin) {
  const { privateKey, publicKey } = generateKeyPairSync("ec", { namedCurve: "P-256" });
  const { x, y } = publicKey.export({ format: "jwk" });
  const rpId = new URL(origin).hostname;
  const publicJwk = { kty: "EC", crv: "P-256", x, y, alg: "ES256", kid: await thumbprint({ kty: "EC", crv: "P-256", x, y }), use: "sig", webauthn: { rp_id: rpId, origins: [origin] } };
  const sha256 = (b) => createHash("sha256").update(b).digest();
  let counter = 0;
  return {
    scheme: "webauthn", uri, kid: publicJwk.kid, publicJwk,
    async sign(envelope) {
      const { sig: _old, ...unsigned } = envelope;
      const authData = Buffer.alloc(37);
      sha256(rpId).copy(authData, 0);
      authData[32] = 0x05;
      authData.writeUInt32BE(++counter, 33);
      const clientData = Buffer.from(JSON.stringify({ type: "webauthn.get", challenge: sha256(canonicalize(unsigned)).toString("base64url"), origin, crossOrigin: false }));
      const signature = cryptoSign("sha256", Buffer.concat([authData, sha256(clientData)]), { key: privateKey, dsaEncoding: "der" });
      return { ...unsigned, sig: `webauthn:${publicJwk.kid}:${[authData, clientData, signature].map((b) => b.toString("base64url")).join(".")}` };
    },
  };
}

/** The hooks read the gate from the environment; point them at this one. */
export function hookEnv(g) {
  return { ...process.env, CHAP_URL: g.gate.url, CHAP_AGENT_KEY: g.keyPath, CHAP_CONFIG: g.configPath, CHAP_NO_BROWSER: "1", CHAP_AUTOSTART: "0" };
}

export async function demoRepo({ hooks = true } = {}) {
  return createDemoRepo(await mkdtemp(join(tmpdir(), "chap-repo-")), { log: () => {}, hooks, gateDir: projectDir });
}

export async function appendTo(repo, path, text) {
  await writeFile(join(repo, path), (await readFile(join(repo, path), "utf8").catch(() => "")) + text);
}

/** Open reviews for a reviewer, from the read API. */
export async function reviewsFor(g, who) {
  return (await (await fetch(`${g.base}/api/reviews?reviewer=${encodeURIComponent(who.from)}`)).json()).reviews;
}

/**
 * A decision as the desk sends it: with the digest of the artefact shown and
 * the digest of the submission that opened the round. `round` names another
 * submission, for a test that mixes rounds.
 */
export async function decide(who, method, review, extra = {}) {
  const round = review.submission?.envelope ? await contentHash(review.submission.envelope) : undefined;
  return who.call(method, { task_id: review.task_id, approved_artefact_digest: await contentHash(review.artefact), ...(round ? { round } : {}), ...extra });
}

/** git commit -am in a repository, through its hooks, with the gate in the environment. */
export function commit(g, repo, message, env = {}) {
  return run("git", ["commit", "-q", "-am", message], { cwd: repo, env: { ...hookEnv(g), ...env } });
}

export async function git_(repo, args, input) {
  const p = run("git", args, { cwd: repo });
  if (input !== undefined) p.child.stdin.end(input);
  return (await p).stdout;
}
