/**
 * deliberation/1.0 profile (profiles/deliberation.md).
 *
 * Methods:
 *   - deliberate.open
 *   - deliberate.comment
 *   - deliberate.vote
 *   - deliberate.close
 *
 * Rules: any_one_approves | all_approve | quorum:N |
 *        weighted_vote:T | weighted_vote_with_veto:T
 *
 * Error codes (spec S5):
 *   -32030 voter not in participant list
 *   -32031 already voted
 *   -32032 closed or lapsed
 *   -32033 unknown rule
 */
import type { Coordinator } from "../coordinator.js";
import { E, rpcError } from "../jsonrpc.js";
import { paramsError } from "../params.js";
import type { Deliberation } from "../types.js";

// Names a supplied id cannot take: JavaScript gives them special meaning as
// object keys, and the patch engine refuses them as path segments too.
const RESERVED_IDS = new Set(["__proto__", "constructor", "prototype"]);

// A rule's argument is read by these patterns alone, so both references read
// the same number from it: parseFloat and Python's float() each take forms
// the other refuses, such as "1.5x", "1_0" and "inf".
const QUORUM_ARG = /^[0-9]+$/;
const THRESHOLD_ARG = /^[0-9]+(\.[0-9]+)?$/;

function parseRule(rule: string): { kind: string; params: Record<string, number> } {
  const colon = rule.indexOf(":");
  if (colon >= 0) {
    const kind = rule.slice(0, colon);
    const arg = rule.slice(colon + 1);
    if (kind === "quorum" && QUORUM_ARG.test(arg)) return { kind, params: { n: parseInt(arg, 10) } };
    if ((kind === "weighted_vote" || kind === "weighted_vote_with_veto") && THRESHOLD_ARG.test(arg)) {
      return { kind, params: { threshold: parseFloat(arg) } };
    }
  }
  if (rule === "any_one_approves" || rule === "all_approve") return { kind: rule, params: {} };
  throw new Error(`Unknown rule: ${rule}`);
}

function computeOutcome(delib: Deliberation): Deliberation["outcome"] {
  const parsed = parseRule(delib.rule);
  const yea = delib.votes.filter(v => v.vote === "yea");
  const nay = delib.votes.filter(v => v.vote === "nay");
  const vetoes = delib.votes.filter(v => v.veto_invoked && (delib.veto ?? {})[v.voter]);
  const weights = delib.weights ?? {};

  const weighted = (vs: typeof yea) =>
    vs.reduce((s, v) => s + (weights[v.voter] ?? 1.0), 0);

  if (parsed.kind === "any_one_approves") {
    return {
      outcome: yea.length >= 1 ? "approved" : "rejected",
      rule: delib.rule,
      tally: { yea: yea.length, nay: nay.length },
      vetoes: vetoes.map(v => v.voter),
    };
  }
  if (parsed.kind === "all_approve") {
    const passed = yea.length === delib.participants.length && nay.length === 0;
    return {
      outcome: passed ? "approved" : "rejected",
      rule: delib.rule,
      tally: { yea: yea.length, nay: nay.length },
      vetoes: vetoes.map(v => v.voter),
    };
  }
  if (parsed.kind === "quorum") {
    const n = parsed.params.n;
    const cast = yea.length + nay.length;
    if (cast < n) {
      return {
        outcome: "rejected", reason: "quorum not met", rule: delib.rule,
        tally: { yea: yea.length, nay: nay.length }, vetoes: [],
      };
    }
    return {
      outcome: yea.length > nay.length ? "approved" : "rejected",
      rule: delib.rule,
      tally: { yea: yea.length, nay: nay.length },
      vetoes: [],
    };
  }
  if (parsed.kind === "weighted_vote") {
    const yeaW = weighted(yea), nayW = weighted(nay);
    return {
      outcome: yeaW >= parsed.params.threshold ? "approved" : "rejected",
      rule: delib.rule,
      tally: { yea: yeaW, nay: nayW }, vetoes: [],
    };
  }
  if (parsed.kind === "weighted_vote_with_veto") {
    if (vetoes.length) {
      return {
        outcome: "rejected", rule: delib.rule,
        tally: { yea: 0, nay: 0 },
        vetoes: vetoes.map(v => v.voter),
      };
    }
    const yeaW = weighted(yea), nayW = weighted(nay);
    return {
      outcome: yeaW >= parsed.params.threshold ? "approved" : "rejected",
      rule: delib.rule,
      tally: { yea: yeaW, nay: nayW }, vetoes: [],
    };
  }
  return { outcome: "error", rule: delib.rule, reason: `unsupported rule ${parsed.kind}` };
}

export function registerDeliberation(coord: Coordinator): void {
  coord.handlers.set("deliberate.open", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    for (const f of ["from", "rule"]) {
      if (!(f in p)) return { error: rpcError(E.PARAMS, `Missing field: ${f}`) };
    }
    for (const name of ["to", "participants"]) {
      const v = p[name];
      if (v != null && typeof v !== "string" && !(Array.isArray(v) && v.every((x) => typeof x === "string"))) {
        return { error: rpcError(E.PARAMS, `${name} must be a string or a list of strings`) };
      }
    }
    if (typeof p.rule !== "string") return { error: rpcError(E.PARAMS, "rule must be a string") };
    const bad = paramsError(p, [["weights", "object"], ["veto", "object"]]);
    if (bad) return bad;
    // Weights are summed and vetoes read as true or false when the vote is
    // counted, so they are checked when it opens.
    const weights = (p.weights ?? {}) as Record<string, unknown>;
    if (!Object.values(weights).every((w) => typeof w === "number" && Number.isInteger(w))) {
      return { error: rpcError(E.PARAMS, "weights must map participants to integers") };
    }
    const veto = (p.veto ?? {}) as Record<string, unknown>;
    if (!Object.values(veto).every((v) => typeof v === "boolean")) {
      return { error: rpcError(E.PARAMS, "veto must map participants to booleans") };
    }
    const to = p.to ?? p.participants;
    const participants: string[] = Array.isArray(to) ? (to as string[]) : typeof to === "string" ? [to] : [];
    if (!participants.length) {
      return { error: rpcError(E.PARAMS, "deliberate.open needs 'to' (participants list)") };
    }
    try { parseRule(p.rule as string); }
    catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      return { error: rpcError(E.DELIB_UNKNOWN_RULE, msg) };
    }
    // A supplied id names a new deliberation. One already in use was stored
    // over the existing object, which reopened, reset or replaced it.
    const suppliedDeliberationId = p.deliberation_id;
    if (suppliedDeliberationId !== undefined && suppliedDeliberationId !== null && suppliedDeliberationId !== "") {
      if (typeof suppliedDeliberationId !== "string") {
        return { error: rpcError(E.PARAMS, "deliberation_id must be a string") };
      }
      // The id is a key in the stored state, and a JavaScript object given
      // the key __proto__ drops it, so the object would be lost on a restart.
      if (RESERVED_IDS.has(suppliedDeliberationId)) {
        return { error: rpcError(E.PARAMS, `deliberation_id cannot be ${JSON.stringify(suppliedDeliberationId)}`) };
      }
      if (ws.deliberations.has(suppliedDeliberationId)) {
        return { error: rpcError(E.PARAMS, `deliberation_id already in use: ${suppliedDeliberationId}`) };
      }
    }
    const id = (p.deliberation_id as string) || coord.ids.deliberationId();
    const delib: Deliberation = {
      id,
      task_id: p.task_id as string | undefined,
      opener: p.from as string,
      participants,
      rule: p.rule as string,
      question: p.question as string | undefined,
      weights: p.weights as Deliberation["weights"],
      veto: p.veto as Deliberation["veto"],
      deadline: p.deadline as string | undefined,
      state: "open",
      comments: [],
      votes: [],
      opened_at: coord.now(),
    };
    ws.deliberations.set(id, delib);
    return { result: { deliberation_id: id, state: "open" } };
  });

  coord.handlers.set("deliberate.comment", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const delib = ws.deliberations.get(p.deliberation_id as string);
    if (!delib) return { error: rpcError(E.PARAMS, "Unknown deliberation") };
    if (delib.state !== "open") {
      return { error: rpcError(E.DELIB_CLOSED_OR_LAPSED, "Deliberation not open") };
    }
    const bad = paramsError(p, [["comment", "string"], ["text", "string"]]);
    if (bad) return bad;
    delib.comments.push({
      ts: coord.now(),
      from: p.from as string,
      text: (p.comment as string) || (p.text as string) || "",
    });
    return { result: { accepted: true } };
  });

  coord.handlers.set("deliberate.vote", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const delib = ws.deliberations.get(p.deliberation_id as string);
    if (!delib) return { error: rpcError(E.PARAMS, "Unknown deliberation") };
    if (delib.state !== "open") {
      return { error: rpcError(E.DELIB_CLOSED_OR_LAPSED, "Deliberation not open") };
    }
    for (const f of ["from", "vote"]) {
      if (!(f in p)) return { error: rpcError(E.PARAMS, `Missing field: ${f}`) };
    }
    const v = p.vote as string;
    if (v !== "yea" && v !== "nay" && v !== "abstain") {
      return { error: rpcError(E.PARAMS, "vote must be yea/nay/abstain") };
    }
    const bad = paramsError(p, [["veto_invoked", "boolean"]]);
    if (bad) return bad;
    const voter = p.from as string;
    if (!delib.participants.includes(voter)) {
      return { error: rpcError(E.DELIB_VOTER_NOT_IN_LIST,
        `Voter ${voter} not in participant list`) };
    }
    if (delib.votes.some(x => x.voter === voter)) {
      return { error: rpcError(E.DELIB_ALREADY_VOTED, `Voter ${voter} has already voted`) };
    }
    delib.votes.push({
      ts: coord.now(),
      voter,
      vote: v as "yea" | "nay" | "abstain",
      weight: p.weight as number | undefined,
      comment: p.comment as string | undefined,
      veto_invoked: !!p.veto_invoked,
    });
    return { result: { recorded: true } };
  });

  coord.handlers.set("deliberate.close", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const delib = ws.deliberations.get(p.deliberation_id as string);
    if (!delib) return { error: rpcError(E.PARAMS, "Unknown deliberation") };
    if (delib.state === "closed") return { result: delib.outcome! };
    delib.state = "closed";
    delib.outcome = computeOutcome(delib);
    return { result: delib.outcome };
  });
}
