/**
 * security-signed/1.0 profile (profiles/security-signed.md).
 *
 * Top-level `sig` field on every envelope: ed25519:<kid>:<base64>.
 * Verification happens at dispatch (see Coordinator.verifySignature).
 *
 * Methods:
 *   - participant.rotate_key
 *   - participant.revoke_key
 */
import type { Coordinator } from "../coordinator.js";
import { E, rpcError } from "../jsonrpc.js";
import { paramsError } from "../params.js";
import type { KeyRecord } from "../types.js";

export function registerSecuritySigned(coord: Coordinator): void {
  coord.handlers.set("participant.rotate_key", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    for (const f of ["from", "old_kid", "new_jwk"]) {
      if (!(f in p)) return { error: rpcError(E.PARAMS, `Missing field: ${f}`) };
    }
    // Both are written into the refusals below, where null reads one way in
    // each language.
    for (const f of ["from", "old_kid"]) {
      if (typeof p[f] !== "string") return { error: rpcError(E.PARAMS, `${f} must be a string`) };
    }
    const member = ws.members.get(p.from as string);
    if (!member) return { error: rpcError(E.SIG_KEY_NOT_FOUND, `Unknown participant: ${p.from}`) };
    const oldKid = p.old_kid as string;
    const oldKey = member.keys.find(k => k.kid === oldKid);
    if (!oldKey) return { error: rpcError(E.SIG_KEY_NOT_FOUND, `No key ${oldKid} for ${p.from}`) };
    if (oldKey.revoked_at) return { error: rpcError(E.SIG_KEY_REVOKED, `Key ${oldKid} is revoked`) };

    const newJwk = p.new_jwk as Record<string, unknown>;
    if (!newJwk || typeof newJwk.kid !== "string") {
      return { error: rpcError(E.PARAMS, "new_jwk must include kid") };
    }
    // Keys are found by kid, so a new key under a kid the member holds would
    // be closed with the old one, or shadowed by it.
    if (member.keys.some((k) => k.kid === newJwk.kid)) {
      return { error: rpcError(E.PARAMS, `${p.from} already holds a key ${newJwk.kid}; a new key takes a kid of its own`) };
    }
    const now = coord.now();
    oldKey.valid_until = now;
    member.keys.push({
      jwk: newJwk as unknown as KeyRecord["jwk"],
      kid: newJwk.kid as string,
      valid_from: now,
    });
    return { result: { rotated: true, old_kid: oldKid, new_kid: newJwk.kid, valid_from: now } };
  });

  coord.handlers.set("participant.revoke_key", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    for (const f of ["target_uri", "kid"]) {
      if (!(f in p)) return { error: rpcError(E.PARAMS, `Missing field: ${f}`) };
    }
    // Both are written into the refusals below, where null reads one way in
    // each language.
    for (const f of ["target_uri", "kid"]) {
      if (typeof p[f] !== "string") return { error: rpcError(E.PARAMS, `${f} must be a string`) };
    }
    const bad = paramsError(p, [["from", "string"], ["reason", "string"]]);
    if (bad) return bad;
    const sender = p.from as string | undefined;
    if (sender !== p.target_uri) {
      const caller = sender ? ws.members.get(sender) : undefined;
      if (!caller || caller.role !== "admin") {
        return { error: rpcError(E.NOT_AUTHORISED,
          "Revoking another member's key requires the admin role") };
      }
    }
    const member = ws.members.get(p.target_uri as string);
    if (!member) return { error: rpcError(E.SIG_KEY_NOT_FOUND, `Unknown target: ${p.target_uri}`) };
    const key = member.keys.find(k => k.kid === p.kid);
    if (!key) return { error: rpcError(E.SIG_KEY_NOT_FOUND, `No key ${p.kid} for target`) };
    const now = coord.now();
    key.revoked_at = now;
    key.revoked_reason = (p.reason as string) || "unspecified";
    return { result: { revoked: true, kid: key.kid, revoked_at: now, reason: key.revoked_reason } };
  });
}
