/**
 * whisper/1.0 profile (profiles/whisper.md).
 *
 * Methods:
 *   - whisper.ask     -> pose a deadline-bound question with options + default
 *   - whisper.answer  -> answer a whisper
 *
 * Lapse handling: coordinator.checkWhisperLapses(workspaceId, now?) is
 * registered on the Coordinator instance for deployments to call from a
 * scheduler.
 *
 * Error codes (per spec S6):
 *   -32020 WHISPER_ALREADY_ANSWERED
 *   -32021 WHISPER_LAPSED
 *   -32022 WHISPER_OPTION_NOT_IN_SET
 */
import type { Coordinator } from "../coordinator.js";
import { canonicalize } from "../canonical.js";
import { E, rpcError } from "../jsonrpc.js";
import { paramsError } from "../params.js";
import { rawValues } from "../tracked.js";
import type { WhisperPrompt, Envelope } from "../types.js";

// Names a supplied id cannot take: JavaScript gives them special meaning as
// object keys, and the patch engine refuses them as path segments too.
const RESERVED_IDS = new Set(["__proto__", "constructor", "prototype"]);

function parseIso(ts: string): number { return new Date(ts).getTime(); }

/**
 * Whether an answer field holds anything, read as Python reads a value's
 * truth, so both references agree that an empty answer is no answer.
 */
function present(v: unknown): boolean {
  if (v === undefined || v === null || v === false || v === 0 || v === "") return false;
  if (Array.isArray(v)) return v.length > 0;
  if (typeof v === "object") return Object.keys(v as object).length > 0;
  return true;
}

export function registerWhisper(coord: Coordinator): void {
  coord.handlers.set("whisper.ask", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    for (const f of ["from", "to", "task_id", "question", "deadline_ms", "default_if_lapsed"]) {
      if (!(f in p)) return { error: rpcError(E.PARAMS, `Missing field: ${f}`) };
    }
    if (!ws.tasks.has(p.task_id as string)) {
      return { error: rpcError(E.PARAMS, "Unknown task") };
    }
    const bad = paramsError(p, [["options", "list"], ["urgency", "string"]]);
    if (bad) return bad;
    // The deadline is required, and a number of milliseconds.
    if (typeof p.deadline_ms !== "number" || !Number.isInteger(p.deadline_ms)) {
      return { error: rpcError(E.PARAMS, "deadline_ms must be an integer") };
    }
    const to = p.to;
    const askee: string[] = Array.isArray(to) ? (to as string[]) : [to as string];
    // A supplied id names a new whisper. One already in use was stored
    // over the existing object, which reopened, reset or replaced it.
    const suppliedWhisperId = p.whisper_id;
    if (suppliedWhisperId !== undefined && suppliedWhisperId !== null && suppliedWhisperId !== "") {
      if (typeof suppliedWhisperId !== "string") {
        return { error: rpcError(E.PARAMS, "whisper_id must be a string") };
      }
      // The id is a key in the stored state, and a JavaScript object given
      // the key __proto__ drops it, so the object would be lost on a restart.
      if (RESERVED_IDS.has(suppliedWhisperId)) {
        return { error: rpcError(E.PARAMS, `whisper_id cannot be ${JSON.stringify(suppliedWhisperId)}`) };
      }
      if (ws.whispers.has(suppliedWhisperId)) {
        return { error: rpcError(E.PARAMS, `whisper_id already in use: ${suppliedWhisperId}`) };
      }
    }
    const id = (p.whisper_id as string) || coord.ids.artefactId();
    const prompt: WhisperPrompt = {
      id,
      task_id: p.task_id as string,
      asker: p.from as string,
      askee,
      question: p.question as string,
      options: p.options as WhisperPrompt["options"],
      asked_at: coord.now(),
      deadline_ms: Number(p.deadline_ms),
      default_if_lapsed: p.default_if_lapsed,
      urgency: (p.urgency as WhisperPrompt["urgency"]) || "low",
      state: "pending",
    };
    ws.whispers.set(id, prompt);
    return { result: { whisper_id: id, deadline_ms: prompt.deadline_ms } };
  });

  coord.handlers.set("whisper.answer", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    for (const f of ["from", "whisper_id"]) {
      if (!(f in p)) return { error: rpcError(E.PARAMS, `Missing field: ${f}`) };
    }
    const prompt = ws.whispers.get(p.whisper_id as string);
    if (!prompt) return { error: rpcError(E.PARAMS, "Unknown whisper id") };
    // Only a participant the whisper was addressed to may answer it. A
    // broadcast scope (workspace:/group:) is satisfied by any member; the
    // coordinator does not model group membership (see SPECIFICATION.md).
    const answerer = p.from as string;
    const broadcast = prompt.askee.some((a) => typeof a === "string" && (a.startsWith("workspace:") || a.startsWith("group:")));
    if (broadcast) {
      if (!ws.members.has(answerer)) {
        return { error: rpcError(E.NOT_AUTHORISED, `Not a workspace member: ${answerer}`) };
      }
    } else if (!prompt.askee.includes(answerer)) {
      return { error: rpcError(E.NOT_AUTHORISED, `Whisper was not addressed to ${answerer}`) };
    }
    if (prompt.state === "answered") {
      return { error: rpcError(E.WHISPER_ALREADY_ANSWERED, "Whisper already answered") };
    }
    if (prompt.state === "lapsed") {
      return { error: rpcError(E.WHISPER_LAPSED, "Whisper already lapsed") };
    }

    // A null option is no option, and an empty answer no answer, as in Python.
    const answerOption = p.answer_option as string | undefined;
    const hasOption = answerOption !== undefined && answerOption !== null;
    const answerText = (present(p.answer) ? p.answer : p.answer_text) as string | undefined;
    if (prompt.options && prompt.options.length) {
      if (!hasOption) {
        return { error: rpcError(E.PARAMS, "answer_option is required when options are defined") };
      }
      // An option that is not an object offers no id, as in Python.
      const valid = new Set(prompt.options
        .filter((o) => o !== null && typeof o === "object" && !Array.isArray(o))
        .map((o) => o.id));
      if (!valid.has(answerOption)) {
        return { error: rpcError(E.WHISPER_OPTION_NOT_IN_SET,
          `Answer option ${canonicalize(answerOption as never).toString("utf-8")} not in option set`) };
      }
    } else if (!present(answerText) && !hasOption) {
      return { error: rpcError(E.PARAMS, "answer or answer_option required") };
    }

    prompt.state = "answered";
    prompt.answered_at = coord.now();
    prompt.answered_by = p.from as string;
    prompt.answer_option = answerOption;
    prompt.answer_text = answerText;
    prompt.comment = p.comment as string | undefined;
    return { result: { answered: true, whisper_id: prompt.id, task_id: prompt.task_id } };
  });

  // Expose the lapse-check function on the coordinator instance. A check runs
  // outside any call, under the rules a call keeps: it waits for a held
  // workspace, and a lapse whose write fails is undone and reported to nobody.
  coord.checkWhisperLapses = (workspaceId: string, now?: string): Envelope[] =>
    coord.outsideCall(workspaceId, () => lapse(workspaceId, now));

  function lapse(workspaceId: string, now?: string): Envelope[] {
    const ws = coord.workspaces.get(workspaceId);
    if (!ws) return [];
    const cutoff = parseIso(now ?? coord.now());
    const emitted: Envelope[] = [];
    for (const prompt of rawValues(ws.whispers)) {
      if (prompt.state !== "pending") continue;
      const asked = parseIso(prompt.asked_at);
      const deadline = asked + prompt.deadline_ms;
      if (cutoff < deadline) continue;
      prompt.state = "lapsed";
      prompt.default_applied = prompt.default_if_lapsed;
      // The prompts are read without being recorded, so each that lapses is
      // set again to be written.
      ws.whispers.set(prompt.id, prompt);
      const notify: Envelope = {
        jsonrpc: "2.0",
        method: "notify.message",
        params: {
          workspace: ws.id,
          from: "service:coordinator",
          to: [prompt.asker, ...prompt.askee],
          ts: coord.now(),
          kind: "whisper_lapsed",
          whisper_id: prompt.id,
          // Carry the task so a task-filtered audit.read surfaces the
          // lapse. A lapsed whisper applies its default with no human
          // input, so it is the case most in need of being visible on
          // the task's thread.
          task_id: prompt.task_id,
          default_applied: prompt.default_if_lapsed,
        },
      };
      coord.recordAudit(ws, notify);
      emitted.push(notify);
    }
    return emitted;
  }
}
