/**
 * control/1.0 profile (profiles/control.md).
 *
 * Methods:
 *   - control.pause / control.resume   (scope: task|participant|workspace)
 *   - control.cancel
 *   - control.snapshot                  (returns art_... id)
 *   - control.rollback                  (to_snapshot_artefact_id + what_to_restore)
 *   - control.supersede                 (creates successor in one shot)
 *   - control.set_mode_ceiling
 */
import type { Coordinator } from "../coordinator.js";
import { E, rpcError } from "../jsonrpc.js";
import { paramsError } from "../params.js";
import { contentHash } from "../canonical.js";
import { rawValues } from "../tracked.js";
import { modeLE } from "../types.js";
import { openRequiredReviewAuthors, successorAuthors } from "../coordinator.js";
import type { Mode, SnapshotArtefact, Task, TaskState } from "../types.js";

const VALID_MODES = new Set<Mode>(["shadow", "trial", "production"]);
const VALID_SCOPES = new Set(["task", "participant", "workspace"]);
const SCOPE_ERROR = "scope must be task, participant or workspace";

export function registerControl(coord: Coordinator): void {
  coord.handlers.set("control.pause", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const bad = paramsError(p, [
      ["scope", "string"], ["participant_uri", "string"], ["uri", "string"], ["in_flight_policy", "string"],
    ]);
    if (bad) return bad;
    const scope = (p.scope as string) || "task";
    if (!VALID_SCOPES.has(scope)) {
      return { error: rpcError(E.PARAMS, SCOPE_ERROR) };
    }
    if (scope === "task") {
      const task = ws.tasks.get(p.task_id as string);
      if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
      if (task.state === "completed" || task.state === "declined" || task.state === "cancelled" || task.state === "superseded") {
        return { error: rpcError(E.CONTROL_NOT_AUTHORISED, `Cannot pause ${task.state} task`) };
      }
      task.paused = true;
      const prior = task.state;
      if (prior !== "paused") task.paused_from = prior;
      task.state = "paused";
      task.updated_at = coord.now();
      task.history.push({ ts: task.updated_at, from: p.from as string, state: "paused", note: `was ${prior}` });
      return { result: { scope: "task", task_id: task.id, state: "paused" } };
    }
    if (scope === "participant") {
      const uri = (p.participant_uri as string) || (p.uri as string);
      if (!uri) return { error: rpcError(E.PARAMS, "participant_uri is required") };
      if (!ws.members.has(uri)) return { error: rpcError(E.PARAMS, `Unknown participant: ${uri}`) };
      ws.members.get(uri)!.paused = true;
      return { result: {
        scope: "participant", participant_uri: uri, paused: true,
        in_flight_policy: (p.in_flight_policy as string) || "allow_to_complete",
      }};
    }
    // workspace
    ws.state = "paused";
    return { result: { scope: "workspace", workspace: ws.id, state: "paused" } };
  });

  coord.handlers.set("control.resume", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const bad = paramsError(p, [["scope", "string"], ["participant_uri", "string"], ["uri", "string"]]);
    if (bad) return bad;
    const scope = (p.scope as string) || "task";
    if (!VALID_SCOPES.has(scope)) {
      return { error: rpcError(E.PARAMS, SCOPE_ERROR) };
    }
    if (scope === "task") {
      const task = ws.tasks.get(p.task_id as string);
      if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
      if (task.state !== "paused") {
        return { error: rpcError(E.CONTROL_NOT_AUTHORISED, `Cannot resume ${task.state} task`) };
      }
      task.paused = false;
      const restored: TaskState = task.paused_from ?? "in_progress";
      task.paused_from = undefined;
      task.state = restored;
      task.updated_at = coord.now();
      task.history.push({ ts: task.updated_at, from: p.from as string, state: restored });
      return { result: { scope: "task", task_id: task.id, state: restored } };
    }
    if (scope === "participant") {
      const uri = (p.participant_uri as string) || (p.uri as string);
      if (!uri) return { error: rpcError(E.PARAMS, "participant_uri is required") };
      if (!ws.members.has(uri)) return { error: rpcError(E.PARAMS, `Unknown participant: ${uri}`) };
      // A pause holds until someone else lifts it: the paused member lifting
      // its own would make the pause its to keep or drop.
      if (uri === p.from) return { error: rpcError(E.NOT_AUTHORISED, "A paused participant does not lift its own pause") };
      ws.members.get(uri)!.paused = false;
      return { result: { scope: "participant", participant_uri: uri, paused: false } };
    }
    ws.state = "active";
    return { result: { scope: "workspace", workspace: ws.id, state: "active" } };
  });

  coord.handlers.set("control.cancel", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const task = ws.tasks.get(p.task_id as string);
    if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
    if (task.state === "completed" || task.state === "declined" || task.state === "cancelled" || task.state === "superseded") {
      return { error: rpcError(E.CONTROL_NOT_AUTHORISED, `Cannot cancel ${task.state} task`) };
    }
    // A review a task requires ends with a decision. Its authors pulling the
    // emergency brake on it would end it with none; other members still can.
    if (openRequiredReviewAuthors(ws, task).includes(p.from as string)) {
      return { error: rpcError(E.NOT_AUTHORISED,
        "The authors of the work under review cannot end its review without a decision") };
    }
    task.state = "cancelled";
    task.updated_at = coord.now();
    task.history.push({ ts: task.updated_at, from: p.from as string, state: "cancelled", note: p.reason as string | undefined });
    return { result: { state: "cancelled" } };
  });

  coord.handlers.set("control.snapshot", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const bad = paramsError(p, [["include", "strings"], ["label", "string"]]);
    if (bad) return bad;
    if (Array.isArray(p.include) && p.include.length === 0) {
      return { error: rpcError(E.PARAMS, "include must not be empty") };
    }
    const include: string[] = Array.isArray(p.include)
      ? [...p.include as string[]]
      : ["members", "open_tasks", "mode_ceiling"];
    const state: Record<string, unknown> = {};
    if (include.includes("members")) {
      // Read-only projections: read without recording a change.
      const members = Array.from(rawValues(ws.members)).map(m => ({
        uri: m.uri, type: m.type,
        ...(m.role ? { role: m.role } : {}),
        ...(m.scopes?.length ? { scopes: m.scopes } : {}),
      }));
      if (members.length) state.members = members;
    }
    if (include.includes("open_tasks")) {
      const tasks = Array.from(rawValues(ws.tasks))
        .filter(t => t.state !== "completed" && t.state !== "declined" && t.state !== "cancelled" && t.state !== "superseded")
        .map(t => ({ id: t.id, kind: t.kind, state: t.state,
          ...(t.assignee ? { assignee: t.assignee } : {}),
        }));
      if (tasks.length) state.open_tasks = tasks;
    }
    if (include.includes("mode_ceiling")) state.mode_ceiling = ws.mode_ceiling;
    if (include.includes("policy") && ws.routing_policy_uri) state.routing_policy_uri = ws.routing_policy_uri;
    if (include.includes("audit") || include.includes("all")) state.audit_seq = ws.audit.length;

    // Store the same canonical artefact that is emitted on the wire. Copies
    // belong to this explicit capture boundary, never Coordinator.snapshot().
    const content: SnapshotArtefact["content"] = structuredClone({
      workspace: ws.id,
      audit_seq: ws.audit.length,
      include,
      state,
      ...(p.label ? { label: p.label as string } : {}),
    });
    const snapId = coord.ids.artefactId();
    const snap: SnapshotArtefact = {
      id: snapId,
      kind: "snapshot",
      produced_at: coord.now(),
      produced_by: p.from as string,
      content_hash: contentHash(content),
      content,
    };
    ws.snapshots.set(snapId, snap);
    return {
      result: {
        snapshot_artefact_id: snapId,
        audit_seq: snap.content.audit_seq,
        artefact: structuredClone(snap),
      },
    };
  });

  coord.handlers.set("control.rollback", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const bad = paramsError(p, [
      ["to_snapshot_artefact_id", "string"], ["snapshot_artefact_id", "string"], ["snapshot_id", "string"],
      ["what_to_restore", "strings"], ["reason", "string"],
    ]);
    if (bad) return bad;
    const snapId = (p.to_snapshot_artefact_id as string)
                 || (p.snapshot_artefact_id as string)
                 || (p.snapshot_id as string);
    if (!snapId) return { error: rpcError(E.PARAMS, "to_snapshot_artefact_id is required") };
    const snap = ws.snapshots.get(snapId);
    if (!snap) return { error: rpcError(E.CONTROL_SNAPSHOT_NOT_FOUND, `Unknown snapshot: ${snapId}`) };
    if (Array.isArray(p.what_to_restore) && p.what_to_restore.length === 0) {
      return { error: rpcError(E.PARAMS, "what_to_restore must not be empty") };
    }
    const what: string[] = (p.what_to_restore as string[]) ?? snap.content.include;
    const restored: string[] = [];
    if (what.includes("mode_ceiling") && snap.content.state.mode_ceiling) {
      ws.mode_ceiling = snap.content.state.mode_ceiling as Mode;
      restored.push("mode_ceiling");
    }
    if (what.includes("members") && Array.isArray(snap.content.state.members)) {
      const snapByUri = new Map<string, Record<string, unknown>>();
      for (const m of snap.content.state.members as Array<Record<string, unknown>>) {
        snapByUri.set(m.uri as string, m);
      }
      for (const [uri, snapM] of snapByUri) {
        if (ws.members.has(uri)) {
          const cur = ws.members.get(uri)!;
          // The admin role is granted by an admin (SPECIFICATION 6.3), and a
          // rollback, which any member may call, neither grants nor removes it.
          const role = (snapM.role as string) ?? cur.role;
          if (role !== "admin" && cur.role !== "admin") cur.role = role;
          cur.scopes = Array.isArray(snapM.scopes) ? [...snapM.scopes as string[]] : undefined;
        }
      }
      restored.push("members");
    }
    return { result: {
      rolled_back_to: snapId, audit_seq: snap.content.audit_seq, restored,
      ...(p.reason ? { reason: p.reason as string } : {}),
    }};
  });

  coord.handlers.set("control.supersede", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const oldId = p.task_id as string;
    const old = ws.tasks.get(oldId);
    if (!old) return { error: rpcError(E.PARAMS, "Unknown task") };
    if (openRequiredReviewAuthors(ws, old).includes(p.from as string)) {
      return { error: rpcError(E.NOT_AUTHORISED,
        "The authors of the work under review cannot end its review without a decision") };
    }
    const newSpec = (p.successor_task as Record<string, unknown>) ?? {};
    if (typeof newSpec.kind !== "string" || !newSpec.kind) {
      return { error: rpcError(E.PARAMS, "successor_task must include kind") };
    }
    const bad = paramsError(p, [["successor_task.assignee", "string"], ["reason", "string"]]);
    if (bad) return bad;
    const assignee = (newSpec.assignee as string) || old.assignee;
    if (typeof assignee !== "string" || !ws.members.has(assignee)) {
      return { error: rpcError(E.PARAMS, "successor assignee not in workspace") };
    }
    // The successor is a created task, so the participant-paused check
    // task.create applies has to apply here too. Without it, superseding is a
    // way to hand work to a participant whose work was stopped.
    if (ws.members.get(assignee)!.paused) {
      return { error: rpcError(E.CONTROL_WORKSPACE_PAUSED, `Assignee ${assignee} is paused`) };
    }
    // The successor is a created task, so it is bound by the same modes/1.0
    // invariants as task.create: it must not exceed the workspace ceiling, and
    // a trial-mode task forces review on regardless of its own setting.
    if (newSpec.mode !== undefined && newSpec.mode !== null && typeof newSpec.mode !== "string") {
      return { error: rpcError(E.PARAMS, "successor_task.mode must be a string") };
    }
    const requestedMode = (newSpec.mode as Mode) || old.mode;
    if (!modeLE(requestedMode, ws.mode_ceiling)) {
      return { error: rpcError(E.MODE_CEILING_EXCEEDED,
        `Requested mode ${requestedMode} exceeds ceiling ${ws.mode_ceiling}`) };
    }
    if (newSpec.review_required !== undefined && newSpec.review_required !== null
        && typeof newSpec.review_required !== "boolean") {
      return { error: rpcError(E.PARAMS, "successor_task.review_required must be a boolean") };
    }
    const now = coord.now();
    const newId = coord.ids.taskId();
    const newTask: Task = {
      id: newId,
      kind: newSpec.kind as string,
      state: "created",
      assignee,
      delegator: p.from as string,
      input: (newSpec.input as Record<string, unknown>) ?? {},
      created_at: now,
      updated_at: now,
      mode: requestedMode,
      supersedes: old.id,
      history: [{ ts: now, from: p.from as string, state: "created",
                  note: `supersedes ${old.id}: ${(p.reason as string) || ""}` }],
      paused: false,
    };
    // A successor keeps the review requirement of the task it replaces, so
    // superseding never removes a required review. Trial forces review only
    // when the workspace opted into modes/1.0, matching task.create, since
    // mode is inert without the profile. Otherwise the spec's own setting
    // applies.
    if (old.review_required || (ws.profiles.some(pr => pr.startsWith("modes/")) && newTask.mode === "trial")) {
      newTask.review_required = true;
    } else if ("review_required" in newSpec) {
      newTask.review_required = !!newSpec.review_required;
    }
    // Whoever made the work it replaces is an author of the successor's
    // review too, so superseding does not make its author a reviewer of it.
    newTask.prior_authors = successorAuthors(old, p.from);
    ws.tasks.set(newId, newTask);
    old.state = "superseded";
    old.superseded_by = newId;
    old.updated_at = now;
    old.history.push({ ts: now, from: p.from as string, state: "superseded",
                       note: `-> ${newId}: ${(p.reason as string) || ""}` });
    return { result: {
      superseded_task_id: old.id, new_task_id: newId,
      ...(p.reason != null ? { reason: p.reason as string } : {}),
    } };
  });

  coord.handlers.set("control.set_mode_ceiling", (p) => {
    const ws = coord.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const bad = paramsError(p, [["reason", "string"]]);
    if (bad) return bad;
    const m = (p.new_ceiling as Mode) ?? (p.mode_ceiling as Mode);
    if (!VALID_MODES.has(m)) {
      return { error: rpcError(E.PARAMS, "new_ceiling must be shadow, trial or production") };
    }
    ws.mode_ceiling = m;
    return { result: { mode_ceiling: ws.mode_ceiling, ...(p.reason != null ? { reason: p.reason as string } : {}) } };
  });
}
