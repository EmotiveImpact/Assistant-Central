/**
 * @brightbeamai/chap-coordinator/coordinator
 *
 * The Coordinator class. CHAP protocol logic, packaged as a library
 * rather than a CLI server. Applications instantiate one, call
 * `dispatch(envelope)`, subscribe to audit events, and persist via
 * the provided hooks.
 *
 * Coverage:
 *   - Core (9 methods)
 *   - review/1.0 (6 methods)
 *   - whisper/1.0 (2 methods + lapse handling)
 *   - deliberation/1.0 (4 methods)
 *   - modes/1.0 (mode handling at task.create; trial forces review)
 *   - handoff/1.0 (3 methods with multi-task and group support)
 *   - control/1.0 (7 methods with task/participant/workspace scopes)
 *   - routing/1.0 (3 methods producing route_decision artefacts)
 *   - security-signed/1.0 (top-level `sig` field; key history)
 *   - audit-scitt/1.0 (statement assembly + local chain linkage)
 *   - identity-oidc/1.0 + identity-vc/1.0 (binding hooks at join)
 */

import { canonicalize, contentHash, sha256Hex, ZERO_HASH } from "./canonical.js";
import { ALWAYS_AVAILABLE, OWNING_PROFILE, PROFILE_VERSIONS } from "./catalogue.js";
import {
  isEd25519Key, isWebAuthnKey, jwkThumbprint, parseWebAuthnAssertion, publicKeyFromJwk, verifyEnvelope,
  webAuthnFailure,
} from "./crypto.js";
import { IdFactory } from "./ids.js";
import { E, isValidEnvelope, rpcError } from "./jsonrpc.js";
import { paramsError } from "./params.js";
import { entryCall, entryRecord, isSigned, linkHash, refusalIsRecorded, signedDigest } from "./audit.js";
import { applyJsonPatch } from "./patch.js";
import type { Store, StoreChange, WorkspaceRecord } from "./storage/store.js";
import { COLLECTIONS, IDEMPOTENCY_KEYS, MemoryStore, StoreConflictError } from "./storage/store.js";
import { TrackedMap, rawEntries, rawValues, type Tracker } from "./tracked.js";
import { makeApi, type CoordinatorApi } from "./api.js";
import type {
  ArtefactId,
  AuditEntry,
  AuditListener,
  Envelope,
  KeyRecord,
  Invitation,
  JoinPolicy,
  Jwk,
  Member,
  Mode,
  OverrideArtefact,
  SignaturePolicy,
  ParticipantUri,
  SnapshotArtefact,
  Task,
  TaskId,
  TaskState,
  Workspace,
  WorkspaceId,
} from "./types.js";
import { modeLE } from "./types.js";
import { registerAuditScitt } from "./profiles/audit_scitt.js";
import { registerControl } from "./profiles/control.js";
import { registerDeliberation } from "./profiles/deliberation.js";
import { registerHandoff } from "./profiles/handoff.js";
import { registerRouting } from "./profiles/routing.js";
import { registerSecuritySigned } from "./profiles/security_signed.js";
import { registerWhisper } from "./profiles/whisper.js";

// ============================================================
//   Options
// ============================================================

export type TokenVerifier = (token: string) => Record<string, unknown> | null;
export type CredentialVerifier = (presentation: Record<string, unknown>) => Record<string, unknown> | null;
export type ScittSubmitter = (statement: Record<string, unknown>) => Record<string, unknown> | null;
export type ScittReceiptVerifier = (receipt: Record<string, unknown>) => boolean;
export type RoutingPolicyFn = (task: Task, candidates: ParticipantUri[]) => {
  selected: ParticipantUri;
  rationale: Record<string, unknown>;
};
export type ReviewDepthPolicyFn = (task: Task, hints: Record<string, unknown>) => {
  depth: "skip" | "spot_check" | "full" | "escalated";
  sampling_probability?: number;
  rationale: Record<string, unknown>;
};
export type EscalationPolicyFn = (task: Task, hints: Record<string, unknown>) => {
  escalate: boolean;
  to?: ParticipantUri;
  triggered_rule?: Record<string, unknown>;
};

/** Methods classified as privileged for step-up auth. */
export const PRIVILEGED_METHODS = new Set<string>([
  "control.pause", "control.resume", "control.cancel", "control.supersede",
  "control.snapshot", "control.rollback", "control.set_mode_ceiling",
  "workspace.set_profiles", "workspace.invite",
  "participant.rotate_key", "participant.revoke_key",
]);

// Methods outside the control, deliberate, handoff and whisper namespaces that
// dispatch holds to the membership floor before the handler runs.
const MEMBER_ONLY_METHODS = new Set<string>([
  "task.route", "review.depth", "escalate.auto", "participant.leave",
]);

// Read-only methods return workspace state but do not mutate it, so they are not
// recorded in the audit chain -- recording a read would grow and re-link it.
const READ_ONLY_METHODS = new Set<string>([
  "workspace.describe", "audit.read", "audit.verify_chain", "audit.verify_receipt",
  // Submitting the chain to a transparency service reads it and sends it
  // onward. Recording the submission would append to the very log being
  // submitted, so the receipt would attest a chain one entry shorter.
  "audit.submit_to_scitt",
]);

// Cap on a workspace's task.create idempotency map. Older keys are evicted, so
// the dedup window is bounded rather than growing unbounded in a long-lived
// workspace; a redelivery beyond this many intervening creates is not deduped.
const MAX_IDEMPOTENCY_KEYS = 10_000;

// Largest envelope accepted, published in the workspace descriptor (SPEC S4.4).
const DEFAULT_MAX_ENVELOPE_BYTES = 1_048_576;

// How deeply a request may nest, counting the envelope as level one. The
// reference HTTP servers refuse deeper bodies before dispatch; the same limit
// here means an in-process caller cannot send what the canonicaliser, the
// copy of a recorded call and the two references handle differently.
const MAX_NESTING = 64;

function withinNesting(value: unknown, limit: number): boolean {
  const stack: Array<[unknown, number]> = [[value, 1]];
  while (stack.length) {
    const [node, depth] = stack.pop()!;
    if (depth > limit) return false;
    if (Array.isArray(node)) {
      for (const v of node) stack.push([v, depth + 1]);
    } else if (node !== null && typeof node === "object") {
      for (const v of Object.values(node as Record<string, unknown>)) stack.push([v, depth + 1]);
    }
  }
  return true;
}

export interface CoordinatorOptions {
  deterministicIds?: boolean;
  deterministicClock?: boolean;
  enableChain?: boolean;
  /**
   * Require signatures on every workspace, as advertising
   * `security-signed/1.0` does on one.
   */
  requireSignatures?: boolean;
  /**
   * The signature policy of a workspace whose `workspace.create` names none:
   * "all" (the default) verifies every call, and "humans" takes an unsigned
   * call from an agent member.
   */
  signaturePolicy?: SignaturePolicy;
  /**
   * The join policy of a workspace whose `workspace.create` names none:
   * "open" (the default) admits anyone, and "invite" admits only a
   * participant an admin invited, and the first member.
   */
  joinPolicy?: JoinPolicy;
  enforceStepUp?: boolean;
  requireReadMembership?: boolean;
  /** Largest envelope accepted (default 1 MiB), published in the descriptor. */
  maxEnvelopeBytes?: number;
  /** Told of each audit entry once the store has taken it. */
  onAudit?: AuditListener;
  onAutoEscalate?: (task: Task, to: ParticipantUri) => void;
  /**
   * Called when a write to the store fails, with the workspace and the
   * version the write would have reached. When unset, the failure is written
   * to stderr. What happens to the call is `storeErrors`'s to say.
   */
  onStoreError?: (err: unknown, record: { id: string; version: number }) => void;
  /**
   * What a failed synchronous write does to the call that made it. "raise"
   * (the default): the call is answered with -32603 and
   * `data: { reason: "store" }`, and the workspace goes back to what the
   * store holds. "log": the call is answered as it was, and the next write
   * carries its change again. A write another writer got to first is
   * answered as "raise" says under either, and the call may be sent again.
   * An asynchronous write's call was answered already, and the next write
   * to the workspace carries what this one did not.
   */
  storeErrors?: "raise" | "log";
  /**
   * Called when a handler throws, with the error and the call's method and
   * workspace. The caller is answered with -32603 and no detail. When unset,
   * the error is written to stderr.
   */
  onInternalError?: (err: unknown, call: { method: string; workspace?: string }) => void;
  verifyOidcToken?: TokenVerifier;
  verifyVc?: CredentialVerifier;
  scittSubmitter?: ScittSubmitter;
  verifyScittReceipt?: ScittReceiptVerifier;
  routingPolicy?: RoutingPolicyFn;
  reviewDepthPolicy?: ReviewDepthPolicyFn;
  escalationPolicy?: EscalationPolicyFn;
  defaultProfiles?: string[];
  /**
   * Persistence backend. Defaults to MemoryStore (no persistence).
   * Pass SqliteStore or any other Store implementation to persist
   * workspaces between process restarts. The Coordinator calls
   * `store.load()` once when it starts, and after each call that adds to a
   * workspace's log it calls `store.apply()` with what changed, or
   * `store.save()` with the whole workspace when the store has no `apply`.
   */
  store?: Store;
}

// ============================================================
//   Helpers
// ============================================================

function nowIso(clockMs?: number): string {
  const d = clockMs === undefined ? new Date() : new Date(clockMs);
  return d.toISOString().replace(/\.(\d{3})Z$/, ".$1Z");
}

function missing(params: Record<string, unknown>, fields: string[]): string | null {
  for (const f of fields) if (!(f in params)) return f;
  return null;
}

const MODES = new Set<string>(["shadow", "trial", "production"]);

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function reviewRuleSupported(rule: string): boolean {
  if (rule === "any_one_approves" || rule === "all_approve") return true;
  if (rule.startsWith("quorum:")) {
    const arg = rule.slice("quorum:".length);
    return /^[0-9]+$/.test(arg) && parseInt(arg, 10) >= 1;
  }
  return false;
}

function reviewSatisfied(review: { requested_to: string[]; rule: string; decisions: { kind: string; reviewer: string }[] }): boolean {
  const approvers = new Set(review.decisions.filter(d => d.kind === "approve").map(d => d.reviewer));
  const rule = review.rule || "any_one_approves";
  if (rule === "all_approve") {
    // A broadcast-only review has no bounded reviewer set to wait on, so it
    // degrades to first-approve.
    const named = review.requested_to.filter(r => !(r.startsWith("workspace:") || r.startsWith("group:")));
    if (named.length === 0) return approvers.size >= 1;
    return named.every(r => approvers.has(r));
  }
  if (rule.startsWith("quorum:")) return approvers.size >= parseInt(rule.slice("quorum:".length), 10);
  return approvers.size >= 1;  // any_one_approves (and the default)
}

/** Whether a workspace advertises a profile, matched by name as the gate matches it. */
function advertises(ws: Workspace, name: string): boolean {
  return ws.profiles.some((p) => p === name || p.startsWith(name + "/"));
}

/**
 * Whether a profile id names a profile the catalogue lists, at its major
 * version: `<name>/<major>.<minor>` in ASCII digits (SPECIFICATION 6.5). A
 * later minor version is the same profile (SPECIFICATION 15.4).
 */
function knownProfile(id: string): boolean {
  const m = /^([a-z][a-z0-9-]*)\/(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$/.exec(id);
  if (!m || !Object.prototype.hasOwnProperty.call(PROFILE_VERSIONS, m[1])) return false;
  return PROFILE_VERSIONS[m[1]].split(".")[0] === m[2];
}

/** Profiles that cannot be removed once advertised: each states a guarantee about every later call. */
const LASTING_PROFILES = ["security-signed", "identity-oidc", "identity-vc"];

/** The refusal of a profile list naming a profile the catalogue does not list, or null. */
function profilesError(profiles: string[]): { error: ReturnType<typeof rpcError> } | null {
  const unknown = profiles.find((x) => !knownProfile(x));
  if (unknown === undefined) return null;
  return { error: rpcError(E.PARAMS,
    `Unknown profile ${JSON.stringify(unknown)}: a profile id is <name>/<major>.<minor> for a profile the catalogue lists`) };
}

/** Names a task.create idempotency key cannot take (SPECIFICATION 12.3). */
const RESERVED_KEYS = ["__proto__", "constructor", "prototype"];

/** The participant types SPECIFICATION 5.1 names, each the scheme of its URIs. */
const PARTICIPANT_TYPES = ["human", "agent", "service", "group", "workspace"];

/** The types that may hold the admin role (SPECIFICATION 6.3). */
const ADMIN_TYPES = ["human", "service"];

/**
 * Why `uri` cannot name a participant of this type, or null: the type is one
 * of the five, and the URI's scheme names it (SPECIFICATION 5.1). `field` is
 * the param that holds the URI.
 */
function participantError(type: string, uri: string, field: string): { error: ReturnType<typeof rpcError> } | null {
  if (!PARTICIPANT_TYPES.includes(type)) {
    return { error: rpcError(E.PARAMS, "type must be human, agent, service, group or workspace") };
  }
  if (!uri.startsWith(`${type}:`)) {
    return { error: rpcError(E.PARAMS, `${field} must start with "${type}:" for type ${type}`) };
  }
  // A group: or workspace: URI addresses everyone it covers, as a review's
  // `to` does, so it names no one who could join and act.
  if (type === "group" || type === "workspace") {
    return { error: rpcError(E.PARAMS, "group: and workspace: URIs name address scopes, which cannot join") };
  }
  return null;
}

/** Whether a key may sign now: neither revoked nor past its validity. */
function inForce(key: KeyRecord, now: string): boolean {
  return !(key.revoked_at !== undefined && now >= key.revoked_at)
    && !(key.valid_until !== undefined && now >= key.valid_until);
}

/**
 * Whether two JWKs are the same key: the same kid and the same RFC 7638
 * thumbprint, or, for a key with no thumbprint, the same JSON throughout.
 */
function sameKey(a: Record<string, unknown>, b: Record<string, unknown>): boolean {
  const material = (k: Record<string, unknown>) => jwkThumbprint(k) ?? canonicalize(k).toString("utf-8");
  return a.kid === b.kid && material(a) === material(b);
}

/**
 * The keys a credential binds for a join: its confirmation key, named by its
 * kid or else by its RFC 7638 thumbprint, or, where it carries none, the
 * join's keys whose thumbprint its nonce is (SPECIFICATION 5.4). Every key
 * the join carries must be a bound one: null where one is not. Undefined
 * where the credential binds no key.
 */
function credentialKeys(cnf: unknown, nonce: unknown, joinKeys: Array<Record<string, unknown> & { kid: string }>):
    Array<Record<string, unknown> & { kid: string }> | null | undefined {
  if (isObject(cnf)) {
    const kid = typeof cnf.kid === "string" && cnf.kid !== "" ? cnf.kid : jwkThumbprint(cnf);
    if (kid === undefined) return null;
    const key = { ...cnf, kid };
    return joinKeys.every((j) => sameKey(key, j)) ? [key] : null;
  }
  if (typeof nonce === "string") return joinKeys.every((j) => jwkThumbprint(j) === nonce) ? joinKeys : null;
  return undefined;
}

/** An invitation, read without recording it as changed. */
function rawInvitation(ws: Workspace, uri: string): Invitation | undefined {
  return Map.prototype.get.call(ws.invitations, uri) as Invitation | undefined;
}

/**
 * Whether nobody has joined the workspace yet: it holds no member and its log
 * holds no accepted participant.join. A workspace whose members have all left
 * has had its first member.
 */
function awaitsFirstMember(ws: Workspace): boolean {
  if (ws.members.size > 0) return false;
  return !ws.audit.some((e) => e.outcome == null && entryCall(e)?.method === "participant.join");
}

/** The keys of a join's `jwks` a signature can name: objects with a non-empty string kid. */
function signingKeys(jwks: unknown): Array<Record<string, unknown> & { kid: string }> {
  const keys = isObject(jwks) && Array.isArray(jwks.keys) ? jwks.keys : [];
  return keys.filter((j): j is Record<string, unknown> & { kid: string } =>
    isObject(j) && typeof j.kid === "string" && j.kid !== "");
}

/**
 * A call as the log holds it. A participant.join keeps its credentials off
 * the chain: an `oidc_token` is recorded as the SHA-256 of its UTF-8 bytes
 * and a `vc_presentation` as the SHA-256 of its JCS form, so the log shows
 * which credential a member joined with and never holds one a reader could
 * present again.
 */
function recordedForm(envelope: Envelope): Envelope {
  if (envelope.method !== "participant.join" || !isObject(envelope.params)) return envelope;
  const params = { ...envelope.params };
  if (typeof params.oidc_token === "string") params.oidc_token = sha256Hex(params.oidc_token);
  if (isObject(params.vc_presentation)) params.vc_presentation = contentHash(params.vc_presentation);
  return { ...envelope, params };
}

/** The answer to a call whose workspace the store could not be brought in line with. */
function storeFailed() {
  return rpcError(E.INTERNAL, "Internal error", { reason: "store" });
}

/** The workspace a call names, where it names one. */
function targetOf(envelope: unknown): WorkspaceId | undefined {
  const params = isObject(envelope) ? envelope.params : undefined;
  const id = isObject(params) ? params.workspace : undefined;
  return typeof id === "string" && id !== "" ? id : undefined;
}

/**
 * The fields that keep a null. A whisper's default_if_lapsed is required, and
 * null is the default a lapse applies and records.
 */
const KEPT_NULLS: Readonly<Record<string, readonly string[]>> = { whispers: ["default_if_lapsed"] };

/** Deletes the fields of `o` that hold null, but those named in `keep`. */
function dropNulls(o: Record<string, unknown>, keep: readonly string[] = []): void {
  for (const key of Object.keys(o)) if (o[key] === null && !keep.includes(key)) delete o[key];
}

/**
 * Puts one object of a workspace's collection in the shape this coordinator
 * stores and restores, in place, whichever coordinator made it. Called on
 * copies only: the objects a workspace holds keep what its handlers put in
 * them, and every read treats a field holding null as one left out. A field
 * with no value is left out: the Python coordinator writes it as null, and a
 * call that gives a param as null gives it no value, as both coordinators
 * read params. The Python coordinator also names a history entry's sender
 * `from_` and keeps a route decision's fields of its kind in `extra`; this
 * one names the sender `from` and keeps those fields beside `kind`. What an
 * input, an output or an artefact holds is kept as it is.
 */
function shapeObject(name: string, item: Record<string, unknown>): Record<string, unknown> {
  if (name === "route_decisions") {
    const extra = item.extra;
    delete item.extra;
    if (isObject(extra)) Object.assign(item, extra);
    item.kind = "route_decision";
  }
  dropNulls(item, KEPT_NULLS[name]);
  const each = (o: Record<string, unknown>, field: string, f?: (x: Record<string, unknown>) => void) => {
    if (!Array.isArray(o[field])) return;
    for (const x of o[field] as unknown[]) {
      if (isObject(x)) {
        dropNulls(x);
        f?.(x);
      }
    }
  };
  if (name === "members") each(item, "keys");
  if (name === "tasks") {
    each(item, "history", (h) => {
      if (h.from === undefined && typeof h.from_ === "string") h.from = h.from_;
      delete h.from_;
    });
    if (isObject(item.review)) {
      dropNulls(item.review);
      each(item.review, "decisions");
    }
  }
  if (name === "deliberations") each(item, "votes");
  if (name === "handoffs") {
    each(item, "tasks");
    if (Array.isArray(item.accepted_task_ids) && item.accepted_task_ids.length === 0) delete item.accepted_task_ids;
  }
  return item;
}

/** A copy of one object of a collection, in the shape this coordinator stores. */
function storedCopy(name: string, item: Record<string, unknown>): Record<string, unknown> {
  return shapeObject(name, structuredClone(item));
}

/**
 * A workspace snapshot in this coordinator's shape, whichever coordinator
 * wrote it: its own fields with no value left out, and a copy of each object
 * of its collections put in shape. The snapshot itself is not changed.
 */
function shapeSnapshot(w: Record<string, unknown>): Record<string, unknown> {
  const out = { ...w };
  dropNulls(out);
  for (const name of COLLECTIONS) {
    if (Array.isArray(out[name])) {
      out[name] = (out[name] as unknown[]).map((x) => (isObject(x) ? storedCopy(name, x) : x));
    }
  }
  return out;
}

/**
 * Whether a task's work must be decided by a person: it carries
 * review_required, or it runs in trial on a workspace advertising modes/1.0.
 */
export function reviewRequired(ws: Workspace, task: Task): boolean {
  return task.review_required === true || (task.mode === "trial" && advertises(ws, "modes"));
}

/** A member, read without recording it as changed. */
function rawMember(ws: Workspace, uri: unknown): Member | undefined {
  return typeof uri === "string" ? Map.prototype.get.call(ws.members, uri) as Member | undefined : undefined;
}

/** The members of the lists in order, each once. */
export function unionOf(...lists: ReadonlyArray<ParticipantUri>[]): ParticipantUri[] {
  const out: ParticipantUri[] = [];
  for (const list of lists) for (const uri of list) if (!out.includes(uri)) out.push(uri);
  return out;
}

/**
 * Who made the work: the task's assignee, then whoever completed it, then
 * the authors it carries from a task it replaces, once each.
 */
export function authorsOf(task: Task, completer: unknown): ParticipantUri[] {
  const authors: ParticipantUri[] = [task.assignee];
  if (typeof completer === "string" && completer !== task.assignee) authors.push(completer);
  return unionOf(authors, Array.isArray(task.prior_authors) ? task.prior_authors : []);
}

/**
 * The state a task was in before the history entry at `i`, passing over
 * pauses, which leave the work where it was.
 */
function stateBefore(history: Task["history"], i: number): TaskState | undefined {
  for (let j = i - 1; j >= 0; j--) {
    if (history[j].state !== "paused") return history[j].state;
  }
  return undefined;
}

/**
 * Whether the history entry at `i` records the work completed: the task
 * entering `completed` from any state but review. A reviewer's decision
 * completes a task out of review, and an entry a task already completed
 * takes, such as a route or a handoff of it, completes nothing.
 */
function workCompletion(history: Task["history"], i: number): boolean {
  if (history[i].state !== "completed") return false;
  const before = stateBefore(history, i);
  return before !== "review_requested" && before !== "completed";
}

/** The sender of the task's latest completion of the work, if it has one. */
function lastCompleter(task: Task): ParticipantUri | undefined {
  for (let i = task.history.length - 1; i >= 0; i--) {
    if (workCompletion(task.history, i)) return task.history[i].from;
  }
  return undefined;
}

/** The notes on the history entries of the reviews task.complete opened. */
const OPENED_ON_COMPLETE = "review required; opened on task.complete";
const NEW_ROUND_ON_COMPLETE = "a new round of the review; opened on task.complete";

/**
 * The authors of a review recorded before authors were kept, read from the
 * task's history: the assignee, whoever completed the work, whether the
 * completion opened the review or came before a review.request, and the
 * member whose review.request opened the review, which supplied the
 * artefact under review. A reviewer's decision that completed the task is
 * not a completion of the work.
 */
function storedAuthors(task: Task): ParticipantUri[] {
  let requester: ParticipantUri | undefined;
  const withRequester = (authors: ParticipantUri[]) => unionOf(authors, requester !== undefined ? [requester] : []);
  for (let i = task.history.length - 1; i >= 0; i--) {
    const h = task.history[i];
    const opens = h.state === "review_requested" && stateBefore(task.history, i) !== "review_requested";
    if (opens && (h.note === OPENED_ON_COMPLETE || h.note === NEW_ROUND_ON_COMPLETE)) return withRequester(authorsOf(task, h.from));
    if (opens && requester === undefined) requester = h.from;
    if (workCompletion(task.history, i)) return withRequester(authorsOf(task, h.from));
  }
  return withRequester(authorsOf(task, undefined));
}

/** The states in which a task is over. */
const ENDED: ReadonlyArray<TaskState> = ["completed", "declined", "cancelled", "superseded", "escalated"];

/**
 * The authors a review the task requires holds, whatever state the task is
 * in: those of its own review, until a reviewer rejects or overrides the
 * round under review, or approves it as its rule asks; or, for a task with
 * no review yet, those of the task it replaces, since an escalation or a
 * supersede carries that review on, however long the chain.
 */
function reviewHolds(ws: Workspace, task: Task): ParticipantUri[] {
  const seen = new Set<string>();
  for (let t: Task | undefined = task; t && !seen.has(t.id); t = typeof t.supersedes === "string" ? ws.tasks.get(t.supersedes) : undefined) {
    seen.add(t.id);
    if (!reviewRequired(ws, t)) return [];
    if (t.review) {
      const decided = t.review.decisions.some((d) => d.kind === "reject" || d.kind === "override") || reviewSatisfied(t.review);
      return decided ? [] : t.review.authors;
    }
  }
  return [];
}

/**
 * The authors a review the task requires holds to it: from the moment the
 * review opens until the task is over, unless a reviewer has rejected the
 * round under review, and through a successor an escalation or a supersede
 * makes. They may take the work back to revise it, and hand it on with
 * escalate.raise; they do not end the task, or its successor, around a
 * decision. Once a reviewer rejects the work, its authors may give the task
 * up. Empty where the task holds no such review.
 */
export function openRequiredReviewAuthors(ws: Workspace, task: Task): ParticipantUri[] {
  return ENDED.includes(task.state) ? [] : reviewHolds(ws, task);
}

/**
 * The task's assignee, as an author of its work, where it moves the task on
 * itself; otherwise nobody. Whoever completed the work is an author by its
 * completion. A member another member routed or escalated the task to made
 * none of the work it was handed, so nobody can leave a person out of a
 * review's reviewers by passing the task through them.
 */
export function heldBy(task: Task, mover: unknown): ParticipantUri[] {
  return mover === task.assignee ? [task.assignee] : [];
}

/**
 * The authors a successor carries from the task it replaces: that task's
 * review authors where it held a review, its assignee where heldBy counts
 * it, whoever completed the work, and the authors it carried itself.
 */
export function successorAuthors(old: Task, mover: unknown): ParticipantUri[] {
  const completer = lastCompleter(old);
  return unionOf(old.review ? old.review.authors : [], heldBy(old, mover),
                 completer !== undefined ? [completer] : [],
                 Array.isArray(old.prior_authors) ? old.prior_authors : []);
}

/** Whether a URI is an address scope, which every member it covers answers to. */
function isScope(uri: unknown): boolean {
  return typeof uri === "string" && (uri.startsWith("workspace:") || uri.startsWith("group:"));
}

function reply(env: Envelope, body: { result?: unknown; error?: { code: number; message: string; data?: unknown } }): Envelope {
  // JSON-RPC answers with a null id where the request carries none, or is
  // not an object at all, as the Python reference does, so dispatch(null)
  // is answered too.
  const sent = env !== null && typeof env === "object" && !Array.isArray(env) ? env.id : undefined;
  const out = { jsonrpc: "2.0", id: sent ?? null } as Envelope;
  if (body.error !== undefined) out.error = body.error;
  else out.result = body.result;
  return out;
}

/** The signed calls on a log, keyed by `signedDigest`: refusals, and the seq each accepted call took. */
interface SignedIndex {
  refused: Map<string, { seq: number; code: number }>;
  accepted: Map<string, number>;
}

function indexSigned(index: SignedIndex, entry: AuditEntry): void {
  const call = entryCall(entry);
  if (!isSigned(call)) return;
  let digest: string;
  try { digest = signedDigest(call as Envelope); }
  catch { return; /* an entry that cannot be canonicalised was altered; verify_chain reports it */ }
  if (entry.outcome != null) index.refused.set(digest, { seq: entry.seq, code: entry.outcome.code });
  // A log written before signed copies were refused can hold one call twice;
  // the first is where it took effect.
  else if (!index.accepted.has(digest)) index.accepted.set(digest, entry.seq);
}

// ============================================================
//   Handler type for profile modules
// ============================================================

export type Handler = (params: Record<string, unknown>) => { result?: unknown; error?: { code: number; message: string; data?: unknown } };

// ============================================================
//   Coordinator
// ============================================================

function isThenable(value: unknown): value is PromiseLike<void> {
  return typeof (value as PromiseLike<void> | undefined)?.then === "function";
}

/** A deep copy where the value can be cloned, else the value itself. */
function ownCopy<T>(value: T): T {
  try {
    return structuredClone(value);
  } catch {
    return value;
  }
}

// States in which a task has been deliberately stopped. review.request and
// task.complete both refuse these, so neither can revive a terminated task nor
// bypass a pause.
const REVIEW_REQUEST_STOPPED: string[] = ["cancelled", "superseded", "paused"];

/** What the store holds of one workspace, as far as a Coordinator knows. */
interface Persisted {
  /** Audit entries the store holds. */
  seq: number;
  /** Write the whole workspace next: the store's copy is unknown. */
  replace: boolean;
  /** Idempotency keys written or removed since the last write. */
  keys: Set<string>;
  /** The time to stamp on the next write. */
  updatedAt?: string;
}

export class Coordinator {
  readonly workspaces = new Map<WorkspaceId, Workspace>();
  readonly options: CoordinatorOptions;
  readonly ids: IdFactory;
  readonly store: Store;
  private wsVersions = new Map<WorkspaceId, number>();
  private saveChains = new Map<WorkspaceId, Promise<void>>();
  /** Records which objects change, for stores that implement `apply`. */
  private readonly tracker: Tracker;
  /** What the store holds of each workspace, as far as this instance knows. */
  private persisted = new WeakMap<Workspace, Persisted>();
  /** Workspaces with entries not yet written in the call being handled. */
  private unflushed = new Set<Workspace>();
  /** Workspaces with a write queued behind an async write in flight. */
  private flushQueued = new Set<Workspace>();
  /**
   * Workspaces whose store copy may differ from memory after a synchronous
   * write failed or conflicted. Each is reloaded from the store before the
   * next call on it, which is refused while the reload fails.
   */
  private held = new Set<WorkspaceId>();
  /** Entries appended and not yet written, which the audit listeners hear of once they are. */
  private unannounced = new WeakMap<Workspace, AuditEntry[]>();
  private clockMs?: number;
  private frozenNow?: string;
  private auditListeners: AuditListener[] = [];
  /**
   * The signed calls on each workspace's log, by what their senders signed:
   * recorded refusals with their seq and code, and accepted calls with their
   * seq. Rebuilt from the log when missing, so a snapshot never carries it.
   */
  private signedIndexes = new WeakMap<Workspace, SignedIndex>();
  /** Method handler registry; profiles plug into this. */
  readonly handlers = new Map<string, Handler>();
  /** Custom lapse-check function (whisper/1.0). Set by the whisper profile. */
  checkWhisperLapses?: (workspaceId: string, now?: string) => Envelope[];
  /** Typed method facade. Defined via getter in the constructor. */
  readonly api!: CoordinatorApi;
  /** @internal cached facade instance */
  private _api?: CoordinatorApi;

  constructor(options: CoordinatorOptions = {}) {
    this.options = options;
    this.store = options.store ?? new MemoryStore();
    this.tracker = { enabled: typeof this.store.apply === "function", depth: 0 };
    this.ids = new IdFactory(!!options.deterministicIds, 0n, 1_700_000_000_000);
    if (options.deterministicClock) this.clockMs = 1_700_000_000_000;
    if (options.onAudit) this.auditListeners.push(options.onAudit);

    this.registerCoreHandlers();
    this.registerProfileHandlers();

    // Lazily-initialised typed facade. Constructed on first access so
    // tests that don't use it pay nothing.
    Object.defineProperty(this, "api", {
      get: () => {
        if (!this._api) this._api = makeApi(this);
        return this._api;
      },
      enumerable: false,
      configurable: true,
    });

    // Rehydrate any persisted state synchronously. Async stores can
    // call `start()` instead; this fallback covers the common
    // synchronous Memory/Sqlite path with no async setup needed.
    try {
      const loaded = this.store.load();
      if (!isThenable(loaded)) {
        this.applyRecords(loaded as WorkspaceRecord[]);
      }
    } catch {
      /* fall through; caller must invoke start() */
    }
  }

  /**
   * Asynchronously hydrate workspaces from the store. Required only for
   * stores whose `load()` returns a Promise. Idempotent.
   */
  async start(): Promise<void> {
    const records = await this.store.load();
    this.applyRecords(records);
  }

  private applyRecords(records: WorkspaceRecord[]): void {
    // One restore for every record: restore replaces the workspaces it
    // holds, so restoring record by record kept only the last.
    this.wsVersions.clear();
    this.restore(records.map(r => r.data));
    for (const r of records) this.wsVersions.set(r.id, r.version);
    // What was just loaded is what the store holds.
    for (const ws of this.workspaces.values()) this.markWritten(ws);
  }

  /** A map for a workspace collection, tracked for stores that implement `apply`. */
  private newMap<K, V>(): Map<K, V> {
    return new TrackedMap<K, V>(this.tracker);
  }

  /** Record that the store holds this workspace exactly as it is in memory. */
  private markWritten(ws: Workspace): void {
    for (const name of COLLECTIONS) {
      const map = ws[name];
      if (map instanceof TrackedMap) map.dirty.clear();
    }
    this.persisted.set(ws, { seq: ws.audit.length, replace: false, keys: new Set() });
  }

  /**
   * What the store holds of a workspace. A workspace this instance did not
   * create or load, such as one an application put in `workspaces` itself,
   * or one whose maps an application replaced, is tracked from here on and
   * written whole once.
   */
  private persistedOf(ws: Workspace): Persisted {
    let p = this.persisted.get(ws);
    let untracked = false;
    for (const name of COLLECTIONS) {
      const map = ws[name] as Map<string, unknown>;
      if (map instanceof TrackedMap && map.tracker === this.tracker) continue;
      untracked = true;
      const tracked = new TrackedMap<string, unknown>(this.tracker);
      for (const [key, value] of Map.prototype.entries.call(map) as IterableIterator<[string, unknown]>) {
        tracked.set(key, value);
      }
      (ws as unknown as Record<string, unknown>)[name] = tracked;
    }
    if (!p || untracked) {
      p = { seq: p?.seq ?? 0, replace: true, keys: new Set(), updatedAt: p?.updatedAt };
      this.persisted.set(ws, p);
    }
    return p;
  }

  /** Record that a task.create idempotency key was written or removed. */
  private markKey(ws: Workspace, key: string): void {
    if (this.tracker.enabled) this.persistedOf(ws).keys.add(key);
  }

  /** After an entry is appended: write now, or when the call being handled ends. */
  private persist(ws: Workspace): void {
    if (!this.tracker.enabled) {
      this.persistSnapshot(ws);
      return;
    }
    // One clock reading per entry, where earlier releases read it to stamp
    // the snapshot, so a deterministic clock gives the same times as before.
    this.persistedOf(ws).updatedAt = this.now();
    if (this.tracker.depth > 0) this.unflushed.add(ws);
    else this.flush(ws);
  }

  private flushUnflushed(): void {
    if (!this.unflushed.size) return;
    const list = [...this.unflushed];
    this.unflushed.clear();
    for (const ws of list) this.flush(ws);
  }

  /** Write what changed in one workspace since its last write. */
  private flush(ws: Workspace): void {
    const pending = this.saveChains.get(ws.id);
    if (pending) {
      // An async write is in flight. One more write follows it, built when it
      // runs, so it carries everything that changed until then.
      if (this.flushQueued.has(ws)) return;
      this.flushQueued.add(ws);
      this.chainWrite(ws.id, pending.then(() => {
        this.flushQueued.delete(ws);
        return this.writeChange(ws);
      }));
      return;
    }
    const result = this.writeChange(ws);
    if (result) this.chainWrite(ws.id, result);
  }

  private chainWrite(id: WorkspaceId, work: Promise<void>): void {
    // writeChange reports its own failures; this only keeps the chain alive.
    const guarded = work.catch(() => undefined);
    this.saveChains.set(id, guarded);
    void guarded.then(() => {
      if (this.saveChains.get(id) === guarded) this.saveChains.delete(id);
    });
  }

  private writeChange(ws: Workspace): Promise<void> | void {
    const p = this.persistedOf(ws);
    let change: StoreChange | undefined;
    try {
      change = this.takeChange(ws, p);
    } catch (err) {
      // What was taken is unknown, so the next write carries the whole workspace.
      p.replace = true;
      if (this.options.storeErrors !== "log") this.held.add(ws.id);
      this.reportStoreError(err, { id: ws.id, version: ws.audit.length });
      return;
    }
    if (!change) return;
    const taken = change;
    const done = () => {
      p.seq = taken.version;
      if (taken.replace) p.replace = false;
      this.announce(ws, taken.version);
    };
    const failed = (err: unknown) => {
      this.giveBack(ws, p, taken);
      this.reportStoreError(err, { id: taken.id, version: taken.version });
    };
    let result: PromiseLike<void> | void;
    try {
      result = this.store.apply!(taken);
    } catch (err) {
      // The call that made this change is answered as failed, and the
      // workspace is reloaded from the store before it is used again; under
      // "log" the call stands, and the next write carries the change. A
      // write another writer got to first fails its call under either.
      if (err instanceof StoreConflictError || this.options.storeErrors !== "log") this.held.add(ws.id);
      failed(err);
      return;
    }
    if (isThenable(result)) return Promise.resolve(result).then(done, failed);
    done();
  }

  /** Tell the audit listeners of the entries now written, up to `upTo`. */
  private announce(ws: Workspace, upTo: number): void {
    const queued = this.unannounced.get(ws);
    if (!queued?.length) return;
    const now = queued.filter((e) => e.seq < upTo);
    this.unannounced.set(ws, queued.filter((e) => e.seq >= upTo));
    for (const entry of now) {
      for (const l of this.auditListeners) {
        try { l(ws, entry); } catch { /* listeners never break dispatch */ }
      }
    }
  }

  /**
   * The change since the last write, taking the recorded keys with it. Each
   * object is written as a copy in the shape a restore gives back, so a
   * coordinator restarted on the store holds what this one holds, and the
   * workspace's own objects are left as they are.
   */
  private takeChange(ws: Workspace, p: Persisted): StoreChange | undefined {
    const replace = p.replace;
    const objects: Record<string, Record<string, unknown>> = {};
    for (const name of COLLECTIONS) {
      const map = ws[name] as unknown as TrackedMap<string, Record<string, unknown>>;
      if (replace) {
        const all: Record<string, unknown> = {};
        for (const [key, value] of Map.prototype.entries.call(map) as IterableIterator<[string, Record<string, unknown>]>) {
          all[key] = storedCopy(name, value);
        }
        objects[name] = all;
      } else if (map.dirty.size) {
        const changed: Record<string, unknown> = {};
        for (const key of map.dirty) {
          const value = map.peek(key);
          changed[key] = value === undefined ? null : storedCopy(name, value);
        }
        objects[name] = changed;
      }
      map.dirty.clear();
    }
    if (replace) {
      objects[IDEMPOTENCY_KEYS] = { ...ws.idempotency_keys };
    } else if (p.keys.size) {
      const changed: Record<string, unknown> = {};
      for (const key of p.keys) changed[key] = ws.idempotency_keys[key] ?? null;
      objects[IDEMPOTENCY_KEYS] = changed;
    }
    p.keys.clear();
    const entries = ws.audit.slice(replace ? 0 : p.seq);
    if (!replace && !entries.length && !Object.keys(objects).length) return undefined;
    return {
      id: ws.id,
      base: replace ? 0 : p.seq,
      version: ws.audit.length,
      updated_at: p.updatedAt ?? ws.audit[ws.audit.length - 1]?.arrived ?? ws.created,
      meta: this.metaOf(ws),
      entries,
      objects,
      ...(replace ? { replace: true } : {}),
    };
  }

  /** A failed write's keys go back, so the next write carries them again. */
  private giveBack(ws: Workspace, p: Persisted, change: StoreChange): void {
    if (change.replace) {
      p.replace = true;
      return;
    }
    for (const [name, items] of Object.entries(change.objects)) {
      if (name === IDEMPOTENCY_KEYS) {
        for (const key of Object.keys(items)) p.keys.add(key);
        continue;
      }
      const map = (ws as unknown as Record<string, unknown>)[name];
      if (map instanceof TrackedMap) for (const key of Object.keys(items)) map.dirty.add(key);
    }
  }

  /** Persist the whole workspace, for a store that implements only `save`. */
  private persistSnapshot(ws: Workspace): void {
    const next = (this.wsVersions.get(ws.id) ?? 0) + 1;
    this.wsVersions.set(ws.id, next);
    let record: WorkspaceRecord;
    try {
      record = { id: ws.id, data: this.snapshotOf(ws), version: next, updated_at: this.now() };
    } catch (err) {
      // Nothing was written. The next save builds the whole workspace again.
      this.reportStoreError(err, { id: ws.id, version: next });
      return;
    }

    const upTo = ws.audit.length;
    const pending = this.saveChains.get(ws.id);
    if (pending) {
      this.trackSave(pending.then(() => this.store.save(record)), record, () => this.announce(ws, upTo));
      return;
    }
    let result: PromiseLike<void> | void;
    try {
      result = this.store.save(record);
    } catch (err) {
      if (this.options.storeErrors !== "log") this.held.add(ws.id);
      this.reportStoreError(err, record);
      return;
    }
    if (isThenable(result)) {
      this.trackSave(Promise.resolve(result), record, () => this.announce(ws, upTo));
      return;
    }
    this.announce(ws, upTo);
  }

  private trackSave(save: Promise<void>, record: WorkspaceRecord, saved: () => void): void {
    const guarded = save.then(saved, err => this.reportStoreError(err, record));
    this.saveChains.set(record.id, guarded);
    void guarded.then(() => {
      if (this.saveChains.get(record.id) === guarded) {
        this.saveChains.delete(record.id);
      }
    });
  }

  private reportInternalError(err: unknown, method: string, workspace: string | undefined): void {
    const call = { method, ...(workspace !== undefined ? { workspace } : {}) };
    if (this.options.onInternalError) {
      try {
        this.options.onInternalError(err, call);
      } catch {
        void 0;
      }
      return;
    }
    console.error(`chap coordinator: ${method} failed with an internal error:`, err);
  }

  private reportStoreError(err: unknown, record: { id: string; version: number }): void {
    if (this.options.onStoreError) {
      try {
        this.options.onStoreError(err, { id: record.id, version: record.version });
      } catch {
        void 0;
      }
      return;
    }
    const message = err instanceof Error ? err.message : String(err);
    const line = `chap coordinator: writing workspace ${record.id} to the store failed: ${message}`;
    // Another writer having written first is handled: the workspace is
    // reloaded, and the call may be sent again.
    if (err instanceof StoreConflictError) console.warn(line);
    else console.error(line);
  }

  async drainSaves(): Promise<void> {
    while (this.saveChains.size) {
      await Promise.allSettled([...this.saveChains.values()]);
    }
  }

  // -- lifecycle -----------------------------------------------------

  private advanceClock(): string {
    if (this.clockMs !== undefined) {
      this.clockMs += 1000;
      return nowIso(this.clockMs);
    }
    return nowIso();
  }

  now(): string {
    return this.frozenNow ?? this.advanceClock();
  }

  onAudit(listener: AuditListener): () => void {
    this.auditListeners.push(listener);
    return () => {
      const i = this.auditListeners.indexOf(listener);
      if (i >= 0) this.auditListeners.splice(i, 1);
    };
  }

  /** Convenience: get a workspace by id, or undefined. */
  getWorkspace(id: WorkspaceId): Workspace | undefined {
    return this.workspaces.get(id);
  }

  // ----- authorisation preconditions -----

  /**
   * Assert that `sender` is a joined member of `ws`. Returns an error
   * fragment if not, else null. Every actor-action method runs this on
   * its `from` so a decision, completion, or review request can never
   * be attributed to a participant who never joined. See
   * SPECIFICATION.md S6.3 and the `unknown_participant` condition in
   * S13.3. (The published spec assigns -32403; the reference
   * implementations use NOT_AUTHORISED -32011 because -32403 already
   * denotes OIDC_TOKEN_INVALID in their private range. The spec/impl
   * error-table divergence is tracked separately.)
   */
  private requireMember(ws: Workspace, sender: unknown): { error: ReturnType<typeof rpcError> } | null {
    // A `from` that is not a string names nobody. It is answered in fixed
    // words, so both references refuse it alike whatever was sent.
    if (typeof sender !== "string") {
      return { error: rpcError(E.NOT_AUTHORISED, "Not a workspace member: from is not a participant URI") };
    }
    if (!ws.members.has(sender)) {
      return { error: rpcError(E.NOT_AUTHORISED, `Not a workspace member: ${sender}`) };
    }
    return null;
  }

  /**
   * Assert that `sender` may decide the task's open review. Applied to
   * review-decision methods (decide.* and abstain.declare) and to
   * review.acknowledge: to act on a review you must not be an author of the
   * work under review, must be a human member where the task requires
   * review, and must be one of the reviewers it was addressed to (the `to`
   * set on review.request).
   * Membership is the floor; this is the eligibility ceiling for decisions.
   * Returns an error fragment if not eligible, else null.
   */
  private requireReviewer(ws: Workspace, task: Task, sender: unknown): { error: ReturnType<typeof rpcError> } | null {
    const review = task.review;
    if (!review) return null;
    // A decision by whoever made the work is not a review of it, whatever
    // the reviewer set says, broadcast scopes included.
    if (typeof sender === "string" && review.authors.includes(sender)) {
      return { error: rpcError(E.NOT_AUTHORISED, "The author of the work under review cannot decide it") };
    }
    if (reviewRequired(ws, task) && rawMember(ws, sender)?.type !== "human") {
      return { error: rpcError(E.NOT_AUTHORISED, `This task requires a person's review: ${String(sender)} is not a human member`) };
    }
    if (!review.requested_to || review.requested_to.length === 0) {
      // No recorded reviewer set: fall back to the membership floor,
      // which the caller has already enforced.
      return null;
    }
    // A broadcast-scoped reviewer (workspace:/group: URI) is satisfied by
    // any workspace member; the membership floor already passed. Note the
    // coordinator does not model group membership: a group: target means
    // "any member", not "any member of that group" (deployments needing
    // true group restriction enforce it externally). Keeps the documented
    // `to: workspace:<id>` broadcast pattern working.
    if (review.requested_to.some((r) => typeof r === "string" && (r.startsWith("workspace:") || r.startsWith("group:")))) {
      return null;
    }
    if (typeof sender !== "string" || !review.requested_to.includes(sender as ParticipantUri)) {
      return { error: rpcError(E.NOT_AUTHORISED, `Not an addressed reviewer for this task: ${String(sender)}`) };
    }
    return null;
  }

  /** Serialise all workspaces to a JSON-safe structure for persistence. */
  snapshot(): unknown {
    const out: Array<Record<string, unknown>> = [];
    for (const ws of this.workspaces.values()) out.push(this.snapshotOf(ws));
    return out;
  }

  /** The workspace's own fields: everything except its collections and log. */
  private metaOf(ws: Workspace): Record<string, unknown> {
    return {
      id:           ws.id,
      created:      ws.created,
      state:        ws.state,
      profiles:     ws.profiles,
      mode:         ws.mode,
      mode_ceiling: ws.mode_ceiling,
      routing_policy_uri: ws.routing_policy_uri,
      step_up_window_sec: ws.step_up_window_sec,
      min_acr:      ws.min_acr,
      signature_policy: ws.signature_policy,
      join_policy:  ws.join_policy,
      review_rule:  ws.review_rule,
      chain_head:   ws.chain_head,
      chain_enabled: ws.chain_enabled,
    };
  }

  /**
   * One workspace as `snapshot()` holds it: each object of its collections a
   * copy in the shape the store keeps. Reads nothing as a change.
   */
  private snapshotOf(ws: Workspace): Record<string, unknown> {
    const { chain_head, chain_enabled, ...own } = this.metaOf(ws);
    const stored = (name: (typeof COLLECTIONS)[number]) =>
      Array.from(rawValues(ws[name] as unknown as TrackedMap<string, Record<string, unknown>>))
        .map((v) => storedCopy(name, v));
    return {
      ...own,
      members:         stored("members"),
      tasks:           stored("tasks"),
      overrides:       stored("overrides"),
      whispers:        stored("whispers"),
      deliberations:   stored("deliberations"),
      handoffs:        stored("handoffs"),
      snapshots:       stored("snapshots"),
      route_decisions: stored("route_decisions"),
      invitations:     stored("invitations"),
      idempotency_keys: { ...ws.idempotency_keys },
      audit:           ws.audit,
      chain_head,
      chain_enabled,
    };
  }

  /** Restore from a snapshot produced by ``snapshot()``. Replaces
   *  any existing in-memory workspaces. */
  restore(data: unknown): void {
    this.workspaces.clear();
    this.unflushed.clear();
    if (!Array.isArray(data)) return;
    for (const w of data as Array<Record<string, unknown>>) {
      // One workspace that cannot be rebuilt is skipped, with a warning, so
      // the others still load.
      let ws: Workspace;
      try {
        ws = this.rebuild(w);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.warn(`chap coordinator: workspace ${String(w?.id)} could not be restored: ${message}`);
        continue;
      }
      this.workspaces.set(ws.id, ws);
      // Restored from data the store may not hold: the next write replaces
      // the store's copy whole. Loading from the store marks it written.
      for (const name of COLLECTIONS) (ws[name] as TrackedMap<unknown, unknown>).dirty.clear();
      this.persisted.set(ws, { seq: 0, replace: true, keys: new Set() });
    }
  }

  /** One workspace from a snapshot entry, its maps tracked. */
  private rebuild(snapshot: Record<string, unknown>): Workspace {
    const w = shapeSnapshot(snapshot);
    const ws: Workspace = {
      id: w.id as WorkspaceId,
      created: w.created as string,
      state: (w.state as Workspace["state"]) ?? "active",
      profiles: (w.profiles as string[]) ?? [],
      mode: (w.mode as Mode) ?? "trial",
      mode_ceiling: (w.mode_ceiling as Mode) ?? "production",
      routing_policy_uri: w.routing_policy_uri as string | undefined,
      step_up_window_sec: (w.step_up_window_sec as number) ?? 300,
      min_acr: w.min_acr as string | undefined,
      // A workspace written before the policy existed verified every call,
      // and one written before the join policy existed admitted anyone.
      signature_policy: w.signature_policy === "humans" ? "humans" : "all",
      join_policy: w.join_policy === "invite" ? "invite" : "open",
      review_rule: typeof w.review_rule === "string" && reviewRuleSupported(w.review_rule) ? w.review_rule : undefined,
      members: this.newMap(),
      tasks: this.newMap(),
      overrides: this.newMap(),
      whispers: this.newMap(),
      deliberations: this.newMap(),
      handoffs: this.newMap(),
      snapshots: this.newMap(),
      route_decisions: this.newMap(),
      invitations: this.newMap(),
      idempotency_keys: (w.idempotency_keys as Record<string, string>) ?? {},
      audit: (w.audit as AuditEntry[]) ?? [],
      chain_head: w.chain_head as string | undefined,
      chain_enabled: !!w.chain_enabled,
    };
    for (const m of (w.members as Member[]) ?? []) {
      // Defensive: ensure required collections exist even on older snapshots.
      if (!Array.isArray(m.keys)) m.keys = [];
      if (m.paused === undefined) m.paused = false;
      // A member written before its type was checked against its URI takes
      // the type the scheme names, and holds the admin role only where that
      // type may (SPECIFICATION 5.1, 6.3).
      const scheme = typeof m.uri === "string" ? m.uri.split(":")[0] : "";
      if (PARTICIPANT_TYPES.includes(scheme)) m.type = scheme as Member["type"];
      if (m.role === "admin" && !ADMIN_TYPES.includes(m.type)) m.role = "participant";
      ws.members.set(m.uri, m);
    }
    for (const t of (w.tasks as Task[]) ?? []) {
      // A review written before authors were recorded takes them from the
      // task's history.
      if (t.review && !Array.isArray(t.review.authors)) t.review.authors = storedAuthors(t);
      // and one written before acknowledgements were kept has none.
      if (t.review && !Array.isArray(t.review.acknowledgements)) t.review.acknowledgements = [];
      ws.tasks.set(t.id, t);
    }
    for (const o of (w.overrides as OverrideArtefact[]) ?? []) ws.overrides.set(o.id, o);
    // The dynamic profile collections may not be present on legacy snapshots.
    for (const x of (w.whispers as Array<{ id: string } & Record<string, unknown>>) ?? [])
      ws.whispers.set(x.id, x as never);
    for (const x of (w.deliberations as Array<{ id: string } & Record<string, unknown>>) ?? [])
      ws.deliberations.set(x.id, x as never);
    for (const x of (w.handoffs as Array<{ id: string } & Record<string, unknown>>) ?? [])
      ws.handoffs.set(x.id, x as never);
    for (const x of (w.snapshots as Array<{ id: string } & Record<string, unknown>>) ?? []) {
      // Normalize the former flat store representation only on restore.
      // New snapshots are stored and emitted in the canonical wire shape.
      const content = structuredClone((x.content ?? {
        workspace: x.workspace, audit_seq: x.audit_seq,
        include: x.include, state: x.state,
        ...(x.label ? { label: x.label } : {}),
      }) as SnapshotArtefact["content"]);
      if (!x.content) {
        // Legacy in-memory projections can contain undefined optional
        // fields; full bodies from older stores are not snapshot slices.
        const oldState = content.state;
        const state: Record<string, unknown> = {};
        for (const key of ["mode_ceiling", "routing_policy_uri", "audit_seq"]) {
          if (oldState[key] != null && oldState[key] !== "") state[key] = oldState[key];
        }
        for (const [key, fields] of [
          ["members", ["uri", "type", "role", "scopes"]],
          ["open_tasks", ["id", "kind", "state", "assignee"]],
        ] as const) {
          const items = oldState[key];
          if (Array.isArray(items) && items.length) {
            state[key] = items.map(item => Object.fromEntries(fields
              .filter(field => item[field] != null && item[field] !== ""
                && (!Array.isArray(item[field]) || item[field].length > 0))
              .map(field => [field, item[field]])));
          }
        }
        content.state = state;
      }
      ws.snapshots.set(x.id, {
        id: x.id, kind: "snapshot",
        produced_by: (x.produced_by ?? x.by) as string,
        produced_at: (x.produced_at ?? x.ts) as string,
        content_hash: (x.content_hash as string | undefined) ?? contentHash(content),
        content,
      });
    }
    for (const x of (w.route_decisions as Array<{ id: string } & Record<string, unknown>>) ?? [])
      ws.route_decisions.set(x.id, x as never);
    for (const x of (w.invitations as Invitation[]) ?? []) ws.invitations.set(x.uri, x);
    return ws;
  }

  // -- dispatch ------------------------------------------------------

  dispatch(envelope: Envelope): Envelope {
    this.frozenNow = this.advanceClock();
    this.tracker.depth++;
    let response: Envelope;
    let target: WorkspaceId | undefined;
    let ran = false;
    try {
      target = targetOf(envelope);
      const refused = target === undefined ? null : this.keepUp(target);
      if (refused) {
        response = reply(envelope, { error: refused });
      } else {
        ran = true;
        response = this._dispatch(envelope);
        if (response.error) this.recordRefusal(envelope, response.error);
        else if (target === undefined && envelope.method === "workspace.create") {
          target = (response.result as { workspace?: WorkspaceId } | undefined)?.workspace;
        }
      }
    } finally {
      // One write per call, with everything the call changed, made before
      // dispatch returns.
      if (--this.tracker.depth === 0) this.flushUnflushed();
      this.frozenNow = undefined;
    }
    // The call's write failed, so the store does not hold what it did. It is
    // answered as failed, and the workspace goes back to what the store holds.
    if (ran && target !== undefined && this.tracker.depth === 0 && this.held.has(target)) {
      this.reload(target);
      return reply(envelope, { error: storeFailed() });
    }
    return response;
  }

  /**
   * Work that changes a workspace outside any call, a whisper lapse check
   * for one, kept to the rules a call keeps (SPECIFICATION 10.3): the
   * workspace is first brought up to date with the store, and left alone
   * as long as it is held; what the work changed is written once, when it ends;
   * and where that write fails, the workspace goes back to what the store
   * holds and the work's results are dropped, since none took effect.
   */
  outsideCall<T>(id: WorkspaceId, work: () => T[]): T[] {
    if (this.tracker.depth > 0) return work();
    if (this.keepUp(id)) return [];
    this.tracker.depth++;
    let out: T[];
    try {
      out = work();
    } finally {
      if (--this.tracker.depth === 0) this.flushUnflushed();
    }
    if (this.held.has(id)) {
      this.reload(id);
      return [];
    }
    return out;
  }

  /**
   * Before a call on a workspace: where the store holds a different number of
   * audit entries for it than this instance last wrote, another writer has
   * written it, and it is reloaded. A workspace held after a failed write is
   * reloaded as well, and the call refused while that fails.
   */
  private keepUp(id: WorkspaceId): ReturnType<typeof rpcError> | null {
    if (this.held.has(id)) return this.reload(id) ? null : storeFailed();
    if (typeof this.store.version !== "function" || this.saveChains.has(id)) return null;
    let stored: number | undefined;
    try {
      stored = this.store.version(id);
    } catch {
      // Unread, the store may still take the call's write; if it does not,
      // the write fails and is answered as failed.
      return null;
    }
    if (isThenable(stored)) return null;
    const ws = this.workspaces.get(id);
    const p = ws ? this.persisted.get(ws) : undefined;
    // A workspace written whole on its next write replaces the store's copy.
    if (ws && (!p || p.replace)) return null;
    if (stored === p?.seq) return null;
    return this.reload(id) ? null : storeFailed();
  }

  /** Replace a workspace with what the store holds of it. False when it cannot be read. */
  private reload(id: WorkspaceId): boolean {
    let record: WorkspaceRecord | undefined;
    try {
      if (typeof this.store.loadOne === "function") {
        record = this.store.loadOne(id);
      } else {
        const all = this.store.load();
        if (isThenable(all)) return false;
        record = (all as WorkspaceRecord[]).find((r) => r.id === id);
      }
      if (isThenable(record)) return false;
    } catch (err) {
      this.reportStoreError(err, { id, version: this.workspaces.get(id)?.audit.length ?? 0 });
      return false;
    }
    const old = this.workspaces.get(id);
    if (old) this.unflushed.delete(old);
    if (record) {
      let ws: Workspace;
      try {
        ws = this.rebuild(record.data as Record<string, unknown>);
      } catch (err) {
        this.reportStoreError(err, { id, version: record.version });
        return false;
      }
      this.workspaces.set(id, ws);
      this.markWritten(ws);
      this.wsVersions.set(id, record.version);
    } else {
      this.workspaces.delete(id);
    }
    this.held.delete(id);
    return true;
  }

  private _dispatch(envelope: Envelope): Envelope {
    // SPECIFICATION 10.1 fixes the order of the checks below, because which
    // refusal a call receives decides whether it is recorded. First the
    // request itself, none of whose refusals is recorded.
    if (!isValidEnvelope(envelope) || typeof envelope.method !== "string" || !envelope.method) {
      return reply(envelope, { error: rpcError(E.REQUEST, "Invalid JSON-RPC 2.0 request") });
    }
    if (!withinNesting(envelope, MAX_NESTING)) {
      return reply(envelope, { error: rpcError(E.REQUEST, `Envelope nests deeper than ${MAX_NESTING} levels`) });
    }
    const maxBytes = this.options.maxEnvelopeBytes ?? DEFAULT_MAX_ENVELOPE_BYTES;
    // Canonicalised once: the length is what the size limit measures, and a
    // request that cannot be canonicalised is refused below, once its method
    // is known to exist.
    let size = 0;
    let canonicalError: unknown;
    try { size = canonicalize(envelope).length; } catch (e) { canonicalError = e; }
    if (size > maxBytes) {
      return reply(envelope, { error: rpcError(E.REQUEST,
        `Envelope exceeds max_envelope_bytes (${size} > ${maxBytes})`) });
    }
    const method = envelope.method;
    // JSON-RPC params, when present, must be a structured value (object).
    // CHAP methods use by-name params; reject non-object params cleanly as
    // Invalid params for parity with the Python reference.
    const rawParams = envelope.params;
    if (
      rawParams !== undefined &&
      rawParams !== null &&
      (typeof rawParams !== "object" || Array.isArray(rawParams))
    ) {
      return reply(envelope, { error: rpcError(E.PARAMS, "Invalid params: expected an object") });
    }
    const params = (rawParams ?? {}) as Record<string, unknown>;
    const handler = this.handlers.get(method);
    if (!handler) {
      return reply(envelope, { error: rpcError(E.METHOD, `Unknown method: ${method}`) });
    }
    if (canonicalError !== undefined) {
      const msg = canonicalError instanceof Error ? canonicalError.message : String(canonicalError);
      return reply(envelope, { error: rpcError(E.PARAMS, msg) });
    }
    // A workspace is named by a non-empty string. A list or an object names
    // none, and an empty string is no id participant.join could make a
    // workspace under, so both references refuse either before any lookup.
    if (params.workspace !== undefined && (typeof params.workspace !== "string" || !params.workspace)) {
      return reply(envelope, { error: rpcError(E.PARAMS, "workspace must be a non-empty string") });
    }

    // SPECIFICATION 10.1: a signed request whose signed content matches a
    // recorded refusal is answered with that refusal and not evaluated again,
    // and one that matches an accepted call is refused with -32075. The log
    // publishes every call, signature and all, so without this anyone who can
    // read the log could send a refused request again once whatever refused
    // it had changed, or an accepted one again once it applied anew, a
    // reviewer's reject to a resubmitted artefact for instance, and it would
    // take effect in its signer's name.
    if (isSigned(envelope)) {
      const wsId = params.workspace;
      const ws = typeof wsId === "string" ? this.workspaces.get(wsId) : undefined;
      if (ws) {
        const index = this.signedIndex(ws);
        const digest = signedDigest(recordedForm(envelope));
        const prior = index.refused.get(digest);
        if (prior) {
          return reply(envelope, { error: rpcError(prior.code,
            `Refused at seq ${prior.seq}; a refused request is not evaluated again`,
            { refused_at_seq: prior.seq }) });
        }
        const accepted = index.accepted.get(digest);
        if (accepted !== undefined) {
          return reply(envelope, { error: rpcError(E.SIG_ALREADY_ACCEPTED,
            `Accepted at seq ${accepted}; a signed request takes effect once`,
            { accepted_at_seq: accepted }) });
        }
      }
    }

    // security-signed/1.0: verify the top-level sig where the workspace
    // requires signatures, because it advertises the profile or this
    // coordinator is configured to require them. participant.join and
    // workspace.create are bootstrap operations that run before any signing
    // key is registered for the actor, so they cannot be signature-verified.
    // Under the "humans" policy a call that carries no signature is taken
    // from an agent member, such as one on the server's own transport;
    // people and services sign every call.
    const target = typeof params.workspace === "string" ? this.workspaces.get(params.workspace) : undefined;
    if (this.requiresSignatures(target)
        && method !== "participant.join" && method !== "workspace.create"
        && !(!isSigned(envelope) && target !== undefined
             && !this.mustSign(target, rawMember(target, params.from)?.type))) {
      const sigErr = this.verifySignature(envelope);
      if (sigErr) return reply(envelope, { error: sigErr });
      if (method === "participant.rotate_key") {
        // A null old_kid names no key, as a null param gives no value, and
        // the handler refuses it.
        const signingKid = (envelope.sig as string).split(":")[1];
        const oldKid = params.old_kid as string | null | undefined;
        if (oldKid != null && signingKid !== oldKid) {
          return reply(envelope, { error: rpcError(E.SIG_ROTATION_KEY_MISMATCH,
            "Rotation must be signed with the old key") });
        }
      }
    }

    // identity-oidc/1.0: step-up freshness on privileged methods.
    if (this.options.enforceStepUp && PRIVILEGED_METHODS.has(method)) {
      const stale = this.checkStepUp(params);
      if (stale) return reply(envelope, { error: stale });
    }

    // SPECIFICATION 15.4: refuse a method whose owning profile the workspace
    // does not advertise. The refusal is -32601, the same answer a coordinator
    // that never implemented the method would give, so a deployment cannot
    // tell from outside which of the two it is talking to. The detail rides in
    // `data` for an operator reading the log.
    {
      const gate = this.profileGate(method, params);
      if (gate) return reply(envelope, { error: gate });
    }

    // control/1.0 and deliberation/1.0: these operations are privileged and
    // MUST be performed by a workspace member. Control is the governance
    // "emergency brake"; deliberation open/close set the vote parameters and
    // finalize the tally. Without this floor a non-member could resume a
    // paused workspace, raise the mode ceiling, or open and close a
    // deliberation to finalize an outcome early. (The per-voter eligibility
    // check in deliberate.vote is separate and still applies. A stricter role
    // gate than membership is layered on top via an identity-* profile.)
    // The routing methods and participant.leave sit under the same floor
    // (SPECIFICATION 6.3.1): without it a non-member could reassign a task
    // with task.route, or write a leave to the log under any name.
    if (method.startsWith("control.") || method.startsWith("deliberate.") || method.startsWith("handoff.") || method.startsWith("whisper.") || MEMBER_ONLY_METHODS.has(method)) {
      const wsId = params.workspace as string | undefined;
      const ws = typeof wsId === "string" ? this.workspaces.get(wsId) : undefined;
      if (ws) {
        const notMember = this.requireMember(ws, params.from);
        if (notMember) return reply(envelope, { error: notMember.error });
      }
    }

    // control/1.0 workspace-paused gate (S6 -32063).
    const exempt = new Set(["workspace.create", "workspace.describe",
                            "control.resume", "audit.read",
                            "participant.join", "participant.leave"]);
    if (!exempt.has(method)) {
      const wsId = params.workspace as string | undefined;
      if (typeof wsId === "string") {
        const ws = this.workspaces.get(wsId);
        if (ws && ws.state === "paused") {
          return reply(envelope, { error: rpcError(E.CONTROL_WORKSPACE_PAUSED, `Workspace ${wsId} is paused`) });
        }
      }
    }

    // task.create idempotency: a repeat carrying a seen idempotency_key returns
    // the original task rather than creating (or recording) a duplicate -- safe
    // for at-least-once redelivery.
    if (method === "task.create") {
      const wsId = params.workspace;
      const ws = typeof wsId === "string" ? this.workspaces.get(wsId) : undefined;
      const key = params.idempotency_key;
      if (ws && typeof key === "string") {
        const existingId = ws.idempotency_keys[key];
        const task = existingId ? ws.tasks.get(existingId) : undefined;
        if (task) return reply(envelope, { result: { task_id: existingId, state: task.state } });
      }
    }

    let out: { result?: unknown; error?: { code: number; message: string; data?: unknown } };
    try {
      // The handler works on its own copy of what the caller sent, and the
      // caller gets a copy of the result, so no object is shared between the
      // workspace and the caller. A caller that reused or changed one later
      // would change the workspace outside any call, where no change is
      // recorded for the store.
      out = handler(ownCopy(params));
    } catch (e) {
      // The caller learns only that the call failed. An exception's text can
      // name a path, a query or a value from another workspace, so it goes
      // to the operator through onInternalError and never onto the wire.
      this.reportInternalError(e, method, params.workspace as string | undefined);
      return reply(envelope, { error: rpcError(E.INTERNAL, "Internal error") });
    }
    if (out.error) return reply(envelope, { error: out.error });

    // Record audit on success. A refusal is weighed in dispatch(), once this
    // returns, against the rule in SPECIFICATION 10.1. A workspace.create
    // that names no workspace is recorded in the one it made, which was
    // otherwise left with no entry and never written to the store.
    const wsId = method === "workspace.create"
      ? (out.result as { workspace: string }).workspace
      : params.workspace as string | undefined;
    if (typeof wsId === "string" && !READ_ONLY_METHODS.has(method)) {
      const ws = this.workspaces.get(wsId);
      if (ws) this.recordAudit(ws, recordedForm(envelope));
    }
    return reply(envelope, { result: ownCopy(out.result) });
  }

  // -- audit ---------------------------------------------------------

  recordAudit(ws: Workspace, envelope: Envelope): void {
    this.appendEntry(ws, { envelope: JSON.parse(JSON.stringify(envelope)) as Envelope });
  }

  /**
   * SPECIFICATION 10.1: record a refused call when it is a governed attempt.
   * The caller must be a member of an existing workspace, the call must be a
   * JSON-RPC call for a method that is not a read, and the refusal must be one
   * `refusalIsRecorded` names. The request is kept as it arrived, so a
   * signature on it still verifies. Every call that reaches a recorded refusal
   * has passed the canonical check, so it can be hashed into the chain.
   */
  private recordRefusal(envelope: Envelope, error: { code: number; data?: unknown }): void {
    if (!isValidEnvelope(envelope) || typeof envelope.method !== "string") return;
    const method = envelope.method;
    if (READ_ONLY_METHODS.has(method)) return;
    if (!refusalIsRecorded(method, error, PRIVILEGED_METHODS)) return;
    const raw = envelope.params;
    if (raw === null || typeof raw !== "object" || Array.isArray(raw)) return;
    const params = raw as Record<string, unknown>;
    const ws = typeof params.workspace === "string" ? this.workspaces.get(params.workspace) : undefined;
    if (!ws || typeof params.from !== "string" || !ws.members.has(params.from)) return;
    // A signed copy of a call already on the log is not a new attempt by its
    // signer. A copy of a refusal was answered with it, and a copy of a call
    // that took effect repeats a call its signer made once. Anyone who can
    // read the log can send either.
    if (isSigned(envelope)) {
      const index = this.signedIndex(ws);
      const digest = signedDigest(envelope);
      if (index.refused.has(digest) || index.accepted.has(digest)) return;
    }
    this.appendEntry(ws, {
      request: JSON.parse(JSON.stringify(envelope)) as Envelope,
      outcome: { status: "refused", code: error.code },
    });
  }

  /** The signed calls on this workspace's log, built from the log when missing. */
  private signedIndex(ws: Workspace): SignedIndex {
    let index = this.signedIndexes.get(ws);
    if (!index) {
      index = { refused: new Map(), accepted: new Map() };
      for (const entry of ws.audit) indexSigned(index, entry);
      this.signedIndexes.set(ws, index);
    }
    return index;
  }

  private appendEntry(ws: Workspace, record: Pick<AuditEntry, "envelope" | "request" | "outcome">): void {
    const entry: AuditEntry = { seq: ws.audit.length, arrived: this.now(), ...record };
    if (ws.chain_enabled || this.options.enableChain) {
      const prev = ws.chain_head ?? ZERO_HASH;
      entry.prev_hash = prev;
      ws.chain_head = linkHash(entryRecord(entry), prev);
    }
    ws.audit.push(entry);
    const index = this.signedIndexes.get(ws);
    if (index) indexSigned(index, entry);
    // The listeners hear of the entry once it is written, so they never hear
    // of one the store did not take.
    const queued = this.unannounced.get(ws);
    if (queued) queued.push(entry);
    else this.unannounced.set(ws, [entry]);
    this.persist(ws);
  }

  // -- signature verification (security-signed/1.0) -----------------

  private verifySignature(envelope: Envelope): { code: number; message: string; data?: unknown } | null {
    const sig = envelope.sig;
    if (!sig || typeof sig !== "string") {
      return rpcError(E.SIG_VERIFY_FAILED, "Missing top-level `sig` field");
    }
    // ed25519:<kid>:<base64>, or webauthn:<kid>:<assertion> for a key a
    // browser's authenticator holds (security-signed/1.0 3).
    const parts = sig.split(":");
    const scheme = parts[0];
    if (parts.length !== 3 || (scheme !== "ed25519" && scheme !== "webauthn")) {
      return rpcError(E.SIG_VERIFY_FAILED, "Malformed signature tag");
    }
    const assertion = scheme === "webauthn" ? parseWebAuthnAssertion(parts[2]) : undefined;
    if (scheme === "webauthn" && !assertion) {
      return rpcError(E.SIG_VERIFY_FAILED, "Malformed signature tag");
    }
    const kid = parts[1];
    const params = (envelope.params ?? {}) as Record<string, unknown>;
    const sender = params.from;
    const wsId = params.workspace;
    const rawTs = params.ts;
    // Fail closed: a signature is present and requireSignatures is on, so it
    // must verify. If we cannot resolve the context needed to verify it,
    // reject rather than skip -- a signature we cannot check must never be
    // treated as valid. A `from` or `workspace` that is not a string names
    // nothing, so it counts as missing.
    if (typeof sender !== "string" || !sender || typeof wsId !== "string" || !wsId) {
      return rpcError(E.SIG_VERIFY_FAILED, "Cannot verify signature: missing from/workspace");
    }
    // The key is chosen by the time the sender gives. A `ts` that is not a
    // string gives no time, so no key can be chosen for it.
    if (rawTs !== undefined && rawTs !== null && typeof rawTs !== "string") {
      return rpcError(E.SIG_VERIFY_FAILED, "Cannot verify signature: ts must be a string");
    }
    const ts = (rawTs as string | null | undefined) ?? this.now();
    const ws = this.workspaces.get(wsId);
    if (!ws) {
      return rpcError(E.SIG_VERIFY_FAILED, "Cannot verify signature: unknown workspace");
    }
    const member = ws.members.get(sender);
    if (!member) return rpcError(E.SIG_KEY_NOT_FOUND, `No member: ${sender}`);

    // Revocation is present-tense: a revoked key must be rejected for any
    // live request regardless of the envelope's self-asserted `ts`. Checking
    // against `ts` alone lets a holder of a revoked key backdate `ts` to
    // before the revocation and still be accepted. Use the coordinator's
    // trusted clock for the revocation decision.
    const now = this.now();
    if (member.keys.some(k => k.kid === kid && k.revoked_at !== undefined && now >= k.revoked_at)) {
      return rpcError(E.SIG_KEY_REVOKED, `Key ${kid} is revoked`);
    }
    // Expiry is present-tense for the same reason: a rotated-out key
    // (valid_until set to the rotation time, but never explicitly revoked) must
    // not sign live requests. Selecting it by the self-asserted `ts` alone lets
    // its holder backdate `ts` to before valid_until and keep using it. Judge
    // expiry by the trusted clock.
    if (member.keys.some(k => k.kid === kid && k.valid_until !== undefined && now >= k.valid_until)) {
      return rpcError(E.SIG_KEY_NOT_FOUND, `Key ${kid} is no longer valid`);
    }

    const key = this.lookupKey(member, kid, ts);
    if (!key) {
      const revoked = member.keys.find(k => k.kid === kid && k.revoked_at);
      if (revoked) return rpcError(E.SIG_KEY_REVOKED, `Key ${kid} is revoked`);
      return rpcError(E.SIG_KEY_NOT_FOUND, `No key ${kid} valid at ${ts} for ${sender}`);
    }

    if (assertion) {
      if (!isWebAuthnKey(key.jwk)) return rpcError(E.SIG_VERIFY_FAILED, `Key ${kid} is not a WebAuthn key`);
      const stripped: Envelope = JSON.parse(JSON.stringify(envelope));
      delete stripped.sig;
      const failure = webAuthnFailure(canonicalize(stripped), assertion, key.jwk as unknown as Record<string, unknown>);
      return failure === null ? null : rpcError(E.SIG_VERIFY_FAILED, failure);
    }

    // An ed25519: tag names an Ed25519 key, and a webauthn: tag a WebAuthn
    // key, so neither key is read as the other kind.
    if (!isEd25519Key(key.jwk)) return rpcError(E.SIG_VERIFY_FAILED, `Key ${kid} is not an Ed25519 key`);
    try {
      const stripped: Envelope = JSON.parse(JSON.stringify(envelope));
      delete stripped.sig;
      const canonical = canonicalize(stripped);
      const pub = publicKeyFromJwk(key.jwk);
      if (!verifyEnvelope(canonical, sig, pub)) {
        return rpcError(E.SIG_VERIFY_FAILED, "Signature failed verification");
      }
      return null;
    } catch {
      // An exception here (malformed key or signature bytes) means the
      // signature cannot be verified: fail closed with the same generic code
      // as the Python reference, and do not leak the exception detail.
      return rpcError(E.SIG_VERIFY_FAILED, "Signature failed verification");
    }
  }

  /**
   * SPECIFICATION 6.5: an identity profile states that a verifier checks
   * people's credentials, so advertising one this coordinator has no
   * verifier for describes a guarantee it does not give.
   */
  private unverifiedIdentity(profiles: string[]): ReturnType<typeof rpcError> | null {
    const named = (name: string) => profiles.some((x) => x === name || x.startsWith(name + "/"));
    if (named("identity-oidc") && this.options.verifyOidcToken === undefined) {
      return rpcError(E.PARAMS,
        "identity-oidc/1.0 is advertised but no token verifier is configured. " +
        "A workspace that advertises it and does not enforce it " +
        "describes a guarantee it does not give.");
    }
    if (named("identity-vc") && this.options.verifyVc === undefined) {
      return rpcError(E.PARAMS,
        "identity-vc/1.0 is advertised but no presentation verifier is configured. " +
        "A workspace that advertises it and does not enforce it " +
        "describes a guarantee it does not give.");
    }
    return null;
  }

  /** Whether a workspace requires signatures: it advertises security-signed/1.0, or this coordinator is configured to. */
  private requiresSignatures(ws: Workspace | undefined): boolean {
    return !!this.options.requireSignatures || (ws !== undefined && advertises(ws, "security-signed"));
  }

  /**
   * Whether a participant of this type signs its calls in a workspace that
   * requires signatures: every participant under "all", and every one but an
   * agent under "humans". A non-member signs.
   */
  private mustSign(ws: Workspace, type: string | undefined): boolean {
    return ws.signature_policy === "all" || type !== "agent";
  }

  /** Lookup the key valid for a given participant at a given time. */
  lookupKey(member: Member, kid: string, ts: string): KeyRecord | null {
    for (const k of member.keys) {
      if (k.kid !== kid) continue;
      if (k.revoked_at !== undefined && ts >= k.revoked_at) continue;
      if (ts < k.valid_from) continue;
      if (k.valid_until !== undefined && ts >= k.valid_until) continue;
      return k;
    }
    return null;
  }

  // -- step-up (identity-oidc/1.0) -----------------------------------

  /**
   * The SPECIFICATION 15.4 check, per method rather than per namespace.
   *
   * Core is always present, so a core method is never gated. The reads in
   * ALWAYS_AVAILABLE are never gated either: a workspace must be able to ask
   * what it is and to check its own chain, and `audit.verify_chain` belongs to
   * `audit-scitt/1.0` while chaining also turns on through an option, so
   * gating it would let a workspace write a hash-linked chain it is refused
   * permission to verify.
   */
  private profileGate(method: string, params: Record<string, unknown>) {
    const owner = OWNING_PROFILE[method];
    if (owner === undefined || owner === "core/1.0" || ALWAYS_AVAILABLE.has(method)) return undefined;
    const wsId = params.workspace as string | undefined;
    const ws = typeof wsId === "string" ? this.workspaces.get(wsId) : undefined;
    if (!ws) return undefined;
    // Match on the profile name, so a workspace advertising a later minor
    // version of the owning profile still carries its methods.
    const name = owner.split("/")[0];
    if (ws.profiles.some(p => p === name || p.startsWith(name + "/"))) return undefined;
    return rpcError(E.METHOD, `Unknown method: ${method}`,
                    { profile: owner, advertised: [...ws.profiles] });
  }

  private checkStepUp(params: Record<string, unknown>): { code: number; message: string; data?: unknown } | null {
    // A `from` or `workspace` that is not a string names no member to hold to
    // step-up; the membership check answers such a call.
    const wsId = params.workspace;
    const sender = params.from;
    if (typeof wsId !== "string" || typeof sender !== "string" || !wsId || !sender) return null;
    const ws = this.workspaces.get(wsId);
    if (!ws) return null;
    const member = ws.members.get(sender);
    if (!member) return null;
    // Step-up applies to OIDC actors -- humans, or any member with an OIDC
    // binding. Agents and services authenticate out of band (SPIFFE/X.509),
    // so they are not held to an auth_time window here.
    if (member.type !== "human" && member.oidc_sub === undefined) return null;
    if (member.oidc_auth_time === undefined) {
      return rpcError(E.OIDC_STEP_UP_REQUIRED, "Step-up authentication required", {
        window_sec: ws.step_up_window_sec,
      });
    }
    const nowSec = Math.floor(Date.now() / 1000);
    const age = nowSec - member.oidc_auth_time;
    if (age > ws.step_up_window_sec) {
      return rpcError(E.OIDC_STEP_UP_REQUIRED, "Step-up authentication required", {
        window_sec: ws.step_up_window_sec, age_sec: age,
      });
    }
    if (ws.min_acr !== undefined && member.oidc_acr !== ws.min_acr) {
      return rpcError(E.OIDC_STEP_UP_REQUIRED, "Step-up required: acr below the workspace minimum", {
        required_acr: ws.min_acr, acr: member.oidc_acr,
      });
    }
    return null;
  }

  // ==========================================================
  //   Registration
  // ==========================================================

  private registerCoreHandlers(): void {
    this.handlers.set("workspace.create",       p => this.opWorkspaceCreate(p));
    this.handlers.set("workspace.describe",     p => this.opWorkspaceDescribe(p));
    this.handlers.set("workspace.set_profiles", p => this.opWorkspaceSetProfiles(p));
    this.handlers.set("workspace.invite",       p => this.opWorkspaceInvite(p));
    this.handlers.set("participant.join",       p => this.opParticipantJoin(p));
    this.handlers.set("participant.leave",      p => this.opParticipantLeave(p));
    this.handlers.set("task.create",            p => this.opTaskCreate(p));
    this.handlers.set("task.update",            p => this.opTaskUpdate(p));
    this.handlers.set("task.complete",          p => this.opTaskComplete(p));
    this.handlers.set("audit.read",             p => this.opAuditRead(p));
    this.handlers.set("review.request",         p => this.opReviewRequest(p));
    this.handlers.set("review.acknowledge",     p => this.opReviewAcknowledge(p));
    this.handlers.set("decide.approve",         p => this.opDecide(p, "approve"));
    this.handlers.set("decide.reject",          p => this.opDecide(p, "reject"));
    this.handlers.set("decide.override",        p => this.opDecideOverride(p));
    this.handlers.set("abstain.declare",        p => this.opAbstainDeclare(p));
    this.handlers.set("escalate.raise",         p => this.opEscalateRaise(p));
  }

  private registerProfileHandlers(): void {
    // Profiles register themselves by mutating this.handlers
    registerWhisper(this);
    registerDeliberation(this);
    registerHandoff(this);
    registerControl(this);
    registerRouting(this);
    registerSecuritySigned(this);
    registerAuditScitt(this);
  }

  // ==========================================================
  //   Core method handlers
  // ==========================================================

  private opWorkspaceCreate(p: Record<string, unknown>): ReturnType<Handler> {
    const built = this.buildWorkspace(p);
    if (built.error) return { error: built.error };
    this.addWorkspace(built.ws);
    return { result: { workspace: built.ws.id, created: built.ws.created } };
  }

  /**
   * The workspace a workspace.create with these params makes, or why it
   * cannot be made. Nothing is registered, so participant.join can judge a
   * join by the workspace it would make and make it only once the join
   * passes.
   */
  private buildWorkspace(p: Record<string, unknown>):
      { ws: Workspace; error?: undefined } | { ws?: undefined; error: ReturnType<typeof rpcError> } {
    const bad = paramsError(p, [
      ["profiles", "strings"], ["mode", "string"], ["mode_ceiling", "string"],
      ["routing_policy_uri", "string"], ["step_up_window_sec", "integer"], ["min_acr", "string"],
    ]);
    if (bad) return bad;
    for (const name of ["mode", "mode_ceiling"]) {
      if (p[name] != null && !MODES.has(p[name] as string)) {
        return { error: rpcError(E.PARAMS, `${name} must be shadow, trial or production`) };
      }
    }
    const policy = p.signature_policy ?? this.options.signaturePolicy ?? "all";
    if (policy !== "all" && policy !== "humans") {
      return { error: rpcError(E.PARAMS, "signature_policy must be all or humans") };
    }
    const joinPolicy = p.join_policy ?? this.options.joinPolicy ?? "open";
    if (joinPolicy !== "open" && joinPolicy !== "invite") {
      return { error: rpcError(E.PARAMS, "join_policy must be open or invite") };
    }
    const reviewRule = p.review_rule ?? undefined;
    if (reviewRule !== undefined && (typeof reviewRule !== "string" || !reviewRuleSupported(reviewRule))) {
      return { error: rpcError(E.PARAMS, "review_rule must be any_one_approves, all_approve or quorum:<n>") };
    }
    const id = (p.workspace as string) || this.ids.workspaceId();
    if (this.workspaces.has(id)) return { error: rpcError(E.PARAMS, `workspace already exists: ${id}`) };
    if (Array.isArray(p.profiles)) {
      const unknown = profilesError(p.profiles as string[]);
      if (unknown) return unknown;
    }
    const profiles: string[] = Array.isArray(p.profiles) ? [...(p.profiles as string[])] : [...(this.options.defaultProfiles ?? ["core/1.0", "review/1.0"])];

    // SPECIFICATION 6.5: the descriptor and the enforcement agree. Signatures
    // are enforced wherever security-signed/1.0 is advertised, so enforcing
    // them through the option adds the profile, and advertising it needs
    // nothing configured. A token verifier cannot follow the profile, so
    // identity-oidc/1.0 advertised with none configured describes a
    // guarantee the workspace does not give, and is refused here, where the
    // misconfiguration surfaces at once.
    const signed = profiles.some(x => x === "security-signed" || x.startsWith("security-signed/"));
    if (this.options.requireSignatures && !signed) profiles.push("security-signed/1.0");
    const oidc = profiles.some(x => x === "identity-oidc" || x.startsWith("identity-oidc/"));
    if (this.options.verifyOidcToken !== undefined && !oidc) profiles.push("identity-oidc/1.0");
    const vc = profiles.some(x => x === "identity-vc" || x.startsWith("identity-vc/"));
    if (this.options.verifyVc !== undefined && !vc) profiles.push("identity-vc/1.0");
    const unverified = this.unverifiedIdentity(profiles);
    if (unverified) return { error: unverified };

    const chainEnabled = profiles.includes("audit-scitt/1.0") || !!this.options.enableChain;
    const ws: Workspace = {
      id,
      created: this.now(),
      state: "active",
      profiles,
      mode: (p.mode as Mode) ?? "trial",
      mode_ceiling: (p.mode_ceiling as Mode) ?? "production",
      // A param given as null gives no value, as in the Python reference: a
      // null min_acr sets no minimum.
      routing_policy_uri: (p.routing_policy_uri as string | null | undefined) ?? undefined,
      step_up_window_sec: (p.step_up_window_sec as number | null | undefined) ?? 300,
      min_acr: (p.min_acr as string | null | undefined) ?? undefined,
      signature_policy: policy,
      join_policy: joinPolicy,
      ...(reviewRule !== undefined ? { review_rule: reviewRule } : {}),
      members: this.newMap(),
      tasks: this.newMap(),
      overrides: this.newMap(),
      whispers: this.newMap(),
      deliberations: this.newMap(),
      handoffs: this.newMap(),
      snapshots: this.newMap(),
      route_decisions: this.newMap(),
      invitations: this.newMap(),
      idempotency_keys: {},
      audit: [],
      chain_enabled: chainEnabled,
      chain_head: chainEnabled ? ZERO_HASH : undefined,
    };
    return { ws };
  }

  private addWorkspace(ws: Workspace): void {
    this.workspaces.set(ws.id, ws);
    // New here, so the store holds nothing of it yet.
    this.persisted.set(ws, { seq: 0, replace: false, keys: new Set() });
  }

  private opWorkspaceDescribe(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, `Unknown workspace: ${p.workspace}`) };
    if (this.options.requireReadMembership) {
      const notMember = this.requireMember(ws, p.from);
      if (notMember) return notMember;
    }
    return { result: {
      id: ws.id,
      created: ws.created,
      state: ws.state,
      mode: ws.mode,
      mode_ceiling: ws.mode_ceiling,
      max_envelope_bytes: this.options.maxEnvelopeBytes ?? DEFAULT_MAX_ENVELOPE_BYTES,
      step_up_window_sec: ws.step_up_window_sec,
      signature_policy: ws.signature_policy,
      join_policy: ws.join_policy,
      review_rule: ws.review_rule ?? "any_one_approves",
      profiles: ws.profiles,
      members: Array.from(rawValues(ws.members)).map(memberToDict),
      audit_count: ws.audit.length,
      task_count: ws.tasks.size,
      override_count: ws.overrides.size,
      // Omitted where the workspace has no chain, which is what the Python
      // reference now sends too: JSON.stringify drops an undefined value, so
      // the two answered the same call differently on the wire.
      ...(ws.chain_head ? { evidence_head: ws.chain_head } : {}),
      ...(ws.routing_policy_uri ? { routing_policy_uri: ws.routing_policy_uri } : {}),
    }};
  }

  private opWorkspaceSetProfiles(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "profiles"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    if (!Array.isArray(p.profiles) || !p.profiles.every((x) => typeof x === "string")) {
      return { error: rpcError(E.PARAMS, "profiles must be a list of strings") };
    }
    const unknown = profilesError(p.profiles as string[]);
    if (unknown) return unknown;
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    if (ws.members.get(p.from as string)!.role !== "admin") {
      return { error: rpcError(E.NOT_AUTHORISED, "workspace.set_profiles requires the admin role") };
    }
    // A workspace that requires signatures keeps requiring them, and one that
    // says its people are verified keeps verifying them. Removing either
    // profile would turn its checks off for every call after this one, and
    // the calls the log holds from then on would carry no assurance of who
    // sent them.
    const newProfiles = [...(p.profiles as string[])];
    for (const name of LASTING_PROFILES) {
      const held = ws.profiles.find((x) => x === name || x.startsWith(name + "/"));
      if (held !== undefined && !newProfiles.some((x) => x.startsWith(name + "/"))) {
        return { error: rpcError(E.NOT_AUTHORISED, `${held} cannot be removed once advertised`) };
      }
    }
    const unverified = this.unverifiedIdentity(newProfiles);
    if (unverified) return { error: unverified };
    if (!newProfiles.some(pr => pr.startsWith("core/"))) newProfiles.push("core/1.0");
    ws.profiles = newProfiles;
    if (newProfiles.includes("audit-scitt/1.0") && !ws.chain_enabled) {
      ws.chain_enabled = true;
      ws.chain_head = ZERO_HASH;
    }
    return { result: { profiles: ws.profiles } };
  }

  private opParticipantJoin(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "type"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    // The member is stored under its URI and read by its type, so neither
    // may be null.
    for (const f of ["from", "type"]) {
      if (typeof p[f] !== "string") return { error: rpcError(E.PARAMS, `${f} must be a string`) };
    }
    // SPECIFICATION 5.1: a participant is one of five types, and the scheme
    // of its URI names the type. Otherwise "human:mallory" could join as an
    // agent, which the "humans" signature policy lets call unsigned, and
    // still read as a person on the log.
    const type = p.type as string;
    const named = participantError(type, p.from as string, "from");
    if (named) return named;
    const bad = paramsError(p, [
      ["role", "string"], ["display_name", "string"], ["scopes", "strings"],
      ["capabilities", "object"], ["jwks", "object"], ["jwks.keys", "list"],
      ["oidc_token", "string"], ["vc_presentation", "object"],
    ]);
    if (bad) return bad;
    if (p.role === "admin" && !ADMIN_TYPES.includes(type)) {
      return { error: rpcError(E.PARAMS, "The admin role is held by a human or a service") };
    }
    // A join may make its workspace. It is judged by the workspace it would
    // make, which is registered only once the join passes, so a refused join
    // leaves nothing behind.
    let ws = this.workspaces.get(p.workspace as string);
    const made = ws === undefined;
    if (!ws) {
      const built = this.buildWorkspace({ workspace: p.workspace });
      if (built.error) return { error: built.error };
      ws = built.ws;
    }
    const uri = p.from as ParticipantUri;
    const now = this.now();
    const existing = ws.members.get(uri);
    let tokenVerified = false;
    let holderVerified = false;
    let credentialBound = false;

    // SPECIFICATION 6.3: a newcomer joins in the role an admin's invitation
    // names, else in the role it asks for. The admin role is granted, never
    // claimed: by an invitation, or to the first member, who is the admin of
    // a workspace that admits by invitation. Taken by anyone who asked, it
    // would let an agent drop the workspace's identity profile or revoke a
    // person's key.
    const invitation = existing ? undefined : rawInvitation(ws, uri);
    const asked = typeof p.role === "string" && p.role !== "" ? p.role : undefined;
    let role = asked ?? "participant";
    if (!existing) {
      const first = awaitsFirstMember(ws);
      if (ws.join_policy === "invite" && !invitation && !(first && ADMIN_TYPES.includes(type))) {
        return { error: rpcError(E.NOT_AUTHORISED, `${uri} has no invitation to this workspace`) };
      }
      if (invitation?.role !== undefined) {
        if (asked === "admin" && invitation.role !== "admin") {
          return { error: rpcError(E.NOT_AUTHORISED, "The admin role is granted by an admin") };
        }
        role = invitation.role;
      } else if (first && ws.join_policy === "invite") {
        if (asked !== undefined && asked !== "admin") {
          return { error: rpcError(E.PARAMS,
            "The first member of a workspace that admits by invitation is its admin") };
        }
        role = "admin";
      } else if (asked === "admin" && !first) {
        return { error: rpcError(E.NOT_AUTHORISED, "The admin role is granted by an admin") };
      }
    }

    // identity-oidc/1.0 and identity-vc/1.0: where a verifier is configured
    // and the workspace advertises its profile, a person joins with the
    // credential it checks. Otherwise a workspace that says its people are
    // verified would admit one on nobody's word. Where both apply either
    // will do, since the two coexist (identity-vc/1.0 2).
    if (type === "human") {
      const oidc = this.options.verifyOidcToken !== undefined && advertises(ws, "identity-oidc");
      const vc = this.options.verifyVc !== undefined && advertises(ws, "identity-vc");
      const presented = (oidc && typeof p.oidc_token === "string") || (vc && isObject(p.vc_presentation));
      if ((oidc || vc) && !presented) {
        return { error: oidc
          ? rpcError(E.OIDC_TOKEN_INVALID, vc
            ? "An oidc_token or a vc_presentation is required to join as a human participant"
            : "An oidc_token is required to join as a human participant")
          : rpcError(E.VC_VP_INVALID, "A vc_presentation is required to join as a human participant") };
      }
    }

    const member: Member = {
      uri,
      type: type as Member["type"],
      role,
      joined: now,
      display_name: p.display_name as string | undefined,
      capabilities: p.capabilities as Record<string, unknown> | undefined,
      scopes: p.scopes as string[] | undefined,
      keys: [],
      paused: false,
    };

    // An invitation that names a token subject admits a join carrying a token
    // for that subject, which only a configured verifier can check.
    if (invitation?.oidc_sub !== undefined
        && (this.options.verifyOidcToken === undefined || typeof p.oidc_token !== "string")) {
      return { error: rpcError(E.OIDC_TOKEN_INVALID, "An oidc_token is required: the invitation names a token subject") };
    }

    // identity-oidc/1.0
    if (this.options.verifyOidcToken && typeof p.oidc_token === "string") {
      const claims = this.options.verifyOidcToken(p.oidc_token);
      if (claims === null) return { error: rpcError(E.OIDC_TOKEN_INVALID, "OIDC token invalid") };
      // A token binds only to the participant it belongs to. One naming
      // another participant is refused, and a join under an existing member's
      // name must carry a token for that member: the same subject, or, for a
      // member with no verified subject yet, a token naming the member.
      const boundUri = claims.chap_participant_uri;
      const sub = typeof claims.sub === "string" && claims.sub !== "" ? claims.sub : undefined;
      if (boundUri != null && boundUri !== uri) {
        return { error: rpcError(E.OIDC_CNF_MISMATCH, "OIDC token is bound to another participant") };
      }
      if (invitation?.oidc_sub !== undefined && sub !== invitation.oidc_sub) {
        return { error: rpcError(E.OIDC_CNF_MISMATCH, "OIDC token subject does not match the invitation") };
      }
      if (existing) {
        if (existing.oidc_sub != null) {
          if (sub !== existing.oidc_sub) {
            return { error: rpcError(E.OIDC_CNF_MISMATCH, "OIDC token subject does not match the member") };
          }
        } else if (boundUri !== uri) {
          return { error: rpcError(E.OIDC_CNF_MISMATCH, "OIDC token does not name this member") };
        }
      } else if (type === "human" && boundUri !== uri && invitation?.oidc_sub === undefined) {
        // A provider vouches for its user, and only the token, or an admin's
        // invitation naming the token's subject, says which participant that
        // user is. Otherwise any user of the provider takes any free name.
        return { error: rpcError(E.OIDC_CNF_MISMATCH, "OIDC token does not name this participant") };
      }
      member.oidc_sub = sub;
      tokenVerified = true;
      // A NumericDate may carry a fraction; both coordinators keep whole
      // seconds, and nothing that is not a finite number.
      const at = claims.auth_time;
      if (typeof at === "number" && Number.isFinite(at) && Math.abs(at) <= Number.MAX_SAFE_INTEGER) member.oidc_auth_time = Math.floor(at);
      member.oidc_acr = typeof claims.acr === "string" ? claims.acr : undefined;
      // The token binds the key in its cnf.jwk or, with none, the key whose
      // thumbprint is its nonce: a client that cannot have the key put in the
      // token puts its thumbprint in the nonce it asks the identity provider
      // for. A join that brings another key is refused, so a token taken
      // from its holder admits no key of the taker's.
      const cnf = isObject(claims.cnf) ? claims.cnf.jwk : undefined;
      const bound = credentialKeys(cnf, cnf == null ? claims.nonce : undefined, signingKeys(p.jwks));
      if (bound === null) return { error: rpcError(E.OIDC_CNF_MISMATCH, "The join's keys are not the key the token binds") };
      if (bound !== undefined) {
        credentialBound = true;
        for (const j of bound) member.keys.push({ jwk: j as unknown as KeyRecord["jwk"], kid: j.kid, valid_from: now });
      }
    }
    // identity-vc/1.0
    if (this.options.verifyVc && isObject(p.vc_presentation)) {
      const subject = this.options.verifyVc(p.vc_presentation);
      if (subject === null) return { error: rpcError(E.VC_VP_INVALID, "VC presentation invalid") };
      const holder = [subject.holder, subject.id].find(
        (h): h is string => typeof h === "string" && h !== "");
      // A join under an existing member's name binds a presentation only from
      // the member's own holder.
      if (existing && (existing.vc_holder == null || holder !== existing.vc_holder)) {
        return { error: rpcError(E.VC_HOLDER_BINDING_INVALID, "Presentation holder does not match the member") };
      }
      member.vc_holder = holder;
      holderVerified = true;
      const bound = credentialKeys(subject.cnf_jwk, undefined, signingKeys(p.jwks));
      if (bound === null) {
        return { error: rpcError(E.VC_HOLDER_BINDING_INVALID, "The join's keys are not the key the presentation binds") };
      }
      if (bound !== undefined) {
        credentialBound = true;
        for (const j of bound) member.keys.push({ jwk: j as unknown as KeyRecord["jwk"], kid: j.kid, valid_from: now });
      }
    }

    // A person a credential verifies signs with a key the credential binds,
    // or one an invitation pins: keys the join asserts on its own are not
    // the person's on anyone's word.
    if (!existing && type === "human" && (tokenVerified || holderVerified) && !credentialBound
        && !invitation?.jwks && signingKeys(p.jwks).length > 0) {
      return { error: tokenVerified
        ? rpcError(E.OIDC_CNF_MISMATCH, "The token binds no key: a person it verifies signs with a key it binds")
        : rpcError(E.VC_HOLDER_BINDING_INVALID,
          "The presentation binds no key: a person it verifies signs with a key it binds") };
    }

    // An invitation that pins keys names the keys the member signs with: the
    // join's own keys, and a key an identity profile binds, are among them,
    // and the member holds the pinned keys.
    const pinned = invitation?.jwks?.keys;
    if (pinned) {
      const strays = [...signingKeys(p.jwks), ...member.keys.map((k) => k.jwk as unknown as Record<string, unknown>)]
        .filter((j) => !pinned.some((k) => sameKey(k as unknown as Record<string, unknown>, j)));
      if (strays.length) {
        return { error: rpcError(E.NOT_AUTHORISED, `${uri} joins with keys its invitation does not name`,
          { kids: [...new Set(strays.map((j) => j.kid))] }) };
      }
      member.keys = pinned.map((j) => ({ jwk: j, kid: j.kid, valid_from: now }));
    }

    const attested = [...member.keys];

    // Self-asserted JWKs are ignored for an identity-bound participant: the
    // verifier-pinned key is the signing key (proof of possession).
    if (attested.length === 0) {
      for (const j of signingKeys(p.jwks)) {
        if (!member.keys.some(k => k.kid === j.kid)) {
          member.keys.push({ jwk: j as unknown as KeyRecord["jwk"], kid: j.kid, valid_from: now });
        }
      }
    }

    if (existing) {
      // A member's keys change through participant.rotate_key, which the old
      // key signs. A join under the member's name that brings only keys the
      // member does not hold, and no identity binding one, is refused: the
      // name is held by other keys, and answering it as joined would leave
      // its sender holding a key nothing here accepts.
      if (attested.length === 0) {
        const keys = signingKeys(p.jwks);
        const held = keys.some((j) => existing.keys.some((k) => sameKey(k.jwk as unknown as Record<string, unknown>, j)));
        if (keys.length > 0 && !held) {
          return { error: rpcError(E.NOT_AUTHORISED,
            `${uri} is already a member, with other keys; a new key arrives through participant.rotate_key`,
            { kids: [...new Set(keys.map((j) => j.kid))] }) };
        }
      }
      if (member.oidc_sub !== undefined) existing.oidc_sub = member.oidc_sub;
      if (member.oidc_auth_time !== undefined) existing.oidc_auth_time = member.oidc_auth_time;
      if (member.oidc_acr !== undefined) existing.oidc_acr = member.oidc_acr;
      if (tokenVerified) existing.oidc_acr = member.oidc_acr;
      if (member.vc_holder !== undefined) existing.vc_holder = member.vc_holder;
      for (const k of attested) {
        if (!existing.keys.some(x => x.kid === k.kid)) existing.keys.push(k);
      }
      return { result: { joined: true, as: uri } };
    }
    // A participant that signs its calls joins with a key: without one it
    // would hold a name it could never sign for. The key may be its own, or
    // one an identity profile or an invitation binds.
    if (this.requiresSignatures(ws) && this.mustSign(ws, type) && member.keys.length === 0) {
      return { error: rpcError(E.PARAMS, `${uri} must sign in this workspace, and joins with no key`) };
    }
    if (made) this.addWorkspace(ws);
    ws.members.set(uri, member);
    if (invitation) ws.invitations.delete(uri);
    return { result: { joined: true, as: uri } };
  }

  /**
   * SPECIFICATION 6.3.3: an admin invites a participant. For a URI that is
   * not a member it records an invitation, which the invitee's join takes
   * up. For a member that holds no key in force it registers the
   * invitation's keys: the way back for a member whose keys were all revoked,
   * or who joined a workspace that requires signatures with none.
   */
  private opWorkspaceInvite(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "uri", "type"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    for (const f of ["uri", "type"]) {
      if (typeof p[f] !== "string") return { error: rpcError(E.PARAMS, `${f} must be a string`) };
    }
    const bad = paramsError(p, [
      ["role", "string"], ["jwks", "object"], ["jwks.keys", "list"], ["oidc_sub", "string"],
    ]);
    if (bad) return bad;
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    if (rawMember(ws, p.from)!.role !== "admin") {
      return { error: rpcError(E.NOT_AUTHORISED, "workspace.invite requires the admin role") };
    }
    const uri = p.uri as ParticipantUri;
    const type = p.type as string;
    const named = participantError(type, uri, "uri");
    if (named) return named;
    const role = typeof p.role === "string" && p.role !== "" ? p.role : undefined;
    if (role === "admin" && !ADMIN_TYPES.includes(type)) {
      return { error: rpcError(E.PARAMS, "The admin role is held by a human or a service") };
    }
    const sub = typeof p.oidc_sub === "string" ? p.oidc_sub : undefined;
    if (sub !== undefined && this.options.verifyOidcToken === undefined) {
      return { error: rpcError(E.PARAMS, "oidc_sub names a token subject, and this Coordinator has no token verifier") };
    }
    let pinned: Array<Jwk & Record<string, unknown>> | undefined;
    if (p.jwks != null) {
      pinned = signingKeys(p.jwks) as unknown as Array<Jwk & Record<string, unknown>>;
      if (pinned.length === 0) return { error: rpcError(E.PARAMS, "jwks names no key: each key needs a kid") };
    }
    const now = this.now();
    const member = ws.members.get(uri);
    if (member) {
      // A member's keys otherwise change through participant.rotate_key,
      // which a key it holds signs.
      if (member.keys.some((k) => inForce(k, now))) {
        return { error: rpcError(E.PARAMS,
          `${uri} is a member and holds a key in force; its keys change through participant.rotate_key`) };
      }
      if (!pinned) {
        return { error: rpcError(E.PARAMS, `${uri} is a member; an invitation for a member registers the keys its jwks names`) };
      }
      // Where a token verifier is configured, a person's key is the one their
      // token binds, and they register a new one by joining again with it.
      // Registered here, it would be a key the admin chose, and the admin
      // could revoke a person's keys and sign as them.
      if ((this.options.verifyOidcToken !== undefined && (member.type === "human" || member.oidc_sub !== undefined))
          || (this.options.verifyVc !== undefined && (member.type === "human" || member.vc_holder !== undefined))) {
        return { error: rpcError(E.PARAMS,
          `${uri} registers a new key by joining again with a token that binds it; an invitation does not register a person's keys here`) };
      }
      if ((role !== undefined && role !== member.role) || (sub !== undefined && sub !== member.oidc_sub)) {
        return { error: rpcError(E.PARAMS, `${uri} is a member; an invitation for a member registers keys and changes nothing else`) };
      }
      // A kid names one key for good: a signature naming a revoked kid is
      // refused whatever key holds it now.
      const reused = pinned.find((j) => member.keys.some((k) => k.kid === j.kid));
      if (reused) return { error: rpcError(E.PARAMS, `Key ${reused.kid} was ${uri}'s; a new key takes a new kid`) };
      for (const j of pinned) member.keys.push({ jwk: j, kid: j.kid, valid_from: now });
      return { result: { invited: true, uri, registered: pinned.map((j) => j.kid) } };
    }
    // Where a token verifier is configured, a person's keys arrive with the
    // token or presentation they join with. Pinned here, they would be keys
    // the admin chose, which a join whose token binds no key would take up,
    // and the admin could sign as the person.
    if (pinned && (type === "human" || sub !== undefined)
        && (this.options.verifyOidcToken !== undefined || this.options.verifyVc !== undefined)) {
      return { error: rpcError(E.PARAMS,
        `${uri} joins with a token that binds its key; an invitation does not register a person's keys here`) };
    }
    const invitation: Invitation = {
      uri, type: type as Invitation["type"], invited_by: p.from as ParticipantUri, invited_at: now,
    };
    if (role !== undefined) invitation.role = role;
    if (pinned) invitation.jwks = { keys: pinned };
    if (sub !== undefined) invitation.oidc_sub = sub;
    ws.invitations.set(uri, invitation);
    return { result: { invited: true, uri } };
  }

  private opParticipantLeave(p: Record<string, unknown>): ReturnType<Handler> {
    // Self-removal: deletes the caller's own `from`. Under requireSignatures the
    // signature binds `from`, so a member can only remove itself; evicting
    // another member is an admin operation, not this. Unsigned, a spoofed
    // `from` is the transport's responsibility.
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    // A member that left and joined again would come back unpaused, so a
    // paused member stays until another member lifts its pause.
    if (rawMember(ws, p.from)?.paused) {
      return { error: rpcError(E.NOT_AUTHORISED, "A paused participant does not leave until another member lifts its pause") };
    }
    ws.members.delete(p.from as string);
    return { result: { left: true } };
  }

  private opTaskCreate(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "kind", "input"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    // A param of the wrong type is refused, so both references read the same
    // task from the same call.
    const bad = paramsError(p, [
      ["assignee", "string"], ["to", "string"], ["mode", "string"], ["review_required", "boolean"],
      ["routing_hints", "object"], ["idempotency_key", "string"],
    ]);
    if (bad) return bad;
    // The keys live in a plain object, where these names belong to the
    // object itself: "__proto__" was never stored, so a retry made a second
    // task here and found the first in Python.
    if (RESERVED_KEYS.includes(p.idempotency_key as string)) {
      return { error: rpcError(E.PARAMS, "idempotency_key must not be __proto__, constructor or prototype") };
    }
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const assignee = (p.assignee as string) || (p.to as string);
    if (typeof assignee !== "string" || !ws.members.has(assignee)) {
      return { error: rpcError(E.PARAMS, "Assignee not in workspace") };
    }
    if (ws.members.get(assignee)!.paused) {
      return { error: rpcError(E.CONTROL_WORKSPACE_PAUSED, `Assignee ${assignee} is paused`) };
    }

    // modes/1.0 ceiling check.
    const requestedMode = ((p.mode as Mode) || ws.mode);
    if (!modeLE(requestedMode, ws.mode_ceiling)) {
      return { error: rpcError(E.MODE_CEILING_EXCEEDED,
        `Requested mode ${requestedMode} exceeds ceiling ${ws.mode_ceiling}`) };
    }

    const taskId = this.ids.taskId();
    const now = this.now();
    const task: Task = {
      id: taskId,
      kind: p.kind as string,
      state: "created",
      assignee,
      delegator: p.from as ParticipantUri,
      input: p.input as Record<string, unknown>,
      created_at: now,
      updated_at: now,
      deadline: p.deadline as string | undefined,
      mode: requestedMode,
      routing_hints: p.routing_hints as Task["routing_hints"],
      history: [{ ts: now, from: p.from as ParticipantUri, state: "created" }],
      paused: false,
    };

    // modes/1.0: trial mode forces review
    // modes/1.0: trial forces review, but only when the workspace opted into
    // modes/1.0. mode is inert without the profile.
    if (ws.profiles.some(pr => pr.startsWith("modes/")) && task.mode === "trial") task.review_required = true;
    else if ("review_required" in p) task.review_required = !!p.review_required;

    ws.tasks.set(taskId, task);
    if (typeof p.idempotency_key === "string") {
      ws.idempotency_keys[p.idempotency_key] = taskId;
      this.markKey(ws, p.idempotency_key);
      const keys = Object.keys(ws.idempotency_keys);
      if (keys.length > MAX_IDEMPOTENCY_KEYS) {
        delete ws.idempotency_keys[keys[0]];
        this.markKey(ws, keys[0]);
      }
    }
    return { result: { task_id: taskId, state: "created" } };
  }

  private opTaskUpdate(p: Record<string, unknown>): ReturnType<Handler> {
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const task = ws.tasks.get(p.task_id as string);
    if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
    // The state is required, and is written into the refusal below.
    if (typeof p.state !== "string") return { error: rpcError(E.PARAMS, "state must be a string") };
    const newState = p.state as Task["state"];
    // Pausing and resuming both belong to control/1.0. A Core-only workspace
    // that could pause through task.update would hold a task nothing it
    // advertises can lift. A review opens with review.request, or with
    // task.complete on a task that requires one: task.update into
    // review_requested would leave the task under review with no review for a
    // decision to act on.
    const legal: Record<string, string[]> = {
      created:          ["in_progress", "declined"],
      in_progress:      ["in_progress", "completed", "declined"],
      review_requested: ["in_progress"],
      paused:           ["cancelled"],
    };
    if (!legal[task.state]?.includes(newState)) {
      return { error: rpcError(E.PARAMS, `Illegal transition ${task.state} -> ${newState}`) };
    }
    // task.complete opens a review, and does not complete, when one is
    // required or when the task holds a review already. task.update reaches
    // the same state by another route and carries no output, so completing
    // here would record a finished task with nothing reviewed and no decision
    // on the chain.
    if (newState === "completed" && reviewRequired(ws, task)) {
      return { error: rpcError(E.PARAMS,
        "This task requires review. Submit the output with task.complete, which opens the review; a reviewer decision completes it.") };
    }
    if (newState === "completed" && task.review) {
      return { error: rpcError(E.PARAMS,
        "This task holds a review. Submit the output with task.complete, which opens a new round; a reviewer decision completes it.") };
    }
    // A review once opened is decided. Its authors may take their work back
    // to revise it, and nobody else; and a task whose review no decision has
    // closed is not declined around it.
    if (task.state === "review_requested" && !task.review!.authors.includes(p.from as ParticipantUri)) {
      return { error: rpcError(E.NOT_AUTHORISED,
        "Only the authors of the work under review take it back from review") };
    }
    if (newState === "cancelled" && openRequiredReviewAuthors(ws, task).includes(p.from as ParticipantUri)) {
      return { error: rpcError(E.NOT_AUTHORISED,
        "The authors of the work under review cannot end its review without a decision") };
    }
    if (newState === "declined" && task.review && !task.review.decisions.some((d) => d.kind === "reject")) {
      return { error: rpcError(E.PARAMS,
        "This task holds a review no decision has closed; a reviewer's decision ends it") };
    }
    if (newState === "declined" && !task.review && openRequiredReviewAuthors(ws, task).length > 0) {
      return { error: rpcError(E.PARAMS,
        "This task carries on a review no decision has closed; completing it opens the review a reviewer decides") };
    }
    task.state = newState;
    task.updated_at = this.now();
    task.history.push({
      ts: task.updated_at, from: p.from as ParticipantUri,
      state: newState, note: p.progress_note as string | undefined,
    });
    return { result: { state: newState } };
  }

  private opTaskComplete(p: Record<string, unknown>): ReturnType<Handler> {
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const task = ws.tasks.get(p.task_id as string);
    if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
    // Completion is only legal from an active, non-terminal, non-paused state.
    // An allowlist (rather than a denylist of terminal states) is safer: any
    // state not listed -- cancelled, superseded, paused, already
    // completed/declined, abstained, escalated -- is rejected, so completion
    // can neither revive a terminated task nor bypass a pause.
    if (task.state !== "created" && task.state !== "in_progress") {
      return { error: rpcError(E.PARAMS, `Cannot complete task in state: ${task.state}`) };
    }
    if (p.confidence != null && typeof p.confidence !== "number" && typeof p.confidence !== "string") {
      return { error: rpcError(E.PARAMS, "confidence must be a number or a string") };
    }
    // The assignee does the work a person reviews. A completion from anyone
    // else would make them an author, and an author cannot decide: routing a
    // task to a reviewer and completing it would take that reviewer off the
    // review.
    const required = reviewRequired(ws, task);
    if (required && p.from !== task.assignee) {
      return { error: rpcError(E.NOT_AUTHORISED, "Only the assignee completes a task that requires review") };
    }
    // review/1.0 S3.1: task.complete on a task whose review is required opens a
    // review implicitly and does not complete, and so does task.complete on a
    // task that holds a review from an earlier round. The submitted output
    // becomes the artefact under review; only a reviewer decision (decide.*)
    // then takes the task to completed. Without this a review_required task
    // would reach completed with unreviewed output and no decision, and a task
    // taken back from review with task.update would complete with none.
    if (required || task.review) {
      const now = this.now();
      // The assignee and the completer made this artefact, and neither may
      // decide it.
      const authors = authorsOf(task, p.from);
      let note = OPENED_ON_COMPLETE;
      if (!task.review) {
        // review_required means a person has to see this. The producer must
        // not satisfy its own review, and neither must another agent: an agent
        // approving an agent leaves a decide.approve on the chain that reads
        // as human oversight and is not. So the implicit review is addressed
        // to the human members other than the authors, and where there are
        // none the completion is refused: a review no person can decide would
        // never close.
        const eligible = [...rawEntries(ws.members)]
          .filter(([uri, member]) => !authors.includes(uri) && member.type === "human")
          .map(([uri]) => uri);
        if (eligible.length === 0) {
          return { error: rpcError(E.NOT_AUTHORISED,
            "Task requires review but has no eligible human reviewer (needs a human member other than its assignee and completer)") };
        }
        task.review = { requested_at: now, requested_to: eligible as ParticipantUri[], rule: ws.review_rule ?? "any_one_approves",
                        decisions: [], authors, acknowledgements: [] };
      } else {
        // The task held a review already: it went back to in_progress through
        // task.update or a reject with request_revision, and this completion
        // submits a new artefact. A decision counts only for the artefact it
        // was made on, so the new round starts with no decisions; kept, an
        // approval of the earlier artefact would count towards the rule on
        // this one. The reviewers and the rule stay, so a revision cannot
        // weaken the review. The authors of the new artefact are left out of
        // the reviewers, and so is any member who is not a person where the
        // review is required; where nobody remains, the completion is refused.
        // The authors of the earlier rounds stay authors of this one: the work
        // is theirs as well, whoever resubmits it.
        const roundAuthors = unionOf(task.review.authors, authors);
        const reviewers = task.review.requested_to.filter((r) => !roundAuthors.includes(r)
          && !(required && rawMember(ws, r) !== undefined && rawMember(ws, r)!.type !== "human"));
        if (reviewers.length === 0) {
          return { error: rpcError(E.NOT_AUTHORISED,
            "No reviewer of this task remains once the authors of the work are left out") };
        }
        task.review = { ...task.review, requested_at: now, requested_to: reviewers, decisions: [],
                        authors: roundAuthors, acknowledgements: [] };
        note = NEW_ROUND_ON_COMPLETE;
      }
      task.pending_artefact = p.output;
      task.state = "review_requested";
      task.updated_at = now;
      task.history.push({ ts: now, from: p.from as ParticipantUri, state: "review_requested", note });
      return { result: { state: "review_requested", review_id: task.id } };
    }
    task.output = p.output;
    if (p.confidence != null) task.confidence = p.confidence as number | string;
    task.state = "completed";
    task.updated_at = this.now();
    task.history.push({ ts: task.updated_at, from: p.from as ParticipantUri, state: "completed" });
    return { result: { state: "completed" } };
  }

  private opAuditRead(p: Record<string, unknown>): ReturnType<Handler> {
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    if (this.options.requireReadMembership) {
      const notMember = this.requireMember(ws, p.from);
      if (notMember) return notMember;
    }
    // A range or filter that is not an object reads as none. Within one, a
    // field the read compares or slices by must be of its type.
    const bad = paramsError(p, [
      ["range.from_seq", "integer"], ["range.to_seq", "integer"],
      ["filter.method", "string"], ["filter.from", "string"], ["filter.task_id", "string"],
    ]);
    if (bad) return bad;
    const range = (isObject(p.range) ? p.range : {}) as { from_seq?: number; to_seq?: number };
    const filter = (isObject(p.filter) ? p.filter : {}) as {
      method?: string; from?: string; task_id?: string; outcome?: unknown;
    };
    if (filter.outcome != null && filter.outcome !== "accepted" && filter.outcome !== "refused") {
      return { error: rpcError(E.PARAMS, "filter.outcome must be 'accepted' or 'refused'") };
    }
    const fromSeq = range.from_seq ?? 0;
    const toSeq = range.to_seq ?? ws.audit.length;
    const out: unknown[] = [];
    for (const entry of ws.audit.slice(fromSeq, toSeq)) {
      // Filters read the call an entry records, accepted or refused, and
      // `outcome` narrows to one kind.
      const refused = entry.outcome != null;
      if (filter.outcome === "accepted" && refused) continue;
      if (filter.outcome === "refused" && !refused) continue;
      const call = entryCall(entry) ?? ({} as Envelope);
      const ep = (call.params ?? {}) as Record<string, unknown>;
      if (filter.method && call.method !== filter.method) continue;
      if (filter.from && ep.from !== filter.from) continue;
      if (filter.task_id) {
        let taskId = ep.task_id;
        if (call.method === "whisper.answer") {
          const prompt = ws.whispers.get(ep.whisper_id as string);
          taskId = prompt ? (prompt as { task_id?: string }).task_id : undefined;
        }
        if (taskId !== filter.task_id) continue;
      }
      const item: Record<string, unknown> = { seq: entry.seq, arrived: entry.arrived };
      if (refused) {
        item.request = entry.request;
        item.outcome = entry.outcome;
      } else {
        item.envelope = entry.envelope;
      }
      if (entry.prev_hash) item.prev_hash = entry.prev_hash;
      out.push(item);
    }
    // The next entry to read: the end of the range, or the end of the log
    // where the range runs past it, so a reader paging forward meets the
    // entries written after this read.
    return { result: { entries: out, next_seq: Math.min(toSeq, ws.audit.length) } };
  }

  // ==========================================================
  //   review/1.0 handlers
  // ==========================================================

  private opReviewRequest(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "task_id", "artefact"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const task = ws.tasks.get(p.task_id as string);
    if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
    // task.complete refuses a task that has been stopped, so that a completion
    // "can neither revive a terminated task nor bypass a pause". review.request
    // creates the same kind of state and had no such check, so it revived
    // cancelled and superseded tasks and pulled paused ones back into play. The
    // same three states are refused here.
    //
    // `completed` is deliberately still allowed. Requesting review on a
    // completed task is how every framework bridge submits a draft, and
    // 0.2.12's `review_required` is the route away from that, not this.
    if (REVIEW_REQUEST_STOPPED.includes(task.state)) {
      return { error: rpcError(E.NOT_REVIEWABLE, `Cannot request review for task in state: ${task.state}`) };
    }
    const to = p.to;
    if (to != null && typeof to !== "string"
        && !(Array.isArray(to) && to.every((r) => typeof r === "string"))) {
      return { error: rpcError(E.PARAMS, "to must be a string or a list of strings") };
    }
    const reviewers: string[] = Array.isArray(to) ? (to as string[]) : typeof to === "string" ? [to] : [];
    if (!reviewers.length) return { error: rpcError(E.PARAMS, "review.request needs 'to'") };
    const bad = paramsError(p, [["rule", "string"]]);
    if (bad) return bad;
    const now = this.now();
    const declaredRule = p.rule as string | undefined;
    const rule = declaredRule || "any_one_approves";
    if (!reviewRuleSupported(rule)) {
      return { error: rpcError(E.PARAMS, `Unsupported review rule ${JSON.stringify(rule)}: review/1.0 supports any_one_approves, all_approve, quorum:<n>`) };
    }

    // A review already open on this task. Replacing the artefact underneath
    // it would let a reviewer decide on content they never saw, and would
    // discard decisions already cast while their envelopes remain in the
    // audit log, so a quorum could appear to have been assembled across two
    // different artefacts. Re-requesting the *same* artefact is a different
    // thing: it widens the reviewer set on an open review, which is legitimate
    // and preserves what has been decided so far.
    const open = task.state === "review_requested" ? task.review : undefined;
    if (open) {
      // An artefact left out reads as null, as it does in Python and in a
      // store's copy.
      if (contentHash(task.pending_artefact ?? null) !== contentHash(p.artefact ?? null)) {
        return { error: rpcError(
          E.REVIEW_ALREADY_OPEN,
          "A review is already open on this task with different content. " +
          "Decide, abstain, escalate or cancel it before requesting review of a new artefact.",
        ) };
      }
      // Only a rule the caller actually supplied can be a change. Comparing
      // the resolved default instead refused the documented
      // widen-the-reviewer-set request whenever `rule` was omitted.
      if (declaredRule != null && declaredRule !== open.rule) {
        return { error: rpcError(
          E.REVIEW_ALREADY_OPEN,
          `Cannot change the decision rule of an open review (currently ${open.rule})`,
        ) };
      }
    }

    // Where a person's review is required, the work's authors do not choose
    // who reviews it, and the reviewers a request names, opening the review
    // or widening it, are people other than the authors, each named. Without
    // this the agent whose work a required review holds could add itself, or
    // a person it joined, or any member at all through a broadcast scope,
    // and approve its own work. An explicit review of a task that does not
    // require one keeps its own `to`, so a deliberate agent-reviews-agent
    // flow is still available.
    const authors = open ? open.authors
      : unionOf(task.review ? task.review.authors : [], authorsOf(task, lastCompleter(task)));
    if (reviewRequired(ws, task)) {
      // The review a task requires opens on task.complete, from the assignee,
      // under the workspace's rule. Opened here, by anyone, it would take an
      // artefact, a rule and reviewers its requester chose, and a requester
      // who is not an author could approve work it supplied itself, or reopen
      // a task a review already completed.
      if (!open) {
        return { error: rpcError(E.NOT_AUTHORISED,
          "This task requires a person's review, which opens on task.complete; review.request only adds reviewers to it once it is open") };
      }
      if (authors.includes(p.from as ParticipantUri)) {
        return { error: rpcError(E.NOT_AUTHORISED, "The author of the work under review cannot request its review") };
      }
      const scope = reviewers.find(isScope);
      if (scope !== undefined) {
        return { error: rpcError(E.PARAMS,
          `A review that requires a person names its reviewers, and ${scope} is an address scope`) };
      }
      for (const r of reviewers) {
        if (authors.includes(r)) {
          return { error: rpcError(E.NOT_AUTHORISED, `The author of the work under review cannot review it: ${r}`) };
        }
        const member = rawMember(ws, r);
        if (member && member.type !== "human") {
          return { error: rpcError(E.NOT_AUTHORISED, `This task requires a person's review: ${r} is not a human member`) };
        }
      }
    }

    if (open) {
      // Union, preserving order and the decisions already recorded.
      for (const r of reviewers) {
        if (!open.requested_to.includes(r)) open.requested_to.push(r);
      }
      if (p.deadline != null) open.deadline = p.deadline as string;
      task.updated_at = now;
      return { result: {
        state: "review_requested",
        review_id: task.id,
        amended: true,
        requested_to: [...open.requested_to],
      } };
    }

    task.state = "review_requested";
    task.updated_at = now;
    task.review = {
      requested_at: now,
      requested_to: reviewers,
      rule,
      deadline: p.deadline as string | undefined,
      decisions: [],
      authors,
      acknowledgements: [],
    };
    task.history.push({ ts: now, from: p.from as ParticipantUri, state: "review_requested" });
    task.pending_artefact = p.artefact;
    return { result: { state: "review_requested", review_id: task.id } };
  }

  /**
   * review/1.0 S3.6: a reviewer says they have begun the open review. Only
   * someone who may decide it can, so the log's record of who took a review
   * up, and when, names reviewers alone. It changes nothing else: the review
   * stays open and the acknowledgement counts towards no rule.
   */
  private opReviewAcknowledge(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "task_id"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const task = ws.tasks.get(p.task_id as string);
    if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
    if (task.state !== "review_requested") {
      return { error: rpcError(E.NOT_REVIEWABLE, `Task not awaiting review: ${task.state}`) };
    }
    const notReviewer = this.requireReviewer(ws, task, p.from);
    if (notReviewer) return notReviewer;
    const review = task.review!;
    if (review.acknowledgements.some((a) => a.reviewer === p.from)) {
      return { error: rpcError(E.PARAMS, "Already acknowledged in this round") };
    }
    review.acknowledgements.push({ reviewer: p.from as ParticipantUri, ts: this.now() });
    return { result: { acknowledged: true, requested_at: review.requested_at } };
  }

  /**
   * Verify an optional `approved_artefact_digest` against the artefact under
   * review (review/1.0 S3.2).
   *
   * The digest sits in params, so it is inside whatever the envelope signature
   * covers: the decision then attests the content the reviewer saw rather than
   * a task reference, and a relying party can check it without trusting the
   * Coordinator that produced it. Absent, behaviour is exactly as before.
   *
   * On mismatch nothing is recorded and no state changes, so a client that
   * computes the wrong digest refuses only its own decision.
   */
  private checkArtefactDigest(p: Record<string, unknown>, task: Task): ReturnType<Handler> | null {
    const declared = p.approved_artefact_digest;
    if (declared === undefined || declared === null) return null;
    if (typeof declared !== "string") {
      return { error: rpcError(E.PARAMS, "approved_artefact_digest must be a string") };
    }
    // A null output is no artefact, as it is in the Python reference.
    if (task.pending_artefact === undefined || task.pending_artefact === null) {
      return { error: rpcError(E.PARAMS, "No artefact under review to bind a digest to") };
    }
    const actual = contentHash(task.pending_artefact);
    if (declared !== actual) {
      return { error: rpcError(
        E.SIG_ARTEFACT_DIGEST_MISMATCH,
        "approved_artefact_digest does not match the artefact under review",
        { declared, actual },
      ) };
    }
    return null;
  }

  private opDecide(p: Record<string, unknown>, kind: "approve" | "reject"): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "task_id"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    const bad = paramsError(p, [["tags", "strings"], ["request_revision", "boolean"]]);
    if (bad) return bad;
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const task = ws.tasks.get(p.task_id as string);
    if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
    if (task.state !== "review_requested") {
      return { error: rpcError(E.NOT_REVIEWABLE, `Task not awaiting review: ${task.state}`) };
    }
    const notReviewer = this.requireReviewer(ws, task, p.from);
    if (notReviewer) return notReviewer;
    const digestError = this.checkArtefactDigest(p, task);
    if (digestError) return digestError;
    const now = this.now();
    task.review!.decisions.push({
      reviewer: p.from as ParticipantUri,
      kind,
      ts: now,
      comment: p.comment as string | undefined,
      tags: p.tags as string[] | undefined,
    });
    if (kind === "approve") {
      // Complete only when the rule's approval predicate is met; otherwise the
      // approval is recorded and the task stays review_requested.
      if (reviewSatisfied(task.review!)) {
        task.output = task.pending_artefact;
        task.state = "completed";
      }
    } else {
      task.state = p.request_revision ? "in_progress" : "declined";
    }
    task.updated_at = now;
    task.history.push({ ts: now, from: p.from as ParticipantUri, state: task.state });
    return { result: { state: task.state } };
  }

  private opDecideOverride(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "task_id", "diff", "rationale"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    const bad = paramsError(p, [["tags", "strings"], ["policy_refs", "strings"]]);
    if (bad) return bad;
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const task = ws.tasks.get(p.task_id as string);
    if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
    if (task.state !== "review_requested") {
      return { error: rpcError(E.NOT_REVIEWABLE, `Task not awaiting review: ${task.state}`) };
    }
    const notReviewer = this.requireReviewer(ws, task, p.from);
    if (notReviewer) return notReviewer;
    const digestError = this.checkArtefactDigest(p, task);
    if (digestError) return digestError;
    // The override is of the artefact under review; use the coordinator's
    // record, not a caller-supplied "before" that could be fabricated.
    const base = task.pending_artefact;
    if (base === undefined || base === null) return { error: rpcError(E.PARAMS, "No base artefact for override") };
    let applied: unknown;
    try {
      applied = applyJsonPatch(base, p.diff as never, {
        maxStringBytes: this.options.maxEnvelopeBytes ?? DEFAULT_MAX_ENVELOPE_BYTES,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      return { error: rpcError(E.PATCH_FAILED, msg) };
    }
    const now = this.now();
    const id = this.ids.artefactId();
    const override: OverrideArtefact = {
      id,
      task_id: task.id,
      reviewer: p.from as ParticipantUri,
      based_on_artefact: base,
      diff: p.diff as never,
      result: applied,
      rationale: p.rationale as string,
      tags: (p.tags as string[]) ?? [],
      policy_refs: (p.policy_refs as string[]) ?? [],
      ts: now,
      logical_id: p.logical_id as string | undefined,
      instance_id: p.instance_id as string | undefined,
      intent_preserved: p.intent_preserved as boolean | undefined,
    };
    ws.overrides.set(id, override);
    task.review!.decisions.push({
      reviewer: p.from as ParticipantUri,
      kind: "override",
      ts: now,
      tags: override.tags,
      override_artefact_id: id,
    });
    task.output = applied;
    task.state = "completed";
    task.updated_at = now;
    task.history.push({ ts: now, from: p.from as ParticipantUri, state: "completed", note: "override applied" });
    return { result: { state: "completed", override_artefact_id: id, applied } };
  }

  private opAbstainDeclare(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "task_id", "reason"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    const bad = paramsError(p, [["category", "string"]]);
    if (bad) return bad;
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const task = ws.tasks.get(p.task_id as string);
    if (!task) return { error: rpcError(E.PARAMS, "Unknown task") };
    if (task.state !== "review_requested") {
      return { error: rpcError(E.NOT_REVIEWABLE, `Task not awaiting review: ${task.state}`) };
    }
    const notReviewer = this.requireReviewer(ws, task, p.from);
    if (notReviewer) return notReviewer;
    const now = this.now();
    task.review!.decisions.push({
      reviewer: p.from as ParticipantUri,
      kind: "abstain",
      ts: now,
      comment: p.reason as string,
      abstain_category: (p.category as string) || "other",
    });
    task.state = "abstained";
    task.updated_at = now;
    task.history.push({ ts: now, from: p.from as ParticipantUri, state: "abstained", note: p.reason as string });
    return { result: { state: "abstained" } };
  }

  private opEscalateRaise(p: Record<string, unknown>): ReturnType<Handler> {
    const miss = missing(p, ["workspace", "from", "original_task_id", "new_task"]);
    if (miss) return { error: rpcError(E.PARAMS, `Missing field: ${miss}`) };
    const ws = this.workspaces.get(p.workspace as string);
    if (!ws) return { error: rpcError(E.PARAMS, "Unknown workspace") };
    const notMember = this.requireMember(ws, p.from);
    if (notMember) return notMember;
    const origId = p.original_task_id;
    const orig = typeof origId === "string" ? ws.tasks.get(origId) : undefined;
    if (!orig) return { error: rpcError(E.PARAMS, "Unknown original task") };
    if (orig.state === "completed" || orig.state === "cancelled" || orig.state === "superseded") {
      return { error: rpcError(E.PARAMS, `Cannot escalate a terminal task: ${orig.state}`) };
    }
    if (p.new_task === null || typeof p.new_task !== "object" || Array.isArray(p.new_task)) {
      return { error: rpcError(E.PARAMS, "new_task must be an object") };
    }
    const nt = p.new_task as Record<string, unknown>;
    const bad = paramsError(p, [["new_task.kind", "string"]]);
    if (bad) return bad;
    const assignee = nt.assignee;
    if (typeof assignee !== "string" || !ws.members.has(assignee)) {
      return { error: rpcError(E.PARAMS, "Escalation assignee not in workspace") };
    }
    const named = nt.mode;
    if (named !== undefined && named !== null && typeof named !== "string") {
      return { error: rpcError(E.PARAMS, "new_task.mode must be a string") };
    }
    // The successor is a created task, so it meets the checks task.create and
    // control.supersede apply: its assignee must not be paused, and its mode,
    // the one new_task names or else the original's, must be within the
    // ceiling in force now. Naming a lower mode is how work is escalated
    // after the ceiling has been lowered.
    if (ws.members.get(assignee)!.paused) {
      return { error: rpcError(E.CONTROL_WORKSPACE_PAUSED, `Assignee ${assignee} is paused`) };
    }
    const mode = ((named as Mode | null | undefined) || orig.mode) as Mode;
    if (!modeLE(mode, ws.mode_ceiling)) {
      return { error: rpcError(E.MODE_CEILING_EXCEEDED,
        `Requested mode ${mode} exceeds ceiling ${ws.mode_ceiling}`) };
    }
    const now = this.now();
    const newId = this.ids.taskId();
    const newTask: Task = {
      id: newId,
      kind: (nt.kind as string) || orig.kind,
      state: "created",
      assignee,
      delegator: p.from as ParticipantUri,
      input: (nt.input as Record<string, unknown>) ?? {},
      created_at: now,
      updated_at: now,
      mode,
      supersedes: orig.id,
      history: [{ ts: now, from: p.from as ParticipantUri, state: "created", note: `escalated from ${orig.id}` }],
      paused: false,
    };
    // Escalating hands the work on and keeps its review. The successor
    // requires review when the original did or held a review, since a review
    // once opened is decided, and a trial task forces review under modes/1.0
    // as it does at task.create.
    if (orig.review_required || orig.review !== undefined
        || (ws.profiles.some(pr => pr.startsWith("modes/")) && newTask.mode === "trial")) {
      newTask.review_required = true;
    }
    // Whoever made the work it carries on is an author of its review too, so
    // handing the work on does not make its author a reviewer of it.
    newTask.prior_authors = successorAuthors(orig, p.from);
    ws.tasks.set(newId, newTask);
    orig.state = "escalated";
    orig.updated_at = now;
    orig.superseded_by = newId;
    orig.history.push({ ts: now, from: p.from as ParticipantUri, state: "escalated", note: `-> ${newId}` });
    return { result: { new_task_id: newId, escalated_from: orig.id } };
  }
}

function memberToDict(m: Member): Record<string, unknown> {
  const out: Record<string, unknown> = {
    uri: m.uri, type: m.type, role: m.role, joined: m.joined,
  };
  // Empty capabilities and scopes are left out, as the Python reference
  // leaves them out.
  if (m.display_name) out.display_name = m.display_name;
  if (m.capabilities && Object.keys(m.capabilities).length) out.capabilities = m.capabilities;
  if (m.scopes?.length) out.scopes = m.scopes;
  if (m.keys.length) {
    out.jwks = { keys: m.keys.filter(k => !k.revoked_at && !k.valid_until).map(k => k.jwk) };
    out.key_history = m.keys;
  }
  if (m.paused) out.paused = true;
  if (m.oidc_sub) out.oidc_sub = m.oidc_sub;
  if (m.vc_holder) out.vc_holder = m.vc_holder;
  return out;
}
