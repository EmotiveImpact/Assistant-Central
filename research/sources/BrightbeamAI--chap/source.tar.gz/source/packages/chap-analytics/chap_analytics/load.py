"""
Getting a chain in, from wherever it lives.

Four sources, one shape. A :class:`Chain` is the envelope stream plus whatever
server state was available, and it knows which of the two it has, so a
projection can leave a column null where the source had no value for it.

    from chap_analytics import from_sqlite, from_url, from_json, from_coordinator

    chain = from_sqlite("./chap.db", workspace="wsp_support")
    chain = from_url("http://localhost:8080/chap", workspace="wsp_support")
    chain = from_json("export.json")
    chain = from_coordinator(coord, workspace="wsp_support")

Redaction is applied at load, before anything is projected. An artefact
holds whatever the agent was working on: customer messages, contracts,
source. Pass ``redact=`` a callable and it sees every artefact before the
artefact reaches a table.
"""
from __future__ import annotations

import json
import sqlite3
import urllib.parse
import urllib.request
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Any

__all__ = ["Chain", "from_json", "from_sqlite", "from_url", "from_coordinator", "redact_artefacts"]

#: Called with every artefact before it is stored. Return a replacement.
Redactor = Callable[[Any], Any]


def redact_artefacts(_artefact: Any) -> Any:
    """
    A redactor that drops artefact bodies entirely.

    Keeps the shape of an analysis intact while removing the content: counts,
    rates, latencies and patch paths all survive, because they are computed
    from metadata rather than from what the artefact said. Pass this when the
    person running the analysis is to be kept from the customer's data.
    """
    return None


@dataclass
class Chain:
    """
    One workspace's history, ready to project.

    ``events`` is always present. ``state`` is present where the source
    carried it, and :attr:`has_state` says which, so a projection can leave a
    column null where the source had no value for it.
    """

    workspace: str
    events: list[dict[str, Any]]
    state: dict[str, Any] | None = None
    source: str = "unknown"

    @property
    def has_state(self) -> bool:
        """Whether server-computed values, such as deliberation outcomes, are available."""
        return self.state is not None

    def __len__(self) -> int:
        return len(self.events)

    def __repr__(self) -> str:
        state = "with state" if self.has_state else "envelopes only"
        return f"<Chain {self.workspace!r} {len(self.events)} events, {state}, from {self.source}>"

    def summary(self) -> str:
        methods: dict[str, int] = {}
        for e in self.events:
            if is_refusal(e):
                m = f"{(e.get('request') or {}).get('method', '?')} (refused)"
            else:
                m = (e.get("envelope") or {}).get("method", "?")
            methods[m] = methods.get(m, 0) + 1
        lines = [repr(self)]
        for m, n in sorted(methods.items(), key=lambda kv: (-kv[1], kv[0])):
            lines.append(f"  {n:>5}  {m}")
        return "\n".join(lines)


#: Params that carry arbitrary caller content directly. A whisper's free-text
#: answer travels under either of two names; the coordinator reads both.
_CARRIERS = ("artefact", "output", "input", "answer", "answer_text", "default_if_lapsed")

#: Params that carry a whole task specification, whose own input and output are
#: content. escalate.raise and control.supersede describe the successor they
#: mint this way, so a scan of the top level alone leaves both untouched.
_NESTED_TASKS = ("new_task", "successor_task")


def _redact_diff(diff: Any, redact: Redactor) -> None:
    """
    Drop what a patch operation writes, keep where it writes it.

    An operation's ``value`` is the corrected text itself and is as much
    content as the artefact it corrects. Its ``op`` and ``path`` are the
    analysis: which field of an output reviewers keep changing is the question
    ``patch_ops`` exists to answer, and the paths answer it on their own. So
    the value goes and the path stays.
    """
    if not isinstance(diff, list):
        return
    for op in diff:
        if isinstance(op, dict) and "value" in op:
            op["value"] = redact(op["value"])


def _redact_params(params: Any, redact: Redactor) -> None:
    """Rewrite every content-bearing field of one envelope's params, in place."""
    if not isinstance(params, dict):
        return
    for key in _CARRIERS:
        if key in params:
            params[key] = redact(params[key])
    _redact_diff(params.get("diff"), redact)
    for key in _NESTED_TASKS:
        spec = params.get(key)
        if isinstance(spec, dict):
            for inner in ("input", "output"):
                if inner in spec:
                    spec[inner] = redact(spec[inner])


def is_refusal(entry: Any) -> bool:
    """Whether a log entry records a refused call rather than an accepted one.

    Read by value: a snapshot written by ``dataclasses.asdict`` carries every
    field of an entry, with ``None`` in the ones that do not apply.
    """
    return (isinstance(entry, dict) and isinstance(entry.get("outcome"), dict)
            and not isinstance(entry.get("envelope"), dict))


def _call(entry: dict[str, Any]) -> dict[str, Any]:
    """The call a log entry records: the accepted envelope, or a refused request."""
    call = entry.get("envelope")
    if not isinstance(call, dict):
        call = entry.get("request")
    return call if isinstance(call, dict) else {}


def _apply_redaction(events: list[dict[str, Any]], redact: Redactor | None) -> list[dict[str, Any]]:
    """Rewrite artefact-bearing params on a copy, before anything reads them.

    A refused call carries content as much as an accepted one, so the
    request of a refusal entry is redacted too.
    """
    if redact is None:
        return events
    out: list[dict[str, Any]] = []
    for e in events:
        e = json.loads(json.dumps(e))  # deep copy; events may be shared
        _redact_params(_call(e).get("params"), redact)
        out.append(e)
    return out


def _redact_state(state: dict | None, redact: Redactor | None) -> dict | None:
    """
    Redact the snapshot as well as the envelopes.

    A snapshot holds content in two places beyond the envelopes. It stores
    the artefact a reviewer worked from and the result of correcting it, and
    the projection prefers those where it has them. It also *contains* the
    envelope stream, under ``audit``, so the copy handed to ``events`` and
    the original inside ``state`` both have to be redacted for the redaction
    to hold. Both are covered here.
    """
    if state is None or redact is None:
        return state
    state = json.loads(json.dumps(state))

    for entry in state.get("audit") or []:
        if isinstance(entry, dict):
            _redact_params(_call(entry).get("params"), redact)

    for task in (state.get("tasks") or {}).values():
        if not isinstance(task, dict):
            continue
        for key in ("input", "output", "pending_artefact"):
            if key in task:
                task[key] = redact(task[key])
    for art in (state.get("overrides") or {}).values():
        if not isinstance(art, dict):
            continue
        for key in ("based_on_artefact", "result"):
            if key in art:
                art[key] = redact(art[key])
        _redact_diff(art.get("diff"), redact)
    for w in (state.get("whispers") or {}).values():
        if not isinstance(w, dict):
            continue
        # answer_text is what a person typed; answer_option is which of the
        # asker's own choices they picked, which is metadata and is what makes
        # a redacted whisper still worth counting.
        for key in ("default_if_lapsed", "default_applied", "answer_text"):
            if key in w:
                w[key] = redact(w[key])
    # control.snapshot copies the open tasks, input and output included.
    for snap in (state.get("snapshots") or {}).values():
        if not isinstance(snap, dict):
            continue
        for task in (snap.get("state") or {}).get("open_tasks") or []:
            if not isinstance(task, dict):
                continue
            for key in ("input", "output", "pending_artefact"):
                if key in task:
                    task[key] = redact(task[key])
    return state


# The collections a workspace snapshot holds, and the field each is keyed by.
# The Python coordinator writes them as objects keyed by that field; the
# TypeScript coordinator writes them as lists. The projection reads objects.
_KEYED_COLLECTIONS = {
    "tasks": "id", "overrides": "id", "whispers": "id", "deliberations": "id",
    "handoffs": "id", "snapshots": "id", "route_decisions": "id", "members": "uri",
}


def _keyed_state(state: dict | None) -> dict | None:
    """A snapshot with every collection keyed by id, whichever coordinator wrote it."""
    if not isinstance(state, dict):
        return state
    out = dict(state)
    for name, key in _KEYED_COLLECTIONS.items():
        value = out.get(name)
        if isinstance(value, list):
            out[name] = {item[key]: item for item in value if isinstance(item, dict) and isinstance(item.get(key), str)}
    return out


def _chain(workspace: str, events: Iterable[dict], state: dict | None,
           source: str, redact: Redactor | None) -> Chain:
    evs = _apply_redaction(list(events), redact)
    evs.sort(key=lambda e: e.get("seq", 0) if isinstance(e, dict) else 0)
    return Chain(workspace=workspace, events=evs,
                 state=_redact_state(_keyed_state(state), redact), source=source)


def from_json(path: str, *, workspace: str | None = None, redact: Redactor | None = None) -> Chain:
    """
    Load from a JSON file.

    Accepts an ``audit.read`` result (an object with ``entries``), a bare list
    of entries, or a full workspace snapshot (an object with ``audit``). The
    snapshot carries server state; the other two shapes carry envelopes.
    """
    with open(path, encoding="utf-8") as fh:
        blob = json.load(fh)

    if isinstance(blob, list):
        return _chain(workspace or "unknown", blob, None, f"json:{path}", redact)
    if "entries" in blob:
        ws = workspace or blob.get("workspace") or "unknown"
        return _chain(ws, blob["entries"], None, f"json:{path}", redact)
    if "audit" in blob:
        ws = workspace or blob.get("id") or "unknown"
        return _chain(ws, blob["audit"], blob, f"json:{path}", redact)
    raise ValueError(
        f"{path} holds an unrecognised shape. A chain is a list of entries, an "
        "object with 'entries' from audit.read, or a workspace snapshot with 'audit'."
    )


def _store_snapshot(con: sqlite3.Connection, workspace: str) -> dict:
    """One workspace from the tables chap-coordinator 0.3.2 and later write.

    The workspace's own fields, its log in seq order, and each collection as
    objects keyed by id.
    """
    row = con.execute("SELECT data FROM chap_meta WHERE workspace = ?", (workspace,)).fetchone()
    snap = json.loads(row[0])
    for name in (*_KEYED_COLLECTIONS, "idempotency_keys"):
        snap[name] = {}
    snap["audit"] = [json.loads(d) for (d,) in con.execute(
        "SELECT data FROM chap_entries WHERE workspace = ? ORDER BY seq", (workspace,))]
    for collection, key, data in con.execute(
            "SELECT collection, id, data FROM chap_objects WHERE workspace = ? ORDER BY rowid",
            (workspace,)):
        snap.setdefault(collection, {})[key] = json.loads(data)
    return snap


def from_sqlite(path: str, *, workspace: str | None = None, redact: Redactor | None = None) -> Chain:
    """
    Load from a SqliteStore file.

    The richest source: the store holds the whole workspace, so server-computed
    values are available alongside the envelopes. Reads the tables
    chap-coordinator 0.3.2 and later write, one row per audit entry and per
    object, and the single snapshot table earlier releases wrote. Opens the
    file read-only, so it is safe against a database a coordinator is using.
    """
    uri = f"file:{path}?mode=ro"
    con = sqlite3.connect(uri, uri=True)
    try:
        # One read transaction, so a coordinator writing the file meanwhile
        # cannot leave the log and the objects out of step.
        con.execute("BEGIN")
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        if "chap_meta" in tables:
            available = [r[0] for r in con.execute("SELECT workspace FROM chap_meta ORDER BY rowid")]
            rows = None
        elif "chap_workspaces" in tables:
            rows = con.execute("SELECT id, data FROM chap_workspaces").fetchall()
            available = [r[0] for r in rows]
        else:
            raise ValueError(
                f"{path} lacks the tables a CHAP SqliteStore writes: chap_meta, or "
                "chap_workspaces before chap-coordinator 0.3.2."
            )

        if not available:
            raise ValueError(f"{path} holds an empty workspace table.")
        if workspace is None:
            if len(available) > 1:
                raise ValueError(
                    f"{path} holds {len(available)} workspaces; name one with "
                    f"workspace=. Available: {', '.join(available)}"
                )
            workspace = available[0]
        if workspace not in available:
            raise ValueError(f"{path} holds {', '.join(available)}. Pass one of those as workspace= "
                             f"({workspace!r} was given).")
        if rows is None:
            snap = _store_snapshot(con, workspace)
        else:
            snap = json.loads(next(data for ws_id, data in rows if ws_id == workspace))
    finally:
        con.close()
    return _chain(workspace, snap.get("audit", []), snap, f"sqlite:{path}", redact)


def from_url(url: str, workspace: str, *, actor: str = "service:analytics",
             timeout: int = 30, redact: Redactor | None = None) -> Chain:
    """
    Load over HTTP from a running coordinator, via ``audit.read``.

    Envelopes only: ``audit.read`` returns the log, so columns whose provenance
    is ``state`` come back null. Everything derived by replay is available,
    which is most of what matters.
    """
    scheme = urllib.parse.urlparse(url).scheme.lower()
    if scheme not in ("http", "https"):
        raise ValueError(
            f"from_url only accepts http and https URLs; got {scheme or 'no'} "
            f"scheme in {url!r}."
        )
    body = json.dumps({
        "jsonrpc": "2.0", "id": "analytics-audit-read", "method": "audit.read",
        "params": {"workspace": workspace, "from": actor},
    }).encode()
    req = urllib.request.Request(
        url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        payload = json.load(resp)

    if "error" in payload:
        err = payload["error"]
        raise ValueError(
            f"audit.read was refused with {err.get('code')}: {err.get('message')}. "
            "A coordinator that gates reads on membership needs `actor` to name a member."
        )
    entries = (payload.get("result") or {}).get("entries", [])
    return _chain(workspace, entries, None, f"url:{url}", redact)


def from_coordinator(coord: Any, workspace: str, *, redact: Redactor | None = None) -> Chain:
    """
    Load from an in-process ``Coordinator``.

    Intended for tests and notebooks that drive a coordinator directly. Reads
    the workspace object, so server state is available.
    """
    ws = coord.get_workspace(workspace) if hasattr(coord, "get_workspace") else None
    if ws is None:
        raise ValueError(f"{workspace!r} is unknown to this coordinator.")
    # dataclasses.asdict is what the coordinator itself persists through, so a
    # chain read this way and one read from the resulting SqliteStore file are
    # the same shape by construction.
    from dataclasses import asdict

    snap = asdict(ws)
    return _chain(workspace, snap.get("audit", []), snap, "coordinator", redact)
