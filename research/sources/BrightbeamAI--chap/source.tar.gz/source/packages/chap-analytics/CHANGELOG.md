# Changelog

`chap-analytics` versions on its own track. It is a reader of the protocol,
so a protocol release moves the coordinator packages together and leaves this
one where it is until the tables or the analyses change.

## 0.2.6

Reads the logs of `chap-coordinator` 0.3.5.

### Added

- **Time to open and time to decide.** Coordinators from 0.3.5 record
  `review.acknowledge` when a reviewer opens a review. The decisions table
  gains `acknowledged_at`, `time_to_open_s` and `time_to_decide_s`, and
  `stats.latency` splits each pass's wait the same way, open passes
  included; `open_queue` says which waiting reviews were opened. The
  latency brief reports both medians, counts the waiting reviews nobody
  has opened, and says to tell reviewers when a review arrives where most
  of the wait comes before anyone opens the work. A log without
  acknowledgements reads as before.
- **Decisions a bridge recorded.** A framework bridge records a decision a
  person made outside CHAP, and from 0.3.5 the call carries
  `via: "bridge-record"`. The decisions table and each pass in
  `stats.latency` carry `via`; `latency_by`, `survival` and the latency
  brief leave out passes a recorded decision settled, and the brief counts
  them. It also points out decisions made within a second of their request,
  which a bridge from before 0.3.5 records unmarked.
- **The artefact each decision was made on.** The decisions table gains
  `artefact`.

### Fixed

- **A completion after a review.** From 0.3.5 a task that has held a review
  completes only through a decision, and completing it again opens a new
  pass. The replay read such a completion as the end of the task, so the
  decision that followed landed in the earlier pass. It now holds the
  completion and opens a pass when a decision or an acknowledgement on the
  task follows, or when the state shows the task under review; a log from
  before 0.3.5 reads as before.
- **The successor of an escalated task.** From 0.3.5 `escalate.raise`
  hands a review on with the work: the successor requires review when the
  original held one. The replay now reads it so.
- **Approved evaluation cases.** `export.evaluation_cases(include_approved=True)`
  gave approved tasks an empty `agent_output` and `corrected_output`. Both
  now hold the artefact the settling decision approved.
- **One reviewer.** The concentration brief said reviewing was spread across
  people when one reviewer decided everything on a small sample, and wrote
  "1 reviewers". One reviewer is now named as the only one, and a high
  share on too few decisions says the sample is too small to tell.

## 0.2.5

Reads the review rounds of `chap-coordinator` 0.3.4.

### Changed

- **A revised artefact is a new review pass.** A task that requires review
  and is completed again after a revision now opens a new pass of the same
  review, as `chap-coordinator` 0.3.4 does: the reviewers and the rule stay,
  the completer leaves the reviewers, and the decisions start empty. Before,
  the pass carried on with the decisions on the earlier artefact.
  `n_reviews` and `review_index` count the new pass, in a chain any
  coordinator wrote. In a chain written before 0.3.4, a task completed by
  approvals of an earlier artefact now reads as open from the envelopes and
  as completed bypassing review from state, which is what its chain shows.

### Fixed

- **A patch that grows the document past a size or depth limit.**
  `chap-analytics` applies each override's patch to rebuild the corrected
  artefact. Its copy of the patch engine limited operations and values, and
  nothing limited size or depth, so a few `copy` operations of the root
  could grow an artefact to gigabytes, and a patch that puts one value
  inside another could nest it deeper than Python can follow. It now
  refuses a patch when, after any of its operations, the artefact holds
  more than 64 MiB of string and key text, counted in UTF-8 bytes, or nests
  deeper than 64 levels, or when its copies, and its moves to a deeper
  place or onto the whole artefact, carry more than three times the value
  and size limits between them. The artefact's `result` is then empty. A
  coordinator refuses an override past its own `max_envelope_bytes`, 1 MiB
  by default, so every override a 0.3.4 coordinator accepted is rebuilt
  while that limit is at most 64 MiB.

## 0.2.4

### Fixed

- **A patch `test` that compares a boolean with a number.** `chap-analytics`
  applies each override's patch to rebuild the corrected artefact, and the
  patch's `test` operation counted `true` as equal to `1` and `false` as
  equal to `0`, as Python does. It now tells a boolean from a number, as
  RFC 6902 and both coordinators do.
- **What a lapse rate says.** The whispers chart and brief read a high lapse
  rate as a reviewer who is away from the desk. A lapse records only that
  no answer arrived before the lapse check ran. The chart now points at
  questions the task input should have answered and at questions that reach
  no one in time, and the brief suggests checking that the questions reach
  the people asked.

## 0.2.3

Reads the store of `chap-coordinator` 0.3.2 and later.

### Fixed

- **The 0.3.2 store.** `from_sqlite` reads the tables `chap-coordinator`
  0.3.2 and later write, one row for each audit entry and each object. A
  file an earlier release wrote reads as before.

## 0.2.2

Reads the store of the TypeScript coordinator, which the Node templates of
`create-chap-app` run. Install it with `chap-coordinator` 0.3.0 or later where
the `coordinator` extra drives a live coordinator.

### Fixed

- **A TypeScript coordinator's store.** `from_sqlite` and `from_json` read a
  workspace snapshot the TypeScript coordinator wrote, which holds its tasks,
  members, overrides and the other collections as lists where the Python
  coordinator holds them as objects keyed by id. Reading one stopped with an
  `AttributeError`; the collections are now keyed on load, and both
  coordinators' stores project to the same tables.

## 0.2.1

Reads the logs a 0.3 coordinator writes. Install it with `chap-coordinator`
0.3.0 or later where the `coordinator` extra drives a live coordinator.

### Added

- **A `refusals` table.** A coordinator now records a member's refused call
  when it was a governed attempt, such as a decision on a review addressed to
  someone else or a pull on an emergency brake the workspace has switched off.
  The entry holds the call under `request` with an `outcome` beside it. The
  new table lists those attempts with the code each was refused with, and no
  other table replays them, so a refused approval never counts as a decision.
  `events` now holds the accepted entries, and the two tables together hold
  the whole log. The assurance shares, in `stats`, the brief and the report,
  count both, since a refusal is linked into the chain like any other entry.
  A chain written before refusals were recorded reads exactly as before. The
  redaction hook applies to a refused call's parameters as it does to an
  accepted one's.

### Changed

- **A successor keeps its original's review requirement.** From 0.3.0 the
  coordinators give the successor that `escalate.raise` or
  `control.supersede` makes the review requirement of the task it replaces,
  and require review of a trial successor of `escalate.raise` under
  `modes/1.0`. The replay follows, so completing such a successor opens a
  review in the tables as it does on the coordinator. Read with server state,
  `review_required` is the coordinator's own value, unset where the
  coordinator left it unset, and a review pass the replay inferred on a task
  the coordinator holds no review on is dropped. Read from envelopes alone, a
  chain written by an earlier coordinator shows a successor that coordinator
  completed directly, the successor of a reviewed task or a trial successor
  of `escalate.raise` under `modes/1.0`, as requiring review, in state
  `review_requested` with outcome `open`.
- **A log without a recorded submission says so.** A coordinator from 0.3.0
  returns receipts from `audit.submit_to_scitt` and keeps no submission on the
  log, so its logs mark no entry as submitted. Where the log holds no
  submission, the assurance brief and the report say none is on record, and
  the assurance chart leaves the submitted share out. The receipts the
  coordinator returns are the record of what was submitted.

### Fixed

- **The `fulfils` edge reads the field where the protocol puts it.**
  SPECIFICATION 9.4 carries `fulfils` on the artefact, and the `tasks` table
  reads it from the output a `task.complete` carried. `graph.build` read a
  top-level field of the same name on the envelope instead, so the edge never
  appeared on a chain a producer had actually written, including every chain
  the wrap helper produces. The graph now reads the same field as the table.
  The id is kept as the producer wrote it and lands on a decision node marked
  `referenced`.

## 0.2.0

The decision layer: every row of the roadmap's decision table, as a
statistic with its interval, a chart, and a brief, assembled into a
self-contained interactive report.

- `chap_analytics.stats`: approval, override, rejection and abstention rates
  with Wilson intervals, overall, by group and over time; the refining
  against reversing split; patch-path frequency with the rationales behind
  each cell; the reliability table with expected calibration error and Brier
  score; time to decision as a Kaplan-Meier curve with open reviews
  censored, latency by group and the open queue; promotion readiness as a
  Beta posterior against a threshold and Wald's sequential test; Fleiss'
  kappa on multi-reviewer passes and on deliberation votes, pairwise Cohen's
  kappa and abstentions by category; whisper lapse and handoff acceptance
  rates with response times; chain assurance per period; and a Bernoulli
  CUSUM on the correction rate with its decision interval set by simulation
  for a stated false-alarm rate. Every estimate with a minimum carries a
  `sufficient` flag and the minimum it was judged against.
- `chap_analytics.graph`: the chain as a typed graph with a fixed ontology
  of nine node types and twenty-five edge types; the lineage of one task as
  a graph and as swimlane rows; the collaboration graph with degree,
  betweenness and per-agent reviewer concentration; oversight coverage of
  shipped outcomes; separation-of-duties findings; a Fruchterman-Reingold
  layout; node-link JSON, GraphML and networkx exports; and the ontology
  drawn as SVG from the declarations.
- `chap_analytics.charts`: one Vega-Lite specification per chart in the
  decision table, as a plain dictionary that a notebook renders, Altair
  takes, `Chart.save` writes as SVG or PNG, and the report embeds. Charts
  carry the question they answer and the decision they inform.
- `chap_analytics.briefs`: each decision in a paragraph, with the numbers,
  their intervals, and the decision they support, in words that change with
  the numbers.
- `chap_analytics.report`: one HTML file with the Vega runtime, the rows
  behind every chart and the page inside it. Headline cards per decision, a
  filter bar for date range, kind, agent, reviewer, mode and tag, brushing
  on the time axis, drill-through from the correction heatmap to the
  rationales, the open queue, and a lineage view for any task. Every
  statistic is recomputed in the browser as the reader filters, by a
  JavaScript mirror of the library that the suite checks against the Python
  functions. Artefact content stays out of the file.
- `chap_analytics.watch`: a `Watcher` that reads `audit.read` incrementally
  from a sequence cursor over HTTP, an in-process coordinator or any
  callable, re-projects, regenerates the report, and raises each drift alarm
  once with the tasks behind it.
- `chap_analytics.export`: evaluation cases with the agent's output, the
  corrected output and the rationale, written as JSON lines; prompt-revision
  candidates ranked by frequency and reversing share; and routing
  calibration, the confidence threshold that reaches a target acceptance.
- `chap_analytics.models`: reviewer severity separated from agent quality
  by a Rasch-style logistic model in numpy, with approximate standard
  errors, which declines to fit below its minimum and says why.
- `chap_analytics.sample.synthetic`: a workspace generated from stated
  rates (override, rejection, refining share, quorum share and agreement,
  latency, open share, whisper and lapse rates, handoffs, drift, reviewer
  strictness, agent quality, and how confidence relates to outcomes), so
  every statistic is tested against the truth that produced it. The
  coordinator's own clock follows the simulated timeline.
- `events.signed` and `events.scitt_submitted` columns.
- A `concerns` edge for the task a deliberation is about; `asked_to` and
  `whispered_to` read from the `to` field of the request envelope; `fulfils`
  read from the `fulfils` field of a `task.complete` envelope where a chain
  carries one.
- Documentation: the README carries the decision table and the pictures;
  `docs/methods.md`, `docs/graph.md` and `docs/report.md` state each
  method's assumptions and minimums, the ontology, and how the report is
  built. The walkthrough notebook continues from the tables to the decision
  layer, with the charts drawn inline.
- Extras: `viz` (Altair and vl-convert), `graph` (networkx). numpy is named
  as a dependency alongside pandas.

## 0.1.0

First release: stage one of the analytics roadmap.

- Eleven documented tables, projected from a CHAP audit chain by replaying
  the envelope stream: `events`, `tasks`, `decisions`, `overrides`,
  `patch_ops`, `participants`, `deliberations`, `votes`, `whispers`,
  `handoffs`, `routing`. Every column declared with its dtype and provenance.
- Four loaders: a SQLite store, a JSON export, an `audit.read` endpoint, and
  a `Coordinator` in the same process.
- Review passes kept apart, so a task sent back for revision is measured from
  each pass's own opening and `outcome` reads from the decision that settled
  the last one.
- The corrected artefact reconstructed from the patch with the coordinator's
  own RFC 6902 semantics, and checked against what the coordinator stored by
  the differential suite.
- Successors minted by escalation and supersession counted as tasks, with
  what they inherit from the original.
- `id_certain` and `assignee_certain`, so a row says which of its values are
  inferred.
- A redactor hook that covers every artefact-bearing field, in both the
  envelope stream and the snapshot.
- `chap_analytics.sample.support_desk()`, a generated week of review work; a
  walkthrough notebook and a printed report over it.
- A differential suite: random workspaces against a live coordinator, read
  both ways and checked against what the coordinator holds.
