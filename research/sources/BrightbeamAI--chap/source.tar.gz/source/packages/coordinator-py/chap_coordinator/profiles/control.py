"""
chap_coordinator.profiles.control

The control/1.0 profile (profiles/control.md).

Methods (all per spec):
  - control.pause            (scope: task|participant|workspace)
  - control.resume
  - control.cancel
  - control.snapshot         (returns art_... id)
  - control.rollback         (takes to_snapshot_artefact_id + what_to_restore)
  - control.supersede        (creates successor_task in one shot)
  - control.set_mode_ceiling

All control.* methods are privileged. Step-up enforcement is handled
at the coordinator dispatch layer; we surface CONTROL_STEP_UP_REQUIRED
where appropriate.

Error codes:
  -32060 step-up required
  -32061 not authorised for control operations
  -32062 snapshot artefact not found
  -32063 workspace paused; operation blocked
"""
from __future__ import annotations

import copy
from typing import TYPE_CHECKING

from ..coordinator import _open_required_review_authors, _successor_authors, mode_le
from ..canonical import content_hash
from ..jsonrpc import E, rpc_error
from ..params import lookup, params_error
from ..types import SnapshotArtefact, Task, TaskHistoryEntry

if TYPE_CHECKING:
    from ..coordinator import Coordinator


_VALID_MODES = ("shadow", "trial", "production")
_VALID_SCOPES = ("task", "participant", "workspace")
_SCOPE_ERROR = "scope must be task, participant or workspace"


def register_control(coord: "Coordinator") -> None:

    def control_pause(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        bad = params_error(p, [("scope", "string"), ("participant_uri", "string"),
                               ("uri", "string"), ("in_flight_policy", "string")])
        if bad:
            return bad
        scope = p.get("scope") or "task"
        if scope not in _VALID_SCOPES:
            return {"error": rpc_error(E.PARAMS, _SCOPE_ERROR)}

        if scope == "task":
            task = lookup(ws.tasks, p.get("task_id"))
            if not task:
                return {"error": rpc_error(E.PARAMS, "Unknown task")}
            if task.state in ("completed", "declined", "cancelled", "superseded"):
                return {"error": rpc_error(E.CONTROL_NOT_AUTHORISED,
                                           f"Cannot pause {task.state} task")}
            task.paused = True
            prior = task.state
            if prior != "paused":
                task.paused_from = prior
            task.state = "paused"
            task.updated_at = coord.now_iso()
            task.history.append(TaskHistoryEntry(
                ts=task.updated_at, from_=p.get("from", ""),
                state="paused", note=f"was {prior}",
            ))
            return {"result": {"scope": "task", "task_id": task.id,
                               "state": "paused"}}

        if scope == "participant":
            uri = p.get("participant_uri") or p.get("uri")
            if not uri:
                return {"error": rpc_error(E.PARAMS, "participant_uri is required")}
            if uri not in ws.members:
                return {"error": rpc_error(E.PARAMS,
                                           f"Unknown participant: {uri}")}
            ws.members[uri].paused = True
            return {"result": {"scope": "participant", "participant_uri": uri,
                               "paused": True,
                               "in_flight_policy": p.get("in_flight_policy") or "allow_to_complete"}}

        # workspace
        ws.state = "paused"
        return {"result": {"scope": "workspace", "workspace": ws.id,
                           "state": "paused"}}

    def control_resume(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        bad = params_error(p, [("scope", "string"), ("participant_uri", "string"),
                               ("uri", "string")])
        if bad:
            return bad
        scope = p.get("scope") or "task"
        if scope not in _VALID_SCOPES:
            return {"error": rpc_error(E.PARAMS, _SCOPE_ERROR)}

        if scope == "task":
            task = lookup(ws.tasks, p.get("task_id"))
            if not task:
                return {"error": rpc_error(E.PARAMS, "Unknown task")}
            if task.state != "paused":
                return {"error": rpc_error(E.CONTROL_NOT_AUTHORISED,
                                           f"Cannot resume {task.state} task")}
            task.paused = False
            restored = task.paused_from or "in_progress"
            task.paused_from = None
            task.state = restored
            task.updated_at = coord.now_iso()
            task.history.append(TaskHistoryEntry(
                ts=task.updated_at, from_=p.get("from", ""), state=restored,
            ))
            return {"result": {"scope": "task", "task_id": task.id,
                               "state": restored}}

        if scope == "participant":
            uri = p.get("participant_uri") or p.get("uri")
            if not uri:
                return {"error": rpc_error(E.PARAMS, "participant_uri is required")}
            if uri not in ws.members:
                return {"error": rpc_error(E.PARAMS,
                                           f"Unknown participant: {uri}")}
            # A pause holds until someone else lifts it: the paused member
            # lifting its own would make the pause its to keep or drop.
            if uri == p.get("from"):
                return {"error": rpc_error(E.NOT_AUTHORISED,
                                           "A paused participant does not lift its own pause")}
            ws.members[uri].paused = False
            return {"result": {"scope": "participant",
                               "participant_uri": uri, "paused": False}}

        # workspace
        ws.state = "active"
        return {"result": {"scope": "workspace", "workspace": ws.id,
                           "state": "active"}}

    def control_cancel(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        task = lookup(ws.tasks, p.get("task_id"))
        if not task:
            return {"error": rpc_error(E.PARAMS, "Unknown task")}
        if task.state in ("completed", "declined", "cancelled", "superseded"):
            return {"error": rpc_error(E.CONTROL_NOT_AUTHORISED,
                                       f"Cannot cancel {task.state} task")}
        # A review a task requires ends with a decision. Its authors pulling
        # the emergency brake on it would end it with none; other members
        # still can.
        if p.get("from") in _open_required_review_authors(ws, task):
            return {"error": rpc_error(
                E.NOT_AUTHORISED,
                "The authors of the work under review cannot end its review without a decision")}
        task.state = "cancelled"
        task.updated_at = coord.now_iso()
        task.history.append(TaskHistoryEntry(
            ts=task.updated_at, from_=p.get("from", ""),
            state="cancelled", note=p.get("reason"),
        ))
        return {"result": {"state": "cancelled"}}

    def control_snapshot(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        bad = params_error(p, [("include", "strings"), ("label", "string")])
        if bad:
            return bad
        requested = p.get("include")
        if isinstance(requested, list) and not requested:
            return {"error": rpc_error(E.PARAMS, "include must not be empty")}
        include = list(requested if requested is not None
                       else ["members", "open_tasks", "mode_ceiling"])
        # Each slice has the same deliberately small projection in both refs.
        state: dict = {}
        if "members" in include:
            members = []
            # Read-only projections: read without recording a change.
            for member in dict.values(ws.members):
                item = {"uri": member.uri, "type": member.type}
                if member.role:
                    item["role"] = member.role
                if member.scopes:
                    item["scopes"] = member.scopes
                members.append(item)
            if members:
                state["members"] = members
        if "open_tasks" in include:
            tasks = []
            for task in dict.values(ws.tasks):
                if task.state in ("completed", "declined", "cancelled", "superseded"):
                    continue
                item = {"id": task.id, "kind": task.kind, "state": task.state}
                if task.assignee:
                    item["assignee"] = task.assignee
                tasks.append(item)
            if tasks:
                state["open_tasks"] = tasks
        if "mode_ceiling" in include:
            state["mode_ceiling"] = ws.mode_ceiling
        if "policy" in include and ws.routing_policy_uri:
            state["routing_policy_uri"] = ws.routing_policy_uri
        if "all" in include or "audit" in include:
            state["audit_seq"] = len(ws.audit)

        content = copy.deepcopy({
            "workspace": ws.id,
            "audit_seq": len(ws.audit),
            "include": include,
            "state": state,
        })
        if p.get("label"):
            content["label"] = p["label"]
        snap_id = coord.ids.artefact_id()
        snap = SnapshotArtefact(
            id=snap_id,
            produced_by=p.get("from", ""),
            produced_at=coord.now_iso(),
            content=content,
            content_hash=content_hash(content),
        )
        ws.snapshots[snap_id] = snap
        return {"result": {"snapshot_artefact_id": snap_id,
                           "audit_seq": snap.content["audit_seq"],
                           "artefact": snap.to_dict()}}

    def control_rollback(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        bad = params_error(p, [("to_snapshot_artefact_id", "string"),
                               ("snapshot_artefact_id", "string"), ("snapshot_id", "string"),
                               ("what_to_restore", "strings"), ("reason", "string")])
        if bad:
            return bad
        snap_id = (p.get("to_snapshot_artefact_id")
                   or p.get("snapshot_artefact_id")
                   or p.get("snapshot_id"))
        if not snap_id:
            return {"error": rpc_error(E.PARAMS,
                                       "to_snapshot_artefact_id is required")}
        snap = lookup(ws.snapshots, snap_id)
        if not snap:
            return {"error": rpc_error(E.CONTROL_SNAPSHOT_NOT_FOUND,
                                       f"Unknown snapshot: {snap_id}")}
        requested = p.get("what_to_restore")
        if isinstance(requested, list) and not requested:
            return {"error": rpc_error(E.PARAMS, "what_to_restore must not be empty")}
        what = list(requested if requested is not None else snap.content["include"])

        # Apply the rollback. Per spec, this APPENDS, it does not truncate.
        # We restore the named slices of state.
        restored: list[str] = []
        if "mode_ceiling" in what and "mode_ceiling" in snap.content["state"]:
            ws.mode_ceiling = snap.content["state"]["mode_ceiling"]
            restored.append("mode_ceiling")
        if "members" in what and "members" in snap.content["state"]:
            # Restore each member's role/scopes from the snapshot;
            # we don't recreate departed members (audit is append-only)
            snap_uris = {m["uri"]: m for m in snap.content["state"]["members"]}
            for uri, snap_m in snap_uris.items():
                if uri in ws.members:
                    member = ws.members[uri]
                    # The admin role is granted by an admin (SPECIFICATION
                    # 6.3), and a rollback, which any member may call, neither
                    # grants nor removes it.
                    role = snap_m.get("role", member.role)
                    if role != "admin" and member.role != "admin":
                        member.role = role
                    member.scopes = copy.deepcopy(snap_m.get("scopes"))
            restored.append("members")

        return {"result": {
            "rolled_back_to": snap_id,
            "audit_seq": snap.content["audit_seq"],
            "restored": restored,
            **({"reason": p["reason"]} if p.get("reason") else {}),
        }}

    def control_supersede(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        old_id = p.get("task_id")
        old = lookup(ws.tasks, old_id)
        if not old:
            return {"error": rpc_error(E.PARAMS, "Unknown task")}

        if p.get("from") in _open_required_review_authors(ws, old):
            return {"error": rpc_error(
                E.NOT_AUTHORISED,
                "The authors of the work under review cannot end its review without a decision")}
        # successor_task is an object describing the new task; the Coordinator
        # creates it as part of the supersede operation (per spec).
        new_spec = p.get("successor_task") or {}
        if (not isinstance(new_spec, dict) or not isinstance(new_spec.get("kind"), str)
                or not new_spec["kind"]):
            return {"error": rpc_error(E.PARAMS,
                                       "successor_task must include kind")}
        bad = params_error(p, [("successor_task.assignee", "string"), ("reason", "string")])
        if bad:
            return bad
        assignee = new_spec.get("assignee") or old.assignee
        if not isinstance(assignee, str) or assignee not in ws.members:
            return {"error": rpc_error(E.PARAMS,
                                       "successor assignee not in workspace")}
        # The successor is a created task, so the participant-paused check
        # task.create applies has to apply here too. Without it, superseding
        # is a way to hand work to a participant whose work was stopped.
        if ws.members[assignee].paused:
            return {"error": rpc_error(E.CONTROL_WORKSPACE_PAUSED,
                                       f"Assignee {assignee} is paused")}

        # The successor is a created task, so it is bound by the same modes/1.0
        # invariants as task.create: it must not exceed the workspace ceiling,
        # and a trial-mode task forces review on regardless of its own setting.
        if new_spec.get("mode") is not None and not isinstance(new_spec.get("mode"), str):
            return {"error": rpc_error(E.PARAMS,
                                       "successor_task.mode must be a string")}
        requested_mode = new_spec.get("mode") or old.mode
        if not mode_le(requested_mode, ws.mode_ceiling):
            return {"error": rpc_error(
                E.MODE_CEILING_EXCEEDED,
                f"Requested mode {requested_mode} exceeds ceiling {ws.mode_ceiling}",
            )}
        if (new_spec.get("review_required") is not None
                and not isinstance(new_spec.get("review_required"), bool)):
            return {"error": rpc_error(
                E.PARAMS, "successor_task.review_required must be a boolean")}

        now = coord.now_iso()
        new_id = coord.ids.task_id()
        new_task = Task(
            id=new_id,
            kind=new_spec["kind"],
            state="created",
            assignee=assignee,
            delegator=p.get("from", ""),
            input=new_spec["input"] if new_spec.get("input") is not None else {},
            created_at=now,
            updated_at=now,
            mode=requested_mode,
            supersedes=old.id,
            history=[TaskHistoryEntry(
                ts=now, from_=p.get("from", ""), state="created",
                note=f"supersedes {old.id}: {p.get('reason') or ''}",
            )],
        )
        # A successor keeps the review requirement of the task it replaces,
        # so superseding never removes a required review. Trial forces review
        # only when the workspace opted into modes/1.0, matching task.create,
        # since mode is inert without the profile. Otherwise the spec's own
        # setting applies.
        if old.review_required or (ws.has_profile("modes")
                                   and new_task.mode == "trial"):
            new_task.review_required = True
        elif "review_required" in new_spec:
            new_task.review_required = bool(new_spec["review_required"])
        # Whoever made the work it replaces is an author of the successor's
        # review too, so superseding does not make its author a reviewer of it.
        new_task.prior_authors = _successor_authors(old, p.get("from"))
        ws.tasks[new_id] = new_task

        old.state = "superseded"
        old.superseded_by = new_id
        old.updated_at = now
        old.history.append(TaskHistoryEntry(
            ts=now, from_=p.get("from", ""), state="superseded",
            note=f"-> {new_id}: {p.get('reason') or ''}",
        ))
        return {"result": {
            "superseded_task_id": old.id,
            "new_task_id": new_id,
            **({"reason": p["reason"]} if p.get("reason") is not None else {}),
        }}

    def control_set_mode_ceiling(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        bad = params_error(p, [("reason", "string")])
        if bad:
            return bad
        new_ceiling = (p["new_ceiling"] if p.get("new_ceiling") is not None
                       else p.get("mode_ceiling"))
        if new_ceiling not in _VALID_MODES:
            return {"error": rpc_error(E.PARAMS,
                                       "new_ceiling must be shadow, trial or production")}
        ws.mode_ceiling = new_ceiling
        return {"result": {"mode_ceiling": ws.mode_ceiling,
                           **({"reason": p["reason"]} if p.get("reason") is not None else {})}}

    coord._handlers["control.pause"] = control_pause
    coord._handlers["control.resume"] = control_resume
    coord._handlers["control.cancel"] = control_cancel
    coord._handlers["control.snapshot"] = control_snapshot
    coord._handlers["control.rollback"] = control_rollback
    coord._handlers["control.supersede"] = control_supersede
    coord._handlers["control.set_mode_ceiling"] = control_set_mode_ceiling
