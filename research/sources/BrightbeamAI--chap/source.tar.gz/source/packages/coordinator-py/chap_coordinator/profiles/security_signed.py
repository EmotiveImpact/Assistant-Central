"""
chap_coordinator.profiles.security_signed

The security-signed/1.0 profile (profiles/security-signed.md).

Adds a top-level ``sig`` field on every envelope:
  ``sig: "ed25519:<kid>:<base64>"``

The signature is over JCS of the envelope with ``sig`` removed.
Keys are looked up by (from, kid, ts) so historical envelopes verify
across rotation. ``cryptography`` is imported lazily; verification
is performed at the Coordinator's dispatch layer (see
Coordinator._verify_signature).

Methods:
  - participant.rotate_key  : sign with old key; new key takes effect
  - participant.revoke_key  : admin revokes a participant's key

Error codes:
  -32070 signature verify failed
  -32071 no known key matching (from, kid, ts)
  -32072 key revoked
  -32073 rotation message not signed with old key
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from ..jsonrpc import E, rpc_error
from ..params import lookup, params_error
from ..types import KeyRecord

if TYPE_CHECKING:
    from ..coordinator import Coordinator


def register_security_signed(coord: "Coordinator") -> None:

    def participant_rotate_key(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        for f in ("from", "old_kid", "new_jwk"):
            if f not in p:
                return {"error": rpc_error(E.PARAMS, f"Missing field: {f}")}
        # Both are written into the refusals below, where None reads one way
        # in each language.
        for f in ("from", "old_kid"):
            if not isinstance(p[f], str):
                return {"error": rpc_error(E.PARAMS, f"{f} must be a string")}
        member = lookup(ws.members, p["from"])
        if not member:
            return {"error": rpc_error(E.SIG_KEY_NOT_FOUND,
                                       f"Unknown participant: {p['from']}")}
        old_kid = p["old_kid"]
        old_key = next((k for k in member.keys if k.kid == old_kid), None)
        if old_key is None:
            return {"error": rpc_error(E.SIG_KEY_NOT_FOUND,
                                       f"No key {old_kid} for {p['from']}")}
        if old_key.revoked_at is not None:
            return {"error": rpc_error(E.SIG_KEY_REVOKED,
                                       f"Key {old_kid} is revoked")}

        new_jwk = p["new_jwk"]
        if not isinstance(new_jwk, dict) or not isinstance(new_jwk.get("kid"), str):
            return {"error": rpc_error(E.PARAMS, "new_jwk must include kid")}
        # Keys are found by kid, so a new key under a kid the member holds
        # would be closed with the old one, or shadowed by it.
        if any(k.kid == new_jwk["kid"] for k in member.keys):
            return {"error": rpc_error(
                E.PARAMS,
                f"{p['from']} already holds a key {new_jwk['kid']}; a new key takes a kid of its own")}

        now = coord.now_iso()
        # Close the old key's validity window at the rotation timestamp.
        old_key.valid_until = now
        # Add the new key starting now.
        member.keys.append(KeyRecord(
            jwk=new_jwk, kid=new_jwk["kid"], valid_from=now,
        ))
        return {"result": {"rotated": True,
                           "old_kid": old_kid,
                           "new_kid": new_jwk["kid"],
                           "valid_from": now}}

    def participant_revoke_key(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        for f in ("target_uri", "kid"):
            if f not in p:
                return {"error": rpc_error(E.PARAMS, f"Missing field: {f}")}
        # Both are written into the refusals below, where None reads one way
        # in each language.
        for f in ("target_uri", "kid"):
            if not isinstance(p[f], str):
                return {"error": rpc_error(E.PARAMS, f"{f} must be a string")}
        bad = params_error(p, [("from", "string"), ("reason", "string")])
        if bad:
            return bad
        sender = p.get("from")
        if sender != p["target_uri"]:
            caller = ws.members.get(sender) if sender else None
            if caller is None or caller.role != "admin":
                return {"error": rpc_error(
                    E.NOT_AUTHORISED,
                    "Revoking another member's key requires the admin role")}
        member = lookup(ws.members, p["target_uri"])
        if not member:
            return {"error": rpc_error(E.SIG_KEY_NOT_FOUND,
                                       f"Unknown target: {p['target_uri']}")}
        key = next((k for k in member.keys if k.kid == p["kid"]), None)
        if key is None:
            return {"error": rpc_error(E.SIG_KEY_NOT_FOUND,
                                       f"No key {p['kid']} for target")}
        now = coord.now_iso()
        key.revoked_at = now
        key.revoked_reason = p.get("reason") or "unspecified"
        return {"result": {"revoked": True, "kid": key.kid,
                           "revoked_at": key.revoked_at,
                           "reason": key.revoked_reason}}

    coord._handlers["participant.rotate_key"] = participant_rotate_key
    coord._handlers["participant.revoke_key"] = participant_revoke_key
