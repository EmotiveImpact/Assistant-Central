"""
chap_coordinator.transports.mcp_server
=======================================

MCP server adapter for a CHAP Coordinator. Wraps a Coordinator
instance and exposes every CHAP method as an MCP tool.

Spec target: MCP 2026-07-28, serving handshake-era clients as well.

The 2026-07-28 revision is stateless: instead of negotiating once through
an ``initialize`` handshake, every request carries its protocol version and
client capabilities in ``_meta``, and the server accepts or rejects each
request on its own. The ``mcp`` 2.x SDK implements that boundary natively,
so this adapter inherits ``server/discover``, per-request version rejection
with ``UnsupportedProtocolVersionError``, envelope validation, era-aware
``resultType`` tagging, and cacheable list results. A handshake-era client
negotiating ``2025-11-25`` through ``initialize`` continues to work
unchanged on the same server.

Two version sets, deliberately different, matching the TypeScript adapter:

- Only ``2026-07-28`` may be declared in a per-request envelope, because
  only revisions that use per-request metadata can be. A request naming
  anything else is refused with ``-32022``, whose payload lists just the
  declarable versions so a retry never lands on the same refusal.

- ``server/discover`` advertises ``2026-07-28`` and ``2025-11-25``, because
  CHAP serves both eras. The SDK's default handler advertises only the
  modern set, so this module replaces it.

Usage (stdio)::

    from chap_coordinator import Coordinator
    from chap_coordinator.transports.mcp_server import make_chap_mcp_server
    from mcp.server.stdio import stdio_server

    coord = Coordinator()
    server = make_chap_mcp_server(coord, name="chap", version="0.3.5")

    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())

That server offers every tool, and each call names its own ``from``. A
server that is one participant's connection, such as an assistant's, pins it
and offers the agent's tools::

    server = make_chap_mcp_server(
        coord,
        participant="agent:assistant",
        tool_filter=lambda name: name in AGENT_MCP_TOOLS,
    )

``python -m chap_coordinator.transports.mcp_cli`` runs such a server on
stdio, alone or forwarding to a desk server with ``--url``; see that
module.

Architecture notes
------------------

- One Coordinator -> one MCP server. Multi-workspace is handled
  inside the Coordinator (workspaces are addressable by id).

- The adapter holds no state. Every tool call translates to a
  JSON-RPC envelope and dispatches through ``coord.dispatch()``.

- Tool naming follows ``chap.<method>`` so the prefix avoids
  collisions with other MCP servers a client might load.

- Tool inputs are described by JSON Schemas (not Pydantic models)
  and are passed through to the Coordinator without re-validating
  at the MCP layer. The Coordinator's own dispatch validates params
  and returns spec-correct JSON-RPC error codes, which we surface
  as MCP tool errors. This keeps the schema definitions
  single-sourced.

- Authentication is intentionally out of scope at this layer.
  Apply OAuth 2.1 / Streamable HTTP auth at the transport layer
  per MCP's auth model.
"""
from __future__ import annotations

import inspect
import json
import logging
from itertools import count
from typing import Any, Awaitable, Callable, Optional, Protocol, Union

from mcp import MCPError
from mcp.server import CacheHint, Server
from mcp.server.context import ServerRequestContext
from mcp.types import (
    INVALID_PARAMS,
    CallToolRequestParams,
    CallToolResult,
    DiscoverResult,
    ListToolsResult,
    PaginatedRequestParams,
    RequestParams,
    TextContent,
    Tool,
)

from chap_coordinator.coordinator import Coordinator

from .mcp_schemas import SCHEMAS, TOOL_NAMES, method_for_tool, coerce_tool_args
from .mcp_tools import AGENT_MCP_TOOLS, TOOL_ANNOTATIONS, TOOL_DESCRIPTIONS
from .remote import ChapEndpointError


logger = logging.getLogger(__name__)

#: JSON-RPC's internal error: a fault inside the coordinator, which refused nothing.
_INTERNAL_ERROR = -32603

#: What a client is told of a fault inside the server; the detail is in the server's log.
_FAILED_INSIDE = "The CHAP call failed inside the server; its log has the detail."

#: Revisions that may be declared in a per-request ``_meta`` envelope.
MODERN_PROTOCOL_VERSIONS = ("2026-07-28",)

#: Revisions advertised by ``server/discover``, newest first. Spans both
#: eras because CHAP serves both.
SUPPORTED_PROTOCOL_VERSIONS = ("2026-07-28", "2025-11-25")

#: Freshness hint for cacheable list results. The CHAP tool surface is fixed
#: at construction, so a long TTL is safe.
LIST_TTL_MS = 3_600_000

_LIST_CACHE_HINT = CacheHint(ttl_ms=LIST_TTL_MS, scope="public")

_INSTRUCTIONS = (
    "CHAP Coordinator exposed as MCP tools. Every accepted call that "
    "changes state is recorded on the CHAP audit log, as is a member's "
    "refused attempt at a governed action. Governed methods enforce "
    "membership and review rules server-side."
)

__all__ = [
    "make_chap_mcp_server",
    "AGENT_MCP_TOOLS",
    "ChapDispatcher",
    "MODERN_PROTOCOL_VERSIONS",
    "SUPPORTED_PROTOCOL_VERSIONS",
    "LIST_TTL_MS",
    "dispatch_tool_call",
    "SCHEMAS",
    "TOOL_NAMES",
    "TOOL_ANNOTATIONS",
    "TOOL_DESCRIPTIONS",
    "method_for_tool",
    "coerce_tool_args",
]


class ChapDispatcher(Protocol):
    """What the server dispatches each call through: a Coordinator, or anything
    with the same ``dispatch``, such as a client that forwards the envelope to
    a running server. The answer may be returned or awaited."""

    def dispatch(self, envelope: dict[str, Any]) -> Union[dict[str, Any], Awaitable[dict[str, Any]]]: ...


def _pinned_schema(schema: dict[str, Any], participant: str) -> dict[str, Any]:
    """A tool's input schema as a server that acts as ``participant`` advertises
    it. ``from`` is filled in, so a client need not send it, and the schema
    says whose name the calls carry."""
    properties = schema.get("properties") or {}
    if "from" not in properties:
        return schema
    return {
        **schema,
        "properties": {
            **properties,
            "from": {
                "type": "string",
                "description": f"This server acts as {participant}: it fills this in, "
                               "and refuses a call that names anyone else.",
            },
        },
        "required": [key for key in schema.get("required", []) if key != "from"],
    }


def _refuse_person(participant: Optional[str]) -> None:
    """Refuse a ``human:`` participant, as the commands refuse one: a server
    that makes every call as one member is a connection for an agent, and a
    person decides in a desk."""
    if participant is not None and participant.startswith("human:"):
        raise ValueError(f"participant {participant} names a person. This server acts for an agent, "
                         "and a person decides in a desk; give the agent's own URI, such as "
                         "agent:assistant.")


def make_chap_mcp_server(
    coord: ChapDispatcher,
    *,
    name: str = "chap",
    version: str = "0.3.5",
    tool_filter: Optional[Callable[[str], bool]] = None,
    envelope_id_factory: Optional[Callable[[], Any]] = None,
    participant: Optional[str] = None,
) -> Server:
    """Wrap a CHAP Coordinator as an MCP server.

    The returned :class:`mcp.server.Server` has ``tools/list`` and
    ``tools/call`` handlers registered for every CHAP method; pass it
    to a transport (stdio, Streamable HTTP) to start serving.

    Parameters
    ----------
    coord
        The Coordinator instance to wrap, or any object with the same
        ``dispatch``, whose answer may be awaitable.
    name
        Server name advertised to MCP clients.
    version
        Server version string.
    tool_filter
        Optional predicate to restrict which CHAP methods are offered.
        Default: all of them. A tool the predicate excludes is left out of
        the list and refused when called.
    envelope_id_factory
        Optional callable returning a fresh envelope id per call.
        Default: a counter producing ``"mcp-1"``, ``"mcp-2"``, ...
    participant
        Make every call as this participant: ``from`` is filled in on each
        call, and a call that names another ``from`` is refused. Use it where
        the server is one participant's connection, such as an agent's, so
        the connection cannot act in anyone else's name. The tools then list
        ``from`` as optional, with this URI in its description. A ``human:``
        URI is refused with ``ValueError``: a person decides in a desk, never
        through a connection made for an agent. Default: each call names its
        own ``from``.

    ``AGENT_MCP_TOOLS`` is the tool set such a connection offers an agent:
    pass ``tool_filter=lambda name: name in AGENT_MCP_TOOLS``.
    """
    _refuse_person(participant)
    if envelope_id_factory is None:
        counter = count(1)

        def _next_id() -> str:
            return f"mcp-{next(counter)}"

        next_id = _next_id
    else:
        next_id = envelope_id_factory

    filter_fn = tool_filter or (lambda _name: True)

    enabled = [
        tool_name
        for tool_name in TOOL_NAMES
        if filter_fn(tool_name) and method_for_tool(tool_name) is not None
    ]

    # Behavioural hints travel with each tool. Without them a client has only
    # the prose to judge whether a call is safe to make or to retry, and the
    # title was the tool name repeated back, which told a reader nothing.
    tool_list: list[Tool] = [
        Tool(
            name=tool_name,
            title=TOOL_ANNOTATIONS.get(tool_name, {}).get("title", tool_name),
            description=TOOL_DESCRIPTIONS.get(tool_name, f"CHAP method {method_for_tool(tool_name)}."),
            inputSchema=(SCHEMAS[tool_name] if participant is None
                         else _pinned_schema(SCHEMAS[tool_name], participant)),
            annotations=TOOL_ANNOTATIONS.get(tool_name),
        )
        for tool_name in enabled
    ]

    async def _list_tools(
        ctx: ServerRequestContext[Any],
        params: PaginatedRequestParams | None,
    ) -> ListToolsResult:
        return ListToolsResult(tools=tool_list)

    async def _call_tool(
        ctx: ServerRequestContext[Any],
        params: CallToolRequestParams,
    ) -> CallToolResult:
        tool_name = params.name
        arguments = params.arguments or {}

        # A name that is no CHAP tool is a protocol error, -32602, as the
        # tools page of both revisions has it. A tool this server leaves out
        # is refused below as a tool result, as any refusal is.
        if tool_name not in SCHEMAS:
            raise MCPError(INVALID_PARAMS, f"Unknown tool: {tool_name}")
        method = method_for_tool(tool_name)
        # The filter decides what this server offers, so a tool it excludes is
        # refused here as well as left out of the list. Hidden alone, it still
        # ran for any client that called it by name.
        if not filter_fn(tool_name):
            return CallToolResult(
                isError=True,
                content=[TextContent(type="text",
                                     text=f"CHAP tool not offered by this server: {tool_name}")],
            )

        params = dict(coerce_tool_args(tool_name, arguments))
        if participant is not None:
            if "from" in params and params["from"] != participant:
                return CallToolResult(
                    isError=True,
                    content=[TextContent(
                        type="text",
                        text=(f"This server acts as {participant}; a call cannot name "
                              f"another from ({json.dumps(params['from'], ensure_ascii=False)})."),
                    )],
                )
            params["from"] = participant

        envelope = {
            "jsonrpc": "2.0",
            "id": next_id(),
            "method": method,
            "params": params,
        }

        try:
            response = coord.dispatch(envelope)
            if inspect.isawaitable(response):
                response = await response
        except ChapEndpointError as exc:
            # A forwarding dispatcher's own failures are written for the
            # client: the server could not be reached, or did not answer in
            # JSON-RPC.
            return CallToolResult(isError=True, content=[TextContent(type="text", text=str(exc))])
        except Exception:  # noqa: BLE001 - a fault in the server, reported without its text
            # The exception's text can carry a path or a stack line, so it
            # goes to the server's log, which the client never sees.
            logger.exception("CHAP dispatch failed")
            return CallToolResult(
                isError=True,
                content=[TextContent(type="text", text=_FAILED_INSIDE)],
            )

        if "error" in response:
            err = response["error"]
            body: dict[str, Any] = {
                "chap_error": err.get("code"),
                "message": err.get("message", ""),
            }
            if "data" in err:
                body["data"] = err["data"]
            if err.get("code") == _INTERNAL_ERROR:
                # A fault inside the coordinator, whose data can carry the
                # exception's text. It goes to the server's log, and the
                # client is told only that the call failed. A refusal is
                # passed on as it came.
                logger.error("CHAP call failed: %s", err)
                body = {"chap_error": _INTERNAL_ERROR, "message": _FAILED_INSIDE}
            return CallToolResult(
                isError=True,
                content=[TextContent(type="text", text=json.dumps(body, indent=2, default=str))],
            )

        return CallToolResult(
            content=[TextContent(
                type="text",
                text=json.dumps(response.get("result"), indent=2, default=str),
            )],
        )

    server: Server = Server(
        name,
        version=version,
        instructions=_INSTRUCTIONS,
        # SEP-2549. The SDK stamps ttlMs and cacheScope onto these results
        # for a modern caller and withholds them from a handshake-era one.
        cache_hints={
            "tools/list": _LIST_CACHE_HINT,
            "server/discover": _LIST_CACHE_HINT,
        },
        on_list_tools=_list_tools,
        on_call_tool=_call_tool,
    )

    async def _discover(
        ctx: ServerRequestContext[Any],
        params: RequestParams | None,
    ) -> DiscoverResult:
        """Advertise both eras.

        The SDK default names only the modern set. CHAP also serves
        handshake-era clients, so both are advertised; which mechanism
        reaches which revision is settled by the version rules above, and a
        request declaring the handshake revision is still refused.
        """
        return DiscoverResult(
            supported_versions=list(SUPPORTED_PROTOCOL_VERSIONS),
            capabilities=server.get_capabilities(protocol_version=ctx.protocol_version),
            instructions=_INSTRUCTIONS,
        )

    server.add_request_handler("server/discover", RequestParams, _discover)

    return server


def dispatch_tool_call(
    coord: Coordinator,
    tool_name: str,
    arguments: dict[str, Any],
    envelope_id: Any = "mcp-call",
) -> dict[str, Any]:
    """Lower-level helper: translate a tool call to a CHAP envelope
    and back. Useful for tests and for embedding the adapter inside a
    larger MCP server that registers its own additional tools.
    """
    method = method_for_tool(tool_name)
    if method is None:
        return {
            "jsonrpc": "2.0",
            "id": envelope_id,
            "error": {"code": -32601, "message": f"Unknown CHAP tool: {tool_name}"},
        }
    return coord.dispatch({
        "jsonrpc": "2.0",
        "id": envelope_id,
        "method": method,
        "params": coerce_tool_args(tool_name, arguments or {}),
    })
