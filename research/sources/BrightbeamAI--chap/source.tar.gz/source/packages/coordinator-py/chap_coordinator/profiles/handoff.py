"""
chap_coordinator.profiles.handoff

The handoff/1.0 profile (profiles/handoff.md).

Methods:
  - handoff.propose : propose moving one or more tasks to a recipient
  - handoff.accept  : accept; atomically reassigns the accepted tasks
  - handoff.decline : decline; original assignee stays; suggest alternative

`to` is a single participant URI or a group:... URI. For groups, the
first member to accept wins; subsequent accepts return
HANDOFF_ALREADY_RESOLVED.

Error codes:
  -32050 one or more task ids not currently assigned to the proposer
  -32051 already accepted/declined
  -32052 recipient not a workspace member
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from ..coordinator import _held_by, _union_of
from ..jsonrpc import E, rpc_error
from ..params import lookup, params_error
from ..types import Handoff, HandoffTask, TaskHistoryEntry

# Names a supplied id cannot take, as in the TypeScript coordinator.
_RESERVED_IDS = frozenset({"__proto__", "constructor", "prototype"})

if TYPE_CHECKING:
    from ..coordinator import Coordinator


def register_handoff(coord: "Coordinator") -> None:

    def handoff_propose(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        for f in ("from", "to", "tasks"):
            if f not in p:
                return {"error": rpc_error(E.PARAMS, f"Missing field: {f}")}
        # The recipient is compared and looked up when the handoff is resolved.
        if not isinstance(p["to"], str):
            return {"error": rpc_error(E.PARAMS, "to must be a string")}
        bad = params_error(p, [("context_links", "strings")])
        if bad:
            return bad

        proposer = p["from"]
        recipient = p["to"]

        # Recipient must be a workspace member or a group:... URI
        if isinstance(recipient, str) and not recipient.startswith("group:"):
            if recipient not in ws.members:
                return {"error": rpc_error(E.HANDOFF_RECIPIENT_NOT_MEMBER,
                                           f"Recipient {recipient} is not a member")}

        # tasks is a list of task descriptor objects, each carrying a task_id
        tasks_in = p["tasks"]
        if not isinstance(tasks_in, list) or not tasks_in:
            return {"error": rpc_error(E.PARAMS, "tasks must be a non-empty list")}

        proposed: list[HandoffTask] = []
        for t in tasks_in:
            if not isinstance(t, dict) or not isinstance(t.get("task_id"), str):
                return {"error": rpc_error(
                    E.PARAMS, "each entry in tasks must be an object with a string task_id")}
            bad = params_error(t, [("blockers", "strings")])
            if bad:
                return bad
            tid = t["task_id"]
            if not tid or tid not in ws.tasks:
                return {"error": rpc_error(E.PARAMS,
                                           f"Unknown task in handoff: {tid}")}
            task = ws.tasks[tid]
            if task.assignee != proposer:
                return {"error": rpc_error(
                    E.HANDOFF_TASKS_NOT_ASSIGNED_TO_PROPOSER,
                    f"Task {tid} is not currently assigned to {proposer}")}
            proposed.append(HandoffTask(
                task_id=tid,
                title=t.get("title"),
                status_summary=t.get("status_summary"),
                next_action=t.get("next_action"),
                blockers=list(t.get("blockers") or []),
            ))

        # A supplied id names a new handoff. One already in use was stored
        # over the existing object, which reopened, reset or replaced it.
        supplied_id = p.get("handoff_id")
        if supplied_id is not None and supplied_id != "":
            if not isinstance(supplied_id, str):
                return {"error": rpc_error(E.PARAMS, "handoff_id must be a string")}
            # Refused as in the TypeScript coordinator, where __proto__ as an
            # object key is dropped when the workspace is saved.
            if supplied_id in _RESERVED_IDS:
                return {"error": rpc_error(E.PARAMS, f'handoff_id cannot be "{supplied_id}"')}
            if supplied_id in ws.handoffs:
                return {"error": rpc_error(E.PARAMS, f"handoff_id already in use: {supplied_id}")}
        hid = p.get("handoff_id") or coord.ids.handoff_id()
        ho = Handoff(
            id=hid,
            proposer=proposer,
            recipient=recipient,
            proposed_at=coord.now_iso(),
            tasks=proposed,
            summary=p.get("summary"),
            context_links=list(p.get("context_links") or []),
        )
        ws.handoffs[hid] = ho
        return {"result": {"handoff_id": hid, "state": "proposed",
                           "task_ids": [t.task_id for t in proposed]}}

    def handoff_accept(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        for f in ("from", "handoff_id"):
            if f not in p:
                return {"error": rpc_error(E.PARAMS, f"Missing field: {f}")}
        ho = lookup(ws.handoffs, p["handoff_id"])
        if not ho:
            return {"error": rpc_error(E.PARAMS, "Unknown handoff")}
        if ho.state != "proposed":
            return {"error": rpc_error(E.HANDOFF_ALREADY_RESOLVED,
                                       f"Handoff already {ho.state}")}

        acceptor = p["from"]
        # The acceptor must be the named recipient, OR (for group recipients)
        # a workspace member. For exact-URI recipients, only that URI may accept.
        if ho.recipient.startswith("group:"):
            if acceptor not in ws.members:
                return {"error": rpc_error(E.HANDOFF_RECIPIENT_NOT_MEMBER,
                                           "Acceptor is not a workspace member")}
        else:
            if acceptor != ho.recipient:
                return {"error": rpc_error(E.HANDOFF_RECIPIENT_NOT_MEMBER,
                                           "Acceptor is not the named recipient")}
            if acceptor not in ws.members:
                return {"error": rpc_error(E.HANDOFF_RECIPIENT_NOT_MEMBER,
                                           "Acceptor is not a workspace member")}
        # Accepting makes the acceptor the assignee. A paused participant is
        # assigned no new tasks (control/1.0), so it cannot take tasks this
        # way.
        if ws.members[acceptor].paused:
            return {"error": rpc_error(E.CONTROL_WORKSPACE_PAUSED,
                                       f"Acceptor {acceptor} is paused")}

        bad = params_error(p, [("accepted_task_ids", "strings")])
        if bad:
            return bad
        # Omission accepts all proposed tasks; an explicit empty selection
        # is invalid and must not record a handoff with no ownership transfer.
        if isinstance(p.get("accepted_task_ids"), list) and not p["accepted_task_ids"]:
            return {"error": rpc_error(E.PARAMS, "accepted_task_ids must not be empty")}
        accepted_ids = (
            list(p["accepted_task_ids"])
            if isinstance(p.get("accepted_task_ids"), list)
            else [t.task_id for t in ho.tasks]
        )
        valid_ids = {t.task_id for t in ho.tasks}
        for tid in accepted_ids:
            if tid not in valid_ids:
                return {"error": rpc_error(E.PARAMS,
                                           f"Task {tid} not in this handoff")}
        # The proposer offered tasks it held. One routed, superseded or
        # handed to someone else since is no longer the proposer's to give,
        # and taking it would move it away from whoever holds it now.
        for tid in accepted_ids:
            task = ws.tasks.get(tid)
            if task is None or task.assignee != ho.proposer:
                return {"error": rpc_error(
                    E.HANDOFF_TASKS_NOT_ASSIGNED_TO_PROPOSER,
                    f"Task {tid} is not currently assigned to {ho.proposer}")}

        # Atomically reassign
        now = coord.now_iso()
        for tid in accepted_ids:
            task = ws.tasks[tid]
            # The proposer, which holds the task and hands it on, stays among
            # the authors of the work (review/1.0 S3.1), so it cannot hand its
            # work on and then review it.
            if acceptor != task.assignee:
                task.prior_authors = _union_of(task.prior_authors or [], _held_by(task, ho.proposer))
            task.assignee = acceptor
            task.updated_at = now
            task.history.append(TaskHistoryEntry(
                ts=now, from_=acceptor, state=task.state,
                note=f"handoff accepted from {ho.proposer}",
            ))

        ho.state = "accepted"
        ho.accepted_by = acceptor
        ho.accepted_task_ids = list(accepted_ids)
        ho.accept_comment = p.get("comment")
        ho.resolved_at = now
        return {"result": {"accepted": True,
                           "task_ids": list(accepted_ids),
                           "assignee": acceptor}}

    def handoff_decline(p: dict) -> dict:
        ws = coord.workspaces.get(p.get("workspace", ""))
        if not ws:
            return {"error": rpc_error(E.PARAMS, "Unknown workspace")}
        for f in ("from", "handoff_id"):
            if f not in p:
                return {"error": rpc_error(E.PARAMS, f"Missing field: {f}")}
        ho = lookup(ws.handoffs, p["handoff_id"])
        if not ho:
            return {"error": rpc_error(E.PARAMS, "Unknown handoff")}
        if ho.state != "proposed":
            return {"error": rpc_error(E.HANDOFF_ALREADY_RESOLVED,
                                       f"Handoff already {ho.state}")}
        # Decline. For group recipients, a single decline does NOT resolve
        # the handoff (others may still accept). For exact-URI recipients,
        # the named recipient declining does resolve it.
        decliner = p["from"]
        ho.decline_reason = p.get("reason")
        ho.decline_suggested_target = p.get("suggested_target")
        if not ho.recipient.startswith("group:") and decliner == ho.recipient:
            ho.state = "declined"
            ho.resolved_at = coord.now_iso()
        return {"result": {"recorded": True, "state": ho.state}}

    coord._handlers["handoff.propose"] = handoff_propose
    coord._handlers["handoff.accept"] = handoff_accept
    coord._handlers["handoff.decline"] = handoff_decline
