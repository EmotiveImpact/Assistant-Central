"""Tests for the review/1.0 profile."""
from __future__ import annotations

import pytest

from chap_coordinator import Coordinator, CoordinatorOptions


@pytest.fixture
def coord_with_task():
    coord = Coordinator(CoordinatorOptions(
        deterministic_ids=True, deterministic_clock=True,
    ))

    def send(method, **params):
        return coord.dispatch({
            "jsonrpc": "2.0", "id": f"t-{method}", "method": method, "params": params,
        })

    send("workspace.create", workspace="wsp_r")
    send("participant.join", workspace="wsp_r",
         **{"from": "human:alice@x", "type": "human", "role": "reviewer"})
    send("participant.join", workspace="wsp_r",
         **{"from": "agent:bot", "type": "agent", "role": "drafter"})
    r = send("task.create", workspace="wsp_r",
             **{"from": "human:alice@x", "kind": "draft", "input": {}},
             assignee="agent:bot")
    return coord, send, r["result"]["task_id"]


def test_override_with_diff(coord_with_task):
    coord, send, tid = coord_with_task
    draft = {"severity": "warning", "text": "issue"}
    send("review.request", workspace="wsp_r", task_id=tid,
         **{"from": "agent:bot", "to": "human:alice@x", "artefact": draft})
    r = send("decide.override", workspace="wsp_r", task_id=tid,
             **{"from": "human:alice@x"},
             diff=[{"op": "replace", "path": "/severity", "value": "info"}],
             rationale="false positive",
             tags=["false-positive"])
    assert "result" in r
    assert r["result"]["applied"]["severity"] == "info"


def test_override_carries_intent_preserved(coord_with_task):
    coord, send, tid = coord_with_task
    draft = {"severity": "warning"}
    send("review.request", workspace="wsp_r", task_id=tid,
         **{"from": "agent:bot", "to": "human:alice@x", "artefact": draft})
    r = send("decide.override", workspace="wsp_r", task_id=tid,
             **{"from": "human:alice@x"},
             diff=[{"op": "replace", "path": "/severity", "value": "info"}],
             rationale="cosmetic only",
             tags=[],
             intent_preserved=True,
             logical_id="lgl_abc123")
    art_id = r["result"]["override_artefact_id"]
    ws = coord.workspaces["wsp_r"]
    override = ws.overrides[art_id]
    assert override.intent_preserved is True
    assert override.logical_id == "lgl_abc123"


def test_override_rejects_invalid_patch(coord_with_task):
    coord, send, tid = coord_with_task
    send("review.request", workspace="wsp_r", task_id=tid,
         **{"from": "agent:bot", "to": "human:alice@x", "artefact": {"a": 1}})
    r = send("decide.override", workspace="wsp_r", task_id=tid,
             **{"from": "human:alice@x"},
             diff=[{"op": "replace", "path": "/nonexistent", "value": 2}],
             rationale="x", tags=[])
    assert r["error"]["code"] == -32012  # PATCH_FAILED


def test_decide_override_requires_review_state(coord_with_task):
    coord, send, tid = coord_with_task
    # No review.request: task is in 'created'
    r = send("decide.override", workspace="wsp_r", task_id=tid,
             **{"from": "human:alice@x"},
             diff=[], rationale="x", tags=[])
    assert r["error"]["code"] == -32010  # NOT_REVIEWABLE


def test_abstain_declare(coord_with_task):
    coord, send, tid = coord_with_task
    send("review.request", workspace="wsp_r", task_id=tid,
         **{"from": "agent:bot", "to": "human:alice@x", "artefact": {}})
    r = send("abstain.declare", workspace="wsp_r", task_id=tid,
             **{"from": "human:alice@x"},
             reason="conflict of interest",
             category="conflict_of_interest")
    assert r["result"]["state"] == "abstained"


def test_escalate_raise(coord_with_task):
    coord, send, tid = coord_with_task
    send("participant.join", workspace="wsp_r",
         **{"from": "human:senior@x", "type": "human", "role": "lead"})
    r = send("escalate.raise", workspace="wsp_r",
             **{"from": "human:alice@x"},
             original_task_id=tid,
             new_task={"kind": "review", "input": {"reason": "high-risk"},
                       "assignee": "human:senior@x"})
    assert "result" in r
    assert r["result"]["escalated_from"] == tid


def test_task_update_cannot_complete_task_awaiting_review(coord_with_task):
    coord, send, tid = coord_with_task
    send("review.request", workspace="wsp_r", task_id=tid,
         **{"from": "agent:bot", "to": "human:alice@x", "artefact": {"text": "draft"}})

    # The drafter tries to self-complete the task under review, with no reviewer
    # decision. The review gate lives in decide.*/abstain (reviewer-gated); a plain
    # task.update by a member must not reach a terminal state around it.
    bypass = send("task.update", workspace="wsp_r", task_id=tid,
                  **{"from": "agent:bot", "state": "completed"})
    assert "error" in bypass
    assert coord.get_workspace("wsp_r").tasks[tid].state == "review_requested"

    # Withdrawing the review request back to in_progress stays legal.
    withdraw = send("task.update", workspace="wsp_r", task_id=tid,
                    **{"from": "agent:bot", "state": "in_progress"})
    assert withdraw["result"]["state"] == "in_progress"


def _rule_coord():
    coord = Coordinator(CoordinatorOptions(deterministic_ids=True, deterministic_clock=True))

    def send(method, **params):
        return coord.dispatch({"jsonrpc": "2.0", "id": f"t-{method}",
                               "method": method, "params": params})

    send("workspace.create", workspace="w")
    for who in ("human:a", "human:b", "human:c"):
        send("participant.join", workspace="w",
             **{"from": who, "type": "human", "role": "reviewer"})
    send("participant.join", workspace="w",
         **{"from": "agent:bot", "type": "agent", "role": "drafter"})
    tid = send("task.create", workspace="w",
               **{"from": "human:a", "kind": "draft", "input": {},
                  "assignee": "agent:bot"})["result"]["task_id"]
    return coord, send, tid


def test_all_approve_requires_every_named_reviewer():
    coord, send, tid = _rule_coord()
    send("review.request", workspace="w",
         **{"from": "agent:bot", "to": ["human:a", "human:b", "human:c"]},
         task_id=tid, artefact={"x": 1}, rule="all_approve")
    assert send("decide.approve", workspace="w", **{"from": "human:a"},
                task_id=tid)["result"]["state"] == "review_requested"
    assert send("decide.approve", workspace="w", **{"from": "human:b"},
                task_id=tid)["result"]["state"] == "review_requested"
    assert send("decide.approve", workspace="w", **{"from": "human:c"},
                task_id=tid)["result"]["state"] == "completed"


def test_all_approve_ignores_a_duplicate_approval():
    coord, send, tid = _rule_coord()
    send("review.request", workspace="w",
         **{"from": "agent:bot", "to": ["human:a", "human:b"]},
         task_id=tid, artefact={"x": 1}, rule="all_approve")
    send("decide.approve", workspace="w", **{"from": "human:a"}, task_id=tid)
    # A second approval from the same reviewer must not satisfy all_approve.
    assert send("decide.approve", workspace="w", **{"from": "human:a"},
                task_id=tid)["result"]["state"] == "review_requested"
    assert send("decide.approve", workspace="w", **{"from": "human:b"},
                task_id=tid)["result"]["state"] == "completed"


def test_quorum_completes_at_n_distinct_approvers():
    coord, send, tid = _rule_coord()
    send("review.request", workspace="w",
         **{"from": "agent:bot", "to": ["human:a", "human:b", "human:c"]},
         task_id=tid, artefact={"x": 1}, rule="quorum:2")
    assert send("decide.approve", workspace="w", **{"from": "human:a"},
                task_id=tid)["result"]["state"] == "review_requested"
    assert send("decide.approve", workspace="w", **{"from": "human:b"},
                task_id=tid)["result"]["state"] == "completed"


def test_review_request_rejects_unhonorable_rule():
    coord, send, tid = _rule_coord()
    r = send("review.request", workspace="w",
             **{"from": "agent:bot", "to": ["human:a"]},
             task_id=tid, artefact={"x": 1}, rule="weighted_vote:2.0")
    assert r["error"]["code"] == -32602  # PARAMS: rule review/1.0 can't honor


def test_a_quorum_is_counted_in_ascii_digits():
    # Other scripts' digits passed str.isdigit(): quorum:١ opened a review the
    # TypeScript coordinator refused, and quorum:² failed in int() with an
    # internal error.
    for rule in ("quorum:١", "quorum:²", "quorum:２"):
        coord, send, tid = _rule_coord()
        r = send("review.request", workspace="w",
                 **{"from": "agent:bot", "to": ["human:a"]},
                 task_id=tid, artefact={"x": 1}, rule=rule)
        assert r["error"]["code"] == -32602, rule


def test_task_complete_refusal_mutates_nothing():
    coord = Coordinator(CoordinatorOptions(deterministic_ids=True, deterministic_clock=True))

    def send(method, **params):
        return coord.dispatch({"jsonrpc": "2.0", "id": f"t-{method}",
                               "method": method, "params": params})

    send("workspace.create", workspace="w")
    send("participant.join", workspace="w",
         **{"from": "agent:bot", "type": "agent", "role": "drafter"})
    tid = send("task.create", workspace="w",
               **{"from": "agent:bot", "kind": "draft", "input": {},
                  "assignee": "agent:bot", "review_required": True})["result"]["task_id"]
    send("task.update", workspace="w", **{"from": "agent:bot"},
         task_id=tid, state="in_progress")
    ws = coord.workspaces["w"]
    audit_before = len(ws.audit)

    r = send("task.complete", workspace="w", **{"from": "agent:bot"},
             task_id=tid, output={"secret": "x"})
    assert r["error"]["code"] == -32011
    t = ws.tasks[tid]
    assert t.pending_artefact is None
    assert t.state == "in_progress"
    # One refusal entry, and no accepted entry: the output never reached the log.
    assert len(ws.audit) == audit_before + 1
    entry = ws.audit[audit_before]
    assert entry.envelope is None
    assert entry.outcome == {"status": "refused", "code": -32011}
