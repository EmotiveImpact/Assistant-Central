"""
The desk server in the package: chap_coordinator.server.

Generated projects carried a copy of the server, so a fix never reached a
project already generated, and a Python user with more than one process
copied it from a clone. The copy answered under its own names only and took
JSON only, and sent no Content-Security-Policy, no X-Frame-Options and no
nosniff, so any page could frame the desk, and a page dropped in analytics/
ran in the desk's own origin, where the reviewer's key is kept. Its store
path was read against the directory the server started in, and a ``~`` in
CHAP_DB_PATH made a directory named ``~``.

These tests run the server as the package ships it: on the standard
library's HTTP server, and as an ASGI app under Starlette and FastAPI.
"""
from __future__ import annotations

import asyncio
import errno
import hashlib
import hmac
import http.client
import json
import logging
import os
import re
import socket
import sqlite3
import sys
import threading
import time
import urllib.request
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urljoin

import pytest
from fastapi import FastAPI
from starlette.applications import Starlette
from starlette.responses import PlainTextResponse
from starlette.routing import Mount, Route
from starlette.testclient import TestClient

from chap_coordinator import server as server_module
from chap_coordinator.client import HttpCoordinator, Participant, Signer
from chap_coordinator.crypto import public_jwk
from chap_coordinator.server import (
    ANALYTICS_POLICY, MAX_BODY_BYTES, SECURITY_HEADERS, ChapDesk, desk_url, load_config, make_coordinator,
    make_server, public_config, read_desk, serve,
)

HUMAN = "human:you@local"
AGENT = "agent:drafter"
DESK_POLICY = SECURITY_HEADERS["content-security-policy"]
#: The Node server, whose headers the desk is built for.
NODE_SERVER = Path(__file__).resolve().parents[2] / "chap-server" / "lib" / "server.mjs"


def write_config(directory: Path, **fields) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    config = {"workspace": "wsp_test", "profiles": ["core/1.0", "review/1.0"], "store": ":memory:",
              "port": 0, "humans": [{"uri": HUMAN, "display_name": "You", "role": "reviewer"}],
              "agent": {"uri": AGENT, "display_name": "The drafter"}, **fields}
    path = directory / "chap.config.json"
    path.write_text(json.dumps(config), encoding="utf-8")
    return path


@pytest.fixture
def desk_of(tmp_path, monkeypatch):
    """Start the standard library server on a free port, with the store in
    memory and these fields in chap.config.json; returns its port."""
    for name in ("PORT", "CHAP_HOST", "CHAP_DB_PATH", "CHAP_REQUIRE_SIGNATURES", "CHAP_CHAIN", "CHAP_ALLOWED_HOSTS",
                 "CHAP_DESK_SIGNING"):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("CHAP_ENROLMENT_CODE", ENROL)
    servers = []

    def start(**fields) -> int:
        config = load_config(write_config(tmp_path / f"project{len(servers)}", **fields))
        server = make_server(config, make_coordinator(config))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        servers.append(server)
        return server.server_port

    try:
        yield start
    finally:
        for server in servers:
            server.shutdown()
            server.server_close()


@pytest.fixture
def desk(tmp_path, monkeypatch):
    """The standard library server on a free port, with the store in memory."""
    for name in ("PORT", "CHAP_HOST", "CHAP_DB_PATH", "CHAP_REQUIRE_SIGNATURES", "CHAP_CHAIN", "CHAP_ALLOWED_HOSTS"):
        monkeypatch.delenv(name, raising=False)
    config = load_config(write_config(tmp_path / "project", chain=True))
    coord = make_coordinator(config)
    server = make_server(config, coord)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        yield {"config": config, "coord": coord, "port": server.server_port, "ipv6": server.other is not None}
    finally:
        server.shutdown()
        server.server_close()


def request(port: int, method: str, path: str, headers=(), body: bytes = b"", host: str | None = None):
    """One request with exactly these headers; the status, the headers and the body."""
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    conn.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
    conn.putheader("Host", host if host is not None else f"127.0.0.1:{port}")
    for name, value in headers:
        conn.putheader(name, value)
    if body:
        conn.putheader("Content-Length", str(len(body)))
    conn.endheaders(body or None)
    response = conn.getresponse()
    data = response.read()
    conn.close()
    return response.status, {k.lower(): v for k, v in response.getheaders()}, data


#: The enrolment code every server in these tests takes, which a person's
#: first join carries.
ENROL = "TESTS-ENROL"


def call(port: int, method: str, enrolment: str | None = ENROL, **params):
    envelope = {"jsonrpc": "2.0", "id": method, "method": method, "params": {"workspace": "wsp_test", **params}}
    headers = [("Content-Type", "application/json")] + ([("x-chap-enrolment", enrolment)] if enrolment else [])
    status, _, data = request(port, "POST", "/chap", headers, json.dumps(envelope).encode())
    assert status == 200, data
    return json.loads(data)


def assert_secured(headers: dict, csp: str = DESK_POLICY) -> None:
    assert {k: headers.get(k) for k in SECURITY_HEADERS} == {**SECURITY_HEADERS, "content-security-policy": csp}


# -- configuration --------------------------------------------------------------

def test_the_store_is_found_from_the_config_files_directory_wherever_the_server_starts(tmp_path, monkeypatch):
    monkeypatch.delenv("CHAP_DB_PATH", raising=False)
    project = tmp_path / "project"
    path = write_config(project, store="./data/chap.db", template={"name": "support-desk", "version": "0.3.4"})
    monkeypatch.chdir(tmp_path)
    config = load_config(path)
    assert config["store"] == str(project / "data" / "chap.db")
    assert config["analytics"] == str(project / "analytics")
    assert config["template"] == {"name": "support-desk", "version": "0.3.4"}

    # CHAP_DB_PATH follows the same rule, and the config file comes from
    # CHAP_CONFIG when no path is given.
    monkeypatch.setenv("CHAP_DB_PATH", "other.db")
    monkeypatch.setenv("CHAP_CONFIG", str(path))
    assert load_config()["store"] == str(project / "other.db")
    monkeypatch.setenv("CHAP_DB_PATH", ":memory:")
    assert load_config(path)["store"] == ":memory:"


def test_port_0_in_the_file_picks_a_free_port(tmp_path, monkeypatch):
    monkeypatch.delenv("PORT", raising=False)
    config = load_config(write_config(tmp_path, port=0))
    assert config["port"] == 0
    server = make_server(config, make_coordinator(config))
    try:
        assert server.server_port not in (0, 8792)
    finally:
        server.server_close()
    assert load_config(write_config(tmp_path, port=None))["port"] == 8792
    monkeypatch.setenv("PORT", "8790")
    assert load_config(write_config(tmp_path, port=0))["port"] == 8790


def test_a_leading_tilde_is_the_home_directory(tmp_path, monkeypatch):
    home = tmp_path / "home"
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.delenv("CHAP_DB_PATH", raising=False)
    path = write_config(tmp_path / "project", store="~/chap.db", analytics="~/pages")
    config = load_config(path)
    assert (config["store"], config["analytics"]) == (str(home / "chap.db"), str(home / "pages"))
    monkeypatch.setenv("CHAP_DB_PATH", "~/chap-review.db")
    monkeypatch.chdir(tmp_path)
    config = load_config(path)
    assert config["store"] == str(home / "chap-review.db")
    make_coordinator(config).options.store.close()
    assert (home / "chap-review.db").exists()
    assert not any(p.name == "~" for p in tmp_path.rglob("*"))


@pytest.mark.parametrize("in_file, in_env, profiles, expected", [
    (True, None, [], (True, "all")),
    ("humans", None, [], (True, "humans")),
    (False, None, [], (False, None)),
    (False, "humans", [], (True, "humans")),
    (True, "0", [], (False, None)),
    ("humans", "true", [], (True, "all")),
    (False, None, ["security-signed/1.0"], (True, "all")),
])
def test_require_signatures_is_true_false_or_humans(tmp_path, monkeypatch, in_file, in_env, profiles, expected):
    if in_env is None:
        monkeypatch.delenv("CHAP_REQUIRE_SIGNATURES", raising=False)
    else:
        monkeypatch.setenv("CHAP_REQUIRE_SIGNATURES", in_env)
    path = write_config(tmp_path, require_signatures=in_file, profiles=["core/1.0", *profiles])
    config = load_config(path)
    assert (config["require_signatures"], config["signature_policy"]) == expected


def test_desk_signing_says_how_the_desk_signs_as_the_node_server_reads_it(tmp_path, monkeypatch):
    # The desk reads it from /api/config: a passkey asks the person to
    # verify each signature, which a program running as them cannot do.
    monkeypatch.delenv("CHAP_DESK_SIGNING", raising=False)
    assert public_config(load_config(write_config(tmp_path)))["desk_signing"] == "browser-key"
    for value in ("auto", "webauthn", "browser-key"):
        assert public_config(load_config(write_config(tmp_path, desk_signing=value)))["desk_signing"] == value
    monkeypatch.setenv("CHAP_DESK_SIGNING", "webauthn")
    assert load_config(write_config(tmp_path, desk_signing="auto"))["desk_signing"] == "webauthn"
    monkeypatch.setenv("CHAP_DESK_SIGNING", "passkey")
    with pytest.raises(ValueError, match='desk_signing in chap.config.json, or CHAP_DESK_SIGNING, is "passkey"; '
                                         'it is "auto", "webauthn" or "browser-key"'):
        load_config(write_config(tmp_path))
    monkeypatch.delenv("CHAP_DESK_SIGNING")
    with pytest.raises(ValueError, match=r'is \["auto"\]; it is'):
        load_config(write_config(tmp_path, desk_signing=["auto"]))


def test_a_signature_setting_that_says_neither_is_refused(tmp_path, monkeypatch):
    monkeypatch.delenv("CHAP_REQUIRE_SIGNATURES", raising=False)
    with pytest.raises(ValueError, match='is "people"; it takes true, false or "humans"'):
        load_config(write_config(tmp_path, require_signatures="people"))
    monkeypatch.setenv("CHAP_REQUIRE_SIGNATURES", "yes")
    with pytest.raises(ValueError, match="CHAP_REQUIRE_SIGNATURES is 'yes'; it takes 1, true, humans, 0 or false"):
        load_config(write_config(tmp_path, require_signatures=True))


@pytest.mark.parametrize("setting, joined, policy", [
    ("humans", {AGENT}, "humans"),
    (True, set(), "all"),
    (False, {HUMAN, AGENT}, None),
])
def test_the_signature_policy_reaches_the_coordinator_and_decides_who_is_joined(tmp_path, monkeypatch, setting,
                                                                                 joined, policy):
    monkeypatch.delenv("CHAP_REQUIRE_SIGNATURES", raising=False)
    config = load_config(write_config(tmp_path, require_signatures=setting))
    coord = make_coordinator(config)
    ws = coord.get_workspace("wsp_test")
    # The agent calls unsigned under "humans", as a member that is not a
    # person, so it is joined at start; a person joins from the desk with
    # the key the browser makes, and where every call is signed nobody is
    # joined for them.
    assert set(ws.members) == joined
    assert ws.signature_policy == (policy or "all")
    assert ("security-signed/1.0" in ws.profiles) is (policy is not None)
    public = public_config(config)
    assert (public["require_signatures"], public["signature_policy"]) == (policy is not None, policy)


def test_under_humans_the_agent_calls_unsigned_and_a_person_does_not(desk_of):
    port = desk_of(require_signatures="humans")
    # The agent, joined at start, calls unsigned.
    task = call(port, "task.create", **{"from": AGENT}, kind="draft", assignee=AGENT, input={},
                review_required=True)["result"]
    # A person's call is signed, whether or not they have joined.
    stranger = call(port, "task.create", **{"from": "human:stranger@local"}, kind="draft", input={})
    assert stranger["error"]["code"] == -32070
    assert call(port, "participant.join", **{"from": HUMAN}, type="human", role="reviewer",
                jwks={"keys": [public_jwk(HUMAN)]})["result"]["joined"]
    assert call(port, "task.complete", **{"from": AGENT}, task_id=task["task_id"],
                output={"body": "hello"})["result"]["state"] == "review_requested"
    assert call(port, "decide.approve", **{"from": HUMAN}, task_id=task["task_id"])["error"]["code"] == -32070


def test_signed_the_persons_decision_is_accepted_under_humans(desk_of, tmp_path):
    port = desk_of(require_signatures="humans")
    person = Participant(HttpCoordinator(f"http://127.0.0.1:{port}/chap"), "wsp_test", HUMAN,
                         Signer.load_or_create(HUMAN, tmp_path / "desk-keys"), enrolment=ENROL)
    person.join("human", "reviewer")
    task = call(port, "task.create", **{"from": AGENT}, kind="draft", assignee=AGENT, input={},
                review_required=True)["result"]
    call(port, "task.complete", **{"from": AGENT}, task_id=task["task_id"], output={"body": "hello"})
    assert person.call("decide.approve", task_id=task["task_id"])["state"] == "completed"


def test_a_store_keeps_the_signature_settings_its_workspace_was_made_with(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("CHAP_REQUIRE_SIGNATURES", raising=False)
    monkeypatch.delenv("CHAP_DB_PATH", raising=False)
    made = load_config(write_config(tmp_path, require_signatures="humans", store="./data/chap.db"))
    make_coordinator(made).options.store.close()
    capsys.readouterr()
    # Asked for every call signed, or for none, the workspace still takes
    # the agent's calls unsigned, so the configuration says what it does:
    # an agent that read "all" would sign, and its join with a new key
    # would be refused.
    for setting in (True, False):
        config = load_config(write_config(tmp_path, require_signatures=setting, store="./data/chap.db"))
        coord = make_coordinator(config)
        coord.options.store.close()
        assert (config["require_signatures"], config["signature_policy"]) == (True, "humans")
        assert public_config(config)["signature_policy"] == "humans"
        assert ("wsp_test was created under other settings, and runs with people sign every call; an agent "
                "member's calls need no signature. require_signatures in chap.config.json applies to a new "
                "store.") in capsys.readouterr().out
    # As asked, nothing more is said.
    make_coordinator(load_config(write_config(tmp_path, require_signatures="humans",
                                              store="./data/chap.db"))).options.store.close()
    assert "other settings" not in capsys.readouterr().out


def test_a_config_without_a_workspace_or_profiles_is_refused(tmp_path):
    path = tmp_path / "chap.config.json"
    path.write_text(json.dumps({"profiles": ["core/1.0"]}), encoding="utf-8")
    with pytest.raises(ValueError, match="names no workspace"):
        load_config(path)
    path.write_text(json.dumps({"workspace": "wsp_x", "profiles": "core/1.0"}), encoding="utf-8")
    with pytest.raises(ValueError, match="needs profiles"):
        load_config(path)


# -- the standard library server ------------------------------------------------

def test_every_response_carries_the_security_headers(desk):
    port = desk["port"]
    json_post = [("Content-Type", "application/json")]
    for method, path, headers, body, status in [
        ("GET", "/", (), b"", 200),
        ("GET", "/desk.js", (), b"", 200),
        ("GET", "/api/config", (), b"", 200),
        ("GET", "/api/tasks/tsk_missing", (), b"", 404),
        ("POST", "/chap", json_post, b'{"jsonrpc": "2.0", "id": 1, "method": "no.such", "params": {}}', 200),
        ("POST", "/chap", [("Content-Type", "text/plain")], b"{}", 415),
        ("PUT", "/api/config", (), b"", 405),
        ("GET", "/", [("Origin", "http://evil.example")], b"", 403),
    ]:
        got, response_headers, _ = request(port, method, path, headers, body)
        assert got == status, (method, path)
        assert_secured(response_headers)
    got, response_headers, _ = request(port, "GET", "/", host="rebind.evil.example")
    assert got == 421
    assert_secured(response_headers)

    # A method the server has no handler for gets the standard library's
    # own error page, with the same headers.
    with socket.create_connection(("127.0.0.1", port), timeout=5) as raw:
        raw.sendall(f"BREW / HTTP/1.0\r\nHost: 127.0.0.1:{port}\r\n\r\n".encode())
        head = raw.recv(65536).decode("latin-1").lower()
    assert head.startswith("http/1.0 501")
    for name, value in SECURITY_HEADERS.items():
        assert f"{name}: {value.lower()}" in head


@pytest.mark.skipif(not NODE_SERVER.exists(), reason="the Node server's source is not beside this package")
def test_the_headers_are_the_node_servers():
    # The desk is one set of files, built for the policy the Node server
    # sends, so both servers send the same headers.
    source = NODE_SERVER.read_text(encoding="utf-8")
    block = re.search(r"export const SECURITY_HEADERS = \{(.*?)\};", source, re.S).group(1)
    assert dict(re.findall(r'"([a-z-]+)": "([^"]*)"', block)) == SECURITY_HEADERS
    assert re.search(r'export const ANALYTICS_POLICY = "([^"]*)";', source).group(1) == ANALYTICS_POLICY


@pytest.mark.parametrize("host, opened", [
    ("127.0.0.1", "http://localhost:8788/"), ("localhost", "http://localhost:8788/"),
    ("::1", "http://localhost:8788/"), ("0.0.0.0", "http://localhost:8788/"), ("::", "http://localhost:8788/"),
    ("chap.internal", "http://chap.internal:8788/"), ("fd00::5", "http://[fd00::5]:8788/"),
])
def test_on_this_machine_the_desk_is_opened_at_localhost(host, opened):
    # The desk may sign with WebAuthn, whose relying party is a domain name.
    assert desk_url(host, 8788) == opened


def test_localhost_reaches_the_server_on_either_loopback_address(desk):
    port = desk["port"]
    for origin_host in (f"localhost:{port}", f"127.0.0.1:{port}", f"[::1]:{port}"):
        status, _, _ = request(port, "POST", "/chap", [("Content-Type", "application/json"),
                                                       ("Origin", f"http://{origin_host}")],
                               b'{"jsonrpc": "2.0", "id": 1, "method": "workspace.describe", '
                               b'"params": {"workspace": "wsp_test"}}', host=origin_host)
        assert status == 200, origin_host
    with urllib.request.urlopen(f"http://localhost:{port}/", timeout=10) as page:
        assert b"CHAP review desk" in page.read()
    if not desk["ipv6"]:
        pytest.skip("this machine has no IPv6 loopback address")
    conn = http.client.HTTPConnection("::1", port, timeout=10)
    conn.request("GET", "/api/health", headers={"Host": f"localhost:{port}"})
    response = conn.getresponse()
    assert response.status == 200 and json.loads(response.read())["workspace"] == "wsp_test"
    conn.close()


def test_a_port_taken_on_the_other_loopback_address_is_named(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("PORT", raising=False)
    try:
        taken = socket.socket(socket.AF_INET6)
        taken.bind(("::1", 0))
    except OSError:
        pytest.skip("this machine has no IPv6 loopback address")
    with taken:
        taken.listen()
        port = taken.getsockname()[1]
        assert serve(load_config(write_config(tmp_path, port=port))) == 1
    assert f"Port {port} on ::1 is in use, and localhost may reach that address first" in capsys.readouterr().err


def test_port_0_takes_a_port_free_on_both_loopback_addresses(tmp_path, monkeypatch):
    # The port picked on 127.0.0.1 can be another program's on ::1; the
    # server then picks again.
    listener = server_module._Listener
    held: list[int] = []

    class HeldOnce(listener):
        def __init__(self, address, desk) -> None:
            if not held:
                held.append(address[1])
                raise OSError(errno.EADDRINUSE, os.strerror(errno.EADDRINUSE))
            super().__init__(address, desk)

    monkeypatch.setattr(server_module, "_Listener", HeldOnce)
    config = load_config(write_config(tmp_path, port=0))
    server = make_server(config, make_coordinator(config))
    try:
        assert held and server.server_port != 0
    finally:
        server.server_close()


def test_a_page_under_analytics_runs_in_a_sandbox(desk):
    port, analytics = desk["port"], Path(desk["config"]["analytics"])
    analytics.mkdir()
    (analytics / "report.html").write_text("<script>localStorage.getItem('key')</script>", encoding="utf-8")
    (analytics / "summary.json").write_text('{"tasks": 1}', encoding="utf-8")
    status, headers, body = request(port, "GET", "/analytics/report.html")
    assert status == 200 and b"localStorage" in body
    assert headers["content-type"] == "text/html; charset=utf-8"
    assert_secured(headers, ANALYTICS_POLICY)
    status, headers, body = request(port, "GET", "/analytics/summary.json")
    assert (status, json.loads(body)) == (200, {"tasks": 1})
    assert_secured(headers, ANALYTICS_POLICY)
    # One file in the directory, by name: no separator, drive, escape or dot file.
    for path in ("/analytics/..%2Fchap.config.json", "/analytics/sub%5Cx.html", "/analytics/C:report.html",
                 "/analytics/.hidden.html", "/analytics/%2e%2e/chap.config.json", "/analytics/report.exe"):
        assert request(port, "GET", path)[0] == 404, path


def test_requests_from_elsewhere_are_refused_before_their_body_is_read(desk):
    port = desk["port"]
    json_post = [("Content-Type", "application/json")]
    assert request(port, "GET", "/api/tasks", host="rebind.evil.example:80")[0] == 421
    assert request(port, "GET", "/api/tasks", host="localhost")[0] == 421
    assert request(port, "GET", "/api/tasks", host=f"localhost:{port}")[0] == 200
    for origin in ("http://evil.example", "null", f"http://rebind.example:{port}"):
        assert request(port, "POST", "/chap", [*json_post, ("Origin", origin)], b"{}")[0] == 403, origin
    two_origins = [*json_post, ("Origin", f"http://127.0.0.1:{port}"), ("Origin", "http://evil.example")]
    assert request(port, "POST", "/chap", two_origins, b"{}")[0] == 403
    assert request(port, "GET", "/api/config", [("Origin", f"http://127.0.0.1:{port}")])[0] == 200
    for content_type in ("text/plain", "application/x-www-form-urlencoded", "multipart/form-data"):
        assert request(port, "POST", "/chap", [("Content-Type", content_type)], b"{}")[0] == 415
    status, _, body = request(port, "POST", "/chap", [*json_post, ("Content-Length", str(MAX_BODY_BYTES + 1))])
    assert status == 413 and b"over" in body
    assert request(port, "POST", "/chap", [*json_post, ("Content-Length", "ten")])[0] == 400
    status, _, body = request(port, "POST", "/chap", json_post, b"{not json")
    assert (status, json.loads(body)["error"]["code"]) == (400, -32700)
    status, headers, _ = request(port, "OPTIONS", "/chap", [("Access-Control-Request-Method", "POST")])
    assert (status, headers["allow"]) == (405, "GET, POST")


def test_a_call_the_store_did_not_record_is_a_clear_error(desk, monkeypatch, caplog):
    port, coord = desk["port"], desk["coord"]
    tasks = len(coord.get_workspace("wsp_test").tasks)

    def full(_change):
        raise sqlite3.OperationalError("database or disk is full")

    monkeypatch.setattr(coord.options.store, "apply", full)
    with caplog.at_level(logging.ERROR, logger="chap_coordinator"):
        refused = call(port, "task.create", **{"from": AGENT}, kind="draft", assignee=AGENT, input={})
    # The code and the data are the coordinator's, and the words say what
    # happened; the cause is in the server's log, and the call left nothing.
    assert refused["error"] == {"code": -32603, "data": {"reason": "store"},
                                "message": "The store did not record this call, so it took no effect; "
                                           "the server's log says why"}
    assert "writing workspace wsp_test to the store failed: database or disk is full" in caplog.text
    assert len(coord.get_workspace("wsp_test").tasks) == tasks
    monkeypatch.undo()
    assert call(port, "task.create", **{"from": AGENT}, kind="draft", assignee=AGENT, input={})["result"]["state"] == "created"

    # An internal error of any other kind keeps the coordinator's words.
    def broken(_params):
        raise RuntimeError("a fault in a handler")

    monkeypatch.setitem(coord._handlers, "workspace.describe", broken)
    assert call(port, "workspace.describe")["error"] == {"code": -32603, "message": "Internal error"}


def test_a_fault_reaches_the_client_without_its_text(desk, monkeypatch, caplog):
    def broken(_envelope):
        raise RuntimeError("the store at /home/someone/secret.db is gone")

    monkeypatch.setattr(desk["coord"], "dispatch", broken)
    with caplog.at_level(logging.ERROR, logger="chap_coordinator.server"):
        status, headers, body = request(desk["port"], "POST", "/chap", [("Content-Type", "application/json")],
                                        b'{"jsonrpc": "2.0", "id": 1, "method": "workspace.describe"}')
    assert status == 500 and b"secret" not in body
    assert json.loads(body) == {"error": "internal error; the server's log has the detail"}
    assert_secured(headers)
    assert "secret.db is gone" in caplog.text


def test_calls_and_reads_share_one_lock_so_the_chain_stays_whole(desk):
    port = desk["port"]
    failures: list = []

    def create(n: int) -> None:
        for i in range(20):
            r = call(port, "task.create", **{"from": AGENT}, kind="draft", assignee=AGENT, input={"n": n, "i": i})
            if "error" in r:
                failures.append(r)

    def read() -> None:
        for _ in range(20):
            status, _, _ = request(port, "GET", "/api/tasks")
            if status != 200:
                failures.append(status)

    switch = sys.getswitchinterval()
    sys.setswitchinterval(1e-6)
    try:
        threads = [threading.Thread(target=create, args=(n,)) for n in range(6)]
        threads += [threading.Thread(target=read) for _ in range(2)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
    finally:
        sys.setswitchinterval(switch)
    assert failures == []
    entries = call(port, "audit.read", **{"from": HUMAN})["result"]["entries"]
    assert [e["seq"] for e in entries] == list(range(3 + 120))
    assert call(port, "audit.verify_chain", **{"from": HUMAN})["result"]["status"] == "verified"
    assert len(desk["coord"].get_workspace("wsp_test").tasks) == 120


class _Scripts(HTMLParser):
    """Each script element's attributes and text, and every event-handler attribute."""

    def __init__(self) -> None:
        super().__init__()
        self.scripts: list[dict] = []
        self.handlers: list[str] = []
        self._in_script = False

    def handle_starttag(self, tag, attrs):
        self.handlers += [name for name, _ in attrs if name.startswith("on")]
        if tag == "script":
            self.scripts.append({**dict(attrs), "text": ""})
            self._in_script = True

    def handle_endtag(self, tag):
        self._in_script = self._in_script and tag != "script"

    def handle_data(self, data):
        if self._in_script:
            self.scripts[-1]["text"] += data


def test_the_desk_is_served_from_the_package_and_runs_under_its_policy(desk):
    port, files = desk["port"], read_desk()
    assert {"index.html", "desk.js", "chap-client.mjs", "desk.css"} <= set(files)
    for name, (content, content_type) in files.items():
        status, headers, body = request(port, "GET", "/" + name)
        assert (status, headers["content-type"], body) == (200, content_type, content), name
    assert b"CHAP review desk" in request(port, "GET", "/")[2]
    # The policy allows no inline script and no eval, so the desk has none.
    page = _Scripts()
    page.feed(files["index.html"][0].decode("utf-8"))
    assert page.scripts and all(s.get("src") and not s["text"].strip() for s in page.scripts)
    assert page.handlers == []
    for name, (content, _) in files.items():
        if name.endswith((".js", ".mjs")):
            assert not re.search(rb"\beval\(|new Function\(|setTimeout\(\s*[\"'`]", content), name


def test_serve_says_so_when_the_port_is_taken(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("PORT", raising=False)
    with socket.socket() as taken:
        taken.bind(("127.0.0.1", 0))
        taken.listen()
        port = taken.getsockname()[1]
        config = load_config(write_config(tmp_path, port=port))
        assert serve(config) == 1
    err = capsys.readouterr().err
    assert f"Port {port} on 127.0.0.1 is in use" in err and "set PORT to a free port" in err
    assert "Traceback" not in err


# -- the ASGI app -----------------------------------------------------------------

@pytest.fixture
def asgi(tmp_path, monkeypatch):
    for name in ("PORT", "CHAP_DB_PATH", "CHAP_REQUIRE_SIGNATURES", "CHAP_ALLOWED_HOSTS"):
        monkeypatch.delenv(name, raising=False)
    config = load_config(write_config(tmp_path / "project"))
    return config, make_coordinator(config)


def test_the_asgi_app_makes_the_same_checks_and_sends_the_same_headers(asgi):
    config, coord = asgi
    with TestClient(ChapDesk(config, coord), base_url="http://127.0.0.1:8788") as client:
        page = client.get("/")
        assert page.status_code == 200 and "CHAP review desk" in page.text
        assert_secured(page.headers)
        envelope = {"jsonrpc": "2.0", "id": 1, "method": "workspace.describe", "params": {"workspace": "wsp_test"}}
        described = client.post("/chap", json=envelope)
        assert described.status_code == 200 and described.json()["result"]["id"] == "wsp_test"
        assert_secured(described.headers)
        assert client.get("/api/config", headers={"host": "rebind.evil.example:8788"}).status_code == 421
        assert client.post("/chap", json=envelope, headers={"origin": "http://evil.example"}).status_code == 403
        assert client.post("/chap", content=b"{}", headers={"content-type": "text/plain"}).status_code == 415
        too_large = client.post("/chap", content=b"x" * (MAX_BODY_BYTES + 1), headers={"content-type": "application/json"})
        assert too_large.status_code == 413
        assert client.put("/api/config").status_code == 405
        assert client.get("/api/tasks/tsk_missing").status_code == 404
        Path(config["analytics"]).mkdir()
        Path(config["analytics"], "report.html").write_text("<p>report</p>", encoding="utf-8")
        report = client.get("/analytics/report.html")
        assert report.status_code == 200
        assert_secured(report.headers, ANALYTICS_POLICY)


def test_fastapi_mounts_the_desk_beside_its_own_routes(asgi):
    config, coord = asgi
    app = FastAPI()
    desk = ChapDesk(config, coord)

    @app.get("/healthz")
    def healthz() -> dict:
        with desk.lock:
            return {"tasks": len(coord.get_workspace(config["workspace"]).tasks)}

    app.mount("/", desk)
    with TestClient(app, base_url="http://127.0.0.1:8788") as client:
        made = client.post("/chap", json={"jsonrpc": "2.0", "id": 1, "method": "task.create", "params": {
            "workspace": "wsp_test", "from": AGENT, "kind": "draft", "assignee": AGENT, "input": {}}})
        assert made.json()["result"]["state"] == "created"
        assert client.get("/healthz").json() == {"tasks": 1}
        assert client.get("/api/tasks").json()["tasks"][0]["kind"] == "draft"
        assert "CHAP review desk" in client.get("/").text


class _References(HTMLParser):
    """The URLs a page loads: every src and href."""

    def __init__(self) -> None:
        super().__init__()
        self.urls: list[str] = []

    def handle_starttag(self, tag, attrs):
        self.urls += [value for name, value in attrs if name in ("src", "href") and value]


def test_mounted_below_a_prefix_the_desk_works_there(asgi):
    config, coord = asgi

    async def own_config(_request):
        return PlainTextResponse("the application's own /api/config")

    desk = ChapDesk(config, coord)
    app = Starlette(routes=[Route("/api/config", own_config), Mount("/review", app=desk)])
    with TestClient(app, base_url="http://127.0.0.1:8788") as client:
        page = client.get("/review/")
        assert page.status_code == 200 and "CHAP review desk" in page.text
        assert_secured(page.headers)
        # Everything the page loads, and every path the desk's scripts call,
        # is relative to the page, and is served under the prefix.
        refs = _References()
        refs.feed(page.text)
        modules = re.findall(r'from "\./([^"]+)"', "".join(body.decode() for name, (body, _) in read_desk().items()
                                                          if name.endswith((".js", ".mjs"))))
        assert refs.urls and modules
        for ref in [*refs.urls, *modules, "api/config", "api/health?desk=1", "api/tasks?brief=1",
                    "api/reviews?reviewer=human%3Ayou%40local"]:
            assert not ref.startswith("/"), ref
            assert client.get(urljoin("/review/", ref)).status_code == 200, ref
        envelope = {"jsonrpc": "2.0", "id": 1, "method": "workspace.describe", "params": {"workspace": "wsp_test"}}
        assert client.post("/review/chap", json=envelope).json()["result"]["id"] == "wsp_test"
        # The application keeps its own routes, with nothing of the desk's.
        own = client.get("/api/config")
        assert own.text == "the application's own /api/config" and "content-security-policy" not in own.headers

    # An ASGI server can hand the app the mount point itself, which names no
    # page: it is sent to the page, with the query kept.
    sent: list[dict] = []

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(message):
        sent.append(message)

    scope = {"type": "http", "method": "GET", "path": "/review", "root_path": "/review", "query_string": b"task=t1",
             "headers": [(b"host", b"127.0.0.1:8788")], "server": ("127.0.0.1", 8788)}
    asyncio.run(desk(scope, receive, send))
    start = sent[0]
    headers = {name.decode(): value.decode() for name, value in start["headers"]}
    assert (start["status"], headers["location"]) == (308, "/review/?task=t1")
    assert_secured(headers)


# -- notifications ------------------------------------------------------------------

class _Webhook(BaseHTTPRequestHandler):
    """A webhook that keeps what it is sent, and answers ``status`` after ``delay`` seconds."""

    received: list
    status = 204
    delay = 0.0

    def log_message(self, *_args) -> None:
        pass

    def do_POST(self) -> None:
        body = self.rfile.read(int(self.headers["content-length"]))
        time.sleep(self.delay)
        self.received.append({"path": self.path, "headers": list(self.headers.items()), "body": body})
        self.send_response(self.status)
        self.send_header("content-length", "0")
        self.end_headers()


@pytest.fixture
def webhook():
    """Start a webhook answering ``status`` after ``delay``; returns its URL and what it receives."""
    servers = []

    def start(status: int = 204, delay: float = 0.0):
        received: list = []
        handler = type("Handler", (_Webhook,), {"received": received, "status": status, "delay": delay})
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        servers.append(server)
        return f"http://127.0.0.1:{server.server_address[1]}", received

    try:
        yield start
    finally:
        for server in servers:
            server.shutdown()
            server.server_close()


def until(predicate, timeout: float = 5.0):
    deadline = time.monotonic() + timeout
    while not predicate():
        assert time.monotonic() < deadline, "timed out"
        time.sleep(0.02)


def test_a_review_and_a_question_are_told_on_the_console_and_to_the_webhook(desk_of, webhook, capsys):
    url, received = webhook()
    port = desk_of(profiles=["core/1.0", "review/1.0", "whisper/1.0"], notify={
        "console": True, "webhook": {"url": f"{url}/hooks/chap?team=a", "secret": "s3cret"}})
    task = call(port, "task.create", **{"from": AGENT}, kind="draft", assignee=AGENT, input={},
                review_required=True)["result"]["task_id"]
    call(port, "task.complete", **{"from": AGENT}, task_id=task, output={"body": "hello"})
    asked = call(port, "whisper.ask", **{"from": AGENT}, to=HUMAN, task_id=task, question="Which tone?",
                 deadline_ms=60_000, default_if_lapsed="formal")["result"]
    call(port, "decide.approve", **{"from": HUMAN}, task_id=task)
    plain = call(port, "task.create", **{"from": AGENT}, kind="note", assignee=AGENT, input={})["result"]["task_id"]
    assert call(port, "task.complete", **{"from": AGENT}, task_id=plain, output={})["result"]["state"] == "completed"
    asked_for = call(port, "task.create", **{"from": AGENT}, kind="letter", assignee=AGENT, input={})["result"]
    call(port, "review.request", **{"from": AGENT}, task_id=asked_for["task_id"], artefact={"body": "Dear"}, to=[HUMAN])
    until(lambda: len(received) >= 3)
    time.sleep(0.3)
    # The opened reviews and the question, and nothing for a decision or a
    # task completed with no review.
    assert len(received) == 3
    assert json.loads(received[2]["body"])["summary"] == f"{AGENT} asks {HUMAN} to review letter {asked_for['task_id']}"
    link = f"http://localhost:{port}/#task={task}"
    notices = [json.loads(r["body"]) for r in received]
    assert notices[0] == {
        "event": "review.requested", "workspace": "wsp_test", "task_id": task, "kind": "draft", "from": AGENT,
        "to": [HUMAN], "summary": f"{AGENT} asks {HUMAN} to review draft {task}", "link": link,
        "seq": notices[0]["seq"], "at": notices[0]["at"]}
    assert notices[1]["event"] == "whisper.asked" and notices[1]["whisper_id"] == asked["whisper_id"]
    assert notices[1]["summary"] == f"{AGENT} asks {HUMAN} a question on draft {task}" and notices[1]["link"] == link
    # Each is signed with the secret, under the header the Node server uses.
    for r in received:
        assert r["path"] == "/hooks/chap?team=a"
        headers = dict(r["headers"])
        assert headers["Content-Type"] == "application/json"
        assert headers["X-Chap-Signature"] == "sha256=" + hmac.new(b"s3cret", r["body"], hashlib.sha256).hexdigest()
    out = capsys.readouterr().out
    assert f"{AGENT} asks {HUMAN} to review draft {task}: {link}" in out
    assert f"{AGENT} asks {HUMAN} a question on draft {task}: {link}" in out


def test_on_the_console_a_notice_cannot_rewrite_the_terminal(desk_of, capsys):
    # The summary names what an agent sent: its task kind, here with an
    # escape sequence that would clear the screen, and a right-to-left override.
    port = desk_of(notify={"console": True})
    task = call(port, "task.create", **{"from": AGENT}, kind="draft\x1b[2J‮", assignee=AGENT, input={},
                review_required=True)["result"]["task_id"]
    call(port, "task.complete", **{"from": AGENT}, task_id=task, output={})
    printed: list[str] = []
    until(lambda: printed.append(capsys.readouterr().out) or "to review" in "".join(printed))
    [line] = [line for line in "".join(printed).splitlines() if "to review" in line]
    assert line == f"{AGENT} asks {HUMAN} to review draft<U+001B>[2J<U+202E> {task}: http://localhost:{port}/#task={task}"


def test_a_webhook_that_fails_is_logged_and_no_call_waits_on_it(desk_of, webhook, caplog):
    slow, slow_received = webhook(delay=2.0)
    refusing, _ = webhook(status=500)
    with socket.socket() as closed:
        closed.bind(("127.0.0.1", 0))
        gone = f"http://127.0.0.1:{closed.getsockname()[1]}"
    with caplog.at_level(logging.WARNING, logger="chap_coordinator.server"):
        for url in (slow, refusing, gone):
            port = desk_of(notify={"webhook": {"url": url, "secret": "s"}})
            task = call(port, "task.create", **{"from": AGENT}, kind="draft", assignee=AGENT, input={},
                        review_required=True)["result"]["task_id"]
            started = time.monotonic()
            assert call(port, "task.complete", **{"from": AGENT}, task_id=task,
                        output={})["result"]["state"] == "review_requested"
            assert time.monotonic() - started < 1.0, url
        until(lambda: "could not be reached" in caplog.text and "answered HTTP 500" in caplog.text)
    assert f"The webhook at {refusing} answered HTTP 500 to the notice of review.requested on " in caplog.text
    assert f"The webhook at {gone} could not be reached" in caplog.text
    until(lambda: len(slow_received) == 1)


@pytest.mark.parametrize("notify, said", [
    ("yes", "notify in chap.config.json takes"),
    ({"console": True, "email": "me@example.org"}, "notify in chap.config.json takes"),
    ({"console": "yes"}, "notify.console in chap.config.json is true or false"),
    ({"webhook": {"url": "https://hooks.example.org/chap"}}, 'notify.webhook in chap.config.json takes'),
    ({"webhook": {"url": "file:///etc/passwd", "secret": "s"}}, 'notify.webhook.url in chap.config.json is "file'),
    ({"webhook": {"url": "https://hooks.example.org/chap", "secret": ""}}, "a string of one character or more"),
])
def test_a_notify_setting_that_says_something_else_is_refused(tmp_path, notify, said):
    with pytest.raises(ValueError, match=re.escape(said)):
        load_config(write_config(tmp_path, notify=notify))
    assert load_config(write_config(tmp_path))["notify"] is None
    assert load_config(write_config(tmp_path, notify={"console": False}))["notify"] is None


# -- the read API the desk reads --------------------------------------------------

def test_the_read_api_lists_members_with_their_keys_and_reads_and_verifies_the_chain(desk_of, tmp_path):
    # The desk reads these with no signature: under a key that asks for a
    # gesture on every signature, a signed poll would ask each time.
    port = desk_of(require_signatures="humans", chain=True)
    person = Participant(HttpCoordinator(f"http://127.0.0.1:{port}/chap"), "wsp_test", HUMAN,
                         Signer.load_or_create(HUMAN, tmp_path / "desk-keys"), enrolment=ENROL)
    person.join("human", "reviewer", "You")

    def get(path: str):
        status, _, body = request(port, "GET", path)
        return status, json.loads(body)

    assert get("/api/members") == (200, {"members": [
        {"uri": AGENT, "type": "agent", "role": "drafter", "display_name": "The drafter", "keys": []},
        {"uri": HUMAN, "type": "human", "role": "reviewer", "display_name": "You", "keys": [person.signer.public_jwk]},
    ]})
    status, chain = get("/api/chain?from_seq=2")
    assert status == 200 and [e["envelope"]["method"] for e in chain["entries"]] == ["participant.join"]
    assert chain["next_seq"] == 3 and chain["entries"][0]["envelope"]["params"]["from"] == HUMAN
    assert [e["seq"] for e in get("/api/chain?from_seq=0&to_seq=2")[1]["entries"]] == [0, 1]
    for bad in ("/api/chain?from_seq=-1", "/api/chain?to_seq=two", "/api/chain?from_seq="):
        assert get(bad)[0] == 400, bad
    status, verified = get("/api/chain/verify")
    assert status == 200 and verified["result"]["status"] == "verified" and verified["result"]["ok"] is True
    # The same reads through POST /chap need the person's signature.
    assert call(port, "audit.read", **{"from": HUMAN})["error"]["code"] == -32070

    # A key revoked is a key the member no longer signs with.
    person.call("participant.revoke_key", target_uri=HUMAN, kid=person.signer.kid, reason="lost")
    assert get("/api/members")[1]["members"][1]["keys"] == []


def test_without_the_chain_the_verification_says_so(desk_of):
    port = desk_of()
    status, _, body = request(port, "GET", "/api/chain/verify")
    assert status == 200 and json.loads(body)["error"]["message"] == "Chain not enabled for this workspace"


def test_the_server_admits_only_the_members_the_configuration_names(desk_of):
    port = desk_of()
    refused = call(port, "participant.join", **{"from": "human:sock@local", "type": "human", "role": "reviewer"})
    assert refused["error"]["code"] == -32011
    assert "not a member chap.config.json names" in refused["error"]["message"]
    assert call(port, "participant.join", **{"from": HUMAN, "type": "human", "role": "reviewer"})["result"]["joined"] is True


def test_the_read_api_shows_what_another_process_wrote_to_the_store(tmp_path, monkeypatch):
    for name in ("PORT", "CHAP_HOST", "CHAP_DB_PATH", "CHAP_REQUIRE_SIGNATURES", "CHAP_CHAIN", "CHAP_ALLOWED_HOSTS"):
        monkeypatch.delenv(name, raising=False)
    config = load_config(write_config(tmp_path / "project", store="./chap.db"))
    server = make_server(config, make_coordinator(config))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    other = make_coordinator(load_config(tmp_path / "project" / "chap.config.json"))
    try:
        made = other.dispatch({"jsonrpc": "2.0", "id": 1, "method": "task.create", "params": {
            "workspace": "wsp_test", "from": AGENT, "kind": "draft", "assignee": AGENT, "input": {}}})
        task_id = made["result"]["task_id"]
        status, _, data = request(server.server_port, "GET", "/api/tasks")
        assert status == 200
        assert task_id in [t["task_id"] for t in json.loads(data)["tasks"]]
    finally:
        server.shutdown()
        server.server_close()


# -- the enrolment code and the review rule (pre-publish review S3, S4, S7) --------

def test_a_persons_first_join_needs_the_enrolment_code_and_nothing_is_recorded_without_it(desk_of):
    port = desk_of(require_signatures="humans")
    jwks = {"keys": [public_jwk(HUMAN)]}
    for code in (None, "WRONG-CODE0"):
        r = call(port, "participant.join", enrolment=code, **{"from": HUMAN}, type="human", role="reviewer", jwks=jwks)
        assert r["error"]["code"] == -32011 and r["error"]["data"] == {"reason": "enrolment"}, r
        assert "joins for the first time with the enrolment code" in r["error"]["message"]
    entries = call(port, "audit.read", **{"from": AGENT})["result"]["entries"]
    assert not [e for e in entries if (e.get("envelope") or e.get("request") or {}).get("params", {}).get("from") == HUMAN]
    assert call(port, "participant.join", enrolment="tests enrol", **{"from": HUMAN}, type="human", role="reviewer",
                jwks=jwks)["result"]["joined"], "the code is read in any case, with or without its hyphen"
    assert call(port, "participant.join", enrolment=None, **{"from": HUMAN}, type="human", role="reviewer",
                jwks=jwks)["result"]["joined"], "a later join needs no code"
    status, _, body = request(port, "GET", "/api/config")
    config = json.loads(body)
    assert config["enrolment"] is True and ENROL not in body.decode()


def test_no_enrolment_code_where_signatures_are_off_or_chap_config_turns_it_off(tmp_path, monkeypatch):
    from chap_coordinator.server import enrolment_code
    monkeypatch.delenv("CHAP_ENROLMENT_CODE", raising=False)
    for n, fields in enumerate(({"require_signatures": False}, {"require_signatures": "humans", "enrolment": False})):
        assert enrolment_code(load_config(write_config(tmp_path / f"p{n}", **fields))) is None, fields
    code = enrolment_code(load_config(write_config(tmp_path / "p2", require_signatures="humans")))
    assert re.fullmatch(r"[0-9A-HJKMNP-TV-Z]{5}-[0-9A-HJKMNP-TV-Z]{5}", code), code
    # This server signs nobody in, so an oidc entry copied from a Node
    # project does not take the code away.
    assert enrolment_code(load_config(write_config(tmp_path / "p3", require_signatures="humans",
                                                   oidc={"issuer": "https://idp.example.org"}))) is not None


def test_a_code_a_caller_could_guess_is_refused_and_a_desk_mounted_in_an_app_prints_the_code(
        tmp_path, monkeypatch, capsys):
    from chap_coordinator.server import ChapDesk
    monkeypatch.setenv("CHAP_ENROLMENT_CODE", "AB-12")
    with pytest.raises(ValueError, match="CHAP_ENROLMENT_CODE needs 8 letters or digits at least"):
        load_config(write_config(tmp_path / "short", require_signatures="humans"))
    monkeypatch.setenv("CHAP_ENROLMENT_CODE", ENROL)
    config = load_config(write_config(tmp_path / "mounted", require_signatures="humans", store=":memory:"))
    ChapDesk(config, make_coordinator(config))
    out = capsys.readouterr().out
    assert (f"  enrol    {ENROL}: the code {HUMAN} joins with the first time, "
            f"or open the desk at its address with #enrol={ENROL}") in out, out


def test_the_desk_server_creates_the_workspace_under_the_configured_review_rule(desk_of):
    port = desk_of(require_signatures=False, review={"rule": "quorum:2"})
    assert call(port, "workspace.describe", **{"from": AGENT})["result"]["review_rule"] == "quorum:2"


def test_the_chain_the_desk_reports_is_the_one_the_store_keeps(tmp_path, monkeypatch):
    for name in ("CHAP_DB_PATH", "CHAP_CHAIN", "CHAP_REQUIRE_SIGNATURES"):
        monkeypatch.delenv(name, raising=False)
    from chap_coordinator.server import _close, public_config
    _close(make_coordinator(load_config(write_config(tmp_path / "chain", chain=False, store="chap.db"))))
    config = load_config(write_config(tmp_path / "chain", chain=True, store="chap.db"))
    coord = make_coordinator(config)
    assert public_config(config, coord)["chain_enabled"] is False, "a store created with the chain off keeps it off"


def test_a_review_request_that_adds_reviewers_opens_no_round_and_one_after_a_reject_opens_another():
    # A decision names the submission that opened its round, and the code
    # gate's note carries it: the servers, the desk and the note agree on it.
    # Mirrors packages/chap-server/tests/rounds.test.mjs.
    from chap_coordinator import Coordinator, CoordinatorOptions
    from chap_coordinator.server import task_evidence, task_view
    coord = Coordinator(CoordinatorOptions(default_profiles=["core/1.0", "review/1.0"], deterministic_ids=True))
    n = [0]

    def send(method, frm="agent:b", **params):
        n[0] += 1
        r = coord.dispatch({"jsonrpc": "2.0", "id": f"c{n[0]}", "method": method,
                            "params": {"workspace": "w", "from": frm, **params}})
        assert "error" not in r, r
        return r["result"]

    send("workspace.create")
    for uri, kind in (("human:a", "human"), ("human:c", "human"), ("agent:b", "agent")):
        send("participant.join", uri, type=kind)
    tid = send("task.create", kind="k", input={}, assignee="agent:b")["task_id"]
    draft = {"body": "v1"}
    send("task.complete", task_id=tid, output=draft)

    def opened():
        return task_view(coord, "w", tid)["submission"]["envelope"]["method"]

    def noted():
        return [s["envelope"]["method"] for s in task_evidence(coord, "w", tid)["submissions"]]

    send("review.request", task_id=tid, artefact=draft, to=["human:a"])
    send("review.request", task_id=tid, artefact=draft, to=["human:c"])
    assert opened() == "task.complete"
    assert noted() == ["task.complete"]
    send("decide.reject", "human:a", task_id=tid)
    send("review.request", task_id=tid, artefact=draft, to=["human:c"])
    assert opened() == "review.request"
    assert noted() == ["task.complete", "review.request"]


def test_make_server_prints_the_code_and_a_code_of_fewer_than_8_letters_is_not_used(tmp_path, monkeypatch, capsys):
    from chap_coordinator.server import enrolment_code
    for name in ("PORT", "CHAP_HOST", "CHAP_DB_PATH", "CHAP_REQUIRE_SIGNATURES", "CHAP_CHAIN"):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("CHAP_ENROLMENT_CODE", ENROL)
    config = load_config(write_config(tmp_path / "made", require_signatures="humans", store=":memory:", port=0))
    server = make_server(config, make_coordinator(config))
    try:
        assert f"  enrol    {ENROL}: the code {HUMAN} joins with the first time" in capsys.readouterr().out
    finally:
        server.server_close()
    # A configuration built by hand skips load_config's check; the code is
    # made afresh where the one set is short.
    monkeypatch.setenv("CHAP_ENROLMENT_CODE", "ABC-1234")
    assert enrolment_code({"require_signatures": True, "humans": [{"uri": HUMAN}]}) != "ABC-1234"
