# CHAP Conformance Action

Reusable GitHub Action that runs the CHAP conformance harness against
your CHAP coordinator endpoint and fails the job if any vector does
not match. A new implementation can run it in its own CI and link the
result from its entry in IMPLEMENTATIONS.md.

## Usage

```yaml
# .github/workflows/conformance.yml
name: CHAP conformance

on: [pull_request, push]

jobs:
  conformance:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v7

      # Start your CHAP coordinator however you usually do.
      - run: npm install && npm start &
        env:
          PORT: 8080
      - run: |
          for i in {1..30}; do
            curl -sf http://localhost:8080/health && break
            sleep 1
          done

      # Run the harness against it.
      - uses: BrightbeamAI/chap/.github/actions/chap-conformance@v0.3.5
        with:
          url: http://localhost:8080/chap
```

## Inputs

| Input          | Required | Default      | Description                                                                                  |
| -------------- | -------- | ------------ | -------------------------------------------------------------------------------------------- |
| `url`          | yes      | (required)   | JSON-RPC endpoint of your coordinator.                                                       |
| `ref`          | no       | `v0.3.5`     | Tag or branch of the CHAP repository to source the harness from: the release of this action. |
| `core-only`    | no       | `false`      | `true` runs the Core vectors alone, for a coordinator without `review/1.0`.                  |
| `node-version` | no       | `24`         | Node version for the harness.                                                                |

## Outputs

| Output   | Description                                |
| -------- | ------------------------------------------ |
| `passed` | Count of conformance vectors that matched. |
| `failed` | Count that did not.                        |

## Add a "CHAP-conformant" badge

```markdown
![CHAP conformance](https://github.com/<owner>/<repo>/actions/workflows/conformance.yml/badge.svg)
```

Pair it with an entry in the [implementation registry](https://github.com/BrightbeamAI/chap/blob/main/IMPLEMENTATIONS.md).
