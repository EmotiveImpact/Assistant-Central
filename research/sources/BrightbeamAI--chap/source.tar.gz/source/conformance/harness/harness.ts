/**
 * CHAP Conformance Test Harness
 *
 * Runs a battery of test vectors against any CHAP endpoint and reports
 * pass/fail. Produces an in-toto-compatible attestation on success.
 *
 * Usage:
 *   tsx harness.ts                                            # tests localhost:8080
 *   tsx harness.ts --url=http://my-chap.example.org/chap        # tests a remote endpoint
 *   tsx harness.ts --url=...  --workspace=wsp_conformance     # custom workspace id
 *   tsx harness.ts --core-only                                # skip profile tests
 *   tsx harness.ts --attest > attestation.json                # write in-toto attestation
 *
 * Exit codes:
 *   0  all selected tests passed
 *   1  one or more tests failed
 *   2  invalid arguments or harness error
 */

import { createHash } from "node:crypto";
import { request as httpRequest } from "node:http";
import { request as httpsRequest } from "node:https";

interface Args {
  url:        string;
  workspace:  string;
  coreOnly:   boolean;
  attest:     boolean;
  verbose:    boolean;
}

function parseArgs(): Args {
  const args: Args = {
    url:       process.env.CHAP_URL ?? "http://localhost:8080/chap",
    workspace: `wsp_conformance_${Math.random().toString(36).slice(2, 8)}`,
    coreOnly:  false,
    attest:    false,
    verbose:   false,
  };
  for (const a of process.argv.slice(2)) {
    if (a.startsWith("--url="))       args.url       = a.slice(6);
    else if (a.startsWith("--workspace=")) args.workspace = a.slice(12);
    else if (a === "--core-only")     args.coreOnly  = true;
    else if (a === "--attest")        args.attest    = true;
    else if (a === "--verbose" || a === "-v") args.verbose = true;
    else if (a === "--help" || a === "-h") {
      console.log(`Usage: tsx harness.ts [--url=URL] [--workspace=ID] [--core-only] [--attest] [-v]`);
      process.exit(0);
    } else {
      console.error(`Unknown argument: ${a}`);
      process.exit(2);
    }
  }
  return args;
}

// ============================================================
//   CHAP client
// ============================================================

class HapClient {
  constructor(public url: string) {}

  async call(method: string, params: Record<string, unknown>): Promise<{ result?: any; error?: any; raw: any }> {
    const env = { jsonrpc: "2.0" as const, id: `t-${Date.now()}-${Math.random()}`, method, params };
    const res = await fetch(this.url, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(env),
    });
    const body = await res.json();
    return { result: body.result, error: body.error, raw: body };
  }

  async callRaw(rawBody: string): Promise<{ status: number; body: any }> {
    const res = await fetch(this.url, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    rawBody,
    });
    const status = res.status;
    let body: any;
    try { body = await res.json(); } catch { body = await res.text(); }
    return { status, body };
  }

  /**
   * The status of a POST carrying a call under the given headers. Node's
   * fetch sends its own Host, so the request goes through node:http.
   */
  async status(method: string, params: Record<string, unknown>, headers: Record<string, string>): Promise<number> {
    const body = JSON.stringify({ jsonrpc: "2.0", id: `h-${Date.now()}-${Math.random()}`, method, params });
    const url = new URL(this.url);
    const send = url.protocol === "https:" ? httpsRequest : httpRequest;
    return new Promise((resolve, reject) => {
      const req = send(url, { method: "POST", headers: { "Content-Length": String(Buffer.byteLength(body)), ...headers } }, (res) => {
        res.resume();
        res.on("end", () => resolve(res.statusCode ?? 0));
      });
      req.on("error", reject);
      req.end(body);
    });
  }
}

// ============================================================
//   Test framework
// ============================================================

interface TestResult {
  id:       string;
  name:     string;
  group:    string;
  status:   "pass" | "fail" | "skip";
  detail?:  string;
}

const results: TestResult[] = [];

async function test(
  group:   string,
  id:      string,
  name:    string,
  fn:      () => Promise<void> | void,
): Promise<void> {
  try {
    await fn();
    results.push({ id, name, group, status: "pass" });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    results.push({ id, name, group, status: "fail", detail: msg });
  }
}

function assert(cond: any, msg: string): asserts cond {
  if (!cond) throw new Error(msg);
}

function assertEq(actual: unknown, expected: unknown, msg: string): void {
  if (actual !== expected) {
    throw new Error(`${msg} - expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
}

// ============================================================
//   Core tests
// ============================================================

async function runCoreTests(client: HapClient, ws: string): Promise<void> {

  // Create the workspace explicitly, in production mode, before any vector
  // runs. The vectors below cover Core and review/1.0 and say nothing about
  // modes/1.0, but they inherit whatever a server's auto-created workspace
  // defaults to, and those defaults differ between targets: the Python
  // reference loads every profile and defaults to trial, the Core+Review
  // TypeScript reference has no modes at all. Under modes/1.0 a trial task
  // must open a review instead of completing, which is correct behaviour and
  // makes cm-08 fail on one target and pass on the other. Pinning the mode
  // here makes the two comparable and keeps the run about what it claims to
  // test. A server that does not implement modes ignores the field.
  await client.call("workspace.create", { workspace: ws, mode: "production" });

  // -------- Wire format --------

  await test("Wire format", "wf-01", "Malformed JSON returns -32700", async () => {
    const { body } = await client.callRaw("{ not json");
    assert(body?.error?.code === -32700, `Expected -32700, got ${JSON.stringify(body?.error)}`);
  });

  await test("Wire format", "wf-02", "Non-JSON-RPC body returns -32600", async () => {
    const { body } = await client.callRaw(JSON.stringify({ no_jsonrpc_field: "here" }));
    assert(body?.error?.code === -32600, `Expected -32600, got ${JSON.stringify(body?.error)}`);
  });

  await test("Wire format", "wf-03", "Unknown method returns -32601", async () => {
    const { error } = await client.call("does.not.exist", { workspace: ws });
    assert(error?.code === -32601, `Expected -32601, got ${JSON.stringify(error)}`);
  });

  await test("Wire format", "wf-04", "JSON that is no request returns -32600, and the server keeps answering", async () => {
    for (const raw of ["null", "5", "[]", "\"x\""]) {
      const { body } = await client.callRaw(raw);
      assert(body?.error?.code === -32600, `${raw}: expected -32600, got ${JSON.stringify(body)}`);
      assertEq(body?.id, null, `${raw}: the answer's id`);
    }
    const { raw } = await client.call("workspace.describe", { workspace: ws });
    assertEq(raw?.jsonrpc, "2.0", "the server should still answer");
  });

  // A page in a browser can reach a server on the same machine or network
  // (§14.3): a call that is not JSON, comes from another origin, or names
  // another host is refused before it is read.
  const joined = async (uri: string): Promise<boolean> => {
    const { result: d } = await client.call("workspace.describe", { workspace: ws });
    return (d?.members ?? []).some((m: any) => m.uri === uri);
  };
  const join = (uri: string) => ({ workspace: ws, from: uri, type: "agent" });
  const own = new URL(client.url);

  await test("Wire format", "wf-05", "A POST that is not application/json is refused with 415 and takes no effect", async () => {
    for (const type of ["text/plain", "application/x-www-form-urlencoded"]) {
      assertEq(await client.status("participant.join", join("agent:wf-05"), { "Content-Type": type }), 415, `a ${type} call`);
    }
    assert(!(await joined("agent:wf-05")), "a refused call must not join anyone");
  });

  await test("Wire format", "wf-06", "A call from another origin is refused with 403 and takes no effect; one from the server's own is answered", async () => {
    for (const origin of ["https://elsewhere.example", "null"]) {
      assertEq(await client.status("participant.join", join("agent:wf-06"), { "Content-Type": "application/json", Origin: origin }),
        403, `a call from ${origin}`);
    }
    assert(!(await joined("agent:wf-06")), "a refused call must not join anyone");
    assertEq(await client.status("workspace.describe", { workspace: ws }, { "Content-Type": "application/json", Origin: own.origin }),
      200, "a call from the server's own origin");
  });

  await test("Wire format", "wf-07", "A call under another host name is refused with 421 and takes no effect", async () => {
    assertEq(await client.status("participant.join", join("agent:wf-07"), { "Content-Type": "application/json", Host: "elsewhere.example" }),
      421, "a call naming elsewhere.example");
    assert(!(await joined("agent:wf-07")), "a refused call must not join anyone");
  });

  // -------- Core methods --------

  await test("Core methods", "cm-01", "participant.join admits a human", async () => {
    const { result } = await client.call("participant.join", {
      workspace: ws,
      from:      "human:alice@example.org",
      to:        "service:coordinator@example.org",
      ts:        new Date().toISOString(),
      type:      "human",
      role:      "reviewer",
    });
    assert(result, "No result");
    assert(result.joined === true || result.joined === undefined, "join should return joined:true");
  });

  await test("Core methods", "cm-02", "participant.join admits an agent", async () => {
    const { result } = await client.call("participant.join", {
      workspace: ws,
      from:      "agent:test-bot",
      to:        "service:coordinator@example.org",
      ts:        new Date().toISOString(),
      type:      "agent",
      role:      "drafter",
    });
    assert(result, "No result");
  });

  await test("Core methods", "cm-03", "workspace.describe lists members and profiles", async () => {
    const { result } = await client.call("workspace.describe", {
      workspace: ws,
      from:      "human:alice@example.org",
      to:        "service:coordinator@example.org",
      ts:        new Date().toISOString(),
    });
    assert(result, "No result");
    assert(Array.isArray(result.members),  "members should be an array");
    assert(result.members.length >= 2,     "should have at least 2 members");
    assert(Array.isArray(result.profiles), "profiles should be an array");
    assert(result.profiles.some((p: string) => p.startsWith("core/")), "should advertise core/");
  });

  let createdTaskId = "";
  await test("Core methods", "cm-04", "task.create assigns to a member", async () => {
    const { result } = await client.call("task.create", {
      workspace: ws,
      from:      "human:alice@example.org",
      to:        "agent:test-bot",
      ts:        new Date().toISOString(),
      kind:      "test_task",
      assignee:  "agent:test-bot",
      input:     { test: true },
    });
    assert(result?.task_id, "Should return task_id");
    assertEq(result?.state, "created", "Initial state");
    createdTaskId = result.task_id;
  });

  await test("Core methods", "cm-05", "task.create rejects non-member assignee", async () => {
    const { error } = await client.call("task.create", {
      workspace: ws,
      from:      "human:alice@example.org",
      to:        "agent:never-joined",
      ts:        new Date().toISOString(),
      kind:      "test_task",
      assignee:  "agent:never-joined",
      input:     {},
    });
    assert(error?.code === -32602, `Expected -32602, got ${JSON.stringify(error)}`);
  });

  await test("Core methods", "cm-06", "task.update transitions created → in_progress", async () => {
    const { result } = await client.call("task.update", {
      workspace: ws,
      from:      "agent:test-bot",
      to:        "human:alice@example.org",
      ts:        new Date().toISOString(),
      task_id:   createdTaskId,
      state:     "in_progress",
    });
    assertEq(result?.state, "in_progress", "Should be in_progress");
  });

  await test("Core methods", "cm-07", "task.update rejects illegal transition", async () => {
    const { error } = await client.call("task.update", {
      workspace: ws,
      from:      "agent:test-bot",
      to:        "human:alice@example.org",
      ts:        new Date().toISOString(),
      task_id:   createdTaskId,
      state:     "created", // illegal: in_progress → created
    });
    assert(error?.code === -32602, "Illegal transition should fail with -32602");
  });

  await test("Core methods", "cm-08", "task.complete finishes the task", async () => {
    const { result } = await client.call("task.complete", {
      workspace: ws,
      from:      "agent:test-bot",
      to:        "human:alice@example.org",
      ts:        new Date().toISOString(),
      task_id:   createdTaskId,
      output:    { result: "done" },
    });
    assertEq(result?.state, "completed", "Should be completed");
  });

  await test("Core methods", "cm-09", "task.complete on terminal task fails", async () => {
    const { error } = await client.call("task.complete", {
      workspace: ws,
      from:      "agent:test-bot",
      to:        "human:alice@example.org",
      ts:        new Date().toISOString(),
      task_id:   createdTaskId,
      output:    { result: "again" },
    });
    assert(error, "Should error");
  });

  await test("Core methods", "cm-10", "audit.read returns entries in order", async () => {
    const { result } = await client.call("audit.read", {
      workspace: ws,
      from:      "human:alice@example.org",
      to:        "service:coordinator@example.org",
      ts:        new Date().toISOString(),
      range:     { from_seq: 0 },
    });
    assert(Array.isArray(result?.entries), "entries should be an array");
    assert(result.entries.length >= 5, `expected >= 5 entries, got ${result.entries.length}`);
    // Sequence should be monotonic and start at 0
    let prev = -1;
    for (const e of result.entries) {
      assert(typeof e.seq === "number" && e.seq > prev, "seq should be monotonic");
      prev = e.seq;
    }
  });

  await test("Core methods", "cm-11", "audit.read filter by method works", async () => {
    const { result } = await client.call("audit.read", {
      workspace: ws,
      from:      "human:alice@example.org",
      to:        "service:coordinator@example.org",
      ts:        new Date().toISOString(),
      filter:    { method: "task.create" },
    });
    assert(Array.isArray(result?.entries), "entries should be an array");
    // The filter reads the call an entry records: an accepted call's envelope,
    // or a recorded refusal's request.
    for (const e of result.entries) {
      assertEq((e.envelope ?? e.request)?.method, "task.create", "filter should restrict by method");
    }
  });

  await test("Core methods", "cm-12", "participant.leave removes member", async () => {
    const { result } = await client.call("participant.leave", {
      workspace: ws,
      from:      "agent:test-bot",
      to:        "service:coordinator@example.org",
      ts:        new Date().toISOString(),
    });
    assert(result, "Should return a result");
    // Verify via describe
    const { result: d } = await client.call("workspace.describe", { workspace: ws });
    const stillThere = d.members.some((m: any) => m.uri === "agent:test-bot");
    assert(!stillThere, "agent:test-bot should no longer be a member");
  });

  await test("Core methods", "cm-13", "participant.join refuses a type its URI does not name", async () => {
    const join = (from: string, type: string) => client.call("participant.join", {
      workspace: ws, from, to: "service:coordinator@example.org", ts: new Date().toISOString(), type,
    });
    const { error: mismatched } = await join("human:mallory@example.org", "agent");
    assertEq(mismatched?.code, -32602, "a human: URI joining as an agent");
    assertEq(mismatched?.message, 'from must start with "agent:" for type agent', "the refusal names the scheme");
    const { error: unknown } = await join("bot:mallory", "bot");
    assertEq(unknown?.code, -32602, "a type SPECIFICATION 5.1 does not name");
    const { result: d } = await client.call("workspace.describe", { workspace: ws });
    assert(!d.members.some((m: any) => m.uri === "human:mallory@example.org" || m.uri === "bot:mallory"),
      "a refused join adds no member");
  });

  await test("Core methods", "cm-14", "the admin role is granted, never claimed", async () => {
    // cm-01 made alice the workspace's first member, the one participant who
    // could have named the role at a join.
    const join = (from: string, type: string, role: string) => client.call("participant.join", {
      workspace: ws, from, to: "service:coordinator@example.org", ts: new Date().toISOString(), type, role,
    });
    const { error: claimed } = await join("human:mallory@example.org", "human", "admin");
    assertEq(claimed?.code, -32011, "a later joiner naming the admin role");
    assertEq(claimed?.message, "The admin role is granted by an admin", "the refusal says who grants the role");
    const { error: agent } = await join("agent:admin-bot", "agent", "admin");
    assertEq(agent?.code, -32602, "an agent naming the admin role");
    const { result: again } = await join("human:alice@example.org", "human", "admin");
    assertEq(again?.joined, true, "a member joining again is answered as joined");
    const { result: d } = await client.call("workspace.describe", { workspace: ws });
    const alice = d.members.find((m: any) => m.uri === "human:alice@example.org");
    assertEq(alice?.role, "reviewer", "a member joining again keeps its role");
    assert(!d.members.some((m: any) => m.uri === "human:mallory@example.org" || m.uri === "agent:admin-bot"),
      "a refused join adds no member");
  });

  await test("Core methods", "cm-15", "a workspace that admits by invitation admits its admin's invitees alone", async () => {
    const wi = `${ws}-invite`;
    const call = (method: string, from: string, params: Record<string, unknown> = {}) =>
      client.call(method, { workspace: wi, from, ts: new Date().toISOString(), ...params });
    const { result: created } = await call("workspace.create", "human:owner@example.org", { join_policy: "invite" });
    assertEq(created?.workspace, wi, "the workspace is made");
    const { error: agent } = await call("participant.join", "agent:early-bot", { type: "agent" });
    assertEq(agent?.code, -32011, "an agent with no invitation, even before anyone joined");
    const { result: owner } = await call("participant.join", "human:owner@example.org", { type: "human" });
    assertEq(owner?.joined, true, "the first member joins");
    const { error: stranger } = await call("participant.join", "human:guest@example.org", { type: "human" });
    assertEq(stranger?.code, -32011, "a participant with no invitation");
    assertEq(stranger?.message, "human:guest@example.org has no invitation to this workspace", "the refusal names the URI");
    const { result: invited } = await call("workspace.invite", "human:owner@example.org",
      { uri: "human:guest@example.org", type: "human", role: "reviewer" });
    assertEq(invited?.invited, true, "the admin invites");
    const { result: guest } = await call("participant.join", "human:guest@example.org", { type: "human", role: "drafter" });
    assertEq(guest?.joined, true, "the invitee joins");
    const { error: notAdmin } = await call("workspace.invite", "human:guest@example.org",
      { uri: "human:other@example.org", type: "human" });
    assertEq(notAdmin?.code, -32011, "a member who is not an admin invites");
    const { result: d } = await client.call("workspace.describe", { workspace: wi });
    assertEq(d?.join_policy, "invite", "the descriptor names the join policy");
    const roles = Object.fromEntries(d.members.map((m: any) => [m.uri, m.role]));
    assertEq(roles["human:owner@example.org"], "admin", "the first member is the admin");
    assertEq(roles["human:guest@example.org"], "reviewer", "the invitee takes the invitation's role");
    assert(!("agent:early-bot" in roles), "a refused join adds no member");
  });

  await test("Core methods", "cm-16", "group: and workspace: URIs name address scopes, which cannot join", async () => {
    const join = (from: string, type: string) => client.call("participant.join", {
      workspace: ws, from, to: "service:coordinator@example.org", ts: new Date().toISOString(), type,
    });
    for (const [from, type] of [[`workspace:${ws}`, "workspace"], ["group:reviewers@example.org", "group"]]) {
      const { error } = await join(from, type);
      assertEq(error?.code, -32602, `a ${type}: URI joining`);
      assertEq(error?.message, "group: and workspace: URIs name address scopes, which cannot join", "the refusal says why");
    }
    const { result: d } = await client.call("workspace.describe", { workspace: ws });
    assert(!d.members.some((m: any) => m.type === "group" || m.type === "workspace"), "no address scope is a member");
  });
}

// ============================================================
//   Review profile tests
// ============================================================

async function runReviewTests(client: HapClient, ws: string): Promise<void> {
  // Re-add the bot if it left
  await client.call("participant.join", {
    workspace: ws,
    from:      "agent:reviewer-test-bot",
    to:        "service:coordinator@example.org",
    ts:        new Date().toISOString(),
    type:      "agent",
    role:      "drafter",
  });

  let taskId = "";
  await test("Review profile", "rv-01", "setup: create task and request review", async () => {
    const { result: t } = await client.call("task.create", {
      workspace: ws,
      from:      "human:alice@example.org",
      to:        "agent:reviewer-test-bot",
      ts:        new Date().toISOString(),
      kind:      "draft_review_test",
      assignee:  "agent:reviewer-test-bot",
      input:     { test: true },
    });
    taskId = t.task_id;

    await client.call("task.update", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(),
      task_id: taskId, state: "in_progress",
    });

    const { result: r } = await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:alice@example.org"],
      ts: new Date().toISOString(),
      task_id: taskId,
      artefact: { subject: "test", body: "original body", severity: "high" },
      rule: "any_one_approves",
    });
    assertEq(r?.state, "review_requested", "should enter review_requested");
  });

  await test("Review profile", "rv-02", "decide.override applies JSON Patch", async () => {
    const { result } = await client.call("decide.override", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(),
      task_id: taskId,
      based_on_artefact: { subject: "test", body: "original body", severity: "high" },
      diff: [
        { op: "replace", path: "/body",     value: "softened body" },
        { op: "replace", path: "/severity", value: "low" },
      ],
      rationale: "Tone too strong; severity overstated.",
      tags:        ["tone-softened", "severity-downgraded"],
      policy_refs: ["test-policy-v1"],
    });
    assertEq(result?.state, "completed", "should complete");
    assert(result?.override_artefact_id, "should return artefact id");
    assert(result?.applied, "should return applied result");
    assertEq(result.applied.body, "softened body", "patch should apply /body");
    assertEq(result.applied.severity, "low", "patch should apply /severity");
  });

  await test("Review profile", "rv-03", "override audit entry contains structured data", async () => {
    const { result } = await client.call("audit.read", {
      workspace: ws,
      filter:    { method: "decide.override", task_id: taskId, outcome: "accepted" },
    });
    assert(result.entries.length === 1, `expected exactly 1 override entry, got ${result.entries.length}`);
    const params = result.entries[0].envelope.params;
    assert(Array.isArray(params.diff),     "diff should be present");
    assert(typeof params.rationale === "string", "rationale should be present");
    assert(Array.isArray(params.tags),     "tags should be present");
    assert(Array.isArray(params.policy_refs), "policy_refs should be present");
  });

  // -------- Abstain --------
  let abstainTaskId = "";
  await test("Review profile", "rv-04", "setup: another task for abstain", async () => {
    const { result: t } = await client.call("task.create", {
      workspace: ws, from: "human:alice@example.org", to: "agent:reviewer-test-bot",
      ts: new Date().toISOString(),
      kind: "abstain_test", assignee: "agent:reviewer-test-bot", input: {},
    });
    abstainTaskId = t.task_id;
    await client.call("task.update", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(), task_id: abstainTaskId, state: "in_progress",
    });
    await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:alice@example.org"],
      ts: new Date().toISOString(), task_id: abstainTaskId, artefact: {},
    });
  });

  await test("Review profile", "rv-05", "abstain.declare with category transitions to abstained", async () => {
    const { result } = await client.call("abstain.declare", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(),
      task_id:  abstainTaskId,
      reason:   "Out of my authorisation limit.",
      category: "out_of_authority",
    });
    assertEq(result?.state, "abstained", "should be abstained");
  });

  // -------- Reject --------
  let rejectTaskId = "";
  await test("Review profile", "rv-06", "decide.reject with request_revision returns to in_progress", async () => {
    const { result: t } = await client.call("task.create", {
      workspace: ws, from: "human:alice@example.org", to: "agent:reviewer-test-bot",
      ts: new Date().toISOString(),
      kind: "reject_test", assignee: "agent:reviewer-test-bot", input: {},
    });
    rejectTaskId = t.task_id;
    await client.call("task.update", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(), task_id: rejectTaskId, state: "in_progress",
    });
    await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:alice@example.org"],
      ts: new Date().toISOString(), task_id: rejectTaskId, artefact: {},
    });
    const { result } = await client.call("decide.reject", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(),
      task_id: rejectTaskId, comment: "Needs revision.", request_revision: true,
    });
    assertEq(result?.state, "in_progress", "should return to in_progress");
  });

  // -------- Authorisation: membership + reviewer-set --------
  let authTaskId = "";
  await test("Review profile", "rv-07", "decide by a non-member is rejected with -32011", async () => {
    const { result: t } = await client.call("task.create", {
      workspace: ws, from: "human:alice@example.org", to: "agent:reviewer-test-bot",
      ts: new Date().toISOString(),
      kind: "authz_test", assignee: "agent:reviewer-test-bot", input: {},
    });
    authTaskId = t.task_id;
    await client.call("task.update", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(), task_id: authTaskId, state: "in_progress",
    });
    await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:alice@example.org"],
      ts: new Date().toISOString(), task_id: authTaskId, artefact: { body: "x" },
    });
    // A participant who never joined attempts to approve.
    const { error } = await client.call("decide.approve", {
      workspace: ws, from: "human:ghost@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), task_id: authTaskId,
    });
    assert(error?.code === -32011, `non-member decide should fail with -32011, got ${JSON.stringify(error)}`);
  });

  await test("Review profile", "rv-08", "decide by a member not in the reviewer set is rejected with -32011", async () => {
    // Join a second human who is a member but was not addressed in `to`.
    await client.call("participant.join", {
      workspace: ws, from: "human:bystander@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), type: "human", role: "observer",
    });
    const { error } = await client.call("decide.approve", {
      workspace: ws, from: "human:bystander@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), task_id: authTaskId,
    });
    assert(error?.code === -32011, `non-reviewer member decide should fail with -32011, got ${JSON.stringify(error)}`);
    // And the addressed reviewer can still approve, confirming the path is open.
    const { result } = await client.call("decide.approve", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), task_id: authTaskId,
    });
    assertEq(result?.state, "completed", "addressed reviewer should still be able to approve");
  });

  // ---- CEP-001: binding a decision to the content it decided on ----

  await test("Review profile", "rv-09", "approve with a matching approved_artefact_digest is accepted", async () => {
    const artefact = { subject: "digest", body: "bound body", severity: "low" };
    const { result: t } = await client.call("task.create", {
      workspace: ws, from: "human:alice@example.org", to: "agent:reviewer-test-bot",
      ts: new Date().toISOString(), kind: "review_test", assignee: "agent:reviewer-test-bot",
      input: { test: true },
    });
    await client.call("task.update", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(), task_id: t.task_id, state: "in_progress",
    });
    await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:alice@example.org"],
      ts: new Date().toISOString(), task_id: t.task_id, artefact, rule: "any_one_approves",
    });
    const { result } = await client.call("decide.approve", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), task_id: t.task_id,
      approved_artefact_digest: contentDigest(artefact),
    });
    assertEq(result?.state, "completed", "a matching digest should approve as normal");
  });

  await test("Review profile", "rv-10", "approve with a mismatched digest is refused with -32074 and changes nothing", async () => {
    const artefact = { subject: "digest", body: "the reviewed body", severity: "low" };
    const { result: t } = await client.call("task.create", {
      workspace: ws, from: "human:alice@example.org", to: "agent:reviewer-test-bot",
      ts: new Date().toISOString(), kind: "review_test", assignee: "agent:reviewer-test-bot",
      input: { test: true },
    });
    await client.call("task.update", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(), task_id: t.task_id, state: "in_progress",
    });
    await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:alice@example.org"],
      ts: new Date().toISOString(), task_id: t.task_id, artefact, rule: "any_one_approves",
    });
    const { error } = await client.call("decide.approve", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), task_id: t.task_id,
      approved_artefact_digest: contentDigest({ ...artefact, body: "swapped body" }),
    });
    assert(error?.code === -32074, `mismatched digest should fail with -32074, got ${JSON.stringify(error)}`);
    // Nothing recorded: the addressed reviewer can still decide normally.
    const { result } = await client.call("decide.approve", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), task_id: t.task_id,
    });
    assertEq(result?.state, "completed", "a refused decision must leave the review open");
  });

  await test("Review profile", "rv-11", "review.request with different content on an open review is refused with -32014", async () => {
    const artefact = { subject: "swap", body: "first body", severity: "low" };
    const { result: t } = await client.call("task.create", {
      workspace: ws, from: "human:alice@example.org", to: "agent:reviewer-test-bot",
      ts: new Date().toISOString(), kind: "review_test", assignee: "agent:reviewer-test-bot",
      input: { test: true },
    });
    await client.call("task.update", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(), task_id: t.task_id, state: "in_progress",
    });
    await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:alice@example.org"],
      ts: new Date().toISOString(), task_id: t.task_id, artefact, rule: "any_one_approves",
    });
    const { error } = await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:alice@example.org"],
      ts: new Date().toISOString(), task_id: t.task_id,
      artefact: { ...artefact, body: "substituted body" }, rule: "any_one_approves",
    });
    assert(error?.code === -32014, `artefact substitution should fail with -32014, got ${JSON.stringify(error)}`);
    // The identical artefact is an amendment, not a substitution.
    const { result } = await client.call("review.request", {
      workspace: ws, from: "agent:reviewer-test-bot", to: ["human:bystander@example.org"],
      ts: new Date().toISOString(), task_id: t.task_id, artefact, rule: "any_one_approves",
    });
    assertEq(result?.amended, true, "an identical artefact should amend the reviewer set");
  });

  await test("Review profile", "rv-12", "an implicit review is addressed to humans, not to the other agent", async () => {
    // A task whose review is required opens one on task.complete. Excluding the
    // producer is not enough: with a second agent in the workspace it would
    // become an eligible reviewer, and its approval would sit on the chain
    // looking like human oversight.
    const { result: t } = await client.call("task.create", {
      workspace: ws, from: "human:alice@example.org", to: "agent:reviewer-test-bot",
      ts: new Date().toISOString(), kind: "review_test",
      assignee: "agent:reviewer-test-bot", input: { test: true },
      review_required: true,
    });
    await client.call("task.update", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(), task_id: t.task_id, state: "in_progress",
    });
    const { result: opened } = await client.call("task.complete", {
      workspace: ws, from: "agent:reviewer-test-bot", to: "human:alice@example.org",
      ts: new Date().toISOString(), task_id: t.task_id, output: { draft: "implicit" },
    });
    assertEq(opened?.state, "review_requested",
      "a review_required task must open a review rather than complete");

    const { error } = await client.call("decide.approve", {
      workspace: ws, from: "agent:test-bot", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), task_id: t.task_id, comment: "looks fine",
    });
    assert(error?.code === -32011,
      `an agent approved another agent's work, got ${JSON.stringify(error)}`);

    const { result } = await client.call("decide.approve", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), task_id: t.task_id, comment: "fine",
    });
    assertEq(result?.state, "completed", "a human the review was addressed to must be able to decide");
  });

  await test("Review profile", "rv-13", "a member's refused decision is recorded under request, and a non-member's is not", async () => {
    // rv-07 and rv-08 were both refused -32011 on this task. The bystander is
    // a member, so that attempt is recorded; the ghost never joined.
    const { result } = await client.call("audit.read", {
      workspace: ws, from: "human:alice@example.org", to: "service:coordinator@example.org",
      ts: new Date().toISOString(), filter: { task_id: authTaskId, outcome: "refused" },
    });
    const refused = result?.entries ?? [];
    assert(refused.length === 1, `expected the bystander's refusal alone, got ${JSON.stringify(refused)}`);
    const [entry] = refused;
    assert(entry.envelope === undefined, "a refusal entry holds no envelope");
    assertEq(entry.request?.method, "decide.approve", "the refused call is held under request");
    assertEq(entry.request?.params?.from, "human:bystander@example.org", "the recorded refusal is the member's");
    assertEq(entry.outcome?.status, "refused", "the outcome marks the call refused");
    assertEq(entry.outcome?.code, -32011, "the outcome carries the refusal code");
  });

  // ---- The authors of the work, and reviews that need a person ----

  const BOT = "agent:reviewer-test-bot";
  const call = (method: string, from: string, params: Record<string, unknown>) =>
    client.call(method, { workspace: ws, from, ts: new Date().toISOString(), ...params });

  await test("Review profile", "rv-14", "the author of work under a required review can neither join that review nor decide it", async () => {
    const { result: t } = await call("task.create", "human:alice@example.org",
      { kind: "review_test", assignee: BOT, input: {}, review_required: true });
    await call("task.update", BOT, { task_id: t.task_id, state: "in_progress" });
    const draft = { draft: "the bot's own" };
    const { result: opened } = await call("task.complete", BOT, { task_id: t.task_id, output: draft });
    assertEq(opened?.state, "review_requested", "a required review should open on completion");
    const { error: widened } = await call("review.request", BOT, { task_id: t.task_id, artefact: draft, to: [BOT] });
    assert(widened?.code === -32011, `the author added itself to the review, got ${JSON.stringify(widened)}`);
    const { error: approved } = await call("decide.approve", BOT, { task_id: t.task_id });
    assert(approved?.code === -32011, `the author approved its own work, got ${JSON.stringify(approved)}`);
    const { result } = await call("decide.approve", "human:alice@example.org", { task_id: t.task_id });
    assertEq(result?.state, "completed", "a person the review names should still decide it");
  });

  await test("Review profile", "rv-15", "the completer cannot decide a broadcast review of its own work", async () => {
    const { result: t } = await call("task.create", "human:alice@example.org", { kind: "review_test", assignee: BOT, input: {} });
    await call("task.complete", BOT, { task_id: t.task_id, output: { draft: "done" } });
    const { result: r } = await call("review.request", BOT,
      { task_id: t.task_id, artefact: { draft: "done" }, to: ["group:anyone"] });
    assertEq(r?.state, "review_requested", "a broadcast review should open");
    const { error } = await call("decide.approve", BOT, { task_id: t.task_id });
    assert(error?.code === -32011, `the completer decided its own broadcast review, got ${JSON.stringify(error)}`);
    const { result } = await call("decide.approve", "human:alice@example.org", { task_id: t.task_id });
    assertEq(result?.state, "completed", "another member should decide a broadcast review");
  });

  await test("Review profile", "rv-16", "a required review is decided by a person it names", async () => {
    await call("participant.join", "agent:second-bot", { type: "agent" });
    const { result: t } = await call("task.create", "human:alice@example.org",
      { kind: "review_test", assignee: BOT, input: {}, review_required: true });
    const draft = { draft: "needs a person" };
    await call("task.complete", BOT, { task_id: t.task_id, output: draft });
    const { error: added } = await call("review.request", "human:alice@example.org",
      { task_id: t.task_id, artefact: draft, to: ["agent:second-bot"] });
    assert(added?.code === -32011, `an agent was added to a required review, got ${JSON.stringify(added)}`);
    const { error: broadcast } = await call("review.request", "human:alice@example.org",
      { task_id: t.task_id, artefact: draft, to: ["group:anyone"] });
    assert(broadcast?.code === -32602, `a required review took a broadcast scope, got ${JSON.stringify(broadcast)}`);
    const { error } = await call("decide.approve", "agent:second-bot", { task_id: t.task_id });
    assert(error?.code === -32011, `an agent decided a required review, got ${JSON.stringify(error)}`);
    const { result } = await call("decide.approve", "human:bystander@example.org", { task_id: t.task_id });
    assertEq(result?.state, "completed", "a person the review names should decide it");
  });

  await test("Review profile", "rv-17", "a task that holds a review completes only through a decision", async () => {
    const { result: t } = await call("task.create", "human:alice@example.org", { kind: "review_test", assignee: BOT, input: {} });
    await call("review.request", BOT, { task_id: t.task_id, artefact: { draft: "v1" }, to: ["human:alice@example.org"] });
    await call("task.update", BOT, { task_id: t.task_id, state: "in_progress" });
    const { error: skipped } = await call("task.update", BOT, { task_id: t.task_id, state: "completed" });
    assert(skipped?.code === -32602, `task.update completed a task under review, got ${JSON.stringify(skipped)}`);
    const { result: again } = await call("task.complete", BOT, { task_id: t.task_id, output: { draft: "v2" } });
    assertEq(again?.state, "review_requested", "the completion should open a new round");
    const { result } = await call("decide.approve", "human:alice@example.org", { task_id: t.task_id });
    assertEq(result?.state, "completed", "the reviewer's decision completes it");
  });

  await test("Review profile", "rv-18", "a signed call that took effect is not evaluated again", async () => {
    // A call is signed when it carries a top-level `sig` string, whether or
    // not the server checks signatures (SPECIFICATION 10.1), so the rule
    // applies here without keys.
    const { result: t } = await call("task.create", "human:alice@example.org", { kind: "review_test", assignee: BOT, input: {} });
    const body = JSON.stringify({ jsonrpc: "2.0", id: "rv-18-once", method: "task.update",
      params: { workspace: ws, from: BOT, task_id: t.task_id, state: "in_progress" },
      sig: "ed25519:k1:" + "A".repeat(86) + "==" });
    const first = await client.callRaw(body);
    assertEq(first.body?.result?.state, "in_progress", "the first copy should take effect");
    const { result: before } = await client.call("workspace.describe", { workspace: ws });
    const again = await client.callRaw(body);
    assert(again.body?.error?.code === -32075, `a second copy was evaluated, got ${JSON.stringify(again.body)}`);
    assertEq(again.body.error.data?.accepted_at_seq, before.audit_count - 1, "the answer names where it took effect");
    const { result: after } = await client.call("workspace.describe", { workspace: ws });
    assertEq(after.audit_count, before.audit_count, "the copy must not be recorded");
  });

  await test("Review profile", "rv-20", "the authors of work under a required review do not choose its reviewers", async () => {
    const { result: t } = await call("task.create", "human:alice@example.org",
      { kind: "review_test", assignee: BOT, input: {}, review_required: true });
    const draft = { draft: "the bot's work" };
    await call("task.complete", BOT, { task_id: t.task_id, output: draft });
    const { error: own } = await call("review.request", BOT,
      { task_id: t.task_id, artefact: draft, to: ["human:alice@example.org"] });
    assertEq(own?.code, -32011, "the author widening its own review");
    assertEq(own?.message, "The author of the work under review cannot request its review", "the refusal says why");
    const { error: scope } = await call("review.request", "human:alice@example.org",
      { task_id: t.task_id, artefact: draft, to: [`workspace:${ws}`] });
    assertEq(scope?.code, -32602, "a broadcast scope on a required review");
    const { result } = await call("decide.approve", "human:alice@example.org", { task_id: t.task_id });
    assertEq(result?.state, "completed", "a person the review names decides it");
  });

  await test("Review profile", "rv-21", "only the assignee completes a task that requires review", async () => {
    const { result: t } = await call("task.create", "human:alice@example.org",
      { kind: "review_test", assignee: BOT, input: {}, review_required: true });
    const { error } = await call("task.complete", "agent:second-bot", { task_id: t.task_id, output: { draft: "not mine" } });
    assertEq(error?.code, -32011, "a member other than the assignee completing");
    const { result: opened } = await call("task.complete", BOT, { task_id: t.task_id, output: { draft: "mine" } });
    assertEq(opened?.state, "review_requested", "the assignee's completion opens the review");
    const { result } = await call("decide.approve", "human:alice@example.org", { task_id: t.task_id });
    assertEq(result?.state, "completed", "a person decides it");
  });

  await test("Review profile", "rv-22", "a review once opened is decided: only its authors withdraw it, and nobody declines or escalates it away", async () => {
    const { result: t } = await call("task.create", "human:alice@example.org", { kind: "review_test", assignee: BOT, input: {} });
    await call("review.request", BOT, { task_id: t.task_id, artefact: { draft: "v1" }, to: ["human:alice@example.org"] });
    const { error: other } = await call("task.update", "agent:second-bot", { task_id: t.task_id, state: "in_progress" });
    assertEq(other?.code, -32011, "a member who is not an author withdrawing the work");
    const { result: back } = await call("task.update", BOT, { task_id: t.task_id, state: "in_progress" });
    assertEq(back?.state, "in_progress", "the author withdraws its work");
    const { error: declined } = await call("task.update", BOT, { task_id: t.task_id, state: "declined" });
    assertEq(declined?.code, -32602, "declining around an undecided review");
    const { result: escalated } = await call("escalate.raise", BOT,
      { original_task_id: t.task_id, new_task: { kind: "review_test", assignee: "agent:second-bot" } });
    assert(typeof escalated?.new_task_id === "string", `the escalation should be made, got ${JSON.stringify(escalated)}`);
    const { result: next } = await call("task.complete", "agent:second-bot",
      { task_id: escalated.new_task_id, output: { draft: "v2" } });
    assertEq(next?.state, "review_requested", "the successor completes only through a review");
  });

  await test("Review profile", "rv-19", "a reviewer acknowledges an open review once a round, and its author cannot", async () => {
    const { result: t } = await call("task.create", "human:alice@example.org", { kind: "review_test", assignee: BOT, input: {} });
    const { error: unopened } = await call("review.acknowledge", "human:alice@example.org", { task_id: t.task_id });
    assert(unopened?.code === -32010, `a task with no open review was acknowledged, got ${JSON.stringify(unopened)}`);
    await call("review.request", BOT, { task_id: t.task_id, artefact: { draft: "v1" }, to: ["human:alice@example.org"] });
    const { error: author } = await call("review.acknowledge", BOT, { task_id: t.task_id });
    assert(author?.code === -32011, `the author acknowledged the review of its own work, got ${JSON.stringify(author)}`);
    const { result: before } = await client.call("workspace.describe", { workspace: ws });
    const { result: ack } = await call("review.acknowledge", "human:alice@example.org", { task_id: t.task_id });
    assertEq(ack?.acknowledged, true, "the reviewer's acknowledgement should be taken");
    assert(typeof ack?.requested_at === "string", `the answer names the round, got ${JSON.stringify(ack)}`);
    const { result: after } = await client.call("workspace.describe", { workspace: ws });
    assertEq(after.audit_count, before.audit_count + 1, "the acknowledgement is recorded");
    const { error: again } = await call("review.acknowledge", "human:alice@example.org", { task_id: t.task_id });
    assert(again?.code === -32602, `a second acknowledgement in the round was taken, got ${JSON.stringify(again)}`);
    const { result } = await call("decide.approve", "human:alice@example.org", { task_id: t.task_id });
    assertEq(result?.state, "completed", "an acknowledged review is still decided by a decision");
  });
}


/**
 * The digest construction CEP-001 uses: SHA-256 over RFC 8785 (JCS)
 * canonicalisation, in CHAP's `sha256:<hex>` wire form. Implemented here so the
 * harness stays dependency-free and checks the servers rather than a shared
 * library.
 */
function contentDigest(value: unknown): string {
  return "sha256:" + createHash("sha256").update(jcs(value), "utf-8").digest("hex");
}

function jcs(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(jcs).join(",") + "]";
  const keys = Object.keys(value as Record<string, unknown>).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  return "{" + keys.map(k => JSON.stringify(k) + ":" + jcs((value as Record<string, unknown>)[k])).join(",") + "}";
}

// ============================================================
//   Reporting
// ============================================================

function report(args: Args): boolean {
  const byGroup = new Map<string, TestResult[]>();
  for (const r of results) {
    if (!byGroup.has(r.group)) byGroup.set(r.group, []);
    byGroup.get(r.group)!.push(r);
  }

  console.log("\n" + "═".repeat(60));
  console.log("  CHAP Conformance Test Results");
  console.log("═".repeat(60));
  console.log(`  Endpoint:  ${args.url}`);
  console.log(`  Workspace: ${args.workspace}`);
  console.log("═".repeat(60));

  let totalPass = 0, totalFail = 0;
  for (const [group, tests] of byGroup) {
    const pass = tests.filter((t) => t.status === "pass").length;
    const fail = tests.filter((t) => t.status === "fail").length;
    totalPass += pass; totalFail += fail;

    console.log(`\n  ${group}  (${pass}/${tests.length})`);
    for (const t of tests) {
      const icon = t.status === "pass" ? "✓" : t.status === "fail" ? "✗" : "·";
      const colour = t.status === "pass" ? "\x1b[32m" : t.status === "fail" ? "\x1b[31m" : "\x1b[33m";
      const reset = "\x1b[0m";
      console.log(`    ${colour}${icon}${reset} ${t.id}  ${t.name}`);
      if (t.status === "fail" && t.detail) {
        console.log(`        ${t.detail}`);
      }
    }
  }

  console.log("\n" + "═".repeat(60));
  if (totalFail === 0) {
    console.log(`  \x1b[32m✓ All ${totalPass} tests passed.\x1b[0m`);
  } else {
    console.log(`  \x1b[31m✗ ${totalFail} of ${totalPass + totalFail} tests failed.\x1b[0m`);
  }
  console.log("═".repeat(60) + "\n");

  return totalFail === 0;
}

function attestation(args: Args, passed: boolean): unknown {
  const profilesAttested = ["core/1.0"];
  if (!args.coreOnly) profilesAttested.push("review/1.0");

  return {
    _type: "https://in-toto.io/Statement/v1",
    subject: [
      {
        name: args.url,
        digest: { sha256: "0".repeat(64) },
      },
    ],
    predicateType: "https://chap.dev/conformance/v1",
    predicate: {
      timestamp: new Date().toISOString(),
      passed,
      profiles_attested: profilesAttested,
      tests: results.map((r) => ({
        id:     r.id,
        group:  r.group,
        status: r.status,
        ...(r.detail ? { detail: r.detail } : {}),
      })),
    },
  };
}

// ============================================================
//   Entry
// ============================================================

async function main(): Promise<void> {
  const args = parseArgs();

  if (!args.attest) {
    console.log(`CHAP Conformance Harness`);
    console.log(`Endpoint:  ${args.url}`);
    console.log(`Workspace: ${args.workspace}`);
    if (args.coreOnly) console.log(`Mode:      Core-only`);
    console.log("");
  }

  const client = new HapClient(args.url);

  try {
    await runCoreTests(client, args.workspace);
    if (!args.coreOnly) {
      await runReviewTests(client, args.workspace);
    }
  } catch (e) {
    console.error(`\nHarness error: ${e instanceof Error ? e.message : e}`);
    process.exit(2);
  }

  const passed = args.attest
    ? results.every((r) => r.status !== "fail")
    : report(args);

  if (args.attest) {
    console.log(JSON.stringify(attestation(args, passed), null, 2));
  }

  process.exit(passed ? 0 : 1);
}

main().catch((e) => {
  console.error(`Fatal: ${e instanceof Error ? e.message : e}`);
  process.exit(2);
});
