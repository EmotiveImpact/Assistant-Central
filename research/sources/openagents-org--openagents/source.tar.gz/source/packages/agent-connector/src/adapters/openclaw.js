/**
 * OpenClaw adapter for OpenAgents workspace.
 *
 * Bridges OpenClaw to an OpenAgents workspace via:
 * - CLI mode: `openclaw agent --local --json` (preferred)
 * - Workspace context injected via SKILL.md auto-discovery
 *
 * Direct port of Python: sdk/src/openagents/adapters/openclaw.py
 * (CLI mode only — gateway WS and direct HTTP modes are not yet ported)
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { createHash } = require('crypto');
const { execSync } = require('child_process');
// spawn() here is the WSL bridge from ../wsl: same signature as
// child_process.spawn, and a straight pass-through unless the resolved CLI
// lives on the other side of the Windows/WSL boundary.
const { spawn } = require('../wsl');

const BaseAdapter = require('./base');
const { classifyRunFailure, classifiedError, isClassifiedError } = require('./run-failure');
const { formatAttachmentsForPrompt } = require('./utils');
const { buildOpenclawSkillMd, buildOpenclawSystemPrompt, workspaceSkillName } = require('./workspace-prompt');
const { getRuntimePrefix, whereBinary } = require('../paths');

const IS_WINDOWS = process.platform === 'win32';
// What a failed `openclaw agent` run should tell the channel, per cause. The
// classifier appends the CLI's own words, redacted; see run-failure.js.
const OPENCLAW_GUIDANCE = {
  auth:
    'OpenClaw could not authenticate with its model provider. Set LLM_API_KEY ' +
    '(with LLM_BASE_URL and LLM_MODEL) for this agent, or sign in with ' +
    '`openclaw auth` on the device.',
  quota:
    'The provider is rate-limiting this agent, or its quota is exhausted. Wait ' +
    'and try again, or use a key with more quota.',
  network:
    "OpenClaw could not reach its provider from this device. Check the device's " +
    'network, or its proxy, and LLM_BASE_URL if a custom endpoint is set.',
  model:
    'The provider rejected the requested model. Check LLM_MODEL for this agent.',
  timeout: 'OpenClaw timed out before producing a response.',
};

const OPENCLAW_STATE_DIR = path.join(
  IS_WINDOWS ? (process.env.USERPROFILE || '') : (process.env.HOME || ''),
  '.openclaw'
);

/**
 * Archive the legacy auth-profiles.json this adapter used to write.
 *
 * Current OpenClaw keeps credentials in SQLite and refuses to run while a
 * legacy JSON store sits beside an empty one ("requires legacy credential
 * migration; run openclaw doctor --fix"); beside a populated one it silently
 * ignores the file, so a changed key never took effect either. The key now
 * reaches OpenClaw through the env and openclaw.json, so the file only gets
 * in the way.
 *
 * Only a file made entirely of our entries is moved: the `custom` provider
 * exists only because configureNativeAuth created it, and any other entry must
 * carry a key we hold ourselves. A profile the user made (OpenClaw's own
 * paste-token also names them `<provider>:manual`) keeps the file in place,
 * for `openclaw doctor --fix` to migrate. Renamed, never deleted.
 *
 * @param {Array<string|undefined>} knownKeys  API keys this agent is configured with
 */
function retireOwnLegacyAuthProfiles(knownKeys, stateDir = OPENCLAW_STATE_DIR) {
  const file = path.join(stateDir, 'agents', 'main', 'agent', 'auth-profiles.json');
  let data;
  try { data = JSON.parse(fs.readFileSync(file, 'utf-8')); } catch { return false; }
  const keys = new Set((knownKeys || []).filter(Boolean));
  const profiles = Object.values((data && data.profiles) || {});
  const ours = profiles.every((p) => p && p.type === 'token'
    && (p.provider === 'custom' || keys.has(p.token)));
  if (!ours) return false;
  try {
    fs.renameSync(file, `${file}.openagents-retired`);
    return true;
  } catch {
    return false;
  }
}

/**
 * Whether OpenClaw refused to start because local state from an older release
 * still needs its own migration ("Legacy workspace setup state requires
 * migration …; run openclaw doctor --fix", "requires legacy credential
 * migration; run openclaw doctor --fix").
 *
 * Every upgrade across a storage change hits this, and the user's only way out
 * was a terminal. The adapter runs that same Doctor repair itself and retries.
 */
function needsDoctorMigration(message) {
  const text = String(message || '');
  return /requires[^\n]*\bmigration\b/i.test(text) && /openclaw doctor --fix/i.test(text);
}

/** OpenClaw's refusal to run embedded while a Gateway owns the state. */
const GATEWAY_RUNNING = /A Gateway is running for this state directory/i;

/** Budget for one `openclaw doctor --fix` run. */
const DOCTOR_REPAIR_TIMEOUT_MS = 120000;

class OpenClawAdapter extends BaseAdapter {
  /**
   * @param {object} opts - BaseAdapter opts plus:
   * @param {string} [opts.openclawAgentId='main']
   * @param {Set} [opts.disabledModules]
   */
  constructor(opts) {
    super(opts);
    this.openclawAgentId = opts.openclawAgentId || 'main';
    this.agentEnv = OpenClawAdapter.instanceEnv(this.agentName, this.agentEnv, opts.configDir);
    this._openclawStateDir = this.agentEnv.OPENCLAW_STATE_DIR || OPENCLAW_STATE_DIR;
    // Rebuild from this instance's saved env on startup as well as on save:
    // older launchers persisted separate keys but overwrote one native config.
    OpenClawAdapter.configureNativeAuth(this.agentEnv, { agentId: this.openclawAgentId });
    this.disabledModules = opts.disabledModules || new Set();
    // channel → the `openclaw agent` run in flight, so a stop can end it
    // instead of letting it spend tokens until it finishes on its own.
    this._channelProcesses = {};

    // Find the openclaw binary — always use CLI/gateway mode for full tool support
    this._openclawBinary = this._findOpenclawBinary();

    if (this._openclawBinary) {
      this._log(`Using OpenClaw CLI mode (${this._openclawBinary})`);
    } else {
      this._log('OpenClaw binary not found — agent will not be able to process messages');
    }

    // Agents configured before the key stopped going into auth-profiles.json
    // still have that file; clear it before the first run rather than on the
    // next save.
    const env = this.agentEnv || {};
    if (retireOwnLegacyAuthProfiles([env.LLM_API_KEY, env.OPENAI_API_KEY, env.ANTHROPIC_API_KEY], this._openclawStateDir)) {
      this._log('Archived the legacy auth-profiles.json this launcher wrote (OpenClaw now stores credentials in SQLite)');
    }

    // Install workspace skill
    this._installWorkspaceSkill();
  }

  /** An agent's private OpenClaw store, whether or not it exists yet. */
  static instanceStateDir(agentName, configDir = path.join(os.homedir(), '.openagents')) {
    // Hash the identity so case-insensitive filesystems and path-like names
    // cannot alias another agent or escape the managed root.
    const id = createHash('sha256').update(String(agentName)).digest('hex').slice(0, 24);
    return path.resolve(configDir, 'openclaw', id);
  }

  /** The save path and every CLI launch must agree on an instance's store. */
  static instanceEnv(agentName, env, configDir = path.join(os.homedir(), '.openagents')) {
    // Native OpenClaw users with no launcher-managed key retain their own setup.
    if (!env.LLM_API_KEY) return env;
    const stateDir = OpenClawAdapter.instanceStateDir(agentName, configDir);
    const scoped = { ...env, OPENCLAW_STATE_DIR: stateDir, OPENCLAW_CONFIG_PATH: path.join(stateDir, 'openclaw.json') };
    // This supported native override relocates auth outside the state root;
    // an inherited profile there can outrank the instance's provider env key.
    delete scoped.OPENCLAW_AGENT_DIR;
    return scoped;
  }

  // ------------------------------------------------------------------
  // Binary resolution
  // ------------------------------------------------------------------

  _findOpenclawBinary() {
    const home = process.env.USERPROFILE || process.env.HOME || '';

    // Tier 0: Isolated runtime prefix (~/.openagents/runtimes/openclaw/)
    const runtimeMjs = path.join(getRuntimePrefix('openclaw'), 'node_modules', 'openclaw', 'openclaw.mjs');
    if (fs.existsSync(runtimeMjs)) return runtimeMjs;

    // Tier 0b: Legacy shared prefix
    const portableDir = path.join(home, '.openagents', 'nodejs');
    const mjs = path.join(portableDir, 'node_modules', 'openclaw', 'openclaw.mjs');
    if (fs.existsSync(mjs)) return mjs;

    // Fallback: a copy the user installed themselves (npm -g, nvm, a custom
    // npm prefix). whereBinary searches the directories itself instead of
    // shelling out to `where`, which prints in the OEM codepage and mangled
    // any non-ASCII profile path (C:\Users\王…) past recognition.
    const found = whereBinary('openclaw');
    if (found) {
      // Windows: resolve the .cmd shim to openclaw.mjs to avoid spawn issues.
      // Unix: `which` hands back the binary or its symlink, either runs as is.
      const resolved = this._resolveShimToMjs(found);
      if (resolved) return resolved;
      if (!IS_WINDOWS) return found;
    }
    return null;
  }

  /**
   * Resolve a .cmd shim or Unix symlink to the actual openclaw.mjs path.
   * On Windows: parses the .cmd shim to extract %dp0%\..\openclaw\openclaw.mjs
   * On Unix: follows symlink to the .mjs file
   */
  _resolveShimToMjs(binPath) {
    if (IS_WINDOWS) {
      try {
        if (!binPath.toLowerCase().endsWith('.cmd')) return null;
        const cmdContent = fs.readFileSync(binPath, 'utf-8');
        const match = cmdContent.match(/%dp0%\\([^\s"*?]+\.mjs)/i)
          || cmdContent.match(/%dp0%\\([^\s"*?]+\.js)/i);
        if (match) {
          const cmdDir = path.dirname(path.resolve(binPath));
          return path.resolve(cmdDir, match[1]);
        }
      } catch {}
    } else {
      try {
        let target = binPath;
        if (fs.lstatSync(binPath).isSymbolicLink()) {
          target = path.resolve(path.dirname(binPath), fs.readlinkSync(binPath));
        }
        if (target.endsWith('.mjs') || target.endsWith('.js')) return target;
      } catch {}
    }
    return null;
  }

  // ------------------------------------------------------------------
  // Workspace skill installation
  // ------------------------------------------------------------------

  _resolveOpenclawWorkspace() {
    const agentId = this.openclawAgentId;
    // A private store says in its own config where each id's workspace is
    // (configureNativeAuth pins them), so the skill goes where the run looks.
    if (this.agentEnv && this.agentEnv.OPENCLAW_STATE_DIR) {
      let agents = {};
      try {
        const configFile = this.agentEnv.OPENCLAW_CONFIG_PATH || path.join(this._openclawStateDir, 'openclaw.json');
        agents = JSON.parse(fs.readFileSync(configFile, 'utf-8')).agents || {};
      } catch {}
      const entry = (agents.entries || {})[agentId] || {};
      const pinned = entry.workspace || (agents.defaults || {}).workspace;
      if (pinned && fs.existsSync(pinned)) return pinned;
    }
    const wsDir = agentId && agentId !== 'main'
      ? path.join(this._openclawStateDir, `workspace-${agentId}`)
      : path.join(this._openclawStateDir, 'workspace');

    if (fs.existsSync(wsDir)) return wsDir;

    // Fall back to default workspace
    const fallback = path.join(this._openclawStateDir, 'workspace');
    if (fs.existsSync(fallback)) return fallback;

    return null;
  }

  _installWorkspaceSkill() {
    const wsDir = this._resolveOpenclawWorkspace();
    if (!wsDir) {
      this._log('OpenClaw workspace not found, skipping skill install');
      return;
    }

    const skillName = workspaceSkillName(this.agentName);
    // Migration — pre-normalization versions installed the skill under the
    // RAW agent name. For names the normalizer rewrites (uppercase,
    // underscores, …) that leaves a stale directory with an outdated
    // channel/token/endpoint that OpenClaw would keep auto-loading alongside
    // the new one (`always: true` metadata). Remove the exact legacy dir when
    // its name differs from the current one; for already-valid names the two
    // coincide and nothing is deleted.
    // The raw name feeds a recursive delete, so it must be provably inert
    // first — agent names are not validated at creation, and a name carrying
    // path separators or `..` would otherwise let the join escape the skills
    // root (rmSync then destroys whatever it lands on). Only names the safe
    // charset allows are considered, and the resolved target must still be a
    // DIRECT child of the skills root. Legacy dirs from weirder names are
    // left in place — stale beats deleting an unproven path.
    const skillsRoot = path.join(wsDir, 'skills');
    const legacyName = `openagents-workspace-${this.agentName}`;
    const legacyDir = path.join(skillsRoot, legacyName);
    if (
      legacyName !== skillName &&
      /^[A-Za-z0-9._-]+$/.test(String(this.agentName)) &&
      path.dirname(path.resolve(legacyDir)) === path.resolve(skillsRoot)
    ) {
      // Ownership proof — the path checks above cannot see filesystem
      // aliasing (case-insensitive lookup on Windows/macOS, trailing-dot
      // stripping on Windows): agent Foo's legacy path can be the SAME
      // directory as agent foo's CURRENT skill. The stored SKILL.md embeds
      // its owner's identity in a quote-delimited phrase, so delete only
      // when that identity is exactly this agent; otherwise leave the dir.
      let owned = false;
      try {
        const stored = fs.readFileSync(path.join(legacyDir, 'SKILL.md'), 'utf-8');
        owned = stored.includes(`agent '${this.agentName}'`);
      } catch {}
      if (owned) {
        try { fs.rmSync(legacyDir, { recursive: true, force: true }); } catch {}
      }
    }
    const skillDir = path.join(wsDir, 'skills', skillName);
    fs.mkdirSync(skillDir, { recursive: true });

    const content = buildOpenclawSkillMd({
      endpoint: this.endpoint,
      workspaceId: this.workspaceId,
      token: this.token,
      agentName: this.agentName,
      channelName: this.channelName,
      disabledModules: this.disabledModules,
    });

    const skillPath = path.join(skillDir, 'SKILL.md');
    fs.writeFileSync(skillPath, content, 'utf-8');
    this._log(`Installed workspace skill at ${skillPath}`);
  }

  // ------------------------------------------------------------------
  // Message handling
  // ------------------------------------------------------------------

  async _handleMessage(msg) {
    let content = (msg.content || '').trim();
    // Strip a leading mention of OURSELVES. The workspace UI prefixes targeted
    // messages with "@<agentName>", but OpenClaw's inner agent doesn't know its
    // workspace name — it sees a message addressed to a stranger and its
    // group-chat heuristic answers NO_REPLY (empty payloads, silent agent).
    // Mentions of other participants are left intact.
    const selfMention = new RegExp(
      '^\\s*@' + String(this.agentName || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b[,:]?\\s*',
      'i',
    );
    content = content.replace(selfMention, '').trim();
    const attachments = msg.attachments || [];

    // Append attachment info
    const attText = formatAttachmentsForPrompt(attachments);
    if (attText) {
      content = content ? content + attText : attText.trim();
    }

    if (!content) return;

    // msg.sessionId may be a channel name (from workspace UI) or an agent target
    // (from API). Only use it if it looks like a channel, otherwise use channelName.
    let msgChannel = this.channelName || 'general';
    if (msg.sessionId && !msg.sessionId.startsWith('openagents:') && !msg.sessionId.startsWith('agent:')) {
      msgChannel = msg.sessionId;
    }
    const sender = msg.senderName || msg.senderType || 'user';
    this._log(`Processing message from ${sender} in ${msgChannel}: ${content.slice(0, 80)}...`);

    await this._autoTitleChannel(msgChannel, content);
    await this.sendStatus(msgChannel, 'thinking...');

    try {
      const responseText = await this._runCliAgentWithMigration(content, msgChannel);
      if (this._stoppingChannels.has(msgChannel)) return;

      if (responseText) {
        await this.sendResponse(msgChannel, responseText);
      } else {
        await this.sendResponse(msgChannel, 'No response generated. Please try again.');
      }
    } catch (e) {
      this._log(`Error handling message: ${e.message}`);
      await this.sendError(
        msgChannel,
        isClassifiedError(e) ? e.message : `Error processing message: ${this._redact(e.message)}`,
      );
    }
  }

  // ------------------------------------------------------------------
  // CLI mode (openclaw agent --local)
  // ------------------------------------------------------------------

  /**
   * Run the turn; when OpenClaw refuses to start over an unmigrated state
   * store, run its Doctor repair once and retry. Doctor archives what it
   * migrates rather than deleting it.
   */
  async _runCliAgentWithMigration(userMessage, channel) {
    try {
      return await this._runCliTurn(userMessage, channel);
    } catch (e) {
      // At most one repair per turn; a repair that failed is not retried on
      // every later message.
      if (!needsDoctorMigration(e && e.message) || this._doctorRepairFailed) throw e;
      this._log('OpenClaw needs a state migration — running openclaw doctor --fix --non-interactive');
      await this.sendStatus(channel, 'Migrating OpenClaw local data...').catch(() => {});
      const repair = await this._runDoctorRepair();
      this._log(`Doctor repair ${repair.ok ? 'finished' : `failed: ${repair.detail}`}`);
      if (!repair.ok) {
        this._doctorRepairFailed = true;
        throw e;
      }
      return this._runCliTurn(userMessage, channel);
    }
  }

  /**
   * One turn, embedded (`--local`) by default. OpenClaw refuses an embedded
   * run while the user's own Gateway serves the same state directory — "A
   * Gateway is running for this state directory … Run without --local to use
   * it" — and every message failed that way. Hand the turn to that Gateway.
   */
  async _runCliTurn(userMessage, channel) {
    try {
      return await this._runCliAgent(userMessage, channel);
    } catch (e) {
      if (!GATEWAY_RUNNING.test((e && e.message) || '')) throw e;
      this._log('A Gateway is running for this OpenClaw state — retrying the turn through it');
      return this._runCliAgent(userMessage, channel, { local: false });
    }
  }

  /** `openclaw doctor --fix --non-interactive`, resolved to {ok, detail}. */
  _runDoctorRepair() {
    return new Promise((resolve) => {
      const binary = this._openclawBinary || this._findOpenclawBinary();
      if (!binary) { resolve({ ok: false, detail: 'OpenClaw binary not found' }); return; }
      const { spawnBin, spawnArgs } = this._spawnTarget(binary, ['doctor', '--fix', '--non-interactive']);
      let tail = '';
      const keepTail = (d) => { tail = (tail + d).slice(-300); };
      let proc;
      try {
        proc = spawn(spawnBin, spawnArgs, {
          stdio: ['ignore', 'pipe', 'pipe'],
          env: this._spawnEnv(),
          cwd: this.workingDir || process.env.HOME || '/',
          timeout: DOCTOR_REPAIR_TIMEOUT_MS,
          windowsHide: true,
        });
      } catch (err) {
        resolve({ ok: false, detail: err.message });
        return;
      }
      proc.stdout.on('data', keepTail);
      proc.stderr.on('data', keepTail);
      proc.on('error', (err) => resolve({ ok: false, detail: err.message }));
      proc.on('exit', (code) => resolve({ ok: code === 0, detail: `exit ${code}: ${tail.trim()}` }));
    });
  }

  /** The child environment for an `openclaw` run. */
  _spawnEnv() {
    const spawnEnv = { ...(this.agentEnv || process.env) };
    if (IS_WINDOWS) {
      const nodeBinDir = path.dirname(process.execPath);
      const npmBin = path.join(process.env.APPDATA || '', 'npm');
      const portableDir = path.join(os.homedir(), '.openagents', 'nodejs');
      const runtimeBin = path.join(getRuntimePrefix('openclaw'), 'node_modules', '.bin');
      for (const p of [runtimeBin, nodeBinDir, npmBin, portableDir]) {
        if (p && !(spawnEnv.PATH || '').includes(p)) {
          spawnEnv.PATH = p + path.delimiter + (spawnEnv.PATH || '');
        }
      }
    }
    return spawnEnv;
  }

  /**
   * How to start `openclaw <args>`: always node + openclaw.mjs directly (no
   * shims, no cmd.exe, cross-platform). This avoids Windows .cmd shim issues
   * and Unicode path encoding problems.
   */
  _spawnTarget(binary, args) {
    const portableDir = path.join(os.homedir(), '.openagents', 'nodejs');
    // Unified path first (symlink on Unix), then legacy bin/ fallback, then system node
    const nodeUnified = path.join(portableDir, IS_WINDOWS ? 'node.exe' : 'node');
    let nodeBin = fs.existsSync(nodeUnified) ? nodeUnified : path.join(portableDir, 'bin', 'node');
    if (!fs.existsSync(nodeBin)) nodeBin = whereBinary('node') || 'node';

    // binary from _findOpenclawBinary() is already resolved to .mjs when possible
    if (binary && binary.endsWith('.mjs')) {
      // Direct node + .mjs invocation (works for managed, legacy, AND global installs)
      return { spawnBin: nodeBin, spawnArgs: [binary, ...args] };
    }
    // Check managed locations explicitly
    const runtimeMjs = path.join(getRuntimePrefix('openclaw'), 'node_modules', 'openclaw', 'openclaw.mjs');
    const legacyMjs = path.join(portableDir, 'node_modules', 'openclaw', 'openclaw.mjs');
    const openclawMjs = fs.existsSync(runtimeMjs) ? runtimeMjs : (fs.existsSync(legacyMjs) ? legacyMjs : null);
    if (openclawMjs) return { spawnBin: nodeBin, spawnArgs: [openclawMjs, ...args] };
    // Last resort: spawn binary directly with shell (handles .cmd on Windows)
    return { spawnBin: binary, spawnArgs: args };
  }

  _runCliAgent(userMessage, channel, { local = true } = {}) {
    return new Promise((resolve, reject) => {
      // Stopped while this turn was being prepared: start nothing (no tokens).
      if (this._stoppedBeforeStart(channel)) {
        resolve('');
        return;
      }
      // Re-check binary if not found at construction time (installed after daemon started)
      if (!this._openclawBinary) {
        this._openclawBinary = this._findOpenclawBinary();
        if (this._openclawBinary) {
          this._log(`OpenClaw binary found (late): ${this._openclawBinary}`);
        }
      }
      const binary = this._openclawBinary;
      if (!binary) {
        reject(new Error('OpenClaw binary not found'));
        return;
      }

      const channelSuffix = (channel || 'general').replace(/[^a-zA-Z0-9-]/g, '').slice(-8) || 'general';
      const sessionKey = `openagents-${this.workspaceId.slice(0, 8)}-${channelSuffix}`;

      const args = [
        '--log-level', 'trace',
        'agent', ...(local ? ['--local'] : []),
        '--agent', this.openclawAgentId,
        '--session-id', sessionKey,
        '--message', userMessage,
        '--json',
      ];

      this._log(`CLI: ${binary} ${args.slice(0, 5).join(' ')} ...`);

      const spawnEnv = this._spawnEnv();

      // Tool name → human-readable status
      const toolLabels = {
        exec: 'Running command...',
        read: 'Reading file...',
        write: 'Writing file...',
        edit: 'Editing file...',
        browser: 'Using browser...',
        web_search: 'Searching the web...',
        web_fetch: 'Fetching webpage...',
        process: 'Running process...',
        image_generate: 'Generating image...',
        memory_search: 'Searching memory...',
      };

      let output = '';
      let lineBuffer = '';

      const processLine = (line) => {
        const toolStart = line.match(/embedded run tool start:.*tool=(\w+)/);
        if (toolStart) {
          const label = toolLabels[toolStart[1]] || `Using ${toolStart[1]}...`;
          this._log(`Tool: ${label}`);
          this.sendStatus(channel, label).catch(() => {});
        }
        if (line.match(/embedded run agent start/)) {
          this.sendStatus(channel, 'thinking...').catch(() => {});
        }
      };

      // Redirect stderr to temp file for real-time tool status polling.
      // --log-level trace makes OpenClaw write diagnostic events to stderr
      // even in non-TTY mode. We poll the temp file for new lines every 500ms.
      const stderrFile = path.join(os.tmpdir(), `openclaw-stderr-${Date.now()}.log`);
      const stderrFd = fs.openSync(stderrFile, 'w');
      this._log('Spawn: stderr → ' + stderrFile);

      const { spawnBin, spawnArgs } = this._spawnTarget(binary, args);
      const proc = spawn(spawnBin, spawnArgs, {
        stdio: ['ignore', 'pipe', stderrFd],
        env: spawnEnv,
        cwd: this.workingDir || process.env.HOME || '/',
        timeout: 600000,
        // Its own process group, so a stop reaches the tools it started too.
        detached: !IS_WINDOWS,
        windowsHide: true,
      });
      this._channelProcesses[channel] = proc;
      const unregister = () => {
        if (this._channelProcesses[channel] === proc) delete this._channelProcesses[channel];
      };
      if (proc.stdout) proc.stdout.on('data', (d) => { output += d; });

      // Poll stderr file every 500ms for tool events
      let stderrOffset = 0;
      const pollInterval = setInterval(() => {
        try {
          const stat = fs.statSync(stderrFile);
          if (stat.size > stderrOffset) {
            const fd = fs.openSync(stderrFile, 'r');
            const buf = Buffer.alloc(stat.size - stderrOffset);
            fs.readSync(fd, buf, 0, buf.length, stderrOffset);
            fs.closeSync(fd);
            stderrOffset = stat.size;
            const chunk = buf.toString('utf-8');
            const lines = chunk.split('\n');
            for (const line of lines) processLine(line);
          }
        } catch {}
      }, 500);

      // 'error' and 'exit' can BOTH fire for a single failed spawn. Closing
      // stderrFd twice throws EBADF from inside the event callback, which —
      // with no daemon-level handler — used to crash the entire daemon. Guard
      // so the fd is closed once and the promise settles once.
      let settled = false;
      const closeFd = () => { try { fs.closeSync(stderrFd); } catch {} };

      const killTimeout = setTimeout(() => {
        if (settled) return;
        settled = true;
        clearInterval(pollInterval);
        closeFd();
        try { fs.unlinkSync(stderrFile); } catch {}
        try { proc.kill(); } catch {}
        reject(classifiedError(
          'OpenClaw ran for 10 minutes without finishing and was stopped. Send the '
          + 'request again, or break a long task into smaller steps.',
        ));
      }, 600000);

      proc.on('error', (err) => {
        unregister();
        if (settled) return;
        settled = true;
        clearInterval(pollInterval);
        clearTimeout(killTimeout);
        closeFd();
        try { fs.unlinkSync(stderrFile); } catch {}
        reject(err);
      });
      proc.on('exit', (code) => {
        unregister();
        if (settled) return;
        settled = true;
        clearInterval(pollInterval);
        clearTimeout(killTimeout);
        closeFd();
        // Read full stderr content (contains JSON output + trace lines)
        let stderrContent = '';
        try {
          stderrContent = fs.readFileSync(stderrFile, 'utf-8');
          this._log(`CLI exit code=${code}, stdout=${output.length}b, stderr=${stderrContent.length}b`);
          // Process any remaining lines for tool events
          const remaining = stderrContent.slice(stderrOffset);
          if (remaining) {
            for (const line of remaining.split('\n')) processLine(line);
          }
        } catch (e) {
          this._log(`CLI stderr read error: ${e.message}`);
        }
        try { fs.unlinkSync(stderrFile); } catch {}

        // OpenClaw --json writes JSON to stderr, so combine stdout + stderr
        const allOutput = output + '\n' + stderrContent;
        const hasPayloads = allOutput.includes('"payloads"');
        this._log(`CLI parse: hasPayloads=${hasPayloads}, total=${allOutput.length}b`);

        // Killed by a user stop: the stop has been announced, nothing to report.
        if (this._stoppingChannels.has(channel)) {
          resolve('');
          return;
        }
        if (code !== 0) {
          // --log-level trace fills stderr with diagnostics, so quote the lines
          // that say something about the failure rather than the last 300
          // characters of the trace — and strip secrets from what is quoted.
          // Only OpenClaw's own words are read for the cause: its trace, and
          // the error object a failed --json run prints. The reply is the
          // model's, and a reply that mentions a sign-in page or a
          // settings.json is not an auth or a config failure.
          const failure = classifyRunFailure({
            code,
            stderr: OpenClawAdapter._traceOnly(stderrContent),
            error: OpenClawAdapter._cliError(output),
            cli: 'OpenClaw',
            guidance: OPENCLAW_GUIDANCE,
            skip: ['session'],
            secrets: this._knownSecrets(),
          });
          this._log(`Run failed (${failure.kind}, exit ${code})`, 'error');
          reject(classifiedError(failure.message));
          return;
        }
        this._parseCliOutput(allOutput, resolve);
      });
    });
  }

  /** End a run and everything it started (BaseAdapter._stopChannelWork calls this). */
  async _stopProcess(proc) {
    if (!proc || proc.exitCode !== null) return;
    try {
      if (IS_WINDOWS) {
        try { execSync(`taskkill /F /T /PID ${proc.pid}`, { timeout: 5000 }); } catch {}
        return;
      }
      try { process.kill(-proc.pid, 'SIGTERM'); } catch { proc.kill('SIGTERM'); }
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          try { process.kill(-proc.pid, 'SIGKILL'); } catch { proc.kill('SIGKILL'); }
          resolve();
        }, 5000);
        proc.on('exit', () => { clearTimeout(timeout); resolve(); });
      });
    } catch {}
  }

  /**
   * stderr without the `{"payloads": …}` reply --json writes into it: what is
   * left is OpenClaw's trace.
   */
  static _traceOnly(stderr) {
    const text = String(stderr || '');
    const start = text.search(/\{\s*"payloads"/);
    if (start < 0) return text;
    const end = OpenClawAdapter._jsonObjectEnd(text, start);
    return text.slice(0, start) + (end < 0 ? '' : text.slice(end));
  }

  /**
   * Index just past the `}` that closes the JSON object opening at `start`,
   * or -1 if it never closes. Braces inside JSON strings are not structure: a
   * reply that quotes the end of a code block, or a lone "}", once cut the
   * envelope short, and the whole reply was dropped as "No response
   * generated". String contents are skipped, honoring backslash escapes.
   */
  static _jsonObjectEnd(text, start) {
    let depth = 0;
    let inString = false;
    for (let i = start; i < text.length; i++) {
      const ch = text[i];
      if (inString) {
        if (ch === '\\') i++;
        else if (ch === '"') inString = false;
      } else if (ch === '"') inString = true;
      else if (ch === '{') depth++;
      else if (ch === '}' && --depth === 0) return i + 1;
    }
    return -1;
  }

  /**
   * The error a failed `--json` run reports on stdout, as
   * `{"ok":false,"error":{"type","message"}}` (openclaw 2026.9.8), or null.
   * Older releases print nothing there and leave the reason in the trace.
   */
  static _cliError(stdout) {
    const text = String(stdout || '').trim();
    for (const candidate of [text, ...text.split('\n').map((l) => l.trim())]) {
      if (!candidate.startsWith('{')) continue;
      try {
        const parsed = JSON.parse(candidate);
        if (parsed && parsed.ok === false && parsed.error) return parsed.error;
      } catch {}
    }
    return null;
  }

  _parseCliOutput(output, resolve) {
    const text = output.trim();
    if (!text) { resolve(''); return; }

    // OpenClaw --json outputs a JSON blob with {"payloads":[...]} structure.
    // With --log-level trace, stderr also contains diagnostic lines.
    // Find the JSON by looking for '{"payloads"' or the last complete JSON object.
    let jsonStr = null;

    // Strategy 1: each {"payloads" or { "payloads" (with whitespace), up to
    // the brace that closes it. The first one that parses is the envelope; one
    // that does not (a trace line quoting a cut-off envelope) is skipped.
    for (const match of text.matchAll(/\{\s*"payloads"/g)) {
      const end = OpenClawAdapter._jsonObjectEnd(text, match.index);
      if (end < 0) continue;
      const candidate = text.slice(match.index, end);
      try { JSON.parse(candidate); } catch { continue; }
      jsonStr = candidate;
      break;
    }

    // Strategy 2: find last '{' that starts a valid JSON with "payloads"
    if (!jsonStr) {
      for (let i = text.length - 1; i >= 0; i--) {
        if (text[i] === '{') {
          const candidate = text.slice(i);
          try {
            const d = JSON.parse(candidate);
            if (d.payloads) { jsonStr = candidate; break; }
          } catch {}
        }
      }
    }

    // Strategy 3: try each line that starts with '{'
    if (!jsonStr) {
      for (const line of text.split('\n')) {
        const trimmed = line.trim();
        if (trimmed.startsWith('{')) {
          try {
            const d = JSON.parse(trimmed);
            if (d.payloads) { jsonStr = trimmed; break; }
          } catch {}
        }
      }
    }

    if (jsonStr) {
      try {
        const data = JSON.parse(jsonStr);
        const payloads = data.payloads || [];
        this._log(`CLI parsed: ${payloads.length} payloads, keys=${payloads.map(p=>Object.keys(p).join('/')).join(', ')}, text=${payloads.map(p=>(p.text||'').slice(0,50)).join('|')}`);
        if (payloads.length > 0) {
          // NO_REPLY is OpenClaw's "deliberately silent" sentinel, not an
          // answer — surface it as no-response, same as empty payloads.
          const texts = payloads
            .filter(p => p.text && String(p.text).trim() !== 'NO_REPLY')
            .map(p => p.text);
          if (texts.length > 0) {
            resolve(texts.join('\n\n'));
            return;
          }
          resolve('');
          return;
        }
        // A parsed envelope with no text payloads means the run completed but
        // OpenClaw produced no reply. The raw envelope (sessionFile, usage,
        // contextBudgetStatus, …) must never reach the chat — that is exactly
        // what users saw as a wall of JSON. Resolve empty so the caller posts
        // its clean "no response" notice instead.
        resolve('');
        return;
      } catch (e) {
        this._log(`CLI JSON parse error: ${e.message}`);
      }
    }

    // Fallback: return non-diagnostic text. If the output contains an
    // envelope we failed to parse, suppress it the same way — garbage JSON in
    // chat is worse than the caller's "no response" notice.
    if (text.includes('"payloads"')) { resolve(''); return; }
    const cleanLines = text.split('\n').filter(l =>
      !l.includes('[diagnostic]') && !l.includes('[agent/embedded]') && !l.includes('Registered plugin')
    ).map(l => l.trim()).filter(Boolean);
    resolve(cleanLines.join('\n') || '');
  }
  // ------------------------------------------------------------------
  // Static: configure OpenClaw's native auth from LLM env vars
  // ------------------------------------------------------------------

  /**
   * Configure OpenClaw's native auth and model from user-provided
   * LLM_API_KEY / LLM_BASE_URL / LLM_MODEL values.
   * Called when adding/saving an instance and when its adapter starts.
   *
   * For standard providers (OpenAI, Anthropic), the key travels in the env
   * and only the model is set here. For custom endpoints, uses
   * models.providers in openclaw.json which gives full tool support via the
   * CLI gateway mode.
   */
  static configureNativeAuth(env, { agentId } = {}) {
    const apiKey = env.LLM_API_KEY;
    // Strip /chat/completions suffix — OpenClaw appends it internally
    const rawUrl = env.LLM_BASE_URL || 'https://api.openai.com/v1';
    const baseUrl = rawUrl.replace(/\/chat\/completions\/?$/, '');
    const model = env.LLM_MODEL || 'gpt-4o';
    if (!apiKey) return;

    const isOpenAI = baseUrl.includes('api.openai.com');
    const isAnthropic = baseUrl.includes('api.anthropic.com');
    const stateDir = env.OPENCLAW_STATE_DIR || OPENCLAW_STATE_DIR;
    const configFile = env.OPENCLAW_CONFIG_PATH || path.join(stateDir, 'openclaw.json');

    // The key itself never goes into auth-profiles.json any more: current
    // OpenClaw keeps credentials in SQLite and refuses to start while a legacy
    // JSON store sits beside an empty one ("requires legacy credential
    // migration; run openclaw doctor --fix"). A standard provider reads the
    // key from the OPENAI_API_KEY / ANTHROPIC_API_KEY the resolve rules put
    // in its env; a custom one from models.providers below.
    retireOwnLegacyAuthProfiles([apiKey], stateDir);

    try {
      // A private store holds the agent's key and sessions: owner only.
      fs.mkdirSync(path.dirname(configFile), { recursive: true, mode: env.OPENCLAW_STATE_DIR ? 0o700 : 0o777 });
      let config = {};
      try { config = JSON.parse(fs.readFileSync(configFile, 'utf-8')); } catch {}
      const provider = isAnthropic ? 'anthropic' : (isOpenAI ? 'openai' : 'custom');
      if (provider === 'custom') {
        // Custom endpoint — use models.providers for full gateway/tool support.
        // See: https://docs.openclaw.ai/concepts/model-providers
        config.models = config.models || {};
        config.models.providers = config.models.providers || {};
        config.models.providers.custom = {
          baseUrl: baseUrl.replace(/\/+$/, ''),
          apiKey,
          // Without it OpenClaw tries its stored auth profiles BEFORE this
          // apiKey (model-auth-provider-config: shouldPreferExplicitConfig-
          // ApiKeyAuth). A `custom` token profile an older launcher wrote, and
          // `openclaw doctor --fix` copied into SQLite, then outranks every key
          // saved since: the test passes on the new key, the run sends the old
          // one, and the relay answers "Invalid token".
          auth: 'api-key',
          api: 'openai-completions',
          models: [{ id: model, name: model }],
        };
      }
      config.agents = config.agents || {};
      config.agents.defaults = config.agents.defaults || {};
      config.agents.defaults.model = { primary: `${provider}/${model}` };
      if (env.OPENCLAW_STATE_DIR) {
        // OpenClaw's workspace default can still point at ~/.openclaw/workspace;
        // set it explicitly so skills and memory follow the private state too.
        const workspace = config.agents.defaults.workspace || path.join(stateDir, 'workspace');
        config.agents.defaults.workspace = workspace;
        fs.mkdirSync(workspace, { recursive: true });
        // A private store serves one agent, which runs one OpenClaw agent id.
        // `main` needs no entry on any OpenClaw release, and releases up to
        // 2026.7 refuse to start on an `agents.entries` key at all ("Config
        // invalid ... Unrecognized key"). Another id has to be listed there,
        // and alone: 2026.10 refuses a roster of more than one agent that
        // declares no owner ("multi-agent rosters require agents.ownership"),
        // and gives each id of such a roster a workspace of its own
        // (workspace/<id>), where the workspace skill is not installed. So the
        // roster holds the id this agent runs on now, pinned to the private
        // workspace, and is dropped for main. A save with no id (from the
        // launcher) leaves it as the adapter last wrote it.
        if (agentId === 'main') {
          delete config.agents.entries;
        } else if (agentId) {
          const current = (config.agents.entries || {})[agentId] || {};
          config.agents.entries = { [agentId]: { ...current, workspace: current.workspace || workspace } };
        }
      }
      fs.writeFileSync(configFile, JSON.stringify(config, null, 2), { encoding: 'utf-8', mode: 0o600 });
    } catch {}
  }
}

module.exports = OpenClawAdapter;
module.exports.retireOwnLegacyAuthProfiles = retireOwnLegacyAuthProfiles;
module.exports.needsDoctorMigration = needsDoctorMigration;
