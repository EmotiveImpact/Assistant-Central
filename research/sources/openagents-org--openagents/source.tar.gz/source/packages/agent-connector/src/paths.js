/**
 * Cross-platform PATH detection.
 *
 * Finds binary directories for Node.js version managers (nvm, fnm, volta),
 * package managers (npm, Homebrew, pip), and standard system locations.
 * Used by installer.js (binary detection) and daemon.js (agent spawning).
 */

'use strict';

const path = require('path');
const fs = require('fs');
const os = require('os');
const { exec, execSync, execFile, execFileSync } = require('child_process');
const {
  isRunningInWsl,
  resolveWslBinary,
  clearWslBinaryCache,
  wslBinDirs,
} = require('./wsl');
const { canBlock } = require('./probe-mode');

const IS_WINDOWS = process.platform === 'win32';
const IS_MACOS = process.platform === 'darwin';
const SEP = IS_WINDOWS ? ';' : ':';
const HOME = process.env.HOME || process.env.USERPROFILE || '';
const PATH_LOOKUP_CACHE_TTL_MS = 30 * 1000;

let knownBinDirsCache = { value: null, at: 0 };
let extraBinDirsCache = { value: null, at: 0, path: '' };
const whichBinaryCache = new Map();

/**
 * Every directory an agent CLI is known to land in, filtered to the ones that
 * exist on this machine. Ranked: a copy the launcher installed outranks a copy
 * the user installed, which outranks whatever the login shell happens to add.
 *
 * This is the whole curated set, INCLUDING dirs that are already on PATH —
 * which is what separates it from getExtraBinDirs(). Anything resolving a
 * binary off the filesystem wants this one: that lookup exists precisely for
 * the cases where asking the shell failed, and a dir being on PATH is no
 * evidence at all that `where`/`which` succeeded (see resolveBinaryInKnownDirs).
 */
function getKnownBinDirs() {
  if (
    knownBinDirsCache.value &&
    Date.now() - knownBinDirsCache.at < PATH_LOOKUP_CACHE_TTL_MS
  ) {
    return [...knownBinDirsCache.value];
  }

  const dirs = [];

  if (IS_WINDOWS) {
    _addWindowsPaths(dirs);
  } else {
    _addUnixPaths(dirs);
    if (IS_MACOS) {
      _addMacPaths(dirs);
    }
  }

  // Common: ~/.local/bin (pipx, user installs)
  _push(dirs, path.join(HOME, '.local', 'bin'));

  // Every JS package manager's global bin, plus the npm prefix the user
  // actually configured. Shared by both platforms — an agent installed with
  // pnpm/bun/yarn is no less installed than one npm dropped.
  _addPackageManagerPaths(dirs);

  // CLIs whose own installer script picks a directory of its own.
  _addAgentInstallerPaths(dirs);

  // CLIs installed with `uv tool install` — the executable honors XDG_BIN_HOME /
  // XDG_DATA_HOME/../bin / ~/.local/bin and also always lands in the uv tools
  // venv. A GUI/daemon process won't see the installer's PATH edit, so add the
  // real install dirs explicitly (filtered to existing dirs by the caller).
  // `coworker` is OpenWorker's distribution name — see uvToolBinDirs.
  for (const d of aiderBinDirs()) _push(dirs, d);
  for (const d of uvToolBinDirs('coworker')) _push(dirs, d);

  // Also add the directory containing the current node binary
  try {
    const nodeDir = path.dirname(process.execPath);
    if (nodeDir) _push(dirs, nodeDir);
  } catch {}

  // Add portable Node.js directory (~/.openagents/nodejs/)
  const portableNode = path.join(HOME, '.openagents', 'nodejs');
  _push(dirs, portableNode);

  // Core library bin (~/.openagents/core/node_modules/.bin)
  _push(dirs, path.join(HOME, '.openagents', 'core', 'node_modules', '.bin'));

  // Per-agent runtime bins (~/.openagents/runtimes/<type>/node_modules/.bin)
  const runtimesDir = path.join(HOME, '.openagents', 'runtimes');
  try {
    for (const d of fs.readdirSync(runtimesDir, { withFileTypes: true })) {
      if (d.isDirectory()) _push(dirs, path.join(runtimesDir, d.name, 'node_modules', '.bin'));
    }
  } catch {}

  // Legacy: shared node_modules/.bin (for backward compat with pre-isolation installs)
  _push(dirs, path.join(portableNode, 'node_modules', '.bin'));

  // Last, and the widest net: whatever the user's login shell puts on PATH. See
  // loginShellDirs() for why a GUI launch needs this at all. Ranked below every
  // dir above so a copy this launcher installed still wins over a global one.
  for (const d of loginShellDirs()) _push(dirs, d);

  // Filter to existing directories only, deduplicate
  const seen = new Set();
  const value = dirs.filter(d => {
    if (!d || seen.has(d)) return false;
    seen.add(d);
    try {
      return fs.statSync(d).isDirectory();
    } catch {
      return false;
    }
  });
  knownBinDirsCache = { value, at: Date.now() };
  return [...value];
}

/**
 * The known bin dirs that are NOT already on PATH — i.e. what has to be
 * PREPENDED to build an environment in which every agent CLI resolves.
 *
 * Only ever use this to build a PATH. It is a strict subset of
 * getKnownBinDirs(), and the dirs it drops (%APPDATA%\npm, /usr/local/bin, …)
 * are the most common install locations there are, so using it as "the dirs to
 * search" hides exactly the agents a user installed themselves.
 */
function getExtraBinDirs() {
  const currentPATH = process.env.PATH || '';
  if (
    extraBinDirsCache.value &&
    extraBinDirsCache.path === currentPATH &&
    Date.now() - extraBinDirsCache.at < PATH_LOOKUP_CACHE_TTL_MS
  ) {
    return [...extraBinDirsCache.value];
  }
  const value = getKnownBinDirs().filter((d) =>
    // Case-insensitive on Windows.
    IS_WINDOWS ? !currentPATH.toLowerCase().includes(d.toLowerCase()) : !currentPATH.includes(d),
  );
  extraBinDirsCache = { value, at: Date.now(), path: currentPATH };
  return [...value];
}

/**
 * Build a full PATH string that includes all extra bin dirs prepended.
 */
function getEnhancedPATH() {
  const extra = getExtraBinDirs();
  const current = process.env.PATH || '';
  if (extra.length === 0) return current;
  return extra.join(SEP) + SEP + current;
}

/**
 * Build an env object with enhanced PATH for spawning subprocesses.
 */
function getEnhancedEnv(baseEnv) {
  const env = { ...(baseEnv || process.env) };
  const extra = getExtraBinDirs();
  if (extra.length > 0) {
    // Spreading process.env on Windows yields a "Path" key (not "PATH"), so a
    // bare `env.PATH = …` would create a SECOND key holding only the extra dirs
    // — no System32 — and libuv picks that truncated one when resolving spawned
    // executables (cmd.exe / where.exe become unfindable). Update the existing
    // case-insensitive path key in place instead.
    const pathKey = Object.keys(env).find((k) => k.toLowerCase() === 'path') || 'PATH';
    env[pathKey] = extra.join(SEP) + SEP + (env[pathKey] || '');
  }
  if (IS_WINDOWS) {
    // Force UTF-8 output from child processes on non-English Windows locales
    env.PYTHONIOENCODING = env.PYTHONIOENCODING || 'utf-8';
    env.PYTHONUTF8 = env.PYTHONUTF8 || '1';
    env.LANG = env.LANG || 'en_US.UTF-8';
    // Ensure ComSpec points to cmd.exe (Electron may not set it)
    if (!env.ComSpec) {
      const sysRoot = env.SystemRoot || 'C:\\Windows';
      env.ComSpec = path.join(sysRoot, 'System32', 'cmd.exe');
    }
  }
  return env;
}

/**
 * Find a binary by name. Returns full path or null.
 *
 * On Windows the search ends INSIDE WSL when nothing native turned up: an agent
 * CLI the user installed in their distro is a real, usable install, and the
 * Linux path that comes back is what adapters hand to the wsl.js spawn bridge.
 * It is deliberately the last thing tried — a native copy always wins — and
 * `allowWsl: false` opts out for callers (installer.js) that have further
 * native tiers of their own to run first.
 *
 * @param {string} name
 * @param {{allowWsl?: boolean}} [opts]
 */
function whichBinary(name, { allowWsl = true } = {}) {
  if (!name) return null;
  const currentPATH = process.env.PATH || '';
  const cacheKey = `${name}\0${currentPATH}\0${allowWsl ? 'wsl' : 'native'}`;
  const cached = whichBinaryCache.get(cacheKey);
  if (cached && Date.now() - cached.at < PATH_LOOKUP_CACHE_TTL_MS) {
    return cached.value;
  }

  let value = _whichNative(name);
  if (!value && allowWsl) value = resolveWslBinary(name);
  whichBinaryCache.set(cacheKey, { value, at: Date.now() });
  return value;
}

/** The PATH lookup proper — `where`/`which`, this side of any boundary. */
function _whichNative(name) {
  let hits = _runWhich(name);

  if (isRunningInWsl()) {
    // Interop puts the Windows PATH on the distro's PATH, so `which claude`
    // happily answers /mnt/c/Users/…/AppData/Roaming/npm/claude — npm's
    // extensionless POSIX shim, a sh script that execs node.exe with Windows
    // paths. Linux cannot run it, and returning it turns "not installed" into
    // the more confusing "installed but every run fails". Only a real PE image
    // crosses back this way, which interop does exec with argv intact.
    hits = hits.filter((h) => !_isWindowsMount(h) || /\.exe$/i.test(h));
    // `which cursor-agent` can't see cursor-agent.exe — the name on disk
    // carries the suffix — so ask for it explicitly before giving up.
    if (!hits.length && !/\.exe$/i.test(name)) hits = _runWhich(`${name}.exe`);
  }

  let value = hits[0] || null;
  if (IS_WINDOWS && hits.length) {
    // `where` can list npm's extensionless POSIX shim (node_modules/.bin/
    // claude, a sh script) ahead of claude.cmd. Windows cannot execute that
    // file — spawning it fails and the probe misreports an installed CLI as
    // "not installed" while the chat adapters (which prefer .cmd) work fine.
    // Prefer a hit Windows can run; failing that, a runnable sibling of the
    // shim; only then fall back to the raw first hit.
    const RUNNABLE = /\.(cmd|exe|bat|com)$/i;
    const runnable = hits.find((h) => RUNNABLE.test(h));
    if (runnable) {
      value = runnable;
    } else {
      for (const h of hits) {
        const sibling = ['.cmd', '.exe', '.bat'].map((e) => h + e).find((c) => fs.existsSync(c));
        if (sibling) { value = sibling; break; }
      }
    }
  }
  return value;
}

/** The value of an env var, matching the key case-insensitively on Windows. */
function _envValue(env, name) {
  if (!IS_WINDOWS) return env[name];
  const key = Object.keys(env).find((k) => k.toUpperCase() === name);
  return key ? env[key] : undefined;
}

/**
 * Directory listings for _searchPath, keyed by dir. One sweep over every agent
 * type asks for ~20 names × every PATHEXT spelling × every PATH dir — thousands
 * of stats — where reading each dir once answers all of them.
 */
const DIR_INDEX_TTL_MS = 5000;
const dirIndexCache = new Map();

/** name (lower-cased on Windows) → name on disk; null when unlistable. */
function _dirIndex(dir) {
  const hit = dirIndexCache.get(dir);
  if (hit && Date.now() - hit.at < DIR_INDEX_TTL_MS) return hit.names;
  let names = new Map();
  try {
    for (const n of fs.readdirSync(dir)) names.set(IS_WINDOWS ? n.toLowerCase() : n, n);
  } catch (e) {
    // A dir that isn't there holds nothing. One we may not list can still hold
    // files we may run (an execute-only dir), so that one is stat'ed instead.
    if (e && e.code !== 'ENOENT' && e.code !== 'ENOTDIR') names = null;
  }
  dirIndexCache.set(dir, { names, at: Date.now() });
  return names;
}

/** Whether `p` is a file `where`/`which` would report. */
function _isCommandFile(p) {
  try {
    if (!fs.statSync(p).isFile()) return false;
  } catch {
    // App Execution Aliases (…\WindowsApps\*.exe) are reparse points stat
    // cannot follow, yet Windows runs them and `where` lists them.
    if (!IS_WINDOWS) return false;
    try { fs.lstatSync(p); return true; } catch { return false; }
  }
  if (IS_WINDOWS) return true;
  try { fs.accessSync(p, fs.constants.X_OK); return true; } catch { return false; }
}

/**
 * What `where name` (Windows: every match, PATH order, PATHEXT applied to a
 * bare name) or `which name` (Unix: the first executable) would report.
 *
 * Walked in-process rather than by spawning either command. Detection asks
 * this for every agent type every time a lookup cache expires, and each spawn
 * is a cmd.exe start — ~60-300ms apiece on Windows, far more under an
 * antivirus scan — which in the desktop app froze the window for seconds on
 * every refresh. It also removes the codepage hazard the spawn had: `where`
 * printed paths in the OEM codepage (936 on zh-CN), mangling any non-ASCII
 * user name, whereas these paths never leave UTF-16.
 */
function _searchPath(name, env) {
  const hits = [];
  if (!name) return hits;
  const source = env || process.env;
  let names = [name];
  if (IS_WINDOWS) {
    const exts = String(_envValue(source, 'PATHEXT') || '.COM;.EXE;.BAT;.CMD')
      .split(';')
      .map((e) => e.trim().toLowerCase())
      .filter((e) => e.startsWith('.'));
    const ext = path.extname(name).toLowerCase();
    if (!ext || !exts.includes(ext)) names = [name, ...exts.map((e) => name + e)];
  }
  const seen = new Set();
  for (const raw of String(_envValue(source, 'PATH') || '').split(SEP)) {
    const dir = raw.trim().replace(/^"(.*)"$/, '$1');
    if (!dir) continue;
    const index = _dirIndex(dir);
    for (const n of names) {
      let full;
      if (index) {
        const onDisk = index.get(IS_WINDOWS ? n.toLowerCase() : n);
        if (!onDisk) continue;
        full = path.join(dir, onDisk);
      } else {
        full = path.join(dir, n);
      }
      const key = IS_WINDOWS ? full.toLowerCase() : full;
      if (seen.has(key)) continue;
      seen.add(key);
      if (!_isCommandFile(full)) continue;
      hits.push(full);
      if (!IS_WINDOWS) return hits;
    }
  }
  return hits;
}

/** Existing paths `where`/`which` reports for a name, in its own order. */
function _runWhich(name) {
  // getEnhancedEnv(), never `{...process.env, PATH}`: spreading process.env on
  // Windows yields a "Path" key, and a second PATH key makes which one counts
  // undefined.
  return _searchPath(name, getEnhancedEnv());
}

/**
 * A path on a Windows drive as mounted inside a distro (/mnt/c/…). /mnt is
 * WSL's default automount root and the only one interop puts on PATH itself;
 * a distro that moved it in /etc/wsl.conf simply gets the old behaviour.
 */
function _isWindowsMount(p) {
  return /^\/mnt\/[a-z]\//i.test(String(p || ''));
}

/**
 * `where`/`which` lookup, shared by every CLI adapter.
 *
 *   1. (Windows) the npm-global default `%APPDATA%\npm\<name>.cmd` FIRST —
 *      it's where the npm-installed CLIs actually live.
 *   2. Then PATH, as `where <name>.cmd || where <name>.exe || where <name>`
 *      (Unix: `which <name>`) would search it — see _searchPath.
 *
 * @param {string|string[]} names  base name(s), e.g. 'claude' or ['cursor-agent','agent'].
 *                                  On Windows each is tried as <name>.cmd, <name>.exe, <name>.
 * @param {object} [env]           env for the lookup (defaults to getEnhancedEnv()).
 * @returns {string|null}          an existing absolute path, or null.
 */
function whereBinary(names, env) {
  const bases = Array.isArray(names) ? names : [names];

  // 1. npm-global default, derived from Node's env (correct encoding even when
  //    the username is non-ASCII). This is where `npm i -g <cli>` drops the shim.
  if (IS_WINDOWS && process.env.APPDATA) {
    for (const b of bases) {
      const c = path.join(process.env.APPDATA, 'npm', `${b}.cmd`);
      try { if (fs.existsSync(c)) return c; } catch {}
    }
  }

  // 2. PATH lookup.
  const lookupEnv = env || getEnhancedEnv();
  for (const b of bases) {
    for (const form of IS_WINDOWS ? [`${b}.cmd`, `${b}.exe`, b] : [b]) {
      const hit = _searchPath(form, lookupEnv)[0];
      if (hit) return hit;
    }
  }
  return null;
}

/**
 * Every PATH hit for a name, in PATH order — for callers that filter the list
 * (skip the bundled node, find the first one that runs). Like whereBinary it
 * walks PATH in-process: `where` prints in the OEM codepage, and decoding that
 * as UTF-8 mangles any non-ASCII profile path.
 *
 * @param {string} name
 * @param {object} [env]  env whose PATH to search (defaults to process.env)
 * @returns {string[]}
 */
function whereAll(name, env) {
  return _searchPath(name, env || process.env);
}

/**
 * Drop the bin-dir snapshots and every lookup answered from them — for when a
 * background probe has just learned of directories they did not include.
 */
function _invalidateBinDirCaches() {
  knownBinDirsCache = { value: null, at: 0 };
  extraBinDirsCache = { value: null, at: 0, path: '' };
  whichBinaryCache.clear();
}

/**
 * Global bin directories for every JS package manager we might find an agent
 * CLI in — plus the npm prefix the user has actually configured.
 *
 * `npm install -g` only lands in the default prefix when nobody moved it, and
 * moving it is the standard advice for avoiding `sudo` (`npm config set prefix
 * ~/.npm-global`). pnpm/bun/yarn each own a different directory again. Missing
 * any of them makes a perfectly working CLI read as "not installed" — the
 * launcher then offers to install a second copy of something already there.
 * Windows already consulted `npm config get prefix`; Unix never did, which is
 * the half of that check this function restores.
 */
function _addPackageManagerPaths(dirs) {
  // npm's configured prefix. On Windows the shims sit in the prefix itself; on
  // Unix they sit in <prefix>/bin. Cached for the process — it costs a spawn
  // and the value does not change while the app is open.
  const prefix = _npmPrefix();
  if (prefix) {
    _push(dirs, IS_WINDOWS ? prefix : path.join(prefix, 'bin'));
    // A Windows prefix can still carry a bin/ (Git-bash-flavoured setups).
    if (IS_WINDOWS) _push(dirs, path.join(prefix, 'bin'));
  }

  // pnpm — PNPM_HOME when exported, else the per-platform default.
  if (process.env.PNPM_HOME) _push(dirs, process.env.PNPM_HOME);
  if (IS_WINDOWS) {
    if (process.env.LOCALAPPDATA) _push(dirs, path.join(process.env.LOCALAPPDATA, 'pnpm'));
  } else {
    if (IS_MACOS) _push(dirs, path.join(HOME, 'Library', 'pnpm'));
    _push(dirs, path.join(HOME, '.local', 'share', 'pnpm'));
  }

  // bun — the install root is relocatable via BUN_INSTALL.
  const bunRoot = process.env.BUN_INSTALL || path.join(HOME, '.bun');
  _push(dirs, path.join(bunRoot, 'bin'));

  // yarn (both the v1 global bin and the classic global node_modules/.bin)
  _push(dirs, path.join(HOME, '.yarn', 'bin'));
  _push(dirs, path.join(HOME, '.config', 'yarn', 'global', 'node_modules', '.bin'));

  // deno
  const denoRoot = process.env.DENO_INSTALL || path.join(HOME, '.deno');
  _push(dirs, path.join(denoRoot, 'bin'));

  // Version-manager shim dirs — asdf and mise put every tool's shim here, so a
  // CLI installed under a non-default runtime still resolves.
  _push(dirs, path.join(process.env.ASDF_DATA_DIR || path.join(HOME, '.asdf'), 'shims'));
  _push(dirs, path.join(HOME, '.local', 'share', 'mise', 'shims'));

  // Windows package managers that install CLIs outside any of the above.
  if (IS_WINDOWS) {
    _push(dirs, path.join(process.env.SCOOP || path.join(HOME, 'scoop'), 'shims'));
    if (process.env.ChocolateyInstall) _push(dirs, path.join(process.env.ChocolateyInstall, 'bin'));
  }
}

/**
 * Install dirs chosen by an agent CLI's own installer script.
 *
 * These never appear on a GUI process's PATH: the script edits a shell rc file
 * (Unix) or the registry (Windows), neither of which reaches an already-running
 * app. Cursor/Amp/Hermes are handled in the per-platform blocks for historical
 * reasons; anything added here is picked up on both.
 */
function _addAgentInstallerPaths(dirs) {
  // opencode — `curl -fsSL https://opencode.ai/install | bash` is the route
  // opencode.ai leads with, and its INSTALL_DIR is ~/.opencode/bin, reached
  // through a shell rc edit. Reported as "launcher can't see my opencode"
  // (#648, and again on launcher 0.9.27).
  _push(dirs, path.join(HOME, '.opencode', 'bin'));

  // kimi — the npm package (@moonshot-ai/kimi-code) declares a real `kimi` bin,
  // but its postinstall ALSO drops a native build in ~/.kimi-code/bin and puts
  // that on PATH by editing a shell rc file. A running app never sees that
  // edit, and for a user who took the native route it is the only copy there is.
  _push(dirs, path.join(HOME, '.kimi-code', 'bin'));

  // Legacy npm prefixes the opencode/copilot adapters have always searched.
  // They were known to the adapter that SPAWNS the CLI but not to the
  // installer that decides whether it EXISTS — so an agent could run fine and
  // still be offered for install. See the coverage test in
  // test/agent-detection-matrix.test.js.
  _push(dirs, path.join(HOME, '.npm-global', 'bin'));
  _push(dirs, path.join(HOME, '.openagents', 'npm-global', 'bin'));

  // codebuddy — the npm package drops the usual global shim, but CodeBuddy also
  // ships a native build (the engine behind the WorkBuddy desktop app) that
  // installs to its own directory. The codebuddy adapter has always searched
  // these; the installer that decides whether it EXISTS had not.
  _push(dirs, path.join(HOME, '.codebuddy', 'bin'));

  // codearts — Huawei's install.sh / install.ps1 unpack into
  // ~/.codeartsdoer/installers and put that dir on PATH through a shell rc
  // edit or the user `Path` registry value. The `codearts` there is a wrapper
  // script; the CLI itself sits in its bin/, which the installer deliberately
  // keeps off PATH.
  _push(dirs, path.join(HOME, '.codeartsdoer', 'installers'));

  // mimo — Xiaomi's install.sh / install.ps1 drop the binary into
  // ~/.mimocode/bin (mimo.exe on Windows) and reach PATH through a shell rc
  // edit or the user `Path` value, neither of which a GUI launch sees.
  _push(dirs, path.join(HOME, '.mimocode', 'bin'));

  // claude — `claude install` (the native, non-npm build) relocates the CLI to
  // ~/.claude/local and reaches it through a shell alias, which a GUI process
  // inherits no more than it inherits an rc-file PATH edit.
  _push(dirs, path.join(HOME, '.claude', 'local'));

  // hermes — the Unix installer's own bin dir. Its Windows counterparts are in
  // _addWindowsPaths; this is the half nothing covered.
  _push(dirs, path.join(HOME, '.hermes', 'bin'));

  // qoder / qoder-cn — the official install scripts keep the binary in
  // ~/.qoder/bin/qodercli (~/.qoder-cn/bin/qoderclicn). On Windows that dir
  // holds qodercli.exe and reaches PATH only through the user `Path` registry
  // value; on Unix it holds the versioned builds and the CLI is linked from
  // ~/.local/bin, which is searched already.
  _push(dirs, path.join(HOME, '.qoder', 'bin', 'qodercli'));
  _push(dirs, path.join(HOME, '.qoder-cn', 'bin', 'qoderclicn'));

  // Installers that let the user choose the install dir. Each of these CLIs
  // reads an env var for its target, and a user who set one has their ONLY copy
  // there — every hardcoded default above then finds nothing. Added rather than
  // substituted: the default dir usually still holds an older copy, and which
  // of the two is on the user's PATH is not ours to guess.
  if (process.env.OPENCODE_INSTALL_DIR) _push(dirs, process.env.OPENCODE_INSTALL_DIR);
  if (process.env.AMP_HOME) _push(dirs, path.join(process.env.AMP_HOME, 'bin'));
  if (process.env.GOOSE_BIN_DIR) _push(dirs, process.env.GOOSE_BIN_DIR);
  if (process.env.HERMES_INSTALL_DIR) _push(dirs, process.env.HERMES_INSTALL_DIR);
  if (process.env.HERMES_HOME) _push(dirs, path.join(process.env.HERMES_HOME, 'bin'));
  // mimo — install.ps1 installs into MIMOCODE_INSTALL_DIR when it is set.
  if (process.env.MIMOCODE_INSTALL_DIR) _push(dirs, process.env.MIMOCODE_INSTALL_DIR);
  // qwen — install-qwen-standalone.sh / .ps1 read these for a custom target.
  if (process.env.QWEN_INSTALL_BIN_DIR) _push(dirs, process.env.QWEN_INSTALL_BIN_DIR);
  if (process.env.QWEN_INSTALL_ROOT) _push(dirs, path.join(process.env.QWEN_INSTALL_ROOT, 'bin'));

  // uv — `uv tool install X` builds a venv at <uv tool dir>/X and only COPIES
  // the executable into uv's bin dir, which reaches PATH through a shell rc
  // edit a GUI launch never sees. Enumerated rather than named, for the same
  // reason as pipx below: aider, mini-swe-agent and openworker all arrive this
  // way today — `uv tool install mini-swe-agent` is the route mini's own docs
  // give, and the mini adapter already searched here while the detection that
  // decides whether mini EXISTS did not — and so will the next Python agent.
  for (const root of _uvToolRoots()) {
    try {
      for (const d of fs.readdirSync(root, { withFileTypes: true })) {
        if (d.isDirectory()) _push(dirs, path.join(root, d.name, IS_WINDOWS ? 'Scripts' : 'bin'));
      }
    } catch {}
  }

  // pipx — `pipx install X` puts the executable in <PIPX_HOME>/venvs/X/bin and
  // only SYMLINKS it into PIPX_BIN_DIR. When that link step is skipped, or its
  // dir is one a GUI launch can't see, the venv copy is the only one there is.
  // Enumerated rather than listed by name: aider, mini-swe-agent and openworker
  // are all installable this way, and so is the next Python agent.
  for (const root of _pipxHomes()) {
    try {
      const venvs = path.join(root, 'venvs');
      for (const d of fs.readdirSync(venvs, { withFileTypes: true })) {
        if (d.isDirectory()) _push(dirs, path.join(venvs, d.name, IS_WINDOWS ? 'Scripts' : 'bin'));
      }
    } catch {}
  }

  // The plain ~/bin some installers fall back to when ~/.local/bin is absent.
  _push(dirs, path.join(HOME, 'bin'));

  if (IS_WINDOWS && process.env.LOCALAPPDATA) {
    const lad = process.env.LOCALAPPDATA;
    // antigravity (agy) — install.sh targets ~/.local/bin, the Windows
    // installer %LOCALAPPDATA%\agy\bin. Only the adapter knew the latter.
    _push(dirs, path.join(lad, 'agy', 'bin'));
    // cursor-agent also ships under Programs\ on some Windows installs — the
    // cursor adapter checks both, the installer only knew one.
    _push(dirs, path.join(lad, 'Programs', 'cursor-agent'));
    // codebuddy's native Windows install.
    _push(dirs, path.join(lad, 'CodeBuddy', 'bin'));
    // qwen — install-qwen-standalone.ps1 puts its qwen.cmd wrapper here and
    // edits the user Path; on Unix the same installer uses ~/.local/bin.
    _push(dirs, path.join(lad, 'qwen-code', 'bin'));
    // winget's shim dir — how GitHub Copilot CLI arrives on Windows for anyone
    // who didn't take the npm route. The copilot adapter knew it; nothing else did.
    _push(dirs, path.join(lad, 'Microsoft', 'WinGet', 'Links'));
  }
}

/**
 * Roots uv keeps its tool venvs under. UV_TOOL_DIR wins when exported;
 * otherwise it is the XDG data dir on Unix — macOS included, uv does NOT use
 * ~/Library/Application Support for this — and %APPDATA%\uv\tools on Windows.
 */
function _uvToolRoots() {
  if (process.env.UV_TOOL_DIR) return [process.env.UV_TOOL_DIR];
  // os.homedir(), not the module-level HOME: uvToolBinDirs() is also called by
  // the adapters and the post-install verifier at arbitrary times, and that
  // constant is frozen at require time — which resolved to the developer's real
  // home in a test that had moved $HOME.
  const home = os.homedir();
  if (IS_WINDOWS) {
    const appData = process.env.APPDATA || path.join(home, 'AppData', 'Roaming');
    return [path.join(appData, 'uv', 'tools')];
  }
  const dataHome = process.env.XDG_DATA_HOME || path.join(home, '.local', 'share');
  return [path.join(dataHome, 'uv', 'tools')];
}

/**
 * Roots pipx may keep its venvs under. PIPX_HOME wins when exported; otherwise
 * pipx has moved its default once (~/.local/pipx → the platform user-data dir),
 * so both layouts are still in the field.
 */
function _pipxHomes() {
  if (process.env.PIPX_HOME) return [process.env.PIPX_HOME];
  const roots = [path.join(HOME, '.local', 'pipx')];
  if (IS_WINDOWS) {
    if (process.env.LOCALAPPDATA) roots.push(path.join(process.env.LOCALAPPDATA, 'pipx', 'pipx'));
  } else if (IS_MACOS) {
    roots.push(path.join(HOME, 'Library', 'Application Support', 'pipx'));
  } else {
    roots.push(path.join(process.env.XDG_DATA_HOME || path.join(HOME, '.local', 'share'), 'pipx'));
  }
  return roots;
}

let npmPrefixCache;

/**
 * Where the user's `npm install -g` puts things, or null. Probed once.
 *
 * Read from npm's own configuration rather than by asking an npm binary,
 * because WHICH npm answers is not a question we can settle: the launcher
 * prepends its bundled runtime to PATH, Homebrew may have another, and each
 * reports its OWN builtin default. Only a prefix the user deliberately set is
 * interesting here — the builtin defaults are already covered by the
 * well-known dirs — and that setting lives in exactly two places:
 *
 *   1. $NPM_CONFIG_PREFIX  (npm's env override, highest precedence)
 *   2. `prefix=` in ~/.npmrc  (what `npm config set prefix …` writes)
 *
 * Falling back to spawning npm only when neither is present keeps the common
 * case free of a subprocess entirely.
 */
function _npmPrefix() {
  if (npmPrefixCache !== undefined) return npmPrefixCache;
  npmPrefixCache = null;
  const accept = (value) => {
    const v = String(value || '').trim().replace(/^["']|["']$/g, '');
    if (!v || v === 'undefined') return false;
    // ~ is not expanded by npm's config reader for us.
    const abs = v.startsWith('~') ? path.join(HOME, v.slice(1)) : v;
    try {
      if (!fs.existsSync(abs)) return false;
    } catch {
      return false;
    }
    npmPrefixCache = abs;
    return true;
  };

  if (accept(process.env.NPM_CONFIG_PREFIX)) return npmPrefixCache;

  try {
    const npmrc = fs.readFileSync(path.join(HOME, '.npmrc'), 'utf-8');
    for (const line of npmrc.split(/\r?\n/)) {
      const m = /^\s*prefix\s*=\s*(.+?)\s*$/.exec(line);
      if (m && accept(m[1])) return npmPrefixCache;
    }
  } catch {}

  const opts = {
    encoding: 'utf-8',
    timeout: 8000,
    windowsHide: true,
    // The user's PATH first: it is their npm we are asking about.
    env: { ...process.env, PATH: _basePATH() },
  };
  if (!canBlock()) {
    // npm takes a second or more to start on Windows. Answer "no custom
    // prefix" for now; the bin dirs are rebuilt once npm has said otherwise.
    try {
      const child = exec('npm config get prefix', opts, (err, stdout) => {
        if (!err && accept(String(stdout).trim())) _invalidateBinDirCaches();
      });
      if (child.stdin) child.stdin.end();
    } catch {}
    return npmPrefixCache;
  }
  try {
    const out = execSync('npm config get prefix', {
      ...opts,
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim();
    accept(out);
  } catch {}
  return npmPrefixCache;
}

/**
 * PATH for the internal probes above — the process PATH plus the well-known
 * dirs, WITHOUT recursing back into getExtraBinDirs() (which is what calls us).
 */
function _basePATH() {
  const seed = [];
  if (IS_WINDOWS) {
    if (process.env.APPDATA) seed.push(path.join(process.env.APPDATA, 'npm'));
    seed.push(path.join(process.env.ProgramFiles || 'C:\\Program Files', 'nodejs'));
  } else {
    seed.push('/usr/local/bin', '/opt/homebrew/bin', path.join(HOME, '.local', 'bin'));
  }
  try { seed.push(path.dirname(process.execPath)); } catch {}
  // Process PATH FIRST — these seeds are a fallback for a GUI launch with no
  // PATH at all, not a preference. Putting them ahead would answer questions
  // about Homebrew's tooling on a machine whose real toolchain is elsewhere.
  return (process.env.PATH ? process.env.PATH + SEP : '') + seed.join(SEP);
}

const SHELL_PROBE_TIMEOUT_MS = 6000;
const SHELL_ENV_DELIM = '__OPENAGENTS_ENV__';
let loginShellDirsCache;

/**
 * The PATH entries a login shell would hand the user, harvested once.
 *
 * This is the general form of every "installed but not detected" report. A
 * launcher started from Finder / the Dock / a desktop entry does NOT inherit
 * the shell's environment — macOS hands a GUI app `/usr/bin:/bin:/usr/sbin:
 * /sbin` and nothing else. So every CLI the user installed through their own
 * shell (nvm on a non-default version, a relocated npm prefix, bun, pnpm, a
 * hand-rolled ~/bin) is invisible, and no hardcoded list of well-known dirs can
 * ever be complete enough to cover it. Asking the shell is the only answer that
 * generalises: whatever `which opencode` finds in a terminal, we find too.
 *
 * Runs `$SHELL -ilc env` and reads the PATH line out of a delimited block, so a
 * chatty rc file (motd, version-manager banners, prompt setup) can't corrupt the
 * result. Best-effort throughout: no shell, an unusual shell that rejects the
 * flags, or a hang all fall back to the hardcoded dirs. Set
 * OPENAGENTS_SKIP_SHELL_PATH=1 to opt out.
 */
function loginShellDirs() {
  if (loginShellDirsCache !== undefined) return loginShellDirsCache;
  loginShellDirsCache = [];
  if (IS_WINDOWS) return loginShellDirsCache;
  if (process.env.OPENAGENTS_SKIP_SHELL_PATH === '1') return loginShellDirsCache;
  const shell = process.env.SHELL || '/bin/zsh';
  const argv = ['-ilc', `echo ${SHELL_ENV_DELIM}; command env; echo ${SHELL_ENV_DELIM}`];
  const opts = {
    encoding: 'utf-8',
    timeout: SHELL_PROBE_TIMEOUT_MS,
    killSignal: 'SIGKILL',
    maxBuffer: 4 * 1024 * 1024,
  };
  try {
    if (!fs.existsSync(shell)) return loginShellDirsCache;
    if (!canBlock()) {
      // A login shell with nvm/oh-my-zsh in its rc files takes seconds. Search
      // the curated dirs meanwhile and add the shell's once it has answered.
      const child = execFile(shell, argv, opts, (err, stdout) => {
        const dirs = err ? [] : _parseLoginShellPath(stdout);
        if (dirs.length) {
          loginShellDirsCache = dirs;
          _invalidateBinDirCaches();
        }
      });
      if (child.stdin) child.stdin.end();
      return loginShellDirsCache;
    }
    const out = execFileSync(shell, argv, {
      ...opts,
      // stdin closed, stderr dropped: an interactive shell with no tty writes
      // job-control warnings there and we do not want them in the output.
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    loginShellDirsCache = _parseLoginShellPath(out);
  } catch {}
  return loginShellDirsCache;
}

/** The PATH entries in a delimited `env` dump, in order and deduplicated. */
function _parseLoginShellPath(out) {
  const parts = String(out).split(SHELL_ENV_DELIM);
  if (parts.length < 3) return [];
  const line = parts[1].split(/\r?\n/).find((l) => l.startsWith('PATH='));
  if (!line) return [];
  const dirs = [];
  const seen = new Set();
  for (const d of line.slice('PATH='.length).split(SEP)) {
    const dir = d.trim();
    if (dir && !seen.has(dir)) { seen.add(dir); dirs.push(dir); }
  }
  return dirs;
}

// ---- Windows paths ----

function _addWindowsPaths(dirs) {
  const appData = process.env.APPDATA || '';
  const localAppData = process.env.LOCALAPPDATA || '';
  const programFiles = process.env.ProgramFiles || 'C:\\Program Files';
  const sysRoot = process.env.SystemRoot || 'C:\\Windows';

  // System32 (cmd.exe, powershell, etc) — Electron may not have it
  _push(dirs, path.join(sysRoot, 'System32'));

  // npm global bin (default location)
  if (appData) _push(dirs, path.join(appData, 'npm'));

  // npm's custom prefix (e.g. D:\node\node_global) is added for BOTH platforms
  // by _addPackageManagerPaths — see the note there.

  // Portable Node.js installed by OpenAgents Launcher
  _push(dirs, path.join(HOME, '.openagents', 'nodejs'));

  // Cursor CLI native installer.
  //   - ~/.cursor/bin            : the curl|bash layout (also used by some setups)
  //   - %LOCALAPPDATA%\cursor-agent : where the Windows installer
  //     (irm 'https://cursor.com/install?win32=true' | iex) actually drops
  //     cursor-agent.cmd / agent.cmd. The installer edits the *registry* PATH,
  //     so an already-running launcher/daemon process never sees it via `where`
  //     unless we add the dir here explicitly.
  _push(dirs, path.join(HOME, '.cursor', 'bin'));
  if (localAppData) _push(dirs, path.join(localAppData, 'cursor-agent'));
  _push(dirs, path.join(HOME, '.local', 'bin'));

  // Amp CLI (irm https://ampcode.com/install.ps1 | iex) — same registry-PATH
  // staleness as Cursor; add the canonical install dir(s) so an already-running
  // daemon resolves amp without a reboot.
  _push(dirs, path.join(HOME, '.amp', 'bin'));
  if (localAppData) _push(dirs, path.join(localAppData, 'amp'));

  // Hermes CLI native (no-WSL) installer drops hermes.exe in the portable
  // venv's Scripts dir and the uv shim in %LOCALAPPDATA%\hermes\bin. Same
  // registry-PATH staleness as Cursor — add explicitly so an already-running
  // daemon resolves hermes via `where` without a reboot.
  if (localAppData) {
    _push(dirs, path.join(localAppData, 'hermes', 'hermes-agent', 'venv', 'Scripts'));
    _push(dirs, path.join(localAppData, 'hermes', 'bin'));
  }

  // Node.js install
  _push(dirs, path.join(programFiles, 'nodejs'));

  // Kiro CLI — install.ps1 runs an MSI that installs kiro-cli.exe into
  // %ProgramFiles%\Kiro-Cli and edits the machine PATH, which an
  // already-running daemon never sees. (install.sh uses ~/.local/bin, or
  // /usr/local/bin for a system-wide install — both searched already.)
  _push(dirs, path.join(programFiles, 'Kiro-Cli'));

  // nvm for Windows
  const nvmHome = process.env.NVM_HOME;
  if (nvmHome) {
    _push(dirs, nvmHome);
    // nvm symlink dir
    const nvmSymlink = process.env.NVM_SYMLINK || path.join(programFiles, 'nodejs');
    _push(dirs, nvmSymlink);
  }

  // fnm
  if (localAppData) _push(dirs, path.join(localAppData, 'fnm_multishells'));
  const fnmDir = process.env.FNM_DIR || path.join(appData, 'fnm');
  if (fnmDir) {
    // fnm aliases — current version
    try {
      const defaultDir = path.join(fnmDir, 'aliases', 'default');
      if (fs.existsSync(defaultDir)) _push(dirs, defaultDir);
    } catch {}
  }

  // volta
  const voltaHome = process.env.VOLTA_HOME || path.join(localAppData, 'Volta');
  _push(dirs, path.join(voltaHome, 'bin'));

  // Git (needed for some installers)
  _push(dirs, path.join(programFiles, 'Git', 'cmd'));
  _push(dirs, path.join(programFiles, 'Git', 'bin'));

  // Python/pip
  if (localAppData) {
    _push(dirs, path.join(localAppData, 'Programs', 'Python', 'Python312', 'Scripts'));
    _push(dirs, path.join(localAppData, 'Programs', 'Python', 'Python311', 'Scripts'));
    _push(dirs, path.join(localAppData, 'Programs', 'Python', 'Python310', 'Scripts'));
  }
}

// ---- Unix paths ----

function _addUnixPaths(dirs) {
  // Standard
  _push(dirs, '/usr/local/bin');
  _push(dirs, '/usr/bin');

  // Homebrew on Linux. macOS gets /opt/homebrew and /usr/local from
  // _addMacPaths; Linuxbrew's prefix is in neither list, and `brew install` is
  // a real route for goose, opencode, gemini and codex. Its PATH entry comes
  // from `brew shellenv` in a shell rc file — invisible to a GUI launch, the
  // same reason every other dir here is listed explicitly.
  if (!IS_MACOS) {
    if (process.env.HOMEBREW_PREFIX) _push(dirs, path.join(process.env.HOMEBREW_PREFIX, 'bin'));
    _push(dirs, '/home/linuxbrew/.linuxbrew/bin');
    _push(dirs, path.join(HOME, '.linuxbrew', 'bin'));
  }

  // npm agents install to isolated prefixes: ~/.openagents/runtimes/<type>/

  // nvm
  const nvmDir = process.env.NVM_DIR || path.join(HOME, '.nvm');
  try {
    // The version the shell that spawned us is on, when it exported it.
    if (process.env.NVM_BIN) _push(dirs, process.env.NVM_BIN);
    // Find current nvm version
    const defaultPath = path.join(nvmDir, 'alias', 'default');
    if (fs.existsSync(defaultPath)) {
      const version = fs.readFileSync(defaultPath, 'utf-8').trim();
      // Resolve alias like 'lts/*' or version number
      const resolved = _resolveNvmVersion(nvmDir, version);
      if (resolved) _push(dirs, path.join(nvmDir, 'versions', 'node', resolved, 'bin'));
    }
    // Also try current symlink
    _push(dirs, path.join(nvmDir, 'current', 'bin'));
    // Then EVERY installed version, newest first. `npm install -g` writes into
    // whichever version was active in that terminal, which is routinely not the
    // default alias — a user who ran `nvm use 20 && npm i -g opencode` has a
    // real, working CLI that the default-alias-only lookup above cannot see.
    // Newest-first so the most likely copy still wins.
    for (const v of _installedNvmVersions(nvmDir)) {
      _push(dirs, path.join(nvmDir, 'versions', 'node', v, 'bin'));
    }
  } catch {}

  // fnm
  const fnmDir = process.env.FNM_DIR || path.join(HOME, '.fnm');
  try {
    const defaultDir = path.join(fnmDir, 'aliases', 'default');
    if (fs.existsSync(defaultDir)) {
      const target = fs.realpathSync(defaultDir);
      _push(dirs, path.join(target, 'bin'));
    }
  } catch {}

  // volta
  const voltaHome = process.env.VOLTA_HOME || path.join(HOME, '.volta');
  _push(dirs, path.join(voltaHome, 'bin'));

  // pip/pipx user installs
  _push(dirs, path.join(HOME, '.local', 'bin'));

  // cargo
  _push(dirs, path.join(HOME, '.cargo', 'bin'));

  // Cursor CLI native installer (curl https://cursor.com/install | bash)
  _push(dirs, path.join(HOME, '.cursor', 'bin'));

  // Amp CLI native installer (curl https://ampcode.com/install.sh | bash)
  // drops the binary in ~/.amp/bin and only symlinks into ~/.local/bin when
  // that dir is already on PATH — so a GUI- or daemon-spawned process never
  // sees it unless the canonical dir is listed here explicitly.
  _push(dirs, path.join(HOME, '.amp', 'bin'));
}

// ---- macOS-specific ----

function _addMacPaths(dirs) {
  // Homebrew (Apple Silicon + Intel)
  _push(dirs, '/opt/homebrew/bin');
  _push(dirs, '/opt/homebrew/sbin');
  _push(dirs, '/usr/local/bin');
  _push(dirs, '/usr/local/sbin');

  // MacPorts
  _push(dirs, '/opt/local/bin');

  // pkgx
  _push(dirs, path.join(HOME, '.pkgx', 'bin'));
}

// ---- Helpers ----

function _push(arr, dir) {
  if (dir) arr.push(dir);
}

/** Every node version nvm has installed, newest first. */
function _installedNvmVersions(nvmDir) {
  try {
    return fs
      .readdirSync(path.join(nvmDir, 'versions', 'node'))
      .filter((v) => /^v\d+\./.test(v))
      .sort((a, b) => {
        const pa = a.slice(1).split('.').map(Number);
        const pb = b.slice(1).split('.').map(Number);
        for (let i = 0; i < 3; i++) if ((pb[i] || 0) !== (pa[i] || 0)) return (pb[i] || 0) - (pa[i] || 0);
        return 0;
      });
  } catch {
    return [];
  }
}

function _resolveNvmVersion(nvmDir, alias) {
  // Handle direct version like 'v22.14.0'
  if (alias.startsWith('v')) {
    return alias;
  }
  // Handle aliases like 'lts/*', 'lts/jod', 'default', numeric '22'
  try {
    // Try reading alias file
    const aliasFile = path.join(nvmDir, 'alias', alias.replace('/', path.sep));
    if (fs.existsSync(aliasFile)) {
      const target = fs.readFileSync(aliasFile, 'utf-8').trim();
      return _resolveNvmVersion(nvmDir, target);
    }
  } catch {}

  // Try finding latest matching version in versions dir
  try {
    const versionsDir = path.join(nvmDir, 'versions', 'node');
    if (fs.existsSync(versionsDir)) {
      const versions = fs.readdirSync(versionsDir)
        .filter(v => v.startsWith('v'))
        .sort()
        .reverse();
      const match = versions.find(v => v.startsWith('v' + alias));
      if (match) return match;
      // Just return the latest
      if (versions.length > 0) return versions[0];
    }
  } catch {}

  return null;
}

/**
 * Get the isolated npm prefix directory for an agent runtime.
 * Each agent type gets its own prefix to prevent cross-agent interference.
 */
function getRuntimePrefix(agentType) {
  return path.join(HOME, '.openagents', 'runtimes', agentType);
}

/**
 * Get the core library directory (separate from agent runtimes).
 */
function getCorePrefix() {
  return path.join(HOME, '.openagents', 'core');
}

/**
 * A guaranteed-writable working directory for an agent that has no explicit
 * `path` configured.
 *
 * NEVER fall back to process.cwd() for this: on a packaged Windows launcher the
 * daemon (and the agent CLIs it spawns) inherit a cwd of C:\WINDOWS\system32
 * (or the app's Program Files dir), so writing .claude/skills, .claude/plans,
 * etc. relative to cwd fails with `EPERM: operation not permitted, mkdir`.
 *
 * Rooted under ~/.openagents — the same writable tree the daemon already uses
 * for its pid/status/log files — with one isolated subdir per agent. Uses
 * os.homedir() (OS-account based, reliable even when HOME/USERPROFILE are
 * stripped from a child process's environment) rather than the env-derived
 * HOME above.
 */
function defaultAgentWorkdir(agentName) {
  const safe = String(agentName || 'default').replace(/[^A-Za-z0-9._-]/g, '_') || 'default';
  const dir = path.join(os.homedir(), '.openagents', 'workspaces', safe);
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}

/**
 * Reset the two 30s caches that back binary detection. Call this after
 * install / uninstall so a freshly-created bin dir (e.g. ~/.cursor/bin)
 * isn't masked by a pre-install snapshot of getExtraBinDirs(), and so a
 * `whichBinary(name) === null` cached before install doesn't survive.
 */
function clearBinaryLookupCache() {
  knownBinDirsCache = { value: null, at: 0 };
  extraBinDirsCache = { value: null, at: 0, path: '' };
  whichBinaryCache.clear();
  dirIndexCache.clear();
  clearWslBinaryCache();
  // The login-shell / npm-prefix probes are deliberately NOT cleared: they each
  // cost a process spawn, they answer a question about the machine rather than
  // about any install, and this is called after every install/uninstall.
}

/**
 * Pay the one-time probe cost (login shell + npm prefix) up front.
 *
 * getExtraBinDirs() is synchronous and every caller is on a path where a ~1s
 * stall is felt — the marketplace listing, a readiness check, spawning an
 * agent. Calling this once while a splash screen is already up moves that cost
 * somewhere nobody is waiting on. Safe to call more than once; safe to skip.
 */
function primeBinaryLookup() {
  try { loginShellDirs(); } catch {}
  try { _npmPrefix(); } catch {}
  try { getKnownBinDirs(); } catch {}
  // The WSL side has the same shape of cost — one `wsl.exe -e bash -ilc` to
  // learn the distro's login PATH — and it is paid by the first lookup that
  // misses natively, which is the marketplace enumerating agents nobody has
  // installed. Warm it here instead.
  try { wslBinDirs(); } catch {}
}

/**
 * Directories where a `uv tool install`-ed CLI can land, in the SAME priority uv
 * itself uses, so detection matches reality on every platform:
 *   1. $XDG_BIN_HOME
 *   2. $XDG_DATA_HOME/../bin
 *   3. ~/.local/bin              (the default uv-tool / pipx / pip --user bin)
 *   4. the uv tools venv for `pkg` (Scripts on Windows, bin on Unix) — the
 *      executable always lands here on a successful `uv tool install`, even if
 *      the bin-dir copy/PATH edit didn't happen.
 *
 * `pkg` is the DISTRIBUTION name uv keys its tool dir by, which is not always
 * the command name: aider's CLI is `aider` from `aider-chat`, and OpenWorker's
 * is `openworker-server` from `coworker`.
 *
 * Uses os.homedir()/live env so it reflects the current process (test-friendly).
 * Returns directories only; callers join the platform binary names.
 */
function uvToolBinDirs(pkg) {
  const home = os.homedir();
  const dirs = [];
  if (process.env.XDG_BIN_HOME) dirs.push(process.env.XDG_BIN_HOME);
  if (process.env.XDG_DATA_HOME) dirs.push(path.join(process.env.XDG_DATA_HOME, '..', 'bin'));
  dirs.push(path.join(home, '.local', 'bin'));
  for (const root of _uvToolRoots()) {
    dirs.push(path.join(root, pkg, IS_WINDOWS ? 'Scripts' : 'bin'));
  }
  if (IS_WINDOWS) {
    dirs.push(path.join(home, 'bin'));
  } else {
    dirs.push(path.join(home, 'bin'), '/usr/local/bin', '/opt/homebrew/bin');
  }
  return dirs;
}

/** Aider's CLI, installed by aider.chat/install.{sh,ps1} → `uv tool install`. */
function aiderBinDirs() {
  return uvToolBinDirs('aider-chat');
}

/** Executable suffixes to try for a bare binary name, per platform. */
const BIN_EXTS = IS_WINDOWS ? ['.cmd', '.exe', '.bat', ''] : [''];

/**
 * A `#!...node` shebang line, as the Windows launcher matches it (win-exec.ts).
 * `env -S`/flag forms are allowed; `#!/bin/sh -c node` is NOT a node script.
 */
const NODE_SHEBANG_RE =
  /^#!\s*(?:(?:\S*[\\/])?env(?:\.exe)?\s+(?:-\S+\s+)*)?(?:\S*[\\/])?node(?:\.exe)?(?:\s|$)/i;

/**
 * True when a file is an extensionless Node script — npm's package bin shape
 * (e.g. node_modules/cline/bin/cline). Windows cannot execute one: handed to
 * cmd.exe it fails with "is not recognized as an internal or external command",
 * so every caller that shells out to a resolved binary must prefix `node`.
 */
function isNodeShebangScript(filePath) {
  if (!filePath) return false;
  try {
    const fd = fs.openSync(filePath, 'r');
    try {
      const buf = Buffer.alloc(64);
      const n = fs.readSync(fd, buf, 0, buf.length, 0);
      const firstLine = buf.subarray(0, n).toString('utf-8').split('\n', 1)[0];
      return NODE_SHEBANG_RE.test(firstLine);
    } finally {
      fs.closeSync(fd);
    }
  } catch {
    return false;
  }
}

/** Managed npm module roots, in the same priority order used by Installer. */
function managedNpmModuleDirs(agentType) {
  const dirs = [
    path.join(getRuntimePrefix(agentType), 'node_modules'),
    path.join(os.homedir(), '.openagents', 'nodejs', 'node_modules'),
  ];
  return [...new Set(dirs)];
}

/**
 * Resolve a package's declared `bin` target from an OpenAgents-managed npm
 * prefix. This covers packages such as Cline whose root package is installed
 * successfully but npm does not create a node_modules/.bin shim for it.
 */
function resolveManagedNpmPackageBin(agentType, packageName, binaryName) {
  if (!agentType || !packageName || !binaryName) return null;

  for (const modules of managedNpmModuleDirs(agentType)) {
    const pkgDir = path.join(modules, packageName);
    const pkgJsonPath = path.join(pkgDir, 'package.json');
    try {
      if (!fs.existsSync(pkgJsonPath)) continue;
      const bin = JSON.parse(fs.readFileSync(pkgJsonPath, 'utf-8')).bin;
      let rel = null;
      if (typeof bin === 'string') rel = bin;
      else if (bin && typeof bin === 'object') {
        rel = bin[binaryName] || bin[packageName] || Object.values(bin)[0];
      }
      if (!rel) continue;
      const abs = path.join(pkgDir, rel);
      if (fs.existsSync(abs) && fs.statSync(abs).isFile()) return abs;
    } catch {
      /* malformed or unreadable package — keep looking */
    }
  }
  return null;
}

/**
 * Resolve the copy of an npm CLI installed in an OpenAgents-managed prefix.
 * Package presence gates the lookup so an orphaned shim cannot shadow a
 * working global install. The package's own bin is the final managed fallback.
 */
function resolveManagedNpmBinary(agentType, packageName, names) {
  const list = (Array.isArray(names) ? names : [names]).filter(Boolean);
  if (!agentType || !packageName || !list.length) return null;

  for (const modules of managedNpmModuleDirs(agentType)) {
    try {
      if (!fs.existsSync(path.join(modules, packageName, 'package.json'))) continue;
    } catch {
      continue;
    }
    for (const name of list) {
      for (const ext of BIN_EXTS) {
        const candidate = path.join(modules, '.bin', `${name}${ext}`);
        try {
          if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
        } catch {
          /* unreadable shim — keep looking */
        }
      }
    }
    const own = resolveManagedNpmPackageBin(agentType, packageName, list[0]);
    if (own) return own;
  }
  return null;
}

/**
 * Last-resort binary lookup: walk the directories we already know agent CLIs
 * land in and check the filesystem directly, instead of asking the shell.
 *
 * `where`/`which` is not enough on Windows. The Cursor, Amp and Hermes
 * installers edit the *registry* PATH, which an already-running process never
 * inherits — so a perfectly good install is invisible to a PATH lookup until
 * the machine (or at least the app) is restarted. Every adapter grew its own
 * tiered search to cope; the launcher had none, so it alone reported "can't
 * find it" and then opened a terminal running a bare command that could only
 * fail with "'cursor-agent' is not recognized".
 *
 * Deliberately reuses getKnownBinDirs() rather than a second hardcoded list:
 * that list already IS the curated set, and a copy of it is exactly how the
 * launcher and the adapters drifted apart in the first place.
 *
 * It has to be the KNOWN dirs, not the extra ones. getExtraBinDirs() drops
 * everything already on PATH, on the reasoning that PATH covers it — but the
 * only way execution gets here is a `where`/`which` that ALREADY failed, and it
 * fails wholesale on Windows (mangled OEM-codepage output on a non-English
 * install, a 5s timeout, a cmd.exe that isn't resolvable from an Electron
 * process). With the filter in place that failure erased every agent installed
 * to a normal location — %APPDATA%\npm and friends — and the marketplace
 * offered to install CodeBuddy/opencode/dsh over the copies already there.
 *
 * Runs only after a PATH lookup has already missed, so it can add resolutions
 * but never change one that already works.
 *
 * @param {string|string[]} names  binary name(s), e.g. ['cursor-agent','agent']
 * @param {string} [agentType]     adds that agent's isolated runtime bin dir
 * @returns {string|null} absolute path, or null
 */
function resolveBinaryInKnownDirs(names, agentType) {
  const list = (Array.isArray(names) ? names : [names]).filter(Boolean);
  if (!list.length) return null;

  const dirs = [];
  const push = (d) => { if (d && !dirs.includes(d)) dirs.push(d); };

  // The agent's own isolated runtime first — it is the copy this launcher
  // installed, and should win over anything the user happens to have globally.
  if (agentType) push(path.join(getRuntimePrefix(agentType), 'node_modules', '.bin'));
  push(path.join(HOME, '.openagents', 'nodejs', 'node_modules', '.bin'));
  try { push(path.dirname(process.execPath)); } catch {}
  for (const d of getKnownBinDirs()) push(d);

  for (const dir of dirs) {
    for (const name of list) {
      for (const ext of BIN_EXTS) {
        const candidate = path.join(dir, `${name}${ext}`);
        try {
          if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
        } catch {
          /* unreadable path — keep looking */
        }
      }
    }
  }

  // Nothing native anywhere: the last place left to look is inside WSL, whose
  // filesystem none of the dirs above can reach. Last by construction — a
  // Windows copy of the CLI is always preferred to an in-distro one.
  return resolveWslBinary(list);
}


module.exports = {
  getKnownBinDirs,
  getExtraBinDirs,
  getEnhancedPATH,
  getEnhancedEnv,
  whichBinary,
  whereBinary,
  whereAll,
  resolveManagedNpmBinary,
  resolveManagedNpmPackageBin,
  isNodeShebangScript,
  resolveBinaryInKnownDirs,
  clearBinaryLookupCache,
  primeBinaryLookup,
  loginShellDirs,
  getRuntimePrefix,
  getCorePrefix,
  defaultAgentWorkdir,
  aiderBinDirs,
  uvToolBinDirs,
  IS_WINDOWS,
  IS_MACOS,
  SEP,
};
