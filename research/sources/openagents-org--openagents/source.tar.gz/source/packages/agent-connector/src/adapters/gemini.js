/**
 * Gemini CLI adapter for OpenAgents workspace.
 *
 * Bridges Gemini CLI to an OpenAgents workspace via:
 * - Polling loop for incoming messages
 * - Gemini CLI subprocess (stream-json) for task execution
 */

'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');
// spawn() here is the WSL bridge from ../wsl: same signature as
// child_process.spawn, and a straight pass-through unless the resolved CLI
// lives on the other side of the Windows/WSL boundary.
const { spawn, resolveWslBinary } = require('../wsl');

const BaseAdapter = require('./base');
const { whereBinary } = require('../paths');
const { formatAttachmentsForPrompt, SESSION_DEFAULT_RE, generateSessionTitle } = require('./utils');
const { buildClaudeSystemPrompt } = require('./workspace-prompt');
const {
  isFailedRun,
  failureDetail,
  classifyGeminiFailure,
  retriesWithoutResume,
} = require('./gemini-stream');

const IS_WINDOWS = process.platform === 'win32';

class GeminiAdapter extends BaseAdapter {
  /**
   * @param {object} opts - BaseAdapter opts plus:
   * @param {Set} [opts.disabledModules]
   * @param {string} [opts.workingDir]
   */
  constructor(opts) {
    super(opts);
    this.disabledModules = opts.disabledModules || new Set();
    // Pin the channel's glossary into the prompt (read-only:
    // Gemini has no MCP server and no workspace skill, so it cannot write
    // the knowledge entries — it only needs to SEE them).
    this._usesPinnedContext = true;
    this._channelSessions = {}; // channel → Gemini CLI session_id
    this._channelProcesses = {}; // channel → child process
    this._sessionsFile = path.join(
      os.homedir(), '.openagents', 'sessions',
      `${this.workspaceId}_${this.agentName}_gemini.json`
    );
    this._loadSessions();
  }

  _loadSessions() {
    try {
      if (fs.existsSync(this._sessionsFile)) {
        const data = JSON.parse(fs.readFileSync(this._sessionsFile, 'utf-8'));
        if (data && typeof data === 'object') {
          Object.assign(this._channelSessions, data);
          this._log(`Loaded ${Object.keys(data).length} session(s)`);
        }
      }
    } catch {
      this._log('Could not load sessions file, starting fresh');
    }
  }

  _saveSessions() {
    try {
      const dir = path.dirname(this._sessionsFile);
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(this._sessionsFile, JSON.stringify(this._channelSessions));
    } catch {}
  }

  async _stopProcess(proc) {
    if (!proc || proc.exitCode !== null) return;
    try {
      if (IS_WINDOWS) {
        try { execSync(`taskkill /F /T /PID ${proc.pid}`, { timeout: 5000 }); } catch {}
      } else {
        try { process.kill(-proc.pid, 'SIGTERM'); } catch {
          proc.kill('SIGTERM');
        }
        await new Promise((resolve) => {
          const timeout = setTimeout(() => {
            try { process.kill(-proc.pid, 'SIGKILL'); } catch {
              proc.kill('SIGKILL');
            }
            resolve();
          }, 5000);
          proc.on('exit', () => { clearTimeout(timeout); resolve(); });
        });
      }
    } catch {}
  }

  _findNodeBin() {
    const home = os.homedir();
    const candidates = IS_WINDOWS
      ? [path.join(home, '.openagents', 'nodejs', 'node.exe')]
      : [path.join(home, '.openagents', 'nodejs', 'node'),
         path.join(home, '.openagents', 'nodejs', 'bin', 'node')];
    for (const c of candidates) {
      if (fs.existsSync(c)) return c;
    }
    // Fall back to the node already running this daemon (absolute, always valid).
    // Bare 'node' can be off-PATH in a packaged daemon or CI runner.
    return process.execPath;
  }

  _resolveToNodeCmd(binPath) {
    const nodeBin = this._findNodeBin();
    if (IS_WINDOWS && binPath.toLowerCase().endsWith('.cmd')) {
      const cmdDir = path.dirname(path.resolve(binPath));
      const cmdContent = fs.readFileSync(binPath, 'utf-8');
      const jsMatch = cmdContent.match(/%dp0%\\([^\s"*?]+\.m?js)/i);
      if (jsMatch) {
        return [nodeBin, path.resolve(cmdDir, jsMatch[1])];
      }
      // .cmd shims that forward to a native .exe — resolve to the exe and spawn
      // it directly. Wrapping such a .cmd in `cmd.exe /c` caps the command line
      // at cmd.exe's 8191-char limit, truncating long args (e.g. system prompts).
      const exeMatch = cmdContent.match(/%dp0%\\([^\s"*?]+\.exe)/i);
      if (exeMatch) {
        return [path.resolve(cmdDir, exeMatch[1])];
      }
    } else {
      try {
        let target = binPath;
        if (fs.lstatSync(binPath).isSymbolicLink()) {
          target = path.resolve(path.dirname(binPath), fs.readlinkSync(binPath));
        }
        if (target.endsWith('.js') || target.endsWith('.mjs')) {
          return [nodeBin, target];
        }
      } catch {}
    }
    return null;
  }

  _findGeminiBinary() {
    const home = os.homedir();
    const ext = IS_WINDOWS ? '.cmd' : '';

    // Tier 0: Isolated runtime prefix
    const runtimeCandidate = path.join(home, '.openagents', 'runtimes', 'gemini', 'node_modules', '.bin', `gemini${ext}`);
    if (fs.existsSync(runtimeCandidate)) return runtimeCandidate;

    // Tier 1: PATH search via a codepage-safe lookup (whereBinary forces UTF-8
    // output + verifies existence so a non-ASCII/Chinese username isn't mangled
    // into an ENOENT; it also no longer returns an empty string on a miss, which
    // used to short-circuit the Node-derived fallback tiers below).
    const viaWhere = whereBinary('gemini');
    if (viaWhere) return viaWhere;

    // Tier 2: Next to current Node.js interpreter
    const nodeBinDir = path.dirname(process.execPath);
    const nearNode = path.join(nodeBinDir, `gemini${ext}`);
    if (fs.existsSync(nearNode)) return nearNode;

    // Tier 3: Common install locations
    const candidates = IS_WINDOWS ? [
      path.join(process.env.APPDATA || '', 'npm', 'gemini.cmd'),
    ] : [
      path.join(home, '.local', 'bin', 'gemini'),
      path.join(home, '.npm-global', 'bin', 'gemini'),
      '/opt/homebrew/bin/gemini',
      '/usr/local/bin/gemini',
    ];
    for (const c of candidates) {
      if (fs.existsSync(c)) return c;
    }

    // Nothing native anywhere. Last of all, look inside WSL: a CLI the user
    // installed in their distro is a real install, and the marked path it comes
    // back as is what the spawn bridge in ../wsl turns into a wsl.exe run.
    return resolveWslBinary('gemini');
  }

  // The Gemini CLI refuses to run non-interactively unless an auth method is
  // explicitly selected in ~/.gemini/settings.json ("Invalid auth method
  // selected"), even when GEMINI_API_KEY is present. When the user configured an
  // API key, select API-key auth (both the legacy flat and current nested
  // schema) and disable folder-trust so `-y` isn't downgraded. We never override
  // an existing non-api-key selection (e.g. a real OAuth sign-in).
  _ensureGeminiAuth() {
    if (this._geminiAuthReady) return;
    this._geminiAuthReady = true;
    try {
      const env = this.agentEnv || process.env;
      const apiKey = (env.GEMINI_API_KEY || env.GOOGLE_API_KEY || '').trim();
      if (!apiKey) return; // OAuth / other — leave the user's setup alone.
      const dir = path.join(os.homedir(), '.gemini');
      fs.mkdirSync(dir, { recursive: true });
      const file = path.join(dir, 'settings.json');
      let settings = {};
      try { settings = JSON.parse(fs.readFileSync(file, 'utf-8')) || {}; } catch {}
      const current =
        settings.selectedAuthType ||
        (settings.security && settings.security.auth && settings.security.auth.selectedType);
      if (current && current !== 'gemini-api-key') return; // respect explicit OAuth/Vertex.
      settings.selectedAuthType = 'gemini-api-key';
      settings.security = settings.security || {};
      settings.security.auth = { ...(settings.security.auth || {}), selectedType: 'gemini-api-key' };
      settings.security.folderTrust = { ...(settings.security.folderTrust || {}), enabled: false };
      fs.writeFileSync(file, JSON.stringify(settings, null, 2));
      this._log('Configured Gemini CLI for API-key auth (~/.gemini/settings.json)');
    } catch (e) {
      this._log(`gemini auth setup skipped: ${e.message}`);
    }
  }

  _buildGeminiCmd(prompt, channelName, { skipResume = false } = {}) {
    this._ensureGeminiAuth();
    const geminiBin = this._findGeminiBinary();
    if (!geminiBin) {
      throw new Error('gemini CLI not found. Install with: npm install -g @google/gemini-cli');
    }

    const pinned = this.pinnedPromptOpts(channelName);
    const systemPrompt = '\n' + buildClaudeSystemPrompt({
      agentName: this.agentName,
      workspaceId: this.workspaceId,
      channelName,
      mode: this._mode,
      model: this.modelLabel(),
      glossary: pinned.glossary ? { ...pinned.glossary, writeAccess: false } : null,
    });
    
    // For gemini, we combine system prompt with the user message since it doesn't have an append-system-prompt flag
    const fullPrompt = `${systemPrompt}\n\n---\n\nUser message:\n${prompt}`;

    const cmd = [geminiBin, '-p', fullPrompt, '-y', '-o', 'stream-json'];

    // Honor a user-configured model (e.g. when pointing at a relay/proxy whose
    // channels don't match the CLI default). Set via GEMINI_MODEL in env_config.
    const env = this.agentEnv || process.env;
    const model = (env.GEMINI_MODEL || env.GOOGLE_GEMINI_MODEL || '').trim();
    if (model) cmd.push('-m', model);

    const sessionId = this._channelSessions[channelName];
    if (sessionId && !skipResume) {
      cmd.push('-r', sessionId);
    }

    return { cmd };
  }

  async _handleMessage(msg) {
    let content = (msg.content || '').trim();
    const attachments = msg.attachments || [];

    const attText = formatAttachmentsForPrompt(attachments);
    if (attText) {
      content = content ? content + attText : attText.trim();
    }

    if (!content) return;

    const msgChannel = msg.sessionId || this.channelName;
    const sender = msg.senderName || msg.senderType || 'user';
    this._log(`Processing message from ${sender} in ${msgChannel}: ${content.slice(0, 80)}...`);

    if (!this._titledSessions.has(msgChannel)) {
      this._titledSessions.add(msgChannel);
      try {
        const info = await this.client.getSession(this.workspaceId, msgChannel, this.token);
        const resumeFrom = info.resumeFrom;
        if (resumeFrom && !this._channelSessions[msgChannel]) {
          const sourceSession = this._channelSessions[resumeFrom];
          if (sourceSession) {
            this._channelSessions[msgChannel] = sourceSession;
            this._saveSessions();
            this._log(`Resuming channel ${msgChannel} from ${resumeFrom}`);
          }
        }
        const title = generateSessionTitle(content);
        if (title && !info.titleManuallySet && SESSION_DEFAULT_RE.test(info.title || '')) {
          await this.client.updateSession(
            this.workspaceId, msgChannel, this.token,
            { title, autoTitle: true }
          );
        }
      } catch {}
    }

    await this.sendStatus(msgChannel, 'thinking...');

    let cmd;
    const cleanEnv = { ...(this.agentEnv || process.env) };
    // Without it a Gemini CLI with folder trust on (the default for a Google
    // sign-in) stops with "Gemini CLI is not running in a trusted directory"
    // in any working directory the user never trusted by hand. It is what the
    // CLI's own --skip-trust sets; an explicit value of the user's stands.
    if (cleanEnv.GEMINI_CLI_TRUST_WORKSPACE == null) cleanEnv.GEMINI_CLI_TRUST_WORKSPACE = 'true';

    let _shouldRetry = false;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const built = this._buildGeminiCmd(content, msgChannel, { skipResume: attempt > 0 });
        cmd = built.cmd;
      } catch (e) {
        await this.sendError(msgChannel, e.message);
        return;
      }

      // Stopped while this turn was being prepared: start nothing (no tokens).
      if (this._stoppedBeforeStart(msgChannel)) return;

      try {
        const resolved = this._resolveToNodeCmd(cmd[0]);
        if (resolved) {
          cmd = [...resolved, ...cmd.slice(1)];
        } else if (IS_WINDOWS && cmd[0].toLowerCase().endsWith('.cmd')) {
          cmd = ['cmd.exe', '/c', ...cmd];
        }

        const proc = spawn(cmd[0], cmd.slice(1), {
          stdio: ['ignore', 'pipe', 'pipe'],
          env: cleanEnv,
          cwd: this.workingDir,
          detached: !IS_WINDOWS,
          windowsHide: true,
        });
        this._channelProcesses[msgChannel] = proc;

        // Read before any event can replace it: whether this run passed -r.
        const resumed = attempt === 0 && Boolean(this._channelSessions[msgChannel]);
        const lastResponseText = [];
        let hasToolUseSinceLastText = false;
        let postedThinking = false;
        let stderrBuf = '';
        let lineBuffer = '';
        let _pendingLines = Promise.resolve();
        // Where the CLI says a run failed: the final result event, and any
        // error-severity events along the way. See gemini-stream.js.
        let resultStatus = null;
        let resultError = null;
        const errorMessages = [];
        let idleKilled = false;

        if (proc.stderr) {
          proc.stderr.on('data', (chunk) => { stderrBuf += chunk.toString('utf-8'); });
        }

        _shouldRetry = await new Promise((resolve, reject) => {
          let consecutiveTimeouts = 0;
          let lastDataTime = Date.now();
          let timeoutTimer = null;

          const resetTimeout = () => {
            consecutiveTimeouts = 0;
            lastDataTime = Date.now();
          };

          const startTimeoutMonitor = () => {
            timeoutTimer = setInterval(async () => {
              const elapsed = Date.now() - lastDataTime;
              if (elapsed >= 15000) {
                consecutiveTimeouts++;
                lastDataTime = Date.now();
                if (consecutiveTimeouts === 2) {
                  try { await this.sendStatus(msgChannel, 'Processing...'); } catch {}
                }
                if (consecutiveTimeouts >= 20) {
                  this._log(`Process idle for ${consecutiveTimeouts * 15}s, killing...`);
                  idleKilled = true;
                  await this._stopProcess(proc);
                }
              }
            }, 15000);
          };
          startTimeoutMonitor();

          const processLine = async (line) => {
            line = line.trim();
            if (!line) return;
            resetTimeout();

            let event;
            try { event = JSON.parse(line); } catch { return; }

            const eventType = event.type;

            if (eventType === 'init' && event.session_id) {
              this._channelSessions[msgChannel] = event.session_id;
              this._saveSessions();
            } else if (eventType === 'message' && event.role === 'assistant') {
              const text = event.content || '';
              if (text) {
                if (hasToolUseSinceLastText) {
                  lastResponseText.length = 0;
                  hasToolUseSinceLastText = false;
                }
                lastResponseText.push(text);
                postedThinking = true;
                try { await this.sendThinking(msgChannel, text); } catch {}
              }
            } else if (eventType === 'tool_use') {
              hasToolUseSinceLastText = true;
              postedThinking = false;
              lastResponseText.length = 0;
              const toolName = event.tool_name || '';
              let inputPreview = '';
              if (event.parameters && typeof event.parameters === 'object') {
                const inp = event.parameters;
                if (inp.command) inputPreview = inp.command;
                else if (inp.file_path || inp.path) inputPreview = inp.file_path || inp.path;
                else if (inp.pattern) inputPreview = inp.pattern;
                else if (inp.query) inputPreview = inp.query;
                else inputPreview = JSON.stringify(inp).slice(0, 150);
              }
              await this.sendStatus(msgChannel, `${toolName} › ${inputPreview}`);
            } else if (eventType === 'error') {
              // A warning (loop detected) does not fail the run; an error does.
              if (event.severity === 'error' && event.message) {
                errorMessages.push(String(event.message));
              } else if (event.message) {
                this._log(`CLI warning: ${this._redact(event.message)}`);
              }
            } else if (eventType === 'result') {
              if (event.session_id) {
                this._channelSessions[msgChannel] = event.session_id;
                this._saveSessions();
              }
              resultStatus = event.status || null;
              if (event.status === 'error') resultError = event.error || null;
            }
          };

          proc.on('exit', async (code, signal) => {
            if (timeoutTimer) clearInterval(timeoutTimer);

            try { await _pendingLines; } catch {}

            const lines = lineBuffer.split('\n');
            for (const line of lines) {
              try { await processLine(line); } catch {}
            }

            delete this._channelProcesses[msgChannel];

            if (code !== 0) {
              this._log(`CLI exited with ${signal ? `signal ${signal}` : `code ${code}`}`);
              // Redact the whole buffer before cutting it; keep the end, where the failure is.
              const stderrText = this._redact(stderrBuf).trim();
              if (stderrText) this._log(`stderr: ${stderrText.slice(-500)}`);
            }

            // stream-json deltas are fragments of one message: join with no separator.
            const fullResponse = lastResponseText.join('').trim();

            // Stopped by the user: their exit is neither a failure to report
            // nor a reason to retry from a fresh session, and `_handleUserStop`
            // has already told the channel. The base clears the flag when the
            // channel's next turn starts.
            if (this._stoppingChannels.has(msgChannel)) {
              resolve(false);
              return;
            }

            if (idleKilled) {
              if (fullResponse) {
                try { await this.sendResponse(msgChannel, fullResponse); } catch {}
              }
              const detail = failureDetail({
                stderr: stderrBuf, error: resultError, errorMessages, secrets: this._knownSecrets(),
              });
              try {
                await this.sendError(
                  msgChannel,
                  'Gemini CLI produced no output for 5 minutes and was stopped.' +
                    (detail ? `\n\nDetails: ${detail}` : ''),
                );
              } catch {}
              resolve(false);
              return;
            }

            if (!isFailedRun({ code, resultStatus, errorMessages })) {
              if (fullResponse) {
                try { await this.sendResponse(msgChannel, fullResponse); } catch {}
              } else if (!postedThinking) {
                try { await this.sendResponse(msgChannel, 'No response generated. Please try again.'); } catch {}
              }
              resolve(false);
              return;
            }

            const failure = classifyGeminiFailure({
              code, stderr: stderrBuf, error: resultError, errorMessages, secrets: this._knownSecrets(),
            });
            this._log(`Run failed (${failure.kind})`, 'error');

            // Only a resume that failed, or a failure nothing explains, is worth
            // a fresh session. Retrying anything else repeats the same wait for
            // the same error and throws the channel's history away.
            if (!fullResponse && resumed && retriesWithoutResume(failure.kind)) {
              this._log(`Could not resume the session for ${msgChannel}, clearing and retrying without resume`);
              delete this._channelSessions[msgChannel];
              this._saveSessions();
              resolve(true);
              return;
            }

            if (fullResponse) {
              try { await this.sendResponse(msgChannel, fullResponse); } catch {}
            }
            try { await this.sendError(msgChannel, failure.message); } catch {}
            resolve(false);
          });

          proc.on('error', (err) => {
            if (timeoutTimer) clearInterval(timeoutTimer);
            reject(err);
          });

          proc.stdout.on('data', (chunk) => {
            lineBuffer += chunk.toString('utf-8');
            resetTimeout();
            const lines = lineBuffer.split('\n');
            lineBuffer = lines.pop();
            for (const line of lines) {
              _pendingLines = _pendingLines.then(() => processLine(line)).catch(() => {});
            }
          });
        });
      } catch (e) {
        this._log(`Error handling message: ${e.message}`);
        await this.sendError(msgChannel, `Error processing message: ${this._redact(e.message)}`);
        break;
      }
      if (!_shouldRetry) break;
    }
  }
}

module.exports = GeminiAdapter;
