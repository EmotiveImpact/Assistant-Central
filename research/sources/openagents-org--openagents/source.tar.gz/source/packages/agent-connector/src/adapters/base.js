/**
 * Base adapter for OpenAgents workspace.
 *
 * Extracts the common connectivity logic shared by all adapters:
 * - Event cursor management and skip-existing-events on startup
 * - Heartbeat loop (30s)
 * - Adaptive poll loop with deduplication
 * - Control event polling (mode changes, stop)
 * - Per-channel task dispatch with queuing
 * - Auto-titling of new channels
 * - Graceful shutdown with disconnect
 *
 * Subclasses must implement _handleMessage(msg).
 *
 * Direct port of Python: sdk/src/openagents/adapters/base.py
 */

'use strict';

const crypto = require('crypto');
const { WorkspaceClient, SessionRevokedError } = require('../workspace-client');
const { generateSessionTitle, SESSION_DEFAULT_RE, redactSecrets, secretValues } = require('./utils');
const { defaultAgentWorkdir } = require('../paths');
const { configuredModel } = require('../agent-model');
const { buildThreadHistory } = require('./thread-history');
const { publishResponseArtifacts } = require('./response-artifacts');
const { ResponseOutbox } = require('./response-outbox');
const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  glossaryTitle,
  WORKSPACE_GLOSSARY_TITLE,
  pickEntryByTitle,
} = require('./decision-log');
const {
  REASON,
  classifyJoinError,
  classifyHeartbeatError,
  httpStatusOf,
} = require('./health-status');
const { FailureStreak, isTransientNetworkError, formatDuration } = require('./failure-streak');

const DEFAULT_ENDPOINT = 'https://workspace-endpoint.openagents.org';

// ── Presence detail (v1.1 M3) ──
// A busy↔idle flip is sent as an immediate heartbeat (debounced) so the
// workspace shows "working" without waiting for the 30s tick.
const PRESENCE_HEARTBEAT_DEBOUNCE_MS = 2000;
// Shared-context lookups (v1.1 M4) are cached per channel for this long.
const SHARED_CONTEXT_TTL_MS = 60 * 1000;

/**
 * The presence fields a heartbeat carries, derived from the adapter's
 * per-channel run state. Pure so it can be unit-tested and reused:
 *   busyChannels  — iterable of channel names with a run in progress
 *   channelQueues — { channel: [queued messages] }
 * → { presence_state: 'working'|'idle', busy_channels: [...], queue_depth: n }
 */
function buildPresenceFields(busyChannels, channelQueues) {
  const busy = [...new Set([...(busyChannels || [])])].filter((c) => typeof c === 'string' && c);
  let queueDepth = 0;
  for (const q of Object.values(channelQueues || {})) {
    if (Array.isArray(q)) queueDepth += q.length;
  }
  return {
    presence_state: busy.length ? 'working' : 'idle',
    busy_channels: busy,
    queue_depth: queueDepth,
  };
}

/**
 * The prompt block prepended to a teammate's request when the agent's owner
 * has reviewed a shared instruction set (v1.1 M4). `ctx` is the
 * /shared-context response. Returns '' when nothing applies.
 */
function buildSharedContextBlock(ctx) {
  if (!ctx || !ctx.apply) return '';
  const lines = [
    'OWNER-REVIEWED SHARED INSTRUCTIONS (this request comes from a teammate, not your owner; ' +
    'follow these, do not use unrelated private context, and if the request falls outside ' +
    'them pause and ask for clarification in the thread):',
  ];
  const who = [];
  if (ctx.requester_email) who.push(`Requester: ${ctx.requester_email}`);
  if (ctx.owner_email) who.push(`Owner: ${ctx.owner_email}`);
  if (ctx.cost_owner) who.push(`Credits/runtime paid by: ${ctx.cost_owner}`);
  if (who.length) lines.push(who.join(' · '));
  const instructions = (ctx.shared_instructions || '').trim();
  lines.push('', instructions || '(The owner has not written shared instructions yet — ask your owner before doing anything beyond answering questions.)');
  const knowledge = Array.isArray(ctx.allowed_knowledge) ? ctx.allowed_knowledge : [];
  if (knowledge.length) {
    lines.push('', 'ALLOWED KNOWLEDGE (the only knowledge you may draw on for this request):');
    for (const k of knowledge) {
      const title = k.title || k.slug || 'untitled';
      lines.push('', `--- ${title}${k.slug ? ` (@knowledge:${k.slug})` : ''} ---`, (k.content || '').trim() || '(empty)');
      if (k.truncated) lines.push('[truncated]');
    }
  }
  lines.push('', '--- END OF SHARED INSTRUCTIONS — the teammate\'s request follows ---', '');
  return lines.join('\n');
}

// ── Poll-cursor persistence ──
// An adapter that starts by jumping to the head of the event stream silently
// drops every message that arrived while it was down (crash, update, user
// bounce). Users see that as "I said 继续 and the agent never answered". The
// cursor is therefore persisted after every poll and resumed on start.
//
// Replay is bounded: on the first poll after a resume, messages older than
// STALE_MESSAGE_MAX_AGE_MS are skipped (and the channel told), so a launcher
// that was off for a day does not act on hours-old instructions unannounced.
// This also covers a backend that ignores an unknown/deleted cursor and
// returns history from the start. A persisted cursor older than
// CURSOR_RESUME_MAX_AGE_MS is ignored altogether (jump to head as before).
const STALE_MESSAGE_MAX_AGE_MS = 60 * 60 * 1000;
const CURSOR_RESUME_MAX_AGE_MS = 24 * 60 * 60 * 1000;

// Heartbeat runs every 30s. A SINGLE failure is usually a transient blip (brief
// network hiccup, server redeploy) that the next tick recovers from — surfacing
// it as a hard 'error' would make the agent flap red for no real reason. Only
// after this many CONSECUTIVE failures (~60s+ of real downtime) do we report
// heartbeat_failed up to the daemon. A success resets the streak immediately.
const HEARTBEAT_ERROR_THRESHOLD = 2;

// ── Control-poller deadlines ──
// The control poller is one chain of awaits, and it is the only thing that
// delivers Stop. When a link in it never settles — it has: a control poll
// whose response was cut off mid-body — the agent goes on working and
// answering while every later control event sits unread until the daemon
// restarts, and nothing in the log says so. So neither the fetch nor a
// handler is awaited without a bound. A handler that overruns is not
// cancelled or re-run; the poller only stops waiting for it.
const CONTROL_POLL_DEADLINE_MS = 20 * 1000;
const CONTROL_ACTION_DEADLINE_MS = 60 * 1000;
const CONTROL_DEADLINE_HIT = Symbol('control deadline hit');

/**
 * Wrap an adapter's `_channelProcesses` so registering a child for a turn that
 * was already stopped kills it at once (see `_onProcessRegistered`).
 */
function watchProcessRegistry(adapter, registry) {
  if (!registry || typeof registry !== 'object') return registry;
  return new Proxy(registry, {
    set(target, key, value) {
      target[key] = value;
      if (typeof key === 'string') adapter._onProcessRegistered(key, value);
      return true;
    },
  });
}

class BaseAdapter {
  get _channelProcesses() {
    return this.__channelProcesses;
  }

  set _channelProcesses(registry) {
    this.__channelProcesses = watchProcessRegistry(this, registry);
  }

  /**
   * @param {object} opts
   * @param {string} opts.workspaceId
   * @param {string} opts.channelName - default/initial channel
   * @param {string} opts.token
   * @param {string} opts.agentName
   * @param {string} [opts.endpoint]
   */
  constructor({ workspaceId, channelName, token, agentName, endpoint, agentEnv, agentType, workingDir, onStatus, logSink }) {
    this.workspaceId = workspaceId;
    this.channelName = channelName;
    this.token = token;
    this.agentName = agentName;
    this.endpoint = endpoint || DEFAULT_ENDPOINT;
    this.agentEnv = agentEnv || process.env;
    this.agentType = agentType;
    this.workingDir = workingDir || undefined;
    // Optional callback the daemon supplies to surface live runtime/connectivity
    // status (reason + redacted message) into daemon.status.json so the Agents
    // list / TUI can show the REAL failure instead of a swallowed log line. A
    // null reason means "healthy again" (clears any prior error).
    this._onStatus = typeof onStatus === 'function' ? onStatus : null;
    this._lastReportedStatusKey = null;
    // Consecutive heartbeat failures — a transient single blip must not flip the
    // agent to a hard error (see HEARTBEAT_ERROR_THRESHOLD).
    this._heartbeatFailStreak = 0;
    // Structured terminal exit reason ({ reason, message }) read by the daemon
    // after run() returns, to distinguish a clean stop from a real failure.
    this._exitInfo = null;
    // Set when the user explicitly stops this adapter (vs an error/revoke), so a
    // clean stop is never mislabeled as an error.
    this._stopRequested = false;
    // Acts for this one agent: X-Agent-Name on every request (permission model v1.1).
    this.client = new WorkspaceClient(this.endpoint, { agentName: this.agentName });
    this._lastEventId = null;
    this._cursorFile = this._cursorFilePath();
    this._lastPersistedCursor = null;
    this._resumedFromCursor = false;
    // No cursor and no head: polls read from the start of history until they
    // come back empty (see _skipExistingEvents).
    this._unanchored = false;
    this._running = false;
    this._sessionId = null;  // issued by server on /v1/join; used to prove liveness
    this._processedIds = new Set();
    this._titledSessions = new Set();
    this._mode = 'execute';
    // Workspace-selected model id (WorkspaceMember.model). Synced from
    // discover at startup and via the `model.set` control event; null means
    // the agent CLI runs with its own default.
    this.workspaceModel = null;
    this._lastControlId = null;
    this._controlWake = null;
    this._CONTROL_POLL_DEADLINE_MS = CONTROL_POLL_DEADLINE_MS;
    this._CONTROL_ACTION_DEADLINE_MS = CONTROL_ACTION_DEADLINE_MS;
    // Per-channel task tracking for parallel execution
    this._channelBusy = new Set();
    this._channelQueues = {};
    // Stop generations. A stop has to cancel work that is no longer IN the
    // queue: the message a channel worker already shifted out, and anything
    // the interrupted turn queues on its way out (Claude's todo nudge). The
    // adapters clear `_channelQueues`, which cannot reach either — that is
    // why one press of Stop used to report a stop and then let the agent
    // pick straight back up, and only a second press stuck. Workers capture
    // the generation they started under and abandon their drain loop the
    // moment it moves.
    this._stopGeneration = 0;
    this._channelStopGeneration = {};
    // The generation a channel's in-flight message started under, so an
    // adapter can tell "a stop landed while I was preparing this turn" from
    // "this turn started after the stop and is meant to run".
    this._channelRunGeneration = {};
    this._channelRequestContent = {};
    this._channelTriggerId = {};
    // Channels a user stopped whose next turn has not started yet. Everything
    // the send* helpers would post there is dropped: output a killed run was
    // still flushing lands after the stop notice otherwise, and the workspace
    // UI reads the latest message to decide whether the agent is running.
    this._mutedChannels = new Set();
    // Channels whose current stop has been announced, so the control handler
    // and an in-flight turn racing to report the same stop post it once.
    this._stopNoticeSent = new Set();
    // Channels being torn down by a stop. Adapters read it from their exit
    // handlers to tell a user stop from a crash.
    this._stoppingChannels = new Set();
    // Cached workspace.browser_enabled. Populated lazily on first read so we
    // don't pay an HTTP roundtrip per message — adapters that toggle the
    // workspace flag must reconnect/restart to pick up the change (matches
    // the Python adapter behavior in workspace_prompt.py).
    this._browserEnabledCache = null;
    // ── Knowledge pinning (glossary) ──
    // Entry-id caches make the steady state a single GET per pinned entry;
    // reads happen on EVERY message, so they get a hard short deadline
    // instead of the client's default 15s — a workspace hiccup must cost the
    // turn a couple of seconds, not half a minute.
    this._glossaryEntryIds = {}; // channel → knowledge entry id of its glossary
    this._DECISION_FETCH_TIMEOUT_MS = 2000;
    this._warnedKnowledgeDisabled = false;
    this._pinnedStatusWarned = new Set(); // channels already told pinning is inactive
    // Subclasses whose sync prompt builders consume pinnedPromptOpts() set
    // this true; the channel worker then refreshes _pinnedContext before
    // every _handleMessage call. Adapters with their own pinning flow
    // (Claude) fetch directly instead and leave it false.
    this._usesPinnedContext = false;
    this._pinnedContext = {}; // channel → { glossary }
    // ── v1.1 M3/M4 ──
    // Debounce handle for the busy↔idle presence heartbeat.
    this._presenceHeartbeatTimer = null;
    // channel → { fetchedAt, requesterEmail, ctx } from /shared-context.
    this._sharedContext = {};
    // channel → email of the person whose message is being handled (so the
    // per-run MCP server can tell the owner who asked).
    this._requesterEmail = {};
    // Wall-clock timestamp of adapter init, used by the `status` control
    // action to report uptime back to the channel. Reset on reinstantiation
    // (e.g. after a `restart` IPC bounce) so uptime tracks "time since last
    // restart" rather than the long-running daemon's process uptime.
    this._startedAt = Date.now();
    // Inside the daemon, `logSink` routes lines through its daemon.log writer
    // (batching, repeat suppression, rotation). Standalone, they go to stdout.
    const sink = typeof logSink === 'function' ? logSink : null;
    this._log = (msg, level = 'info') => {
      if (sink) return sink(level, msg);
      const ts = new Date().toISOString();
      console.log(`${ts} ${String(level).toUpperCase()} adapter [${this.agentName}]: ${msg}`);
    };
    // Runs of identical background failures (see failure-streak.js).
    this._pollFailures = new FailureStreak();
    this._heartbeatFailures = new FailureStreak();
    // The control poller (Stop, mode changes) fails silently otherwise: its
    // errors are caught so the loop keeps going, and nothing else logs them.
    this._controlFailures = new FailureStreak();
  }

  // ------------------------------------------------------------------
  // Redaction of text quoted into the channel
  // ------------------------------------------------------------------

  /**
   * The exact values this agent must never quote back: the credentials in the
   * environment its CLI runs with, and its own workspace token. A CLI that
   * fails on auth tends to echo the key it was handed, in whatever format the
   * provider issues — matching by value catches it where no pattern would.
   */
  _knownSecrets() {
    return secretValues(this.agentEnv, [this.token]);
  }

  /**
   * Redact CLI or exception text on its way to the channel: this agent's own
   * secrets by value first, then anything shaped like a credential. For quoted
   * text only — authored guidance names variables ("set GEMINI_API_KEY") that
   * the shape rules would rewrite.
   */
  _redact(text) {
    return redactSecrets(text, this._knownSecrets());
  }

  // ------------------------------------------------------------------
  // Runtime status reporting (daemon surfaces this in daemon.status.json)
  // ------------------------------------------------------------------

  /**
   * Surface a live status transition to the daemon. `reason` null/'' means the
   * agent is healthy again (clears any prior error). Deduped so a repeated
   * failure (e.g. heartbeat every 30s on a down workspace) writes the status
   * file once, not on every tick. Never throws — status is best-effort.
   */
  _reportStatus(reason, message) {
    const key = `${reason || ''}|${message || ''}`;
    if (key === this._lastReportedStatusKey) return;
    this._lastReportedStatusKey = key;
    if (!this._onStatus) return;
    try {
      this._onStatus({ reason: reason || null, message: message || null });
    } catch { /* status is best-effort */ }
  }

  /** Record the FIRST terminal failure reason; later teardown noise can't mask it. */
  _setExitInfo(reason, message) {
    if (!this._exitInfo) this._exitInfo = { reason, message };
  }

  /** Read by the daemon after run() returns. null = clean exit. */
  getExitInfo() {
    return this._exitInfo;
  }

  /** True when stop() was called explicitly (a clean user stop, not a failure). */
  wasStopRequested() {
    return this._stopRequested === true;
  }

  /**
   * Preflight gate, run by the daemon BEFORE join. Default: always runnable.
   * Subclasses whose agent needs a resolvable CLI binary override this to return
   * { ok:false, reason:'runtime_missing', message } so the daemon surfaces a
   * precise reason and skips the workspace join (no pointless join loop).
   */
  preflight() {
    return { ok: true };
  }

  // ------------------------------------------------------------------
  // Lifecycle
  // ------------------------------------------------------------------

  /**
   * Announce this agent to the workspace (/v1/join). Returns true on success.
   * On failure surfaces the REAL reason (e.g. "Workspace join failed: HTTP 401")
   * to the daemon status instead of only logging it — non-fatal, the poll/
   * heartbeat loops keep retrying and a later success clears it. Extracted from
   * run() so the failure-reporting can be unit-tested without the poll loop.
   */
  async _joinWorkspace() {
    try {
      const joinResult = await this.client.joinNetwork(this.agentName, this.token, {
        network: this.workspaceId,
        agentType: this.agentType || 'agent',
        serverHost: require('os').hostname(),
        workingDir: this.workingDir || defaultAgentWorkdir(this.agentName),
      });
      this._sessionId = (joinResult && joinResult.session_id) || null;
      this._log(`Joined workspace ${this.workspaceId}${this._sessionId ? ` (session ${this._sessionId.slice(0, 8)})` : ''}`);
      this._reportStatus(null); // joined OK → clear any prior error
      return true;
    } catch (e) {
      const { reason, message } = classifyJoinError(e);
      this._log(`${message} (status: ${e && e.statusCode != null ? e.statusCode : 'n/a'})`);
      this._reportStatus(reason, message);
      return false;
    }
  }

  /**
   * The model this agent is actually running on, for the workspace prompt.
   *
   * The one fact about itself an agent cannot look up. Asked "what model are
   * you?", a CLI-driven agent answers from what its weights remember about
   * their own training, which is a guess — and a user who had configured
   * deepseek was told, confidently, "I am Claude, by Anthropic". We know the
   * real answer: it is the id we hand the CLI.
   *
   * Resolution order is the same one the adapters spawn with: a model chosen
   * in the workspace wins, then this agent type's own model variable, then the
   * generic LLM_MODEL that the LLM-direct types and the daemon's model.set
   * both write. Adapters that qualify the id further (OpenWorker prefixes it
   * with the provider) override this and return exactly what they send.
   *
   * Null when nothing is configured — the CLI is then running its own default
   * and we have nothing truthful to say about it. Better silent than wrong.
   */
  modelLabel() {
    const fromWorkspace = String(this.workspaceModel || '').trim();
    if (fromWorkspace) return fromWorkspace;
    return configuredModel(this.agentType, this.agentEnv);
  }

  async run() {
    this._running = true;

    // Announce agent to workspace
    await this._joinWorkspace();

    // Sync workspace-managed skills into disabledModules
    try {
      const agents = await Promise.race([
        this.client.getAgents(this.workspaceId, this.token),
        new Promise((_, reject) => setTimeout(() => reject(new Error('skill sync timed out (10s)')), 10000)),
      ]);
      const self = agents.find((a) => a.agentName === this.agentName);
      if (self && self.enabledSkills) {
        const { skillsToDisabledModules } = require('../skill-catalog');
        this.disabledModules = skillsToDisabledModules(self.enabledSkills);
        this._log(`Synced skills from workspace: disabled=[${[...this.disabledModules].join(',')}]`);
      }
      if (self && self.model) {
        this.workspaceModel = self.model;
        this._log(`Synced model from workspace: ${this.workspaceModel}`);
      }
    } catch (e) {
      this._log(`Warning: skill sync failed (non-fatal): ${e.message}`, 'warn');
    }

    // Fast-path operations (control-event cursor + heartbeat + control poll)
    // run BEFORE the message-cursor advance. Even though _skipExistingEvents
    // is fast on a healthy backend, we don't want slash commands gated on
    // its success — keeping these paths independent makes /restart and
    // /status responsive immediately after join.
    await this._skipExistingControlEvents();
    const heartbeatInterval = setInterval(() => this._heartbeat(), 30000);
    const responseInterval = setInterval(() => this._flushResponses(), 10000);
    void this._flushResponses();
    const controlPoller = this._controlPollerLoop();

    try {
      // Send initial heartbeat
      try { await this._heartbeat(); } catch (e) {
        this._log(`Heartbeat failed (non-fatal): ${e.message}`, 'warn');
      }
      // Slow path: only the message-poll loop waits for this.
      await this._skipExistingEvents();
      this._log('Starting poll loop...');
      await this._pollLoop();
    } finally {
      this._running = false;
      this._wakeControlPoller();
      clearInterval(heartbeatInterval);
      clearInterval(responseInterval);
      if (this._presenceHeartbeatTimer) { clearTimeout(this._presenceHeartbeatTimer); this._presenceHeartbeatTimer = null; }
      try { await controlPoller; } catch {}
      try {
        await this.client.disconnect(this.workspaceId, this.agentName, this.token);
      } catch {}
    }
  }

  stop() {
    this._stopRequested = true;
    this._running = false;
  }

  // ------------------------------------------------------------------
  // Event cursor / skip existing
  // ------------------------------------------------------------------

  /** Where this agent's poll cursor lives between runs (per workspace+agent). */
  _cursorFilePath() {
    const safe = (v) => String(v || 'unknown').replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 80);
    return path.join(os.homedir(), '.openagents', 'cursors', `${safe(this.workspaceId)}__${safe(this.agentName)}.json`);
  }

  /** The cursor saved by the previous run, or null when absent/stale/foreign. */
  _loadPersistedCursor() {
    try {
      const raw = JSON.parse(fs.readFileSync(this._cursorFile, 'utf-8'));
      if (!raw || typeof raw.cursor !== 'string' || !raw.cursor) return null;
      if (raw.workspaceId !== this.workspaceId || raw.agentName !== this.agentName) return null;
      const age = Date.now() - (Number(raw.savedAt) || 0);
      if (!(age >= 0 && age <= CURSOR_RESUME_MAX_AGE_MS)) return null;
      return raw.cursor;
    } catch {
      return null;
    }
  }

  /** Persist the poll cursor (no-op when unchanged; never throws). */
  _persistCursor(cursor) {
    if (!cursor || cursor === this._lastPersistedCursor) return;
    this._lastPersistedCursor = cursor;
    try {
      fs.mkdirSync(path.dirname(this._cursorFile), { recursive: true });
      const tmp = `${this._cursorFile}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({
        cursor, savedAt: Date.now(), workspaceId: this.workspaceId, agentName: this.agentName,
      }));
      fs.renameSync(tmp, this._cursorFile);
    } catch (e) {
      if (!this._warnedCursorPersist) {
        this._warnedCursorPersist = true;
        this._log(`Could not persist poll cursor (${e.message}) — a restart will skip messages that arrive while offline`, 'warn');
      }
    }
  }

  /** True when a replayed message is too old to act on (see STALE_MESSAGE_MAX_AGE_MS). */
  _isStaleMessage(msg) {
    if (!msg || !msg.createdAt) return false;
    const t = Date.parse(msg.createdAt);
    if (!Number.isFinite(t)) return false;
    return Date.now() - t > STALE_MESSAGE_MAX_AGE_MS;
  }

  async _skipExistingEvents() {
    // Prefer the cursor the previous run persisted: a restart must not drop the
    // messages that arrived in between (bounded by the stale filter in the
    // poll loop).
    const persisted = this._loadPersistedCursor();
    if (persisted) {
      this._lastEventId = persisted;
      this._resumedFromCursor = true;
      this._log(`Resuming from persisted cursor ${persisted}`);
      return;
    }
    // Jump straight to the head with one server call. Pagination from the
    // start was slow and brittle: on a busy workspace it could take many
    // minutes to chew through historical events 200 at a time, leaving the
    // agent silently behind, and a transient mid-paginate empty response
    // (e.g. shared-cache race) would strand the cursor at a non-head id.
    const head = await this.client.getHeadEventId(this.workspaceId, this.token);
    if (head) {
      this._lastEventId = head;
      this._persistCursor(head);
      this._log(`Skipped existing events, cursor at ${head}`);
      return;
    }
    // The head lookup failed (network not up yet, a 5xx) or the workspace is
    // empty. Polling with no cursor reads from the start of history, and a
    // fresh start is not a replay, so every old message that named this agent
    // was run again, one after another — a Codex hitting 429 posted an error
    // every ~20s for an hour. Age-filter until the backlog is drained.
    this._unanchored = true;
    this._log('Could not find the head of the event stream — skipping stale messages until caught up', 'warn');
  }

  // ------------------------------------------------------------------
  // Heartbeat
  // ------------------------------------------------------------------

  /** Presence fields for the next heartbeat (see buildPresenceFields). */
  presenceFields() {
    return buildPresenceFields(this._channelBusy, this._channelQueues);
  }

  /**
   * A channel just went busy or idle (or its queue changed): send a heartbeat
   * soon so the roster flips promptly instead of on the next 30s tick. Bursts
   * collapse into one send.
   */
  _schedulePresenceHeartbeat() {
    if (!this._running) return;
    if (this._presenceHeartbeatTimer) return;
    this._presenceHeartbeatTimer = setTimeout(() => {
      this._presenceHeartbeatTimer = null;
      if (!this._running) return;
      this._heartbeat().catch(() => {});
    }, PRESENCE_HEARTBEAT_DEBOUNCE_MS);
    if (typeof this._presenceHeartbeatTimer.unref === 'function') this._presenceHeartbeatTimer.unref();
  }

  async _heartbeat() {
    try {
      await this.client.heartbeat(this.workspaceId, this.agentName, this.token, this._sessionId, this.presenceFields());
      this._heartbeatFailStreak = 0;
      const recovered = this._heartbeatFailures.succeed();
      if (recovered) {
        this._log(`Workspace heartbeat recovered after ${recovered.count} unsuccessful attempt(s) over ${formatDuration(recovered.ms)}`);
      }
      this._reportStatus(null); // alive → clear any prior connectivity error
    } catch (e) {
      if (e instanceof SessionRevokedError) {
        this._log(`SESSION REVOKED: another client joined as '${this.agentName}'. Stopping adapter.`, 'warn');
        // Terminal (not a user stop): record so the daemon can show why it ended.
        this._setExitInfo(REASON.SESSION_REVOKED, 'Workspace session revoked — another client joined with the same agent name');
        this._reportStatus(REASON.SESSION_REVOKED, 'Workspace session revoked');
        this._running = false;
        return;
      }
      // Only surface a hard error after repeated consecutive failures, so a
      // single transient blip (or an expected brief reconnect) isn't mislabeled.
      this._heartbeatFailStreak++;
      const { reason, message } = classifyHeartbeatError(e);
      if (this._heartbeatFailures.fail()) {
        this._log(`${message} (consecutive failures: ${this._heartbeatFailStreak})`, 'warn');
      }
      if (this._heartbeatFailStreak >= HEARTBEAT_ERROR_THRESHOLD) {
        this._reportStatus(reason, message);
      }
    }
  }

  // ------------------------------------------------------------------
  // Control polling
  // ------------------------------------------------------------------

  /**
   * Advance `_lastControlId` past any pending control events for this agent
   * so we don't re-process them after a respawn. Without this, /restart
   * triggers a daemon bounce, the new adapter starts with _lastControlId=null,
   * polls and re-finds the same /restart event, bounces again — restart loop.
   */
  async _skipExistingControlEvents() {
    try {
      const events = await this.client.pollControl(
        this.workspaceId, this.agentName, this.token,
        { after: null }
      );
      if (events.length > 0) {
        // pollControl returns ascending-by-timestamp; take the latest.
        this._lastControlId = events[events.length - 1].id;
        this._log(`Skipped ${events.length} existing control event(s), cursor at ${this._lastControlId}`);
      }
    } catch {}
  }

  async _pollControl() {
    try {
      const events = await this._withinControlDeadline(
        this.client.pollControl(
          this.workspaceId, this.agentName, this.token,
          { after: this._lastControlId }
        ),
        this._CONTROL_POLL_DEADLINE_MS, 'control poll',
      );
      // A poll abandoned at its deadline delivered nothing; the cursor has
      // not moved, so the next one asks for the same events again.
      if (events === CONTROL_DEADLINE_HIT) return;
      for (const ev of events) {
        if (ev.id) this._lastControlId = ev.id;
        const payload = ev.payload || {};
        const action = payload.action;
        if (action === 'set_mode') {
          const newMode = payload.mode || 'execute';
          if ((newMode === 'execute' || newMode === 'plan') && newMode !== this._mode) {
            const oldMode = this._mode;
            this._mode = newMode;
            this._log(`Mode changed: ${oldMode} -> ${newMode}`);
          }
        } else if (action === 'stop') {
          // Handled here for every adapter, never by an override: a stop has
          // to stay inside the channel it names, and each adapter used to
          // decide that for itself — several stopped every channel.
          await this._withinControlDeadline(
            this._handleUserStop(payload.channel || null),
            this._CONTROL_ACTION_DEADLINE_MS, `stop for ${payload.channel || 'every channel'}`,
          );
        } else {
          await this._withinControlDeadline(
            this._onControlAction(action, payload),
            this._CONTROL_ACTION_DEADLINE_MS, `control action '${action}'`,
          );
        }
      }
      const recovered = this._controlFailures.succeed();
      if (recovered) {
        this._log(`Control poll recovered after ${recovered.count} unsuccessful attempt(s) over ${formatDuration(recovered.ms)}`);
      }
    } catch (e) {
      // Keep polling, but leave a trace: a control channel that keeps failing
      // means Stop and mode changes are not reaching this agent.
      if (this._controlFailures.fail()) {
        const count = this._controlFailures.count;
        const streak = count > 1 ? ` (consecutive failures: ${count})` : '';
        this._log(`Control poll failed: ${e && e.message}${streak}`, isTransientNetworkError(e) ? 'warn' : 'error');
      }
    }
  }

  /**
   * Await `work` for at most `ms`. Resolves to CONTROL_DEADLINE_HIT when the
   * deadline wins; `work` is left to finish, or not, on its own.
   */
  _withinControlDeadline(work, ms, what) {
    let timer;
    const deadline = new Promise((resolve) => {
      timer = setTimeout(() => {
        this._log(`Control poller: ${what} still pending after ${Math.round(ms / 1000)}s — polling on without it`, 'warn');
        resolve(CONTROL_DEADLINE_HIT);
      }, ms);
    });
    return Promise.race([
      Promise.resolve(work).finally(() => clearTimeout(timer)),
      deadline,
    ]);
  }

  /**
   * Record a user stop for `channel` — or for every channel when it is null,
   * which is how a workspace-wide stop arrives — and drop what is still
   * queued there. A stop ends the queued work; it does not defer it.
   */
  _markStopRequested(channel) {
    if (channel) {
      this._channelStopGeneration[channel] = (this._channelStopGeneration[channel] || 0) + 1;
      delete this._channelQueues[channel];
    } else {
      this._stopGeneration++;
      this._channelQueues = {};
    }
  }

  /** Stop generation for one channel; a channel-less stop counts for all. */
  _stopGenerationFor(channel) {
    return `${this._stopGeneration}:${this._channelStopGeneration[channel] || 0}`;
  }

  /**
   * True when a stop landed after the worker handed this channel its current
   * message. Adapters call this at their point of no return — the checks in
   * `_channelWorker` cover the queue, but `_handleMessage` then spends
   * several more HTTP round trips (session lookup, thinking status, pinned
   * knowledge, channel recap) before the CLI is touched, and a stop landing
   * inside those otherwise still reaches it.
   */
  _stopRequestedDuringTurn(channel) {
    const started = this._channelRunGeneration[channel];
    return started !== undefined && this._stopGenerationFor(channel) !== started;
  }

  /**
   * Stop what a user asked to stop, and nothing else.
   *
   * `channel` is the thread the Stop button was pressed in; the workspace
   * sends it for every participant agent. Only that channel's work is
   * touched — the same agent running in another thread carries on. A null
   * channel is the workspace-wide "stop everything" path.
   *
   * Order matters, and all of it is here so no adapter can get it wrong:
   *   1. record the stop and mute the channel before the first await, so
   *      workers and output parsers running during the teardown see it;
   *   2. let the adapter stop its work for that channel;
   *   3. cancel the stopped plan's todos (that posts the updated list);
   *   4. announce the stop last — the UI reads the latest message.
   */
  async _handleUserStop(channel) {
    const channels = channel ? [channel] : this._channelsWithWork();
    // A repeat stop for a thread that has not started a new turn since its
    // last stop — the workspace client re-sends Stop after 3s while it still
    // shows "Stopping…" — has nothing new to cancel. Moving the generation
    // again would only discard what the user typed after the first press.
    const repeat = !!channel && this._mutedChannels.has(channel);
    if (!repeat) this._markStopRequested(channel);
    for (const ch of channels) {
      this._mutedChannels.add(ch);
      this._stoppingChannels.add(ch);
    }
    if (!channel) {
      try { await this._stopSharedWork(); } catch (e) {
        this._log(`Stop: shared work did not stop cleanly: ${e && e.message ? e.message : e}`, 'warn');
      }
    }
    for (const ch of channels) {
      let outcome;
      try {
        outcome = await this._stopChannelWork(ch);
      } catch (e) {
        this._log(`Stop: ${ch} did not stop cleanly: ${e && e.message ? e.message : e}`, 'warn');
        outcome = 'failed';
      }
      // The pressed channel is always answered, so its UI settles even when
      // the agent had nothing running there. A workspace-wide stop only
      // speaks where it actually stopped something.
      if (outcome === 'idle' && ch !== channel) continue;
      await this._finishUserStop(ch, outcome === 'failed' ? 'failed' : 'stopped');
    }
  }

  /**
   * Channels with work a workspace-wide stop should end. Adapters that track
   * runs somewhere other than `_channelProcesses` extend this.
   */
  _channelsWithWork() {
    return [...new Set([...this._channelBusy, ...Object.keys(this._channelProcesses || {})])];
  }

  /**
   * Stop this adapter's work for ONE channel. Returns 'stopped' when
   * something was running, 'idle' when nothing was, 'failed' when the run
   * could not be confirmed dead. Must never touch another channel.
   *
   * The default covers every adapter that registers one child process per
   * channel in `_channelProcesses` and kills it with `_stopProcess`.
   * Adapters with other kinds of work (persistent processes, sockets, open
   * HTTP requests) override it, and call super for their child processes.
   */
  async _stopChannelWork(channel) {
    const procs = this._channelProcesses || {};
    const proc = procs[channel];
    if (!proc) return this._channelBusy.has(channel) ? 'stopped' : 'idle';
    this._log(`Stopping process for channel=${channel}`);
    const ended = typeof this._stopProcess === 'function'
      ? await this._stopProcess(proc)
      : undefined;
    delete procs[channel];
    // `_stopProcess` implementations that can tell return false for a kill
    // they could not confirm; the rest return nothing.
    return ended === false ? 'failed' : 'stopped';
  }

  /** Work shared by every channel, ended only by a workspace-wide stop. */
  async _stopSharedWork() {}

  /**
   * Close out a stopped channel: cancel its plan, then say so. Deduped per
   * channel until its next turn starts.
   */
  async _finishUserStop(channel, outcome = 'stopped') {
    if (!channel || this._stopNoticeSent.has(channel)) return;
    this._stopNoticeSent.add(channel);
    await this.cleanupTodos(channel);
    await this._announceUserStop(channel, outcome);
  }

  /**
   * Post the stop notice. Bypasses the mute on purpose — it is the one
   * message a stopped channel is meant to get.
   *
   * A plain message rather than a `status`: the workspace UI folds statuses
   * into the collapsed step list, and the user has to see that the stop took.
   * No `status_kind` either, which would push it as "<agent> finished".
   * Both wordings match the client's terminal-status regex
   * (/stopped|stopping failed/i).
   */
  async _announceUserStop(channel, outcome) {
    const content = this._stopNoticeText(outcome);
    try {
      await this.client.sendMessage(this.workspaceId, channel, this.token, content, {
        senderType: 'agent',
        senderName: this.agentName,
        metadata: { agent_mode: this._mode, stop_notice: true },
        sessionId: this._sessionId,
      });
    } catch (e) {
      if (e instanceof SessionRevokedError) this._onSessionRevoked();
    }
  }

  /**
   * The words of the stop notice. Override to tell the user something more
   * specific — both must keep matching /stopped|stopping failed/i.
   */
  _stopNoticeText(outcome) {
    return outcome === 'failed'
      ? (this._stopFailedMessage || 'Stopping failed — the agent process did not exit and may still be running.')
      : 'Execution stopped by user.';
  }

  /**
   * The check every adapter makes right before it starts its CLI, sends a
   * prompt, or opens a model request: did the user stop this turn while it
   * was still being prepared? Preparing takes several round trips (session
   * lookup, status post, pinned knowledge, recap), and a run started after
   * the stop spends tokens on an answer nobody will see.
   *
   * Returns true when the caller must give up without starting anything. The
   * stop has already been announced by `_handleUserStop`. The channel is
   * (re)marked as stopping because several adapters clear that flag only
   * after their own first await, which can run after the stop landed.
   */
  _stoppedBeforeStart(channel) {
    if (!this._stopRequestedDuringTurn(channel)) return false;
    this._stoppingChannels.add(channel);
    this._log(`Stop landed while preparing ${channel} — not starting the run`);
    return true;
  }

  /**
   * Last line of defence behind `_stoppedBeforeStart`: a child registered in
   * `_channelProcesses` for a turn that was stopped while it was being
   * prepared is killed on the spot, before it can reach the model. Covers any
   * adapter that misses the explicit check, including ones added later.
   */
  _onProcessRegistered(channel, proc) {
    if (!proc || typeof proc !== 'object' || typeof proc.on !== 'function') return;
    if (!this._stopRequestedDuringTurn(channel)) return;
    this._stoppingChannels.add(channel);
    this._log(`Stop landed before ${channel}'s run registered — killing it`);
    const kill = typeof this._stopProcess === 'function'
      ? this._stopProcess(proc)
      : Promise.resolve(proc.kill && proc.kill('SIGTERM'));
    Promise.resolve(kill).catch(() => {}).finally(() => {
      if (this._channelProcesses && this._channelProcesses[channel] === proc) {
        delete this._channelProcesses[channel];
      }
    });
  }

  /** True while a stopped channel is waiting for its next turn. */
  _isMuted(channel) {
    return !!channel && this._mutedChannels.has(channel);
  }

  /**
   * Handle adapter-specific control actions. Override in subclasses to add
   * per-adapter actions (`stop`, `restart`, …); always call
   * `await super._onControlAction(action, payload)` from the override for
   * actions you don't recognize, so shared actions like `status` keep
   * working uniformly across adapter types.
   */
  async _onControlAction(action, payload) {
    if (action === 'stop') {
      await this._handleUserStop((payload && payload.channel) || null);
    } else if (action === 'status') {
      await this._postStatusReport(payload);
    } else if (action === 'routines') {
      await this._postRoutinesReport(payload);
    } else if (action === 'skill.install') {
      await this._handleSkillInstall(payload);
    } else if (action === 'skill.uninstall') {
      await this._handleSkillUninstall(payload);
    } else if (action === 'model.set') {
      // Adapters read workspaceModel when (re)spawning their CLI; ones with
      // a staleness check (claude.js) respawn on the next message.
      this.workspaceModel = (payload && payload.model) || null;
      this._log(`Workspace model set to ${this.workspaceModel || '(default)'}`);
    }
  }

  /**
   * Install a Skill Hub catalog skill into this agent's local skills
   * directory, then report the result back to the workspace so the UI can
   * show installing → installed / failed. Errors are logged loudly and
   * surfaced as a `failed` status — never swallowed.
   *
   * payload: { action: "skill.install", skill: { id, name, source_repo, source_path } }
   */
  async _handleSkillInstall(payload) {
    const installer = require('../skill-installer');
    const skill = (payload && payload.skill) || null;
    const skillId = skill && (skill.id || skill.skill_id);
    const reportSkillId = skill && (skill.registry_skill_id || skill.registrySkillId) || skillId;
    const versionId = skill && (skill.version_id || skill.versionId);
    if (!skillId) {
      this._log('skill.install: missing skill metadata in payload — ignoring');
      return;
    }
    this._log(`skill.install: starting install of "${skillId}" (type=${this.agentType}, dir=${this.workingDir || defaultAgentWorkdir(this.agentName)})`);

    // Best-effort "installing" ping so the UI flips immediately even if the
    // initial DB write from the request hasn't propagated to this client.
    try {
      await this.client.reportSkillStatus(this.workspaceId, this.agentName, this.token, {
        skillId: reportSkillId, state: 'installing', versionId,
      });
    } catch (e) {
      this._log(`skill.install: could not report 'installing' (non-fatal): ${e && e.message ? e.message : e}`, 'warn');
    }

    try {
      // Custom (uploaded) skills carry source_type=workspace_file + a file_id.
      // Download the package bytes here (async), then hand them to the sync
      // installer. Catalog skills keep their existing fetch-by-source path.
      const sourceType = skill && (skill.source_type || skill.sourceType);
      let result;
      if (sourceType === 'workspace_file') {
        const fileId = skill.file_id || skill.fileId;
        if (!fileId) throw new Error('workspace_file skill is missing file_id');
        this._log(`skill.install: downloading uploaded package (file_id=${fileId})`);
        const buffer = await this.client.readFile(this.workspaceId, this.token, fileId);
        if (!buffer || buffer.length === 0) throw new Error('uploaded skill file is empty');
        result = installer.installUploadedSkill({
          skill, buffer,
          agentType: this.agentType,
          workingDir: this.workingDir,
          log: (m) => this._log(`skill.install: ${m}`),
        });
      } else if (sourceType === 'registry') {
        if (!versionId) throw new Error('registry skill is missing version_id');
        this._log(`skill.install: downloading registry version ${versionId}`);
        const buffer = await this.client.readRegistryVersion(versionId, this.token);
        if (!buffer || buffer.length === 0) throw new Error('registry artifact is empty');
        const expected = skill.content_sha256 || skill.contentSha256;
        const actual = crypto.createHash('sha256').update(buffer).digest('hex');
        if (!expected || actual !== expected) {
          throw new Error(`registry artifact sha256 mismatch (expected ${expected || 'missing'}, got ${actual})`);
        }
        result = installer.installUploadedSkill({
          skill, buffer,
          agentType: this.agentType,
          workingDir: this.workingDir,
          log: (m) => this._log(`skill.install: ${m}`),
        });
      } else {
        result = installer.installSkill({
          skill,
          agentType: this.agentType,
          workingDir: this.workingDir,
          log: (m) => this._log(`skill.install: ${m}`),
        });
      }
      try {
        await this.client.reportSkillStatus(this.workspaceId, this.agentName, this.token, {
          skillId: reportSkillId, state: 'installed', path: result.path,
          partial: result.partial === true, versionId,
        });
      } catch (e) {
        this._log(`skill.install: installed on disk but failed to report 'installed': ${e && e.message ? e.message : e}`, 'warn');
      }
      this._log(`skill.install: SUCCESS "${skillId}" → ${result.path}${result.partial ? ' (partial)' : ''}`);
      await this._onSkillsChanged();
    } catch (e) {
      const msg = e && e.message ? e.message : String(e);
      this._log(`skill.install: FAILED "${skillId}": ${msg}`, 'error');
      try {
        await this.client.reportSkillStatus(this.workspaceId, this.agentName, this.token, {
          skillId: reportSkillId, state: 'failed', error: msg, versionId,
        });
      } catch (e2) {
        this._log(`skill.install: also failed to report 'failed': ${e2 && e2.message ? e2.message : e2}`, 'warn');
      }
    }
  }

  /**
   * Remove a previously-installed skill from disk and report `uninstalled`.
   */
  async _handleSkillUninstall(payload) {
    const installer = require('../skill-installer');
    const skill = (payload && payload.skill) || null;
    const skillId = skill && (skill.id || skill.skill_id);
    const reportSkillId = skill && (skill.registry_skill_id || skill.registrySkillId) || skillId;
    if (!skillId) {
      this._log('skill.uninstall: missing skill metadata in payload — ignoring');
      return;
    }
    try {
      const result = installer.uninstallSkill({
        skill,
        agentType: this.agentType,
        workingDir: this.workingDir,
        log: (m) => this._log(`skill.uninstall: ${m}`),
      });
      this._log(`skill.uninstall: "${skillId}" removed=${result.removed}`);
      try {
        await this.client.reportSkillStatus(this.workspaceId, this.agentName, this.token, {
          skillId: reportSkillId, state: 'uninstalled',
        });
      } catch (e) {
        this._log(`skill.uninstall: failed to report status: ${e && e.message ? e.message : e}`, 'warn');
      }
      await this._onSkillsChanged();
    } catch (e) {
      const msg = e && e.message ? e.message : String(e);
      this._log(`skill.uninstall: FAILED "${skillId}": ${msg}`, 'error');
    }
  }

  /**
   * Hook for subclasses to react to a change in the installed-skills set
   * (e.g. rebuild prompt context). Default: no-op.
   */
  async _onSkillsChanged() {}

  /**
   * Post a chat message back to the requesting channel summarizing agent
   * name, type, agent-launcher version, uptime, and network. Used by the
   * `/status` slash command.
   */
  async _postStatusReport(payload) {
    const channel = (payload && typeof payload === 'object') ? payload.channel : null;
    if (!channel) return;

    let pkgVersion = 'unknown';
    try {
      const path = require('path');
      const pkg = require(path.join(__dirname, '..', '..', 'package.json'));
      pkgVersion = pkg.version || 'unknown';
    } catch {}

    const uptimeMs = Math.max(0, Date.now() - this._startedAt);
    const totalSec = Math.floor(uptimeMs / 1000);
    const days = Math.floor(totalSec / 86400);
    const hours = Math.floor((totalSec % 86400) / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = totalSec % 60;
    let uptime;
    if (days > 0) uptime = `${days}d ${hours}h ${minutes}m`;
    else if (hours > 0) uptime = `${hours}h ${minutes}m`;
    else if (minutes > 0) uptime = `${minutes}m ${seconds}s`;
    else uptime = `${seconds}s`;

    const adapterType = this.agentType || 'unknown';
    const content =
      `**Agent status**\n` +
      `- Name: \`${this.agentName}\` (${adapterType})\n` +
      `- Version: agent-launcher \`${pkgVersion}\`\n` +
      `- Uptime: ${uptime}\n` +
      `- Network: \`${this.workspaceId}\``;

    try {
      await this.client.sendMessage(this.workspaceId, channel, this.token, content, {
        senderType: 'agent',
        senderName: this.agentName,
        messageType: 'chat',
        metadata: { agent_mode: this._mode },
        sessionId: this._sessionId,
      });
    } catch (e) {
      this._log(`Status: failed to post: ${e && e.message ? e.message : e}`, 'warn');
    }
  }

  /**
   * Post a markdown table of the agent's routines (active and paused) back
   * to the requesting channel. Used by the `/routines` slash command. Each agent
   * reports only routines it owns (created_by === openagents:<agentName>)
   * so the user sees a clear "my routines" view per agent, mirroring how
   * /status reports per-agent uptime.
   */
  async _postRoutinesReport(payload) {
    const channel = (payload && typeof payload === 'object') ? payload.channel : null;
    if (!channel) return;

    let routines = [];
    try {
      const data = await this.client.listRoutines(this.workspaceId, channel, this.token);
      // Accept both the canonical `openagents:<name>` source and the bare
      // `<name>` form. Agents that follow the workspace prompt verbatim
      // produce the prefixed form, but some agents send the bare name when
      // they construct the POST body themselves.
      const prefixed = `openagents:${this.agentName}`;
      routines = ((data && data.routines) || []).filter(
        (r) => r.created_by === prefixed || r.created_by === this.agentName,
      );
    } catch (e) {
      this._log(`Routines: failed to list: ${e && e.message ? e.message : e}`, 'warn');
      try {
        await this.client.sendMessage(
          this.workspaceId, channel, this.token,
          `**Routines for \`${this.agentName}\`**\n\n_Failed to fetch routines._`,
          { senderType: 'agent', senderName: this.agentName, messageType: 'chat', sessionId: this._sessionId },
        );
      } catch {}
      return;
    }

    let content;
    if (!routines.length) {
      content = `**Routines for \`${this.agentName}\`**\n\n_No routines._`;
    } else {
      const rows = routines.map((r) => {
        const schedule = (r.schedule_interval_minutes != null)
          ? `every ${r.schedule_interval_minutes} min`
          : `${String(r.schedule_hour ?? 0).padStart(2, '0')}:${String(r.schedule_minute ?? 0).padStart(2, '0')} UTC` +
            (r.schedule_days ? ` (days [${r.schedule_days.join(',')}])` : ' daily');
        // A paused routine keeps its last next_fires_at, which is stale (often
        // in the past) — show that it's paused instead of a time it won't fire.
        const paused = r.status && r.status !== 'active';
        const next = paused ? '—' : (r.next_fires_at || '—');
        const name = String(r.name || '').replace(/\|/g, '\\|') + (paused ? ` [${r.status}]` : '');
        const id = String(r.id || '').slice(0, 8);
        return `| \`${id}\` | ${name} | ${schedule} | ${next} |`;
      });
      content =
        `**Routines for \`${this.agentName}\`** (${routines.length})\n\n` +
        '| ID | Name | Schedule | Next fires |\n' +
        '|---|---|---|---|\n' +
        rows.join('\n');
    }

    try {
      await this.client.sendMessage(this.workspaceId, channel, this.token, content, {
        senderType: 'agent',
        senderName: this.agentName,
        messageType: 'chat',
        metadata: { agent_mode: this._mode },
        sessionId: this._sessionId,
      });
    } catch (e) {
      this._log(`Routines: failed to post: ${e && e.message ? e.message : e}`, 'warn');
    }
  }

  _hasActiveWork() {
    return this._channelBusy.size > 0;
  }

  _controlPollDelayMs() {
    return this._hasActiveWork() ? 250 : 2000;
  }

  _wakeControlPoller() {
    if (this._controlWake) {
      this._controlWake();
      this._controlWake = null;
    }
  }

  async _sleepUntilControlPollDue(delayMs) {
    await new Promise((resolve) => {
      const timeout = setTimeout(resolve, delayMs);
      this._controlWake = () => {
        clearTimeout(timeout);
        resolve();
      };
    });
    this._controlWake = null;
  }

  async _controlPollerLoop() {
    while (this._running) {
      await this._pollControl();
      if (!this._running) break;
      await this._sleepUntilControlPollDue(this._controlPollDelayMs());
    }
  }

  // ------------------------------------------------------------------
  // Poll loop
  // ------------------------------------------------------------------

  async _pollLoop() {
    let idleCount = 0;
    let pollCount = 0;

    while (this._running) {
      pollCount++;
      let messages, rawCursor, composingActive = false;
      try {
        const result = await this.client.pollPending(
          this.workspaceId, this.agentName, this.token,
          { after: this._lastEventId }
        );
        messages = result.messages;
        rawCursor = result.cursor;
        composingActive = !!result.composing;
        this._pollAuthFailStreak = 0;
        const recovered = this._pollFailures.succeed();
        if (recovered) {
          this._log(`Poll recovered after ${recovered.count} unsuccessful attempt(s) over ${formatDuration(recovered.ms)}`);
        }
        if (pollCount <= 3 || pollCount % 20 === 0) {
          this._log(`Poll #${pollCount}: ${messages.length} messages, cursor=${rawCursor || 'none'}${composingActive ? ' composing' : ''}`);
        }
      } catch (e) {
        // A workspace that is down or slow fails every poll until it is back;
        // log the streak, not every attempt (see failure-streak.js).
        if (this._pollFailures.fail()) {
          const count = this._pollFailures.count;
          const streak = count > 1 ? ` (consecutive failures: ${count})` : '';
          if (isTransientNetworkError(e)) {
            this._log(`Poll #${pollCount} failed: ${e.message}${streak} — retrying every 5s`, 'warn');
          } else {
            const stack = count === 1 && e && e.stack ? `\nStack: ${e.stack}` : '';
            this._log(`Poll #${pollCount} failed: ${e && e.message}${streak}${stack}`, 'error');
          }
        }
        // A rejected credential never heals by retrying with the same token —
        // it means the device was re-paired/unpaired and this adapter is
        // running on a revoked one. After a few consecutive rejections (not
        // one: a server redeploy can 401 transiently), surface a hard error
        // so status/heartbeat stop claiming "running" while nothing works.
        // The daemon's credential watch restarts the adapter when a fresh
        // token lands on disk, which also clears this state.
        const sc = httpStatusOf(e);
        if (sc === 401 || sc === 403 || /invalid workspace credentials/i.test(e.message || '')) {
          this._pollAuthFailStreak = (this._pollAuthFailStreak || 0) + 1;
          if (this._pollAuthFailStreak >= 3) {
            this._reportStatus(
              REASON.WORKSPACE_JOIN_FAILED,
              'Workspace rejected this agent\'s credentials — re-pair the device or reconnect the agent to the workspace',
            );
          }
        }
        await this._sleep(5000);
        continue;
      }

      // The cursor stops moving (or none comes back) only once the poll has
      // reached the end of the stream. An empty `messages` alone does not say
      // that: it is the page after events for other agents were dropped.
      const caughtUp = !rawCursor || rawCursor === this._lastEventId;
      if (rawCursor) {
        this._lastEventId = rawCursor;
        this._persistCursor(rawCursor);
      }
      // Only the first poll after resuming from a persisted cursor is a
      // replay; later polls carry live traffic and are never age-filtered
      // (a skewed local clock must not make a live agent go deaf).
      const isReplay = this._resumedFromCursor || this._unanchored;
      this._resumedFromCursor = false;
      if (caughtUp) this._unanchored = false;
      const staleByChannel = {};

      // Deduplicate
      const incoming = [];
      for (const msg of messages) {
        const msgId = msg.id || msg.messageId;
        if (msgId && this._processedIds.has(msgId)) continue;
        if (msg.messageType === 'status') continue;
        if (isReplay && this._isStaleMessage(msg)) {
          if (msgId) this._processedIds.add(msgId);
          const ch = msg.sessionId || this.channelName || 'general';
          staleByChannel[ch] = (staleByChannel[ch] || 0) + 1;
          continue;
        }
        // Handle queue cancellation signals from frontend
        if (msg.messageType === 'queue_cancel') {
          if (msgId) this._processedIds.add(msgId);
          const channel = msg.sessionId || this.channelName || 'general';
          const queueId = msg.metadata?.queue_id || (msg.content || '').replace('__queue_cancel:', '');
          if (queueId) this._cancelQueuedMessage(channel, queueId);
          continue;
        }
        incoming.push(msg);
      }

      for (const [ch, n] of Object.entries(staleByChannel)) {
        const mins = Math.round(STALE_MESSAGE_MAX_AGE_MS / 60000);
        this._log(`Skipped ${n} stale message(s) in ${ch} (older than ${mins} min, arrived while this agent was offline)`);
        try {
          await this.sendStatus(ch, `Skipped ${n} message(s) sent more than ${mins} minutes ago while this agent was offline — resend if still needed.`);
        } catch {}
      }
      if (isReplay && incoming.length > 0) {
        this._log(`Replaying ${incoming.length} message(s) that arrived while this agent was offline`);
      }

      if (incoming.length > 0) {
        idleCount = 0;
        for (const msg of incoming) {
          const msgId = msg.id || msg.messageId;
          if (msgId) this._processedIds.add(msgId);
          await this._dispatchMessage(msg);
        }
        // Cap dedup set
        if (this._processedIds.size > 2000) {
          const arr = [...this._processedIds];
          this._processedIds.clear();
          for (const id of arr.slice(-1000)) this._processedIds.add(id);
        }
      } else {
        idleCount++;
      }

      // Adaptive polling with warm plateau:
      //   Active (messages incoming):  2s
      //   Warm (≤5 min since last msg): 5s
      //   Cooldown (5-7 min):          5s → 15s (ramp 1s per idle poll)
      //   Cold (>7 min):              15s
      // The warm plateau keeps the agent responsive during typical user
      // think-time between messages without hammering the backend.
      const WARM_INTERVAL = 5000;
      const WARM_POLLS = 60;  // 60 × 5s = 5 minutes warm plateau
      let delay;
      if (incoming.length > 0) {
        delay = 2000;
      } else if (composingActive) {
        delay = 2000;
        idleCount = Math.min(idleCount, WARM_POLLS);
      } else if (idleCount <= WARM_POLLS) {
        delay = WARM_INTERVAL;
      } else {
        delay = Math.min(WARM_INTERVAL + (idleCount - WARM_POLLS) * 1000, 15000);
      }
      await this._sleep(delay);
    }
  }

  // ------------------------------------------------------------------
  // Channel dispatch
  // ------------------------------------------------------------------

  async _dispatchMessage(msg) {
    // Use sessionId only if it looks like a channel, not an agent target
    let channel = this.channelName || 'general';
    if (msg.sessionId && !msg.sessionId.startsWith('openagents:') && !msg.sessionId.startsWith('agent:')) {
      channel = msg.sessionId;
    }

    if (this._channelBusy.has(channel)) {
      // A routine that's already running must not stack up. Routine fires are
      // periodic, so a fire that arrives while the previous run is still going
      // is simply dropped — the next scheduled tick re-fires once the agent is
      // free. (The backend guard normally prevents this from even being sent;
      // this is the last line of defense against a queue backlog.)
      if (msg.senderName === 'system:routine') {
        this._log(`Skipping routine fire in ${channel} — previous run still in progress`);
        return;
      }
      if (!this._channelQueues[channel]) this._channelQueues[channel] = [];
      const queueId = `q-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      msg._queueId = queueId;
      msg._acceptedGeneration = this._stopGenerationFor(channel);
      this._channelQueues[channel].push(msg);
      this._schedulePresenceHeartbeat();
      try {
        await this.sendStatus(channel, 'message queued — will process after current task', {
          queued_message: (msg.content || '').slice(0, 200),
          queue_id: queueId,
        });
      } catch {}
      return;
    }

    // A message belongs to the stop generation it arrived in. One accepted
    // before a stop never runs after it; one that arrives after the stop — the
    // user typing again while the stopped run is still winding down — does.
    msg._acceptedGeneration = this._stopGenerationFor(channel);
    // Run channel worker (don't await — parallel execution)
    this._channelWorker(channel, msg);
    this._wakeControlPoller();
  }

  _cancelQueuedMessage(channel, queueId) {
    const queue = this._channelQueues[channel];
    if (!queue) return false;
    const idx = queue.findIndex((m) => m._queueId === queueId);
    if (idx === -1) return false;
    queue.splice(idx, 1);
    this._log(`Cancelled queued message ${queueId} in ${channel}`);
    return true;
  }

  async _channelWorker(channel, msg) {
    this._channelBusy.add(channel);
    this._schedulePresenceHeartbeat();
    // Messages an adapter queues for itself (Claude's todo nudge) carry no
    // generation; they belong to the turn that queued them.
    const startGeneration = msg._acceptedGeneration !== undefined
      ? msg._acceptedGeneration
      : this._stopGenerationFor(channel);
    const generationOf = (m) => (m._acceptedGeneration !== undefined ? m._acceptedGeneration : startGeneration);
    let dropped = 0;

    let next = msg;
    let first = true;
    while (next) {
      const current = next;
      const generation = generationOf(current);
      try {
        if (!first && current._queueId && generation === this._stopGenerationFor(channel)) {
          try { await this.sendStatus(channel, 'processing queued message', { queue_id: current._queueId, queue_status: 'processed' }); } catch {}
        }
        // Pinned entries may have changed while this message waited.
        await this._prefetchPinnedContext(channel);
        this._channelRequestContent[channel] = current.originalContent ?? current.content;
        if (channel && !channel.startsWith('dm:') && current.messageId
            && typeof this.client?.getRecentMessages === 'function') {
          await this._applyThreadHistory(channel, current);
        }
        // A teammate's request runs under the owner-reviewed shared
        // instructions (v1.1 M4); the block is prepended to the message.
        // Gated synchronously so messages it cannot apply to (agents,
        // anonymous humans, system) add no extra tick before the stop check.
        this._applyThreadCollaboration(channel, current);
        if (this._sharedContextCandidate(current)) await this._applySharedContext(channel, current);
        // Checked after the round trips above, which a stop can land inside:
        // a message from before the stop never reaches the CLI.
        if (generation !== this._stopGenerationFor(channel)) {
          dropped++;
        } else {
          this._channelRunGeneration[channel] = generation;
          // A turn the user asked for after the stop speaks normally again.
          this._mutedChannels.delete(channel);
          this._stopNoticeSent.delete(channel);
          this._stoppingChannels.delete(channel);
          this._channelTriggerId[channel] = current.messageId || null;
          await this._handleMessage(current);
        }
      } catch (e) {
        this._log(`Error ${first ? 'in channel worker' : 'processing queued message'} for ${channel}: ${e.message}`, 'error');
        try { await this.sendError(channel, `Agent error: ${this._redact(e.message)}`); } catch {}
      }
      delete this._channelRunGeneration[channel];
      delete this._channelRequestContent[channel];
      delete this._channelTriggerId[channel];
      first = false;

      const queue = this._channelQueues[channel];
      next = queue && queue.length ? queue.shift() : null;
    }
    if (dropped) this._log(`Stop in ${channel} — dropped ${dropped} message(s) accepted before it`);
    this._channelBusy.delete(channel);
    delete this._requesterEmail[channel];
    this._schedulePresenceHeartbeat();
  }

  // ------------------------------------------------------------------
  // Shared context for teammates' requests (v1.1 M4)
  // ------------------------------------------------------------------

  /** The email of the person whose request this channel is running, if known. */
  requesterEmailFor(channel) {
    return this._requesterEmail[channel] || null;
  }

  /**
   * Fetch (cached 60s per channel + requester) the owner-reviewed shared
   * context for this run. Returns the /shared-context payload or null.
   */
  async _fetchSharedContext(channel, requesterEmail) {
    const cached = this._sharedContext[channel];
    const now = Date.now();
    if (cached && cached.requesterEmail === requesterEmail && (now - cached.fetchedAt) < SHARED_CONTEXT_TTL_MS) {
      return cached.ctx;
    }
    if (!this.client || typeof this.client.getSharedContext !== 'function') return null;
    try {
      const ctx = await this.client.getSharedContext(this.workspaceId, this.token, this.agentName, {
        requesterEmail, channel,
      });
      this._sharedContext[channel] = { fetchedAt: now, requesterEmail, ctx };
      return ctx;
    } catch (e) {
      this._log(`Shared-context fetch failed (${e && e.message ? e.message : e}) — running without it`);
      // Keep a stale-but-recent answer rather than flip-flopping on a blip.
      return cached && cached.requesterEmail === requesterEmail ? cached.ctx : null;
    }
  }

  /**
   * When the triggering message comes from an identified person, look up the
   * shared context and, if it applies, prepend the instruction block to the
   * message the adapter will turn into its prompt. Records the requester for
   * the per-run MCP server. Never throws.
   */
  _sharedContextEmail(msg) {
    if (!msg) return null;
    const continuation = msg.senderType === 'agent' && msg.metadata?.orchestration?.action === 'next';
    if (msg.senderType !== 'human' && !continuation) return null;
    // Continuations retain the authenticated original requester so the next
    // agent applies the same owner-reviewed shared context and tool identity.
    const raw = continuation ? (msg.metadata.requester_email || '')
      : (msg.senderEmail || (msg.metadata && msg.metadata.sender_email) || '');
    const email = String(raw).trim().toLowerCase();
    return email && email.includes('@') ? email : null;
  }

  _sharedContextCandidate(msg) {
    return this._sharedContextEmail(msg) !== null;
  }

  _applyThreadCollaboration(channel, msg) {
    if (msg._threadCollaborationApplied || !channel || channel.startsWith('dm:')) return;
    const instructions = msg.metadata?.thread_agent_instructions?.[this.agentName];
    if (typeof instructions !== 'string' || !instructions.trim()) return;
    if (msg.originalContent === undefined) msg.originalContent = msg.content;
    msg.content = `COLLABORATION INSTRUCTIONS FOR THIS THREAD ONLY (do not carry these into other threads; existing owner restrictions still apply):\n${instructions.slice(0, 10000)}\nEND THREAD INSTRUCTIONS\n\n${msg.content || ''}`;
    msg._threadCollaborationApplied = true;
  }

  async _applySharedContext(channel, msg) {
    const email = this._sharedContextEmail(msg);
    if (!email) return false;
    this._requesterEmail[channel] = email;
    if (msg._sharedContextApplied) return true;
    const ctx = await this._fetchSharedContext(channel, email);
    const block = buildSharedContextBlock(ctx);
    if (!block) return false;
    if (msg.originalContent === undefined) msg.originalContent = msg.content;
    msg.content = block + '\n' + (msg.content || '');
    msg._sharedContextApplied = true;
    this._log(`Shared context applied for ${email} in ${channel} (owner: ${ctx.owner_email || '?'})`);
    return true;
  }

  async _applyThreadHistory(channel, msg) {
    // DMs have separate peer sessions. Synthetic nudges have no event boundary.
    if (!channel || channel.startsWith('dm:') || !msg.messageId || msg._threadHistoryApplied) return;
    if (typeof this.client?.getRecentMessages !== 'function') return;
    try {
      const messages = await this.client.getRecentMessages(this.workspaceId, channel, this.token, 100, {
        before: msg.messageId, timeout: 5000, throwOnError: true,
      });
      const block = buildThreadHistory(messages, channel, msg);
      if (!block) return;
      if (msg.originalContent === undefined) msg.originalContent = msg.content;
      msg.content = block + (msg.content || '');
      msg._threadHistoryApplied = true;
    } catch (e) {
      this._log(`Recent thread history unavailable for ${channel}: ${e.message}`);
    }
  }

  // ------------------------------------------------------------------
  // Knowledge pinning (glossary)
  // ------------------------------------------------------------------

  /**
   * Read one pinned knowledge entry with a short per-request deadline
   * (worst case one list + one get, ~2x that budget). `titles` is tried in
   * precedence order against a single listing; `cache` maps channel → entry
   * id. Returns { available, state, entryId, content, error }:
   * - available=false  → knowledge module disabled, pinning inactive
   * - state 'found'    → the entry exists (entryId set; content null when a
   *                      transient error hid it this turn)
   * - state 'absent'   → a successful listing confirmed no entry exists
   * - state 'unknown'  → fetch failed before existence could be confirmed;
   *                      the prompt must NOT claim the entry is missing, or a
   *                      recovered network mid-turn produces a duplicate
   * - error=true       → transient failure; callers must NOT treat this as
   *                      "entry changed/empty"
   * The matched entry id is cached per channel so the steady state is a
   * single GET; a 404 or a soft-deleted entry (the backend keeps deleted
   * rows readable by id with status "deleted") invalidates the cache and
   * falls back to list+match, which only sees active entries.
   */
  async _fetchPinnedEntry(channel, titles, cache, label) {
    if ((this.disabledModules || new Set()).has('knowledge')) {
      if (!this._warnedKnowledgeDisabled) {
        this._warnedKnowledgeDisabled = true;
        this._log(
          'Knowledge module is disabled — glossary pinning is INACTIVE.'
        );
      }
      if (!this._pinnedStatusWarned.has(channel)) {
        this._pinnedStatusWarned.add(channel);
        try {
          await this.sendStatus(
            channel,
            'Glossary pinning inactive: the knowledge module is disabled for ' +
            'this agent, so the shared glossary cannot be pinned across ' +
            'session resets.'
          );
        } catch {}
      }
      return { available: false, state: 'unknown', entryId: null, title: null, content: null, error: false };
    }

    const timeout = this._DECISION_FETCH_TIMEOUT_MS;
    // Only highest-precedence matches are ever cached (see below), so a
    // cached id always belongs to titles[0].
    const cachedId = cache[channel];
    if (cachedId) {
      try {
        const entry = await this.client.getKnowledge(this.workspaceId, this.token, cachedId, { timeout });
        if (entry && entry.status && entry.status !== 'active') {
          // Soft-deleted: still served by id, but dead for updates.
          delete cache[channel];
          // Fall through to list+match below.
        } else if (entry && typeof entry.title === 'string' && entry.title !== titles[0]) {
          // Renamed (e.g. archived): the id no longer owns the canonical
          // title, so the pin must re-resolve — a fallback or a replacement
          // entry has to win over the stale cache.
          delete cache[channel];
          // Fall through to list+match below.
        } else {
          return { available: true, state: 'found', entryId: cachedId, title: titles[0], content: (entry && entry.content) || '', error: false };
        }
      } catch (e) {
        if (/not found|HTTP 404/i.test(e.message || '')) {
          delete cache[channel];
          // Entry is gone — fall through to list+match below.
        } else {
          this._log(`${label} read failed (${e.message}) — reusing last known state`, 'warn');
          return { available: true, state: 'found', entryId: cachedId, title: titles[0], content: null, error: true };
        }
      }
    }

    try {
      const data = await this.client.listKnowledge(this.workspaceId, this.token, { limit: 500, timeout });
      const entries = (data && data.entries) || [];
      let entry = null;
      let matchedTitle = null;
      for (const title of titles) {
        const picked = pickEntryByTitle(entries, title);
        if (picked.duplicates > 0) {
          this._log(
            `${label} WARNING for ${channel} — ${picked.duplicates + 1} knowledge entries share the title ` +
            `"${title}"; using the earliest. The duplicates should be merged manually.`
          );
        }
        if (picked.entry) { entry = picked.entry; matchedTitle = title; break; }
      }
      if (!entry) return { available: true, state: 'absent', entryId: null, title: null, content: null, error: false };
      // Cache ONLY a highest-precedence match. Caching a fallback (e.g. the
      // workspace glossary) under the channel key would let the cached-id
      // fast path skip the precedence check forever, permanently masking a
      // channel-specific entry created later. Fallback users pay one extra
      // list per message instead.
      if (matchedTitle === titles[0]) cache[channel] = entry.id;
      const full = await this.client.getKnowledge(this.workspaceId, this.token, entry.id, { timeout });
      if (full && full.status && full.status !== 'active') {
        // Deleted between the listing and the read.
        delete cache[channel];
        return { available: true, state: 'absent', entryId: null, title: null, content: null, error: false };
      }
      return { available: true, state: 'found', entryId: entry.id, title: matchedTitle, content: (full && full.content) || '', error: false };
    } catch (e) {
      this._log(`${label} fetch failed (${e.message}) — reusing last known state`, 'warn');
      const knownId = cache[channel] || null;
      return { available: true, state: knownId ? 'found' : 'unknown', entryId: knownId, title: knownId ? titles[0] : null, content: null, error: true };
    }
  }

  /**
   * Read the channel's glossary — the channel-specific entry when it exists,
   * else the workspace-wide fallback. See _fetchPinnedEntry for the contract.
   * The result carries scope 'channel' | 'workspace' (null when not found)
   * so prompts can treat the shared fallback as read-only.
   */
  async _fetchGlossary(channel) {
    const res = await this._fetchPinnedEntry(
      channel,
      [glossaryTitle(channel), WORKSPACE_GLOSSARY_TITLE],
      this._glossaryEntryIds,
      'Glossary'
    );
    res.scope = res.title === WORKSPACE_GLOSSARY_TITLE ? 'workspace'
      : res.title ? 'channel' : null;
    return res;
  }

  /** Fetch everything pinnable for a channel: { glossary }. */
  async _fetchPinnedContext(channel) {
    const glossary = await this._fetchGlossary(channel);
    return { glossary };
  }

  /**
   * Refresh the pinned context ahead of _handleMessage for adapters that
   * opted in (_usesPinnedContext). A transient read failure must not wipe
   * the last successful pin — prompt-per-turn adapters would lose the
   * authoritative definitions for that turn — so an errored entry keeps the
   * previous good result; a thrown fetch keeps the previous context whole.
   */
  async _prefetchPinnedContext(channel) {
    if (!this._usesPinnedContext) return;
    try {
      const fresh = await this._fetchPinnedContext(channel);
      const prev = this._pinnedContext[channel];
      if (prev) {
        if (fresh.glossary && fresh.glossary.error && prev.glossary && !prev.glossary.error) {
          fresh.glossary = prev.glossary;
        }
      }
      this._pinnedContext[channel] = fresh;
    } catch (e) {
      this._log(`Pinned-context fetch failed (${e && e.message ? e.message : e}) — reusing the last pinned context`, 'warn');
    }
  }

  /**
   * Prompt-builder options ({ glossary }) derived from the last
   * prefetch for the channel. Sync, so prompt builders can call it inline;
   * returns {} when nothing was prefetched or nothing is usable.
   */
  pinnedPromptOpts(channel) {
    const ctx = this._pinnedContext[channel];
    if (!ctx) return {};
    const opts = {};
    const g = ctx.glossary;
    if (g && g.available && g.state === 'found' && g.content) {
      opts.glossary = { enabled: true, entryId: g.entryId, content: g.content, scope: g.scope || 'channel' };
    }
    return opts;
  }

  // ------------------------------------------------------------------
  // Auto-title helper
  // ------------------------------------------------------------------

  async _autoTitleChannel(channel, content) {
    if (this._titledSessions.has(channel)) return;
    this._titledSessions.add(channel);
    const title = generateSessionTitle(this._channelRequestContent[channel] ?? content);
    if (!title) return;
    try {
      const info = await this.client.getSession(this.workspaceId, channel, this.token);
      if (!info.titleManuallySet && SESSION_DEFAULT_RE.test(info.title || '')) {
        await this.client.updateSession(
          this.workspaceId, channel, this.token,
          { title, autoTitle: true }
        );
        this._log(`Auto-titled channel: ${title}`);
      }
    } catch (e) {
      this._log(`Failed to auto-title channel: ${e.message}`, 'warn');
    }
  }

  // ------------------------------------------------------------------
  // Message helpers
  // ------------------------------------------------------------------

  async sendStatus(channel, content, extraMeta) {
    if (this._isMuted(channel)) return;
    try {
      await this.client.sendMessage(this.workspaceId, channel, this.token, content, {
        senderType: 'agent',
        senderName: this.agentName,
        messageType: 'status',
        metadata: { agent_mode: this._mode, ...extraMeta },
        sessionId: this._sessionId,
      });
    } catch (e) {
      if (e instanceof SessionRevokedError) this._onSessionRevoked();
    }
  }

  async sendThinking(channel, content) {
    // Skip empty thinking traces entirely.
    if (!content || !content.trim()) return;
    if (this._isMuted(channel)) return;
    try {
      await this.client.sendMessage(this.workspaceId, channel, this.token, content, {
        senderType: 'agent',
        senderName: this.agentName,
        messageType: 'thinking',
        metadata: { agent_mode: this._mode },
        sessionId: this._sessionId,
      });
    } catch (e) {
      if (e instanceof SessionRevokedError) this._onSessionRevoked();
    }
  }

  /**
   * Post the agent's answer for a turn — the last thing said before control
   * returns to the user.
   *
   * `status_kind: 'completed'` marks it as exactly that. The backend's push
   * fan-out (workspace/backend/app/services/push.py) reads the field and
   * notifies under the user's "task completions" switch instead of the
   * "all messages" firehose, which is off by default. It has to be a
   * structured field: an earlier attempt matched the word "completed" in the
   * message text and fired on every bash for-loop that ended in `done`.
   */
  async sendResponse(channel, content, { statusKind = 'completed' } = {}) {
    if (this._isMuted(channel)) return;
    try {
      await this._replyOutbox().enqueue({
        channel, content,
        metadata: { status_kind: statusKind, ...(this._channelTriggerId?.[channel] ? { in_reply_to: this._channelTriggerId[channel] } : {}) },
      });
    } catch (e) {
      this._log('Could not save or deliver the final reply; check the local response outbox and disk permissions.', 'error');
      throw e;
    }
  }

  _replyOutbox() {
    if (!this._responseOutbox) this._responseOutbox = new ResponseOutbox({
      endpoint: this.endpoint, workspaceId: this.workspaceId, agentName: this.agentName,
      directory: this._responseOutboxDirectory,
      log: (message, level) => this._log(message, level),
      onRevoked: () => this._onSessionRevoked(),
      prepare: async (entry) => {
        // Old/custom servers may not support idempotency. Never blindly retry
        // an ambiguous send against one of those servers.
        const safeRetry = this.client.supportsMessageDelivery
          ? await this.client.supportsMessageDelivery() : false;
        let published = { content: entry.content, attachments: [] };
        if (!(this.disabledModules || new Set()).has('files') && entry.channel && !entry.channel.startsWith('dm:') && this.client.uploadFile) {
          published = await publishResponseArtifacts({
            content: entry.content, workingDir: this.workingDir,
            upload: (filename, bytes, contentType) => this.client.uploadFile(this.workspaceId, this.token, filename, bytes, {
              contentType, source: `openagents:${this.agentName}`, channelName: entry.channel, visibility: 'inherit',
            }),
            onError: () => this._log('Could not attach a linked document; leaving its original link in the reply.'),
          });
        }
        return { ...published, safeRetry };
      },
      send: async (entry) => {
        if (this._isMuted(entry.channel)) throw new Error('Channel is muted');
        return this.client.sendMessage(this.workspaceId, entry.channel, this.token, entry.content, {
          attachments: entry.attachments, senderType: 'agent', senderName: this.agentName,
          metadata: entry.metadata, sessionId: this._sessionId,
          idempotencyKey: entry.safeRetry ? entry.id : undefined,
        });
      },
    });
    return this._responseOutbox;
  }

  async _flushResponses() {
    try { await this._replyOutbox().flush(); }
    catch { this._log('Could not drain the response outbox; saved replies retained.', 'error'); }
  }

  async cleanupTodos(channel) {
    try {
      const result = await this.client.getTodos(this.workspaceId, channel, this.token, {
        all: false, source: `openagents:${this.agentName}`,
      });
      const todos = (result && result.todos) || [];
      const hasActive = todos.some((t) => t.status === 'pending' || t.status === 'in_progress');
      if (!hasActive) return;
      const updated = todos.map((t) => ({
        content: t.content,
        status: (t.status === 'pending' || t.status === 'in_progress') ? 'cancelled' : t.status,
        assignee: t.assignee,
      }));
      await this.client.putTodos(this.workspaceId, channel, this.token, updated, {
        source: `openagents:${this.agentName}`,
      });
    } catch {
      // Best-effort cleanup
    }
  }

  async getRemainingTodos(channel) {
    try {
      const result = await this.client.getTodos(this.workspaceId, channel, this.token, {
        all: false, source: `openagents:${this.agentName}`,
      });
      const todos = (result && result.todos) || [];
      // Defend against older endpoints returning the entire channel's list.
      return todos.filter((t) => (!t.created_by || t.created_by === `openagents:${this.agentName}`)
        && (!t.assignee || t.assignee === this.agentName || t.assignee === `openagents:${this.agentName}`)
        && (t.status === 'pending' || t.status === 'in_progress'));
    } catch {
      return [];
    }
  }

  async sendTodos(channel, todos) {
    if (this._isMuted(channel)) return;
    try {
      await this.client.putTodos(this.workspaceId, channel, this.token, todos, {
        source: `openagents:${this.agentName}`,
      });
    } catch (e) {
      if (e instanceof SessionRevokedError) { this._onSessionRevoked(); return; }
      // Fallback to event-based approach for older backends
      const lines = todos.map((t) => {
        const icon = t.status === 'completed' ? '✅' : t.status === 'in_progress' ? '🔄' : '⬜';
        return `${icon} ${t.content}`;
      });
      try {
        await this.client.sendMessage(this.workspaceId, channel, this.token, lines.join('\n'), {
          senderType: 'agent',
          senderName: this.agentName,
          messageType: 'todos',
          metadata: { agent_mode: this._mode, todos },
          sessionId: this._sessionId,
        });
      } catch (e2) {
        if (e2 instanceof SessionRevokedError) this._onSessionRevoked();
      }
    }
  }

  /**
   * Post a turn that ended badly. Carries `status_kind: 'error'` so the push
   * fan-out routes it to the user's "agent errors" switch rather than the
   * general message firehose — same structured-field contract as
   * sendResponse's 'completed'.
   */
  async sendError(channel, error) {
    if (this._isMuted(channel)) return;
    try {
      await this.client.sendMessage(this.workspaceId, channel, this.token, error, {
        senderType: 'agent',
        senderName: this.agentName,
        metadata: { status_kind: 'error' },
        sessionId: this._sessionId,
      });
    } catch (e) {
      if (e instanceof SessionRevokedError) this._onSessionRevoked();
    }
  }

  _onSessionRevoked() {
    this._log(`SESSION REVOKED: another client joined as '${this.agentName}'. Stopping adapter.`, 'warn');
    this._running = false;
  }

  // ------------------------------------------------------------------
  // Abstract
  // ------------------------------------------------------------------

  /**
   * Process a single incoming message. Must be implemented by subclasses.
   * @param {object} msg
   */
  async _handleMessage(_msg) {
    throw new Error('_handleMessage must be implemented by subclass');
  }

  // ------------------------------------------------------------------
  // Utility
  // ------------------------------------------------------------------

  _sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Return whether the workspace has the Browser Fabric viewer toggle on.
   * Cached for the lifetime of the adapter — restart to pick up a flip.
   * Falls back to false on error so the prompt builders don't accidentally
   * inject the strong directive against an older backend that can't route
   * to Browser Fabric.
   */
  async getBrowserEnabled() {
    if (this._browserEnabledCache === null) {
      try {
        const meta = await this.client.getWorkspaceMetadata(this.workspaceId, this.token);
        this._browserEnabledCache = !!(meta && meta.browserEnabled);
      } catch (e) {
        this._browserEnabledCache = false;
      }
    }
    return this._browserEnabledCache;
  }
}

module.exports = BaseAdapter;
module.exports.STALE_MESSAGE_MAX_AGE_MS = STALE_MESSAGE_MAX_AGE_MS;
module.exports.CURSOR_RESUME_MAX_AGE_MS = CURSOR_RESUME_MAX_AGE_MS;
module.exports.PRESENCE_HEARTBEAT_DEBOUNCE_MS = PRESENCE_HEARTBEAT_DEBOUNCE_MS;
module.exports.SHARED_CONTEXT_TTL_MS = SHARED_CONTEXT_TTL_MS;
module.exports.buildPresenceFields = buildPresenceFields;
module.exports.buildSharedContextBlock = buildSharedContextBlock;
