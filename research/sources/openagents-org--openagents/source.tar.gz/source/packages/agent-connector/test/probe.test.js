'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { probeAgentType, classifyFailure, buildGuidance, authFlavor, scrub, failureMessage, CODE } = require('../src/probe');

// A minimal fake connector: registry entry + health + env are all injectable
// so no real CLI or network is touched.
function fakeConnector({ entry, health, env = {}, signedInHealth }) {
  return {
    registry: { getEntry: (t) => (entry && entry.name === t ? entry : null) },
    healthCheck: (t, opts) => (opts && opts.cliLogin && signedInHealth ? signedInHealth : health),
    getAgentEnv: () => env,
    resolveAgentEnv: () => ({}),
  };
}

describe('classifyFailure', () => {
  it('maps provider auth errors to invalid_api_key', () => {
    assert.equal(classifyFailure('API Error: 401 authentication_error invalid x-api-key'), CODE.INVALID_API_KEY);
    assert.equal(classifyFailure('Error: Unauthorized'), CODE.INVALID_API_KEY);
  });

  it('maps missing-key wording to missing_api_key', () => {
    assert.equal(classifyFailure('ANTHROPIC_API_KEY environment variable is not set'), CODE.MISSING_API_KEY);
    assert.equal(classifyFailure('No API key provided'), CODE.MISSING_API_KEY);
  });

  it('maps login prompts to not_logged_in', () => {
    assert.equal(classifyFailure('You are not logged in. Please run /login'), CODE.NOT_LOGGED_IN);
    assert.equal(classifyFailure('Not authenticated. Run: claude login'), CODE.NOT_LOGGED_IN);
  });

  it('maps credit / rate / network problems distinctly', () => {
    assert.equal(classifyFailure('Your credit balance is too low'), CODE.OUT_OF_CREDIT);
    assert.equal(classifyFailure('429 Too Many Requests'), CODE.RATE_LIMITED);
    assert.equal(classifyFailure('getaddrinfo ENOTFOUND api.anthropic.com'), CODE.NETWORK);
  });

  it('prefers credit/rate/network over the generic 4xx auth match', () => {
    // "402 payment required" contains no auth wording; make sure the order
    // holds even when both families of patterns could fire.
    assert.equal(classifyFailure('401 unauthorized: rate limit exceeded'), CODE.RATE_LIMITED);
  });

  it('flags timeouts and dead binaries via flags, not text', () => {
    assert.equal(classifyFailure('', { timedOut: true }), CODE.TIMEOUT);
    assert.equal(classifyFailure('', { spawnError: 'spawn claude ENOENT' }), CODE.NOT_INSTALLED);
  });

  it('a timeout whose output names a real API error classifies as THAT error', () => {
    // Claude Code retries hard API failures until the probe clock runs out —
    // observed live: invalid key → the relay's 429 sat in the output while the
    // probe said "may be waiting for interactive input".
    assert.equal(
      classifyFailure('API Error: Request rejected (429) · wait 120s', { timedOut: true }),
      CODE.RATE_LIMITED,
    );
    assert.equal(
      classifyFailure('[claude-code:unrecognized_model] {"model":"claude-x"}', { timedOut: true }),
      CODE.BAD_MODEL,
    );
    // No recognizable error in the output → still a genuine timeout.
    assert.equal(classifyFailure('still working...', { timedOut: true }), CODE.TIMEOUT);
  });

  it('does not read Claude Code\'s unknown-model signal as the reason a run failed', () => {
    // Printed before every request on a relay model; the probe strips it so
    // a timeout stays unexplained and goes on to the direct API check.
    const { stripCliNoise } = require('../src/adapters/utils');
    const output = stripCliNoise('[claude-code:unrecognized_model] {"model":"deepseek-v4-pro[1m]","query_source":"sdk"}\n');
    assert.equal(output.trim(), '');
    assert.equal(classifyFailure(output, { timedOut: true }), CODE.TIMEOUT);
  });

  it('classifies unknown-model errors without a timeout too', () => {
    assert.equal(
      classifyFailure("There's an issue with the selected model (claude-opus-4-6)."),
      CODE.BAD_MODEL,
    );
  });

  it('reads a gateway refusing a model as a bad model, not a CLI error', () => {
    assert.equal(
      classifyFailure('HTTP 400: {"detail":"Model \'gpt-4o-mini\' is not available. This gateway only allows: deepseek-3.2, glm-5.2"}'),
      CODE.BAD_MODEL,
    );
  });

  it('falls back to cli_error for unrecognized output', () => {
    assert.equal(classifyFailure('segmentation fault'), CODE.CLI_ERROR);
  });

  it('reads the wordings seen in the field', () => {
    // CodeBuddy signed out.
    assert.equal(classifyFailure('Authentication required. Please use /login command to sign in to your account'), CODE.NOT_LOGGED_IN);
    // A one-api style relay with no channel for the model.
    assert.equal(
      classifyFailure('HTTP 503: {"error":{"code":"model_not_found","message":"No available channel for model"}}'),
      CODE.BAD_MODEL,
    );
    // A Claude Code sign-in that ran out.
    assert.equal(
      classifyFailure('Failed to authenticate: OAuth session expired and could not be refreshed'),
      CODE.SESSION_EXPIRED,
    );
    // A LiteLLM-style relay rejecting the model.
    assert.equal(
      classifyFailure('HTTP 400: {"error":{"message":"/chat/completions: Invalid model name passed in model=gpt-4o-mini"}}'),
      CODE.BAD_MODEL,
    );
    // A provider having a bad minute.
    assert.equal(
      classifyFailure('504 {"error_description":"API key **** service temporarily unavailable"}'),
      CODE.SERVICE_UNAVAILABLE,
    );
  });
});

describe('scrub', () => {
  it('redacts key-shaped strings from diagnostics', () => {
    const out = scrub('using api key sk-ant-abc123def456ghi789 for request');
    assert.ok(!out.includes('abc123def456'), out);
    assert.ok(out.includes('sk-****'));
    assert.ok(!scrub('Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload').includes('eyJhbGci'));
  });
});

describe('failureMessage', () => {
  const blob = `${'Ab9_'.repeat(14)}.${'Qz3-'.repeat(20)}`;

  it('never offers an encoded blob as the reason', () => {
    const res = { code: 1, stdout: `warning: Falling back from WebSockets to HTTPS transport\n${blob}`, stderr: '' };
    const msg = failureMessage(res, CODE.CLI_ERROR, 120000);
    assert.ok(!msg.includes('Ab9_Ab9_'), msg);
    assert.ok(msg.includes('Falling back'), msg);
  });

  it('leaves out a dumped-object fragment that is mostly encoded', () => {
    const res = {
      code: 1,
      timedOut: true,
      stdout: '',
      stderr: `warning: model metadata missing\n849-1.0.1.${'Qz3x'.repeat(4)}\\",md: '3P2K.${'Ab9_'.repeat(6)}.JdMRRLCtAU4vyOVXABHQclPCjjm5L9wR2.85P8rZZuqdP4zNv0t5HElFIRAXSdJgBc`,
    };
    assert.equal(failureMessage(res, CODE.TIMEOUT, 120000), 'Timed out after 120s: warning: model metadata missing');
  });

  it('keeps hex ids, paths and URLs', () => {
    const line = 'HTTP 402: Insufficient Balance (request_id: e00c569f-0a07-4fe9-a1c2-57d73843a0d3) at https://api.deepseek.com/chat/completions';
    assert.ok(failureMessage({ code: 1, stdout: '', stderr: line }, CODE.OUT_OF_CREDIT, 120000).includes('Insufficient Balance'));
  });

  it('names an unreachable host when Codex times out on one', () => {
    const stderr = 'ERROR rmcp::transport::worker: worker quit with fatal: Transport channel closed, when Client(HttpRequest(HttpRequest("http/request failed: error sending request for url (https://chatgpt.com/backend-api/ps/mcp)")))';
    const res = { code: 1, timedOut: true, stdout: '', stderr };
    const code = classifyFailure(stderr, { timedOut: true });
    assert.equal(code, CODE.NETWORK);
    assert.ok(failureMessage(res, code, 120000).includes('chatgpt.com'));
  });

  it('quotes the model-list error, not the ChatGPT connector, when Codex cannot reach OpenAI', () => {
    // Verbatim shape from the dashboard: a device that cannot reach chatgpt.com
    // ran out the 120s clock, and the connector's line was quoted as the reason.
    const stderr = [
      '2026-11-08T05:37:58.539562Z ERROR rmcp::transport::worker: worker quit with fatal: Transport channel closed, when Client(HttpRequest(HttpRequest("http/request failed")))',
      '2026-11-08T05:38:10.120000Z ERROR codex_models_manager::manager: failed to refresh available models: request timed out',
    ].join('\n');
    const res = { code: null, timedOut: true, stdout: '', stderr };
    const code = classifyFailure(stderr, { timedOut: true });
    assert.equal(code, CODE.NETWORK, 'a lost connection, not a CLI waiting for a login prompt');
    const msg = failureMessage(res, code, 120000);
    assert.equal(msg, 'Timed out after 120s: ERROR codex_models_manager::manager: failed to refresh available models: request timed out');
  });

  it('reads Codex connection wording as a network failure', () => {
    for (const text of [
      'ERROR codex_models_manager::manager: failed to refresh available models: Connection failed: error sending request',
      'stream disconnected before completion: Transport error',
      'failed to lookup address information: nodename nor servname provided',
    ]) {
      assert.equal(classifyFailure(text, { timedOut: true }), CODE.NETWORK, text);
    }
  });

  it('puts what the CLI said in plain words ahead of its log records', () => {
    const stderr = [
      '2026-11-08T05:37:58Z ERROR codex_core::exec: something internal',
      'Error: the configured workspace is read-only',
    ].join('\n');
    const msg = failureMessage({ code: 1, stdout: '', stderr }, CODE.CLI_ERROR, 120000);
    assert.match(msg, /^Error: the configured workspace is read-only/);
    assert.doesNotMatch(msg, /2026-11-08T/, 'the timestamp is dropped from a quoted log record');
  });

  it('reports the error line of a crash, not its stack frames', () => {
    const stderr = [
      'file:///C:/Users/a/.openagents/runtimes/codex/node_modules/@openai/codex/bin/codex.js:108',
      'Error: Missing optional dependency @openai/codex-win32-x64. Reinstall Codex: npm install -g @openai/codex@latest',
      ...Array.from({ length: 12 }, (_, i) => `    at file:///C:/Users/a/.openagents/runtimes/codex/node_modules/@openai/codex/bin/codex.js:${100 + i}:9`),
    ].join('\n');
    const msg = failureMessage({ code: 1, stdout: '', stderr }, CODE.CLI_ERROR, 120000);
    assert.match(msg, /Missing optional dependency/);
    assert.doesNotMatch(msg, /:105:9/);
  });

  it('reads a direct API test that ran out of time as the network', () => {
    assert.equal(classifyFailure('Request to api.openai.com timed out after 15s'), CODE.NETWORK);
  });

  it('says how it exited when the output was only a blob', () => {
    assert.equal(failureMessage({ code: 3, stdout: blob, stderr: '' }, CODE.CLI_ERROR, 120000), 'Exited with code 3');
  });

  it('keeps a JSON error line', () => {
    const res = { code: 1, stdout: '{"detail":"Unauthorized_for_this_model"}', stderr: '' };
    assert.ok(failureMessage(res, CODE.CLI_ERROR, 120000).includes('Unauthorized_for_this_model'));
  });

  it('keeps a failure line that echoes the full key, with the key masked', () => {
    const key = `sk-proj-${'aB3dE5fG7hJ9kL1m'.repeat(10)}`;
    const plain = `Error: 401 Incorrect API key provided: ${key}`;
    const json = JSON.stringify({ error: { message: `Incorrect API key provided: ${key}. You can find your API key at https://platform.openai.com/account/api-keys.`, type: 'invalid_request_error', code: 'invalid_api_key' } });
    for (const stderr of [plain, json]) {
      const msg = failureMessage({ code: 1, stdout: '', stderr }, CODE.INVALID_API_KEY, 120000);
      assert.match(msg, /Incorrect API key provided/);
      assert.ok(!msg.includes('aB3dE5fG7hJ9'), msg);
      assert.ok(!msg.includes(key.slice(8, 30)), msg);
    }
  });

  it('masks a JWT inside a sentence', () => {
    const jwt = 'eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.c2lnbmF0dXJlLXZhbHVl';
    assert.ok(!scrub(`refresh failed for ${jwt} at login`).includes('eyJzdWIi'));
  });
});

describe('buildGuidance', () => {
  const entry = {
    name: 'claude', label: 'Claude Code CLI',
    check_ready: { login_command: 'claude login' },
    env_config: [],
  };

  it('points CLI-login agents at their login command', () => {
    const lines = buildGuidance(CODE.NOT_LOGGED_IN, entry, {});
    assert.ok(lines.some((l) => l.includes('claude login')), lines.join('\n'));
  });

  it('reads an agent on its own type key as keyed, not signed in', () => {
    const kimi = {
      name: 'kimi', label: 'Kimi Code CLI',
      check_ready: { login_command: 'kimi login', env_vars: ['KIMI_API_KEY', 'MOONSHOT_API_KEY'], saved_env_key: 'KIMI_API_KEY' },
      env_config: [{ name: 'KIMI_API_KEY', password: true }],
    };
    assert.equal(authFlavor(kimi, { KIMI_API_KEY: 'sk-x' }), 'api_key');
    assert.equal(authFlavor(kimi, {}), 'cli_login');
    const lines = buildGuidance(CODE.INVALID_API_KEY, kimi, { KIMI_API_KEY: 'sk-x' });
    assert.ok(!lines.some((l) => l.includes('kimi login')), lines.join('\n'));
  });

  it('points API-key agents at reconfiguration', () => {
    const keyed = { name: 'openclaw', label: 'OpenClaw', env_config: [{ name: 'LLM_API_KEY' }] };
    const lines = buildGuidance(CODE.INVALID_API_KEY, keyed, { LLM_API_KEY: 'x' });
    assert.ok(lines.some((l) => /API key/.test(l)), lines.join('\n'));
    assert.ok(lines.some((l) => l.includes('agn test-llm openclaw')));
  });

  // The catalog API flattens install commands macOS -> Linux -> Windows with no
  // idea which platform is asking, so a Windows user chasing a missing hermes
  // was handed a `curl … | bash` one-liner that cannot run there.
  it('offers the install command for THIS platform, not the catalog default', () => {
    const hermes = {
      name: 'hermes',
      label: 'Hermes Agent',
      install_command: 'curl -fsSL https://example.test/install.sh | bash',
      install: {
        binary: 'hermes',
        macos: 'curl -fsSL https://example.test/install.sh | bash',
        linux: 'curl -fsSL https://example.test/install.sh | bash',
        windows: 'powershell -NoProfile -Command "irm https://example.test/install.ps1 | iex"',
      },
    };
    const lines = buildGuidance(CODE.NOT_INSTALLED, hermes, {});
    const manual = lines.find((l) => l.startsWith('Or install manually: '));
    assert.ok(manual, lines.join('\n'));
    const expected = process.platform === 'win32' ? hermes.install.windows
      : process.platform === 'darwin' ? hermes.install.macos
        : hermes.install.linux;
    assert.equal(manual, `Or install manually: ${expected}`);
  });

  it('falls back to the flat catalog field when the entry has no install block', () => {
    const lines = buildGuidance(CODE.NOT_INSTALLED, { name: 'x', label: 'X', install_command: 'npm i -g x' }, {});
    assert.ok(lines.some((l) => l === 'Or install manually: npm i -g x'), lines.join('\n'));
  });
});

describe('probeAgentType', () => {
  const baseEntry = { name: 'claude', label: 'Claude Code CLI', check_ready: { login_command: 'claude login' } };

  it('fails fast when the type is unknown', async () => {
    const c = fakeConnector({ entry: null, health: {} });
    const r = await probeAgentType(c, 'nope');
    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.UNKNOWN_TYPE);
  });

  it('fails fast with install guidance when not installed', async () => {
    const c = fakeConnector({ entry: baseEntry, health: { installed: false, ready: false } });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.NOT_INSTALLED);
    assert.ok(r.guidance.length > 0);
  });

  it('fails with auth guidance when definitively unconfigured', async () => {
    const c = fakeConnector({
      entry: baseEntry,
      health: { installed: true, ready: false, auth_status: 'no_credentials', message: 'Not logged in. Run: claude login' },
    });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.NOT_READY);
    assert.ok(r.guidance.length > 0);
    assert.equal(r.method, 'none');
  });

  it('runs the declared CLI probe and succeeds on stdout', async () => {
    const entry = {
      name: 'claude', label: 'Claude Code CLI',
      probe: { args: ['hi there'], timeout_s: 30 },
    };
    const c = fakeConnector({
      entry,
      health: { installed: true, ready: true, binary: 'echo' },
    });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.ok, true, JSON.stringify(r));
    assert.equal(r.method, 'cli');
    assert.equal(r.reply, 'hi there');
  });

  it('runs the CLI with the env its probe declares, under the agent\'s own values', async () => {
    const entry = {
      name: 'gemini', label: 'Gemini CLI',
      probe: {
        args: ['-e', 'console.log(`${process.env.OA_PROBE_FLAG}/${process.env.OA_PROBE_OWN}`)'],
        env: { OA_PROBE_FLAG: 'true', OA_PROBE_OWN: 'declared' },
        timeout_s: 30,
      },
    };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'gemini', { agentEnv: { OA_PROBE_OWN: 'mine' } });
    assert.equal(r.ok, true, JSON.stringify(r));
    assert.equal(r.reply, 'true/mine');
  });

  it('classifies a failing CLI probe and returns guidance', async () => {
    // `node -e` prints an auth-looking error and exits 1 — a realistic stand-in
    // for a CLI whose key was rejected.
    const entry = {
      name: 'claude', label: 'Claude Code CLI',
      check_ready: { login_command: 'claude login' },
      probe: { args: ['-e', 'console.error("API Error: 401 authentication_error"); process.exit(1)'], timeout_s: 30 },
    };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.INVALID_API_KEY);
    assert.ok(r.guidance.length > 0);
  });

  it('probes a signed-in agent without the key saved for its type', async () => {
    const entry = {
      name: 'claude', label: 'Claude',
      probe: { args: ['-e', 'console.log(process.env.LLM_API_KEY || "no-key")'], timeout_s: 30 },
    };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath }, env: { LLM_API_KEY: 'sk-type' } });
    const keyed = await probeAgentType(c, 'claude', { agentEnv: {} });
    assert.notEqual(keyed.reply, 'no-key');
    const signedIn = await probeAgentType(c, 'claude', { agentEnv: { OPENAGENTS_AUTH_MODE: 'cli_login' } });
    assert.equal(signedIn.reply, 'no-key');
  });

  it('judges readiness on the agent\'s own env, not the type\'s alone', async () => {
    // Kimi keyed from the workspace: the key lives on the agent, <type>.env is
    // empty, and the smoke test said "run: kimi login" while chat worked.
    const entry = { name: 'kimi', label: 'Kimi Code CLI', check_ready: { login_command: 'kimi login' } };
    const agentEnv = { LLM_API_KEY: 'sk-agent' };
    let seen;
    const c = fakeConnector({ entry, health: { installed: true, ready: true, auth_mode: 'api_key' } });
    c.healthCheck = (t, opts) => {
      seen = opts && opts.agentEnv;
      return seen && seen.LLM_API_KEY
        ? { installed: true, ready: true, auth_mode: 'api_key' }
        : { installed: true, ready: false, auth_status: 'no_credentials', message: 'run: kimi login' };
    };
    c.resolveAgentEnv = () => ({});
    const r = await probeAgentType(c, 'kimi', { agentEnv, timeoutMs: 50 });
    assert.deepEqual(seen, agentEnv);
    assert.notEqual(r.code, CODE.NOT_READY, JSON.stringify(r));
  });

  it('does not pass a signed-in agent with no live probe on the type key', async () => {
    // Codex declares no probe: the static verdict must be its sign-in's.
    const entry = { name: 'codex', label: 'Codex' };
    const c = fakeConnector({
      entry,
      health: { installed: true, ready: true, auth_mode: 'api_key' },
      signedInHealth: { installed: true, ready: false, auth_status: 'unknown', message: 'Not configured' },
      env: { LLM_API_KEY: 'sk-type' },
    });
    const r = await probeAgentType(c, 'codex', { agentEnv: { OPENAGENTS_AUTH_MODE: 'cli_login' } });
    assert.notEqual(r.ok, true);
    assert.equal(r.method, 'none');
  });

  it('reports a sign-in it could not check as unverified, not failed', async () => {
    const entry = { name: 'codex', label: 'Codex' };
    const c = fakeConnector({
      entry,
      health: { installed: true, ready: false, auth_status: 'unknown', message: 'Not configured' },
    });
    const r = await probeAgentType(c, 'codex');
    assert.equal(r.ok, null);
    assert.equal(r.code, CODE.STATIC_ONLY);
    assert.equal(r.auth_status, 'unknown');
  });

  it('lets the declared live check overrule a static "not logged in"', async () => {
    // Claude signed in where the static checks cannot look (a keychain, a
    // relay set in its own settings.json) answers fine.
    const entry = {
      name: 'claude', label: 'Claude', check_ready: { login_command: 'claude login' },
      probe: { args: ['-e', 'console.log("hello")'], timeout_s: 30 },
    };
    const c = fakeConnector({
      entry,
      health: { installed: true, ready: false, auth_status: 'no_credentials', binary: process.execPath, message: 'Not logged in' },
    });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.ok, true, JSON.stringify(r));
    assert.equal(r.method, 'cli');
  });

  it('keeps the static verdict when the live check explains nothing', async () => {
    const entry = {
      name: 'claude', label: 'Claude', check_ready: { login_command: 'claude login' },
      probe: { args: ['-e', 'process.exit(1)'], timeout_s: 30 },
    };
    const c = fakeConnector({
      entry,
      health: { installed: true, ready: false, auth_status: 'no_credentials', binary: process.execPath, message: 'Not logged in. Run: claude login' },
    });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.NOT_READY);
    assert.equal(r.message, 'Not logged in. Run: claude login');
  });

  it('reports the CLI\'s own sign-in error over the static verdict', async () => {
    const entry = {
      name: 'claude', label: 'Claude', check_ready: { login_command: 'claude login' },
      probe: { args: ['-e', 'console.log("Not logged in · Please run /login"); process.exit(1)'], timeout_s: 30 },
    };
    const c = fakeConnector({
      entry,
      health: { installed: true, ready: false, auth_status: 'no_credentials', binary: process.execPath },
    });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.code, CODE.NOT_LOGGED_IN);
    assert.equal(r.message, 'Not logged in · Please run /login');
  });

  it('reports an unsupported version as such, with reinstall guidance', async () => {
    const entry = {
      name: 'deepseek', label: 'DeepSeek Harness',
      install: { supported_version: '0.1.0-rc.6', windows: 'npm install -g @deepseek-ai/dsh@0.1.0-rc.6', macos: 'npm install -g @deepseek-ai/dsh@0.1.0-rc.6', linux: 'npm install -g @deepseek-ai/dsh@0.1.0-rc.6' },
    };
    const c = fakeConnector({
      entry,
      health: {
        installed: true, ready: false, compatible: false, reason: 'version_incompatible',
        auth_status: 'no_credentials', message: 'DeepSeek Harness 0.2.0-rc.2 is not supported',
      },
    });
    const r = await probeAgentType(c, 'deepseek');
    assert.equal(r.code, CODE.VERSION_INCOMPATIBLE);
    assert.ok(r.guidance.some((l) => l.includes('@deepseek-ai/dsh@0.1.0-rc.6')), JSON.stringify(r.guidance));
  });

  it('hands a keyed agent to the API tier when its CLI probe cannot see the key', async () => {
    // Codex reaches a relay through launch flags the bare probe run lacks: the
    // CLI probe would test OpenAI's default endpoint instead of the relay.
    const path = require.resolve('../src/utils');
    const saved = require.cache[path];
    require.cache[path] = {
      id: path, filename: path, loaded: true,
      exports: { testLLMConnection: async () => ({ success: true, response: 'from-api' }) },
    };
    try {
      const entry = {
        name: 'codex', label: 'Codex',
        probe: { args: ['-e', 'console.log("from-cli")'], timeout_s: 30, skip_cli_with_key: true },
      };
      const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
      const keyed = await probeAgentType(c, 'codex', { agentEnv: { OPENAI_API_KEY: 'sk-relay' } });
      assert.equal(keyed.method, 'llm_api', JSON.stringify(keyed));
      const signedIn = await probeAgentType(c, 'codex', { agentEnv: { OPENAGENTS_AUTH_MODE: 'cli_login' } });
      assert.equal(signedIn.method, 'cli', JSON.stringify(signedIn));
      assert.equal(signedIn.reply, 'from-cli');
    } finally {
      if (saved) require.cache[path] = saved; else delete require.cache[path];
    }
  });

  it('tests a Codex agent in Responses mode on the Responses API, and names a refused field', async () => {
    const path = require.resolve('../src/utils');
    const saved = require.cache[path];
    const calls = [];
    const refusal = 'HTTP 400: {"error":{"message":"Unsupported Responses request parameter.","type":"invalid_request_error","param":"client_metadata","code":"unsupported_parameter"}}';
    require.cache[path] = {
      id: path, filename: path, loaded: true,
      exports: { testLLMConnection: async (_env, opts) => { calls.push(opts); return { success: false, error: refusal }; } },
    };
    try {
      const entry = { name: 'codex', label: 'Codex', probe: { args: ['exec', 'hi'], timeout_s: 30, skip_cli_with_key: true } };
      const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
      const relay = { OPENAI_API_KEY: 'sk-relay', OPENAI_BASE_URL: 'https://relay.example/v1' };

      const r = await probeAgentType(c, 'codex', { agentEnv: { ...relay, CODEX_WIRE_API: 'responses' } });
      assert.equal(calls.at(-1).protocol, 'responses');
      assert.equal(r.code, CODE.ENDPOINT_INCOMPATIBLE, JSON.stringify(r));
      const text = r.guidance.join('\n');
      assert.match(text, /refuses the "client_metadata" field that Codex sends with every one of them/);
      assert.match(text, /Chat only · Chat Completions API/);

      // Chat-only mode (direct API) keeps the chat test, and a parameter
      // refusal there is not read as an incompatible endpoint.
      const chat = await probeAgentType(c, 'codex', { agentEnv: { ...relay, CODEX_WIRE_API: 'chat' } });
      assert.equal(calls.at(-1).protocol, undefined);
      assert.notEqual(chat.code, CODE.ENDPOINT_INCOMPATIBLE);
      // OpenAI itself is never tested as a custom Responses provider.
      await probeAgentType(c, 'codex', { agentEnv: { OPENAI_API_KEY: 'sk-x', OPENAI_BASE_URL: 'https://api.openai.com/v1', CODEX_WIRE_API: 'responses' } });
      assert.equal(calls.at(-1).protocol, undefined);
    } finally {
      if (saved) require.cache[path] = saved; else delete require.cache[path];
    }
  });

  it('does not blame Codex for a refused max_output_tokens — the test sends it, the CLI never does', async () => {
    const path = require.resolve('../src/utils');
    const saved = require.cache[path];
    let refusal = 'HTTP 400: {"error":{"message":"Unsupported parameter: max_output_tokens","type":"invalid_request_error","param":"max_output_tokens","code":"unsupported_parameter"}}';
    require.cache[path] = {
      id: path, filename: path, loaded: true,
      exports: { testLLMConnection: async () => ({ success: false, error: refusal }) },
    };
    try {
      const entry = { name: 'codex', label: 'Codex', probe: { args: ['exec', 'hi'], timeout_s: 30, skip_cli_with_key: true } };
      const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
      const agentEnv = { OPENAI_API_KEY: 'sk-relay', OPENAI_BASE_URL: 'https://relay.example/v1', CODEX_WIRE_API: 'responses' };
      const r = await probeAgentType(c, 'codex', { agentEnv });
      assert.notEqual(r.code, CODE.ENDPOINT_INCOMPATIBLE, JSON.stringify(r));
      assert.doesNotMatch(r.guidance.join('\n'), /sends with every one of them/);

      // A refusal that names another field is the endpoint's, whatever else its message mentions.
      refusal = 'error: {"param":"client_metadata","code":"unsupported_parameter","message":"Unsupported parameter: client_metadata (max_output_tokens is fine)"}';
      const other = await probeAgentType(c, 'codex', { agentEnv });
      assert.equal(other.code, CODE.ENDPOINT_INCOMPATIBLE, JSON.stringify(other));
      assert.match(other.guidance.join('\n'), /refuses the "client_metadata" field/);
    } finally {
      if (saved) require.cache[path] = saved; else delete require.cache[path];
    }
  });

  it('skips the API call for an agent whose key is not a model API key', async () => {
    const path = require.resolve('../src/utils');
    const saved = require.cache[path];
    let called = false;
    require.cache[path] = {
      id: path, filename: path, loaded: true,
      exports: { testLLMConnection: async () => { called = true; return { success: false, error: 'getaddrinfo ENOTFOUND api.openai.com' }; } },
    };
    try {
      const entry = { name: 'cursor', label: 'Cursor', probe: { api_test: false } };
      const c = fakeConnector({ entry, health: { installed: true, ready: true }, env: { LLM_API_KEY: 'key_cursor' } });
      const r = await probeAgentType(c, 'cursor');
      assert.equal(called, false);
      assert.equal(r.code, CODE.STATIC_ONLY);
      assert.equal(r.ok, true);
    } finally {
      if (saved) require.cache[path] = saved; else delete require.cache[path];
    }
  });

  it('reports the error line, not a harmless warning on stderr', async () => {
    const entry = {
      name: 'claude', label: 'Claude',
      probe: {
        args: ['-e', 'console.error("⚠ claude.ai connectors are disabled because ANTHROPIC_API_KEY is set"); console.log("API Error: 403 insufficient_quota"); process.exit(1)'],
        timeout_s: 30,
      },
    };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.code, CODE.OUT_OF_CREDIT);
    assert.equal(r.message, 'API Error: 403 insufficient_quota');
  });

  it('looks past Claude Code\'s unknown-model notice to the real error', async () => {
    // A relay model Claude Code does not know makes it print a long notice
    // ending "…auto-compact keeps this session within 200k tokens (the context
    // window it assumes)…". That notice was all the dashboard ever showed.
    const notice = 'Claude Code doesn\'t recognize the model "glm-5", so it assumes a context window of 200000 tokens. '
      + 'Until then auto-compact keeps this session within 200k tokens (the context window it assumes); '
      + 'CLAUDE_CODE_DISABLE_UNKNOWN_MODEL_WINDOW_ENFORCEMENT=1 restores the previous wait-for-the-API behavior.';
    const entry = {
      name: 'claude', label: 'Claude', check_ready: { login_command: 'claude login' },
      probe: {
        args: ['-e', `console.log("Failed to authenticate: OAuth session expired and could not be refreshed"); console.error(${JSON.stringify(notice)}); process.exit(1)`],
        timeout_s: 30,
      },
    };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.code, CODE.SESSION_EXPIRED);
    assert.equal(r.message, 'Failed to authenticate: OAuth session expired and could not be refreshed');
    assert.ok(r.guidance.some((l) => /expired/.test(l) && /claude login/.test(l)), JSON.stringify(r.guidance));
  });

  it('looks past Codex\'s fallback-metadata warning to the real error', async () => {
    const warning = 'warning: Model metadata for `gpt-5.5` not found. Defaulting to fallback metadata; this can degrade performance and cause issues.';
    const entry = {
      name: 'codex', label: 'Codex',
      probe: {
        args: ['-e', `console.error(${JSON.stringify(warning)}); console.error("stream error: unexpected status 502 Bad Gateway"); process.exit(1)`],
        timeout_s: 30,
      },
    };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'codex');
    assert.equal(r.ok, false);
    assert.ok(!/Model metadata/.test(r.message), r.message);
    assert.ok(/502 Bad Gateway/.test(r.message), r.message);
  });

  it('does not count the unknown-model notice alone as a reply', async () => {
    const entry = {
      name: 'claude', label: 'Claude',
      probe: { args: ['-e', 'console.log("Until then auto-compact keeps this session within 200k tokens (the context window it assumes)")'], timeout_s: 30 },
    };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.EMPTY_RESPONSE);
  });

  it('runs a Windows .cmd shim from a folder with a space in it', { skip: process.platform !== 'win32' }, async () => {
    const fs = require('fs');
    const os = require('os');
    const path = require('path');
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'probe space '));
    try {
      const shim = path.join(dir, 'agent.cmd');
      fs.writeFileSync(shim, '@echo off\r\necho hello %1\r\n');
      const entry = { name: 'codebuddy', label: 'CodeBuddy', probe: { args: ['hi'], timeout_s: 30 } };
      const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: shim } });
      const r = await probeAgentType(c, 'codebuddy');
      assert.equal(r.ok, true, JSON.stringify(r));
      assert.equal(r.reply, 'hello hi');
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });

  it('treats exit-0-with-no-output as empty_response', async () => {
    const entry = { name: 'claude', label: 'Claude', probe: { args: ['-e', ''], timeout_s: 30 } };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'claude');
    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.EMPTY_RESPONSE);
  });

  it('counts an answer from a CLI that then fails to exit as a pass', async () => {
    const entry = { name: 'claude', label: 'Claude', probe: { args: ['-e', 'console.log("Hi! What can I help you with?"); setTimeout(()=>{}, 60000)'] } };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'claude', { timeoutMs: 500 });
    assert.equal(r.ok, true);
    assert.equal(r.code, CODE.OK);
    assert.match(r.message, /did not exit within/);
    assert.equal(r.reply, 'Hi! What can I help you with?');
  });

  it('still reports a timeout when what it printed is an error or a retry', async () => {
    for (const line of ['Attempt 1 failed with status 503. Retrying with backoff...', 'API Error: 401 unauthorized']) {
      const entry = { name: 'claude', label: 'Claude', probe: { args: ['-e', `console.log(${JSON.stringify(line)}); setTimeout(()=>{}, 60000)`] } };
      const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
      const r = await probeAgentType(c, 'claude', { timeoutMs: 500 });
      assert.equal(r.ok, false, line);
    }
  });

  it('drops codex housekeeping from the timeout message', async () => {
    const stderr = [
      'Reading additional input from stdin...',
      '2026-10-28T08:48:54.592712Z  WARN codex_core::plugins: failed to refresh plugin cache',
      '2026-10-28T08:48:54.592712Z ERROR codex_skills_extension::host_service: failed to install system skills',
    ].join('\n');
    const entry = { name: 'codex', label: 'Codex', probe: { args: ['-e', `console.error(${JSON.stringify(stderr)}); setTimeout(()=>{}, 60000)`] } };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'codex', { timeoutMs: 500 });
    assert.equal(r.ok, false);
    assert.doesNotMatch(r.message, /Reading additional input|WARN/);
    assert.match(r.message, /failed to install system skills/);
  });

  it('drops Node process warnings that come ahead of the real error', async () => {
    const stderr = [
      '(node:18244) [DEP0190] DeprecationWarning: Passing args to a child process with shell option true can lead to security vulnerabilities',
      '(Use `node --trace-warnings ...` to show where the warning was created)',
      '401 Authentication required. Please use /login command to sign in to your account',
    ].join('\n');
    const entry = { name: 'codebuddy', label: 'CodeBuddy', probe: { args: ['-e', `console.error(${JSON.stringify(stderr)}); process.exit(1)`] } };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'codebuddy', { timeoutMs: 5000 });
    assert.equal(r.ok, false);
    assert.doesNotMatch(r.message, /DeprecationWarning|trace-warnings/);
    assert.match(r.message, /401 Authentication required/);
  });

  it('kills and reports a hanging CLI as timeout', async () => {
    const entry = { name: 'claude', label: 'Claude', probe: { args: ['-e', 'setTimeout(()=>{}, 60000)'] } };
    const c = fakeConnector({ entry, health: { installed: true, ready: true, binary: process.execPath } });
    const r = await probeAgentType(c, 'claude', { timeoutMs: 500 });
    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.TIMEOUT);
    assert.ok(r.guidance.some((l) => /interactive/.test(l)));
  });

  it('reports static_only when no live probe is possible', async () => {
    const entry = { name: 'mystery', label: 'Mystery' };
    const c = fakeConnector({ entry, health: { installed: true, ready: true } });
    const r = await probeAgentType(c, 'mystery');
    assert.equal(r.ok, true);
    assert.equal(r.code, CODE.STATIC_ONLY);
    assert.equal(r.method, 'none');
  });
});

/**
 * A CLI that hangs tells you nothing. The endpoint always knows why.
 *
 * Seen live: a relay answering 403 "预扣费额度失败" made Claude Code retry in
 * silence for its whole 120s, leaving the probe with a timeout and an
 * unrelated stderr warning — which the guidance read as "it may be waiting for
 * a login prompt", sending the user to a terminal to fix a working install.
 */
describe('a CLI verdict that explains nothing defers to the endpoint', () => {
  // `sleep 5` stands in for a CLI that hangs: the probe's clock is set well
  // below it, so every case here starts from a genuine timeout.
  const ENTRY = {
    name: 'claude',
    label: 'Claude Code CLI',
    probe: { args: ['5'], timeout_s: 1 },
  };

  /** Stand in for the HTTP client probe.js lazily requires. */
  function withLLM(answer, run) {
    const path = require.resolve('../src/utils');
    const original = require.cache[path];
    require.cache[path] = {
      id: path,
      filename: path,
      loaded: true,
      exports: { testLLMConnection: async () => answer },
    };
    return run().finally(() => {
      if (original) require.cache[path] = original;
      else delete require.cache[path];
    });
  }

  const hanging = fakeConnector({
    entry: ENTRY,
    health: { installed: true, ready: true, binary: 'sleep' },
    env: { ANTHROPIC_API_KEY: 'sk-test', ANTHROPIC_BASE_URL: 'https://relay.example' },
  });

  it('reports the real reason the endpoint gives, not the timeout', async () => {
    const answer = {
      success: false,
      error: 'HTTP 403: 预扣费额度失败, 用户剩余额度: $1.73, 需要预扣费额度: $3.50',
    };
    const r = await withLLM(answer, () => probeAgentType(hanging, 'claude', { timeoutMs: 400 }));

    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.OUT_OF_CREDIT);
    assert.equal(r.method, 'llm_api');
    // The guidance the user acts on must be about money, not about terminals.
    assert.match(r.guidance.join(' '), /credit|quota/i);
    assert.doesNotMatch(r.guidance.join(' '), /interactive input|waiting/i);
  });

  it('keeps the CLI verdict when the endpoint is healthy', async () => {
    // The endpoint answering means the CLI's own trouble is real and still
    // unexplained; "everything is fine" would be a worse answer than vague.
    const r = await withLLM({ success: true, response: 'hi' }, () =>
      probeAgentType(hanging, 'claude', { timeoutMs: 400 }),
    );

    assert.equal(r.ok, false);
    assert.equal(r.code, CODE.TIMEOUT);
    assert.equal(r.method, 'cli');
  });

  it('keeps the CLI verdict when the endpoint fails just as vaguely', async () => {
    const r = await withLLM({ success: false, error: 'something went wrong' }, () =>
      probeAgentType(hanging, 'claude', { timeoutMs: 400 }),
    );

    assert.equal(r.method, 'cli');
    assert.equal(r.code, CODE.TIMEOUT);
  });

  it('does not call the endpoint for an agent with no key', async () => {
    let called = false;
    const keyless = fakeConnector({
      entry: ENTRY,
      health: { installed: true, ready: true, binary: 'sleep' },
      env: {},
    });
    const path = require.resolve('../src/utils');
    const original = require.cache[path];
    require.cache[path] = {
      id: path, filename: path, loaded: true,
      exports: { testLLMConnection: async () => { called = true; return { success: false }; } },
    };
    try {
      const r = await probeAgentType(keyless, 'claude', { timeoutMs: 400 });
      assert.equal(called, false);
      assert.equal(r.method, 'cli');
    } finally {
      if (original) require.cache[path] = original;
      else delete require.cache[path];
    }
  });
});

describe('out-of-credit is not only an English 402', () => {
  it('reads a relay saying it in Chinese, and at 403', () => {
    // The relay this came from answers 403 with its own wording; the original
    // pattern matched neither, so it fell through to "invalid credentials" —
    // which sends the user to re-authenticate a key that works.
    assert.equal(
      classifyFailure('HTTP 403: 预扣费额度失败, 用户剩余额度: $1.73'),
      CODE.OUT_OF_CREDIT,
    );
    assert.equal(classifyFailure('余额不足，请充值'), CODE.OUT_OF_CREDIT);
    assert.equal(classifyFailure('You exceeded your current quota'), CODE.OUT_OF_CREDIT);
  });

  it('still reads the English wording it always did', () => {
    assert.equal(classifyFailure('Your credit balance is too low'), CODE.OUT_OF_CREDIT);
    assert.equal(classifyFailure('402 payment required'), CODE.OUT_OF_CREDIT);
  });
});

describe('a direct test runs on the model the agent runs on', () => {
  // Codex declares no CLI probe: an agent with a key is tested on its API.
  const CODEX = { name: 'codex', label: 'OpenAI Codex CLI', check_ready: { login_command: 'codex login' } };
  const connector = fakeConnector({ entry: CODEX, health: { installed: true, ready: true } });

  /** Stand in for the HTTP client, recording what it was asked. */
  function withLLM(answer, run) {
    const path = require.resolve('../src/utils');
    const original = require.cache[path];
    const seen = [];
    require.cache[path] = {
      id: path, filename: path, loaded: true,
      exports: { testLLMConnection: async (env, opts) => { seen.push({ env, opts }); return answer; } },
    };
    return run(seen).finally(() => {
      if (original) require.cache[path] = original;
      else delete require.cache[path];
    });
  }

  it('tests a launcher-made codex agent on its CODEX_MODEL', async () => {
    await withLLM({ success: true, response: 'hi' }, async (seen) => {
      const r = await probeAgentType(connector, 'codex', { agentEnv: {
        OPENAI_API_KEY: 'sk-test-123456', OPENAI_BASE_URL: 'https://api-gateway.example/v1', CODEX_MODEL: 'openai-gpt-oss-20b',
      } });
      assert.equal(r.ok, true);
      assert.equal(seen[0].opts.model, 'openai-gpt-oss-20b');
    });
  });
});

describe('a direct test calls the endpoint the agent\'s key is for', () => {
  // DeepSeek takes the generic key and endpoint under names of its own.
  const DEEPSEEK = {
    name: 'deepseek', label: 'DeepSeek Harness',
    resolve_env: { rules: [
      { from: 'LLM_API_KEY', to: 'DEEPSEEK_API_KEY' },
      { from: 'LLM_BASE_URL', to: 'DEEPSEEK_BASE_URL' },
      { from: 'LLM_MODEL', to: 'DEEPSEEK_MODEL' },
    ] },
    env_config: [{ name: 'DEEPSEEK_API_KEY', password: true }, { name: 'DEEPSEEK_BASE_URL' }],
  };
  const OPENCODE = {
    name: 'opencode', label: 'OpenCode',
    resolve_env: { rules: [{ from: 'LLM_API_KEY', to: 'OPENAI_API_KEY' }, { from: 'LLM_BASE_URL', to: 'OPENAI_BASE_URL' }] },
  };
  const ready = (entry) => fakeConnector({ entry, health: { installed: true, ready: true } });

  function withLLM(run) {
    const path = require.resolve('../src/utils');
    const original = require.cache[path];
    const seen = [];
    require.cache[path] = {
      id: path, filename: path, loaded: true,
      exports: { testLLMConnection: async (env, opts) => { seen.push({ env, opts }); return { success: true, response: 'hi' }; } },
    };
    return run(seen).finally(() => {
      if (original) require.cache[path] = original;
      else delete require.cache[path];
    });
  }

  it('calls the endpoint saved under the type\'s own name', async () => {
    await withLLM(async (seen) => {
      const r = await probeAgentType(ready(DEEPSEEK), 'deepseek', { agentEnv: {
        LLM_API_KEY: 'sk-ds-123456', DEEPSEEK_BASE_URL: 'https://api.deepseek.com',
      } });
      assert.equal(r.ok, true);
      assert.equal(seen[0].opts.baseUrl, 'https://api.deepseek.com');
    });
  });

  it('does not send a key of its own to OpenAI when no endpoint is set', async () => {
    await withLLM(async (seen) => {
      const r = await probeAgentType(ready(DEEPSEEK), 'deepseek', { agentEnv: { LLM_API_KEY: 'sk-ds-123456' } });
      assert.equal(seen.length, 0);
      assert.equal(r.code, CODE.STATIC_ONLY);
    });
  });

  it('leaves the endpoint to the client for a generic one, or an OpenAI-style key', async () => {
    await withLLM(async (seen) => {
      await probeAgentType(ready(DEEPSEEK), 'deepseek', { agentEnv: { LLM_API_KEY: 'sk-ds-123456', LLM_BASE_URL: 'https://relay.example/v1' } });
      await probeAgentType(ready(OPENCODE), 'opencode', { agentEnv: { LLM_API_KEY: 'sk-oc-123456' } });
      assert.equal(seen.length, 2);
      assert.equal(seen[0].opts.baseUrl, undefined);
      assert.equal(seen[1].opts.baseUrl, undefined);
    });
  });
});

describe('a direct test of a Pi agent speaks the API format Pi uses', () => {
  const PI = {
    name: 'pi', label: 'Pi',
    resolve_env: { rules: [
      { from: 'LLM_API_KEY', to: 'PI_API_KEY' }, { from: 'LLM_BASE_URL', to: 'PI_BASE_URL' }, { from: 'LLM_MODEL', to: 'PI_MODEL' },
    ] },
    env_config: [{ name: 'PI_API_KEY', password: true }, { name: 'PI_BASE_URL' }],
  };
  const connector = fakeConnector({ entry: PI, health: { installed: true, ready: true } });
  const relay = { LLM_API_KEY: 'sk-pi-123456', LLM_BASE_URL: 'https://relay.example/v1', PI_BASE_URL: 'https://relay.example/v1', PI_MODEL: 'm' };

  function withLLM(run) {
    const path = require.resolve('../src/utils');
    const original = require.cache[path];
    const seen = [];
    require.cache[path] = {
      id: path, filename: path, loaded: true,
      exports: { testLLMConnection: async (env, opts) => { seen.push(opts); return { success: true, response: 'hi' }; } },
    };
    return run(seen).finally(() => {
      if (original) require.cache[path] = original;
      else delete require.cache[path];
    });
  }

  it('tests an Anthropic-format Pi agent on the Anthropic API', async () => {
    await withLLM(async (seen) => {
      await probeAgentType(connector, 'pi', { agentEnv: { ...relay, PI_PROVIDER: 'anthropic', PI_API_FORMAT: 'anthropic-messages' } });
      await probeAgentType(connector, 'pi', { agentEnv: { ...relay, PI_PROVIDER: 'anthropic' } });
      assert.deepEqual(seen.map((o) => o.protocol), ['anthropic', 'anthropic']);
    });
  });

  it('tests a relay-only Pi agent the way Pi infers it', async () => {
    await withLLM(async (seen) => {
      await probeAgentType(connector, 'pi', { agentEnv: relay });
      assert.equal(seen[0].protocol, 'openai');
    });
  });

  it('leaves a Pi agent on its own provider config to the client', async () => {
    // No PI_PROVIDER or PI_BASE_URL: the launcher's provider is not in play,
    // and Pi runs on its own config, here an Anthropic relay.
    await withLLM(async (seen) => {
      await probeAgentType(connector, 'pi', { agentEnv: {
        ANTHROPIC_API_KEY: 'sk-ant-123456', ANTHROPIC_BASE_URL: 'https://anthropic-relay.example', PI_MODEL: 'm',
      } });
      assert.equal(seen.length, 1);
      assert.equal(seen[0].protocol, undefined);
      assert.equal(seen[0].baseUrl, undefined);
    });
  });

  it('reports static checks for a format the direct test does not speak', async () => {
    await withLLM(async (seen) => {
      const r = await probeAgentType(connector, 'pi', { agentEnv: { ...relay, PI_PROVIDER: 'openai' } });
      assert.equal(seen.length, 0);
      assert.equal(r.code, CODE.STATIC_ONLY);
    });
  });
});
