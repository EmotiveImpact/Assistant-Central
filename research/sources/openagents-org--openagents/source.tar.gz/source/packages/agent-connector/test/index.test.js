'use strict';

const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { AgentConnector } = require('../src/index');

let tmpDir;

beforeEach(() => {
  tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ac-index-'));
});

afterEach(() => {
  fs.rmSync(tmpDir, { recursive: true, force: true });
});

describe('AgentConnector instance env', () => {
  it('merges type env with instance env without cross-agent overwrite', () => {
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.saveAgentEnv('opencode', {
      LLM_API_KEY: 'sk-test',
      LLM_BASE_URL: 'https://openrouter.ai/api/v1',
      LLM_MODEL: 'default-model',
    });

    connector.addAgent({ name: 'agent-a', type: 'opencode', role: 'worker' });
    connector.addAgent({ name: 'agent-b', type: 'opencode', role: 'worker' });

    connector.saveAgentInstanceEnv('agent-a', { LLM_MODEL: 'model-a' });
    connector.saveAgentInstanceEnv('agent-b', { LLM_MODEL: 'model-b' });

    const agents = connector.listAgents();
    const agentA = agents.find((agent) => agent.name === 'agent-a');
    const agentB = agents.find((agent) => agent.name === 'agent-b');

    assert.equal(agentA.env.LLM_MODEL, 'model-a');
    assert.equal(agentB.env.LLM_MODEL, 'model-b');
    assert.equal(agentA.env.LLM_BASE_URL, 'https://openrouter.ai/api/v1');
    assert.equal(agentB.env.LLM_BASE_URL, 'https://openrouter.ai/api/v1');
    assert.deepEqual(connector.getAgentInstanceEnv('agent-a'), { LLM_MODEL: 'model-a' });
    assert.deepEqual(connector.getAgentInstanceEnv('agent-b'), { LLM_MODEL: 'model-b' });
  });
});

describe('AgentConnector display names', () => {
  /** Stand in for the workspace half so no network is involved. */
  function stubWorkspace(connector, impl) {
    connector._workspaceClientFor = () => ({
      client: impl,
      network: { id: 'ws-1', token: 't' },
    });
  }

  it('keeps `name` as the identity and stores the label beside it', () => {
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'copilot-jade-robin', type: 'copilot' });
    connector._workspaceClientFor = () => null; // local-only agent

    return connector.setAgentDisplayName('copilot-jade-robin', 'My Copilot')
      .then(() => {
        const [agent] = connector.config.getAgents();
        // The identity is what keys the working dir, sessions and membership.
        assert.equal(agent.name, 'copilot-jade-robin');
        assert.equal(agent.display_name, 'My Copilot');
        assert.equal(connector.listAgents()[0].displayName, 'My Copilot');
      });
  });

  it('pushes the label to the workspace before writing it locally', async () => {
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    const calls = [];
    stubWorkspace(connector, {
      setMemberDisplayName: async (ws, token, name, label) => {
        calls.push({ ws, name, label });
      },
    });

    await connector.setAgentDisplayName('a1', 'Renamed');
    assert.deepEqual(calls, [{ ws: 'ws-1', name: 'a1', label: 'Renamed' }]);
    assert.equal(connector.config.getAgent('a1').display_name, 'Renamed');
  });

  it('leaves both sides unchanged when the workspace rejects the label', async () => {
    // The workspace refuses a label another member already answers to (it
    // doubles as an @-mention alias). Writing locally anyway would leave the
    // two sides permanently disagreeing about what this agent is called.
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    stubWorkspace(connector, {
      setMemberDisplayName: async () => {
        throw new Error('Display name conflicts with another member');
      },
    });

    await assert.rejects(() => connector.setAgentDisplayName('a1', 'Taken'));
    assert.equal(connector.config.getAgent('a1').display_name, undefined);
  });

  it('clears the label back to nothing on an empty value', async () => {
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    connector._workspaceClientFor = () => null;

    await connector.setAgentDisplayName('a1', 'Something');
    await connector.setAgentDisplayName('a1', '   ');
    // Cleared, not deleted: the key round-trips through YAML as null rather
    // than disappearing. What matters is that nothing downstream reads it as a
    // label — listAgents reports null and the UI falls back to `name`.
    assert.ok(!connector.config.getAgent('a1').display_name);
    assert.equal(connector.listAgents()[0].displayName, null);
  });
});

describe('AgentConnector workspace removal', () => {
  it('drops the member row, and is a no-op for a local-only agent', async () => {
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'local-only', type: 'copilot' });
    connector._workspaceClientFor = () => null;

    const res = await connector.removeAgentFromWorkspace('local-only');
    assert.equal(res.skipped, true);
    // Nothing over there to remove, and the agent is untouched here.
    assert.equal(connector.config.getAgent('local-only').name, 'local-only');
  });

  it('treats a 404 as done — the member row is already gone', async () => {
    // Removal is local-LAST, so a failure here means the agent cannot be
    // removed at all. A workspace that has since been deleted, or a member
    // someone already removed over there, would otherwise strand it here
    // forever with no way to clean it up.
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    connector._workspaceClientFor = () => ({
      client: {
        removeMember: async () => {
          const e = new Error('Member not found');
          e.status = 404;
          throw e;
        },
      },
      network: { id: 'ws-1', token: 't' },
    });

    const res = await connector.removeAgentFromWorkspace('a1');
    assert.equal(res.alreadyGone, true);
  });

  it('still refuses on a transient failure, so nothing is lost silently', async () => {
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    connector._workspaceClientFor = () => ({
      client: {
        removeMember: async () => {
          const e = new Error('Bad gateway');
          e.status = 502;
          throw e;
        },
      },
      network: { id: 'ws-1', token: 't' },
    });

    await assert.rejects(() => connector.removeAgentFromWorkspace('a1'));
    // The agent is untouched here, so the user can retry.
    assert.equal(connector.config.getAgent('a1').name, 'a1');
  });

  it('leaveWorkspace drops the member row but keeps the agent', async () => {
    // The bug this replaces: unbinding locally while the workspace kept
    // listing the agent, with nothing in the launcher able to reach that row.
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    connector.config.setAgentNetwork('a1', 'ws-slug');
    const removed = [];
    connector._workspaceClientFor = () => ({
      client: { removeMember: async (ws, tok, n) => removed.push(n) },
      network: { id: 'ws-1', token: 't' },
    });

    await connector.leaveWorkspace('a1');
    assert.deepEqual(removed, ['a1']);
    const agent = connector.config.getAgent('a1');
    assert.equal(agent.name, 'a1');          // still here, with its config
    assert.ok(!agent.network);               // and no longer bound
  });

  it('leaveWorkspace keeps the binding when the workspace call fails', async () => {
    // Unbinding anyway would orphan the membership — the exact outcome this
    // whole change exists to prevent.
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    connector.config.setAgentNetwork('a1', 'ws-slug');
    connector._workspaceClientFor = () => ({
      client: {
        removeMember: async () => {
          const e = new Error('Bad gateway');
          e.status = 502;
          throw e;
        },
      },
      network: { id: 'ws-1', token: 't' },
    });

    await assert.rejects(() => connector.leaveWorkspace('a1'));
    assert.equal(connector.config.getAgent('a1').network, 'ws-slug');
  });

  it('keeps disconnectWorkspace synchronous for agn/TUI callers', () => {
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    connector.config.setAgentNetwork('a1', 'ws-slug');
    const result = connector.disconnectWorkspace('a1');
    assert.equal(typeof result.then, 'undefined');
    assert.ok(!connector.config.getAgent('a1').network);
  });

  it('keeps removeAgent synchronous so its callers keep working', () => {
    // `agn remove` and the TUI call this without awaiting, inside a try/catch.
    // Making it async would turn a throw into an unhandled rejection they can
    // no longer see, so the network half lives in removeAgentFromWorkspace.
    const connector = new AgentConnector({ configDir: tmpDir });
    connector.addAgent({ name: 'a1', type: 'copilot' });
    const result = connector.removeAgent('a1');
    assert.equal(typeof result.then, 'undefined');
    assert.equal(connector.config.getAgents().length, 0);
  });
});

describe('AgentConnector native auth on add', () => {
  // A key typed while adding an agent must reach the CLI's own config, exactly
  // like one saved later — otherwise the run uses a stale key or none at all.
  // Hermes is not here: a keyed Hermes agent writes its own provider when it
  // runs (HermesAdapter._endpoint), nothing device-wide on save.
  for (const type of ['openclaw']) {
    it(`configures ${type} from the env it is added with`, () => {
      const adapter = require(`../src/adapters/${type}`);
      const original = adapter.configureNativeAuth;
      const calls = [];
      adapter.configureNativeAuth = (env) => { calls.push(env); };
      try {
        const connector = new AgentConnector({ configDir: tmpDir });
        connector.addAgent({ name: `${type}-new`, type, env: { LLM_API_KEY: 'sk-new', LLM_BASE_URL: 'https://relay.example/v1' } });
        connector.addAgent({ name: `${type}-bare`, type });
        assert.equal(calls.length, 1);
        assert.equal(calls[0].LLM_API_KEY, 'sk-new');
        assert.equal(calls[0].LLM_BASE_URL, 'https://relay.example/v1');
      } finally {
        adapter.configureNativeAuth = original;
      }
    });
  }
});

describe('AgentConnector native auth for a Hermes sign-in', () => {
  function stubRestore() {
    const adapter = require('../src/adapters/hermes');
    const saved = adapter.restoreNativeAuth;
    const calls = { restore: 0 };
    adapter.restoreNativeAuth = () => { calls.restore++; };
    return { calls, undo: () => { adapter.restoreNativeAuth = saved; } };
  }

  it('hands Hermes back its own provider for an agent added on the sign-in tab', () => {
    const { calls, undo } = stubRestore();
    try {
      const connector = new AgentConnector({ configDir: tmpDir });
      connector.env.save('hermes', { LLM_API_KEY: 'sk-old', LLM_BASE_URL: 'https://relay.example/v1' });
      connector.addAgent({ name: 'h', type: 'hermes', env: { OPENAGENTS_AUTH_MODE: 'cli_login' } });
      assert.equal(calls.restore, 1);
    } finally {
      undo();
    }
  });

  it('restores Hermes\'s own provider when an agent moves to the sign-in', () => {
    const { calls, undo } = stubRestore();
    try {
      const connector = new AgentConnector({ configDir: tmpDir });
      connector.addAgent({ name: 'h', type: 'hermes', env: { LLM_API_KEY: 'sk-own', LLM_BASE_URL: 'https://relay.example/v1' } });
      assert.equal(calls.restore, 0);
      connector.saveAgentInstanceEnv('h', { OPENAGENTS_AUTH_MODE: 'cli_login', LLM_API_KEY: '', LLM_BASE_URL: '' });
      assert.equal(calls.restore, 1);
    } finally {
      undo();
    }
  });
});
