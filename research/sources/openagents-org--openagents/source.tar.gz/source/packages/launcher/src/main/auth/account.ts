import { accountApiBase, apiBase, webBase } from "./endpoints"
import { authFetch } from "./http"
import { registrationPasswordError } from "../../shared/account-registration"
import {
  refreshIdToken,
  signInWithCustomToken,
  signInWithPassword as firebaseSignInWithPassword,
} from "./firebase-rest"
import { startHandoffServer, type Handoff } from "./handoff-server"
import {
  clearSession,
  isFresh,
  loadSession,
  saveSession,
  toAccountInfo,
  type AccountInfo,
  type AccountSession,
} from "./session-store"

/**
 * The signed-in user, as the main process holds them.
 *
 * Account identity lives here rather than in the renderer because two different
 * origins need it: the launcher's own UI (a file:// page) and the embedded
 * workspace view (https://workspace.openagents.org). Browser auth state is
 * per-origin and cannot be shared between them — only main can feed both.
 *
 * Signing in is a workspace-scoped gate, never an app-scoped one: everything
 * under My Agents works signed out, and nothing here is touched until the user
 * asks for something that is theirs (their workspaces, authorizing this
 * machine). See docs on the lazy gate in the desktop-workspace plan.
 */

/** One membership from GET /v1/account/workspaces. */
export interface AccountWorkspace {
  workspaceId: string
  name: string
  slug: string
  /** Shared workspace access token; null for a viewer or a tokenless workspace. */
  token: string | null
  role: "owner" | "admin" | "member" | "viewer"
  lastActivityAt: string | null
}

export interface AccountDeps {
  /** The configured workspace endpoint, if the user set one. */
  endpoint: () => string | undefined
  /** Hand a URL to the OS browser (web-security's openExternalSafely). */
  openExternal: (url: string) => void
  /** Told whenever the account appears, changes or goes away. */
  onChange: (account: AccountInfo | null) => void
}

/** A completed Tencent Captcha run, as its widget callback returns it. */
export interface CaptchaPass {
  ticket: string
  randstr: string
}

/** GET /v1/auth/captcha-config: whether the email forms must run the widget. */
export interface CaptchaConfig {
  enabled: boolean
  appId: string | null
  scriptUrl: string
  surfaces: { register?: boolean; login?: boolean }
}

const CAPTCHA_DISABLED: CaptchaConfig = { enabled: false, appId: null, scriptUrl: "", surfaces: {} }
const CAPTCHA_CONFIG_TTL_MS = 5 * 60 * 1000

/** Google's auth hosts are unreachable in China; that failure must read plainly. */
const FIREBASE_UNREACHABLE = "SIGN_IN_UNREACHABLE"

/** Codes the sign-in form turns into wording; see renderer/lib/account-errors. */
const BAD_CREDENTIALS = "SIGN_IN_BAD_CREDENTIALS"
const TOO_MANY_ATTEMPTS = "SIGN_IN_TOO_MANY_ATTEMPTS"
/**
 * The account service wants a human-verification pass (HTTP 428). The website
 * runs Tencent Cloud Captcha on its email forms and the same rule applies to
 * every client of those endpoints — the in-app form runs the widget too.
 */
const CAPTCHA_REQUIRED = "SIGN_IN_CAPTCHA_REQUIRED"

/**
 * There is no account service in front of this deployment — the only failure
 * Firebase is worth asking about. Anything else (a rejected password, a
 * handoff that would not mint) has already been answered by the service that
 * holds the account, and retrying it against Google would turn a true reason
 * into "wrong password".
 */
const NO_ACCOUNT_SERVICE = "SIGN_IN_NO_ACCOUNT_SERVICE"

/** Firebase's own names for "that is not a valid login". */
const REJECTION_PATTERN =
  /INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD|EMAIL_NOT_FOUND|USER_DISABLED|MISSING_PASSWORD/

/**
 * The browser round trip needs a page on the workspace site to come back
 * through. A deployment that predates it would land the user on a bare 404
 * saying "workspace not found", which explains nothing and looks like their
 * account is broken.
 */
const BROWSER_UNAVAILABLE = "SIGN_IN_BROWSER_UNAVAILABLE"

export class AccountManager {
  private _session: AccountSession | null = null
  private _loaded = false
  private _pending: Handoff | null = null
  private _sessionTimer: ReturnType<typeof setTimeout> | null = null
  private _renewal: { session: AccountSession; promise: Promise<string> } | null = null

  constructor(private _deps: AccountDeps) {}

  /** The account, or null. Reads the stored session on first use. */
  getAccount(): AccountInfo | null {
    this._ensureLoaded()
    return this._session ? toAccountInfo(this._session) : null
  }

  private _ensureLoaded(): void {
    if (this._loaded) return
    this._loaded = true
    this._session = loadSession()
    this._scheduleSessionCheck()
  }

  // An embedded workspace can stay open for days without another main-process
  // API call. Keep its bearer current and check again after system sleep.
  private _scheduleSessionCheck(): void {
    if (this._sessionTimer) clearTimeout(this._sessionTimer)
    this._sessionTimer = null
    if (!this._session) return
    this._sessionTimer = setTimeout(() => {
      this._sessionTimer = null
      void this.bearer().catch(() => {}).finally(() => this._scheduleSessionCheck())
    }, 60_000)
    this._sessionTimer.unref?.()
  }

  private _set(session: AccountSession | null): void {
    this._session = session
    this._loaded = true
    if (session) saveSession(session)
    else clearSession()
    this._scheduleSessionCheck()
    this._deps.onChange(session ? toAccountInfo(session) : null)
  }

  /**
   * Run a sign-in: open the central login in the user's browser and wait for
   * the callback page to hand the session back over loopback.
   *
   * The system browser, not an in-app window: Google refuses OAuth in an
   * embedded webview ("this browser is not secure"), and the user's existing
   * session there is usually what makes this one click.
   */
  async signIn(): Promise<AccountInfo> {
    // A second click while one is in flight replaces it — the first browser tab
    // is already stale, and leaving its port open would be a second live gate.
    this.cancelSignIn()

    const origin = webBase(this._deps.endpoint())
    // Checked before a port is opened and a browser is launched: without the
    // landing page there is no way back into the app, and finding that out
    // after the user has signed in wastes the whole trip.
    if (!(await landingPageExists(origin))) throw new Error(BROWSER_UNAVAILABLE)

    const handoff = await startHandoffServer(origin)
    this._pending = handoff

    // Straight to the workspace's own desktop landing page, NOT to the central
    // login: that login treats `returnTo` as where to go after minting its
    // one-time token and bouncing through /auth/callback, so a returnTo aimed
    // at the callback is taken as the destination and no token is minted at
    // all. /auth/desktop is an ordinary page, so it can send the user through
    // the login itself — and when the browser is already signed in to the
    // workspace, it skips that entirely and answers on the spot.
    this._deps.openExternal(
      `${origin}/auth/desktop?port=${handoff.port}&state=${encodeURIComponent(handoff.state)}`,
    )

    try {
      const result = await handoff.result
      if (result.error) throw new Error(result.error)

      if (result.session?.token && result.session.email) {
        this._set({
          kind: "workspace",
          token: result.session.token,
          email: result.session.email,
          displayName: result.session.displayName ?? null,
          expiresAt: result.session.expiresAt,
        })
      } else if (result.customToken) {
        this._set(await this._redeem(result.customToken))
      } else {
        throw new Error("SIGN_IN_EMPTY_HANDOFF")
      }
      return toAccountInfo(this._session!)
    } finally {
      handoff.close()
      if (this._pending === handoff) this._pending = null
    }
  }

  /**
   * The session as the embedded workspace view needs it — token included.
   *
   * Synchronous because the view's preload has to plant it before the page's
   * first script runs; callers that can afford to await should call `bearer()`
   * first so what is planted is freshly renewed.
   */
  embeddedSession(): {
    token: string
    email: string
    displayName: string | null
    expiresAt: number
  } | null {
    this._ensureLoaded()
    if (!this._session) return null
    const { token, email, displayName, expiresAt } = this._session
    return { token, email, displayName, expiresAt }
  }

  private _captchaConfig: { value: CaptchaConfig; at: number } | null = null

  /**
   * Whether the account service currently requires a captcha on its email
   * forms, and with which app id. Read once per few minutes; any failure reads
   * as "not required" — the service still answers 428 if it disagrees, and the
   * form turns that into a retry with the widget.
   */
  async captchaConfig(): Promise<CaptchaConfig> {
    const cached = this._captchaConfig
    if (cached && Date.now() - cached.at < CAPTCHA_CONFIG_TTL_MS) return cached.value
    let value = CAPTCHA_DISABLED
    try {
      const res = await authFetch(`${accountApiBase()}/v1/auth/captcha-config`, { method: "GET" })
      const json = (await res.json().catch(() => null)) as { data?: Partial<CaptchaConfig> } | null
      const d = json?.data
      if (res.ok && d?.enabled && d.appId && d.scriptUrl)
        value = { enabled: true, appId: String(d.appId), scriptUrl: d.scriptUrl, surfaces: d.surfaces || {} }
    } catch {
      value = CAPTCHA_DISABLED
    }
    this._captchaConfig = { value, at: Date.now() }
    return value
  }

  /**
   * Sign in with an email and password, without leaving the app.
   *
   * Three calls, the last two of which the browser sign-in already ends with:
   *
   *   POST endpoint.openagents.org/v1/auth/login             → account token
   *   POST endpoint.openagents.org/v1/auth/workspace-handoff → custom token
   *   POST workspace-endpoint.../v1/auth/session             → 30-day session
   *
   * This is precisely what openagents.org/login does — its form posts to the
   * first, and its "open workspace" mints the second. Nothing here needs Google,
   * so it works from mainland China, and nothing here is new server-side.
   *
   * Speaking to Firebase instead is what the launcher used to do, and it is
   * why a password the website accepts came back INVALID_LOGIN_CREDENTIALS:
   * the site keeps its email accounts in the service above, not in Firebase,
   * which now holds only the Google/GitHub/Apple identities. That path stays as
   * the fallback for a deployment with no account service in front of it.
   *
   * Only accounts with a password can use this at all. Google, GitHub and Apple
   * identities have none, and their providers refuse to authenticate inside an
   * app window, so those still need a real browser.
   */
  async signInWithPassword(
    email: string,
    password: string,
    captcha?: CaptchaPass,
  ): Promise<AccountInfo> {
    // A form submitted while a browser sign-in is pending replaces it: two
    // live gates would race to be the session.
    this.cancelSignIn()

    let session: AccountSession
    try {
      session = await this._passwordSession(email, password, captcha)
    } catch (err) {
      if ((err as Error)?.message !== NO_ACCOUNT_SERVICE) throw err
      session = await this._firebasePasswordSession(email, password)
    }
    this._set(session)
    return toAccountInfo(session)
  }

  /** Register through the same account service as openagents.org/signup. */
  async signUpWithPassword(
    email: string,
    password: string,
    displayName?: string,
    captcha?: CaptchaPass,
  ): Promise<AccountInfo> {
    const normalizedEmail = email.trim().toLowerCase()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail))
      throw new Error("SIGN_UP_INVALID_EMAIL")
    const passwordError = registrationPasswordError(password)
    if (passwordError) throw new Error(passwordError)
    this.cancelSignIn()

    const res = await authFetch(`${accountApiBase()}/v1/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: normalizedEmail,
        password,
        display_name: displayName?.trim() || undefined,
        captcha_ticket: captcha?.ticket,
        captcha_randstr: captcha?.randstr,
      }),
    })
    const json = (await res.json().catch(() => null)) as {
      code?: number
      data?: { access_token?: string }
      message?: string
    } | null
    if (res.status === 428 || json?.code === 428) throw new Error(CAPTCHA_REQUIRED)
    if (res.status === 429 || json?.code === 429) throw new Error(TOO_MANY_ATTEMPTS)
    if (!res.ok || json?.code !== 200) {
      if (res.status === 409 || /already (?:exists|registered)/i.test(json?.message || ""))
        throw new Error("SIGN_UP_EMAIL_EXISTS")
      throw new Error(json?.message || "SIGN_UP_FAILED")
    }

    // Registration already succeeded. If opening Workspace fails, the UI must
    // offer sign-in rather than ask the user to create the same account again.
    let session: AccountSession
    try {
      if (!json.data?.access_token) throw new Error("Missing account token")
      session = await this._redeem(await this._handoffToken(json.data.access_token))
    } catch {
      throw new Error("SIGN_UP_SESSION_FAILED")
    }
    this._set(session)
    return toAccountInfo(session)
  }

  /** The password half: credentials in, a workspace session out. */
  private async _passwordSession(
    email: string,
    password: string,
    captcha?: CaptchaPass,
  ): Promise<AccountSession> {
    const handoff = await this._handoffToken(
      await this._accountToken(email, password, captcha),
    )
    return this._redeem(handoff)
  }

  /** POST /v1/auth/login — the call the website's own sign-in form makes. */
  private async _accountToken(
    email: string,
    password: string,
    captcha?: CaptchaPass,
  ): Promise<string> {
    const res = await authFetch(`${accountApiBase()}/v1/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email,
        password,
        captcha_ticket: captcha?.ticket,
        captcha_randstr: captcha?.randstr,
      }),
    })
    if (res.status === 428) throw new Error(CAPTCHA_REQUIRED)
    if (res.status === 401) throw new Error(BAD_CREDENTIALS)
    if (res.status === 429) throw new Error(TOO_MANY_ATTEMPTS)
    if (res.status === 404) throw new Error(NO_ACCOUNT_SERVICE)
    const json = (await res.json().catch(() => null)) as {
      code?: number
      data?: { access_token?: string }
      message?: string
    } | null
    // This service reports itself twice — an HTTP status and a `code` in the
    // body — and the website checks both, so a 200 carrying a failure code is
    // a shape that happens.
    if (!res.ok || json?.code !== 200 || !json.data?.access_token)
      throw new Error(json?.message || `HTTP ${res.status}`)
    return json.data.access_token
  }

  /**
   * POST /v1/auth/workspace-handoff — trade the account token for the one-time
   * custom token that opens a workspace.
   *
   * The same token the browser round trip carries back, so from here on the two
   * sign-ins are the same code path.
   */
  private async _handoffToken(accountToken: string): Promise<string> {
    const res = await authFetch(
      `${accountApiBase()}/v1/auth/workspace-handoff`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accountToken}`,
        },
        body: "{}",
      },
    )
    const json = (await res.json().catch(() => null)) as {
      data?: { custom_token?: string }
      message?: string
    } | null
    if (!res.ok || !json?.data?.custom_token)
      throw new Error(json?.message || `HTTP ${res.status}`)
    return json.data.custom_token
  }

  /** Firebase, spoken directly — only where the account service is absent. */
  private async _firebasePasswordSession(
    email: string,
    password: string,
  ): Promise<AccountSession> {
    try {
      const tokens = await firebaseSignInWithPassword(email, password)
      return {
        kind: "firebase",
        token: tokens.idToken,
        refreshToken: tokens.refreshToken,
        email: tokens.email || email,
        displayName: tokens.displayName,
        expiresAt: tokens.expiresAt,
      }
    } catch (err) {
      throw new Error(translateFirebaseError((err as Error).message))
    }
  }

  /** Give the loopback port back without waiting for the browser. */
  cancelSignIn(): void {
    this._pending?.close()
    this._pending = null
  }

  signOut(): void {
    this.cancelSignIn()
    this._set(null)
  }

  /**
   * Turn the one-time custom token into a session we can keep.
   *
   * Both sign-ins end here: the password form mints its own handoff token, and
   * the browser round trip forwards one unspent when the callback page could
   * not spend it (an older front end, or a backend with no session secret).
   */
  private async _redeem(customToken: string): Promise<AccountSession> {
    try {
      return await this._mintWorkspaceSession(customToken)
    } catch (err) {
      // The session endpoint is the one that works everywhere; Firebase is the
      // consolation prize, and where it is blocked there is nothing left to try.
      console.error(
        "workspace session unavailable, falling back to Firebase:",
        (err as Error).message,
      )
    }
    try {
      const tokens = await signInWithCustomToken(customToken)
      return {
        kind: "firebase",
        token: tokens.idToken,
        refreshToken: tokens.refreshToken,
        email: tokens.email,
        displayName: tokens.displayName,
        expiresAt: tokens.expiresAt,
      }
    } catch (err) {
      const message = (err as Error).message
      throw new Error(
        /abort|fetch failed|network/i.test(message)
          ? FIREBASE_UNREACHABLE
          : message,
      )
    }
  }

  private async _mintWorkspaceSession(
    customToken: string,
  ): Promise<AccountSession> {
    const res = await authFetch(
      `${apiBase(this._deps.endpoint())}/v1/auth/session`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ custom_token: customToken }),
      },
    )
    const json = (await res.json().catch(() => null)) as {
      data?: SessionPayload
      message?: string
    } | null
    if (!res.ok || !json?.data?.session_token)
      throw new Error(json?.message || `HTTP ${res.status}`)
    return sessionFrom(json.data)
  }

  /**
   * The bearer to send, renewed if it is about to lapse.
   *
   * Renew workspace sessions during their last day, before the server refuses
   * them. Firebase ID tokens renew hourly. Truly expired workspace sessions
   * still require sign-in; no authentication checks are bypassed.
   */
  async bearer(): Promise<string> {
    this._ensureLoaded()
    const session = this._session
    if (!session) throw new Error("NOT_SIGNED_IN")
    if (isFresh(session) && (session.kind !== "workspace" || session.expiresAt - Date.now() / 1000 > 86400)) return session.token
    if (this._renewal?.session === session) return this._renewal.promise
    const promise = this._renewSession(session)
    this._renewal = { session, promise }
    try { return await promise }
    finally { if (this._renewal?.promise === promise) this._renewal = null }
  }

  private async _renewSession(session: AccountSession): Promise<string> {
    if (session.kind === "workspace" && isFresh(session)) {
      const res = await authFetch(`${apiBase(this._deps.endpoint())}/v1/auth/session/renew`, {
        method: "POST",
        headers: { Authorization: `Bearer ${session.token}` },
        signal: AbortSignal.timeout(15_000),
      })
      if (this._session !== session) throw new Error("SESSION_CHANGED")
      if (res.status === 401) {
        this._set(null)
        throw new Error("SESSION_EXPIRED")
      }
      const json = (await res.json().catch(() => null)) as { data?: SessionPayload } | null
      if (this._session !== session) throw new Error("SESSION_CHANGED")
      if (!res.ok || !json?.data?.session_token) throw new Error("SESSION_RENEWAL_UNAVAILABLE")
      const renewed = sessionFrom(json.data)
      if (renewed.email !== session.email || !Number.isFinite(renewed.expiresAt) || !isFresh(renewed))
        throw new Error("SESSION_RENEWAL_INVALID")
      this._set(renewed)
      return renewed.token
    }

    if (session.kind !== "firebase" || !session.refreshToken) {
      this._set(null)
      throw new Error("SESSION_EXPIRED")
    }
    try {
      const renewed = await refreshIdToken(session.refreshToken)
      if (this._session !== session) throw new Error("SESSION_CHANGED")
      this._set({ ...session, ...renewed, token: renewed.idToken })
      return renewed.idToken
    } catch {
      if (this._session === session) this._set(null)
      throw new Error("SESSION_EXPIRED")
    }
  }

  /**
   * The user's workspaces. The endpoint also reconciles legacy access and
   * gives a brand-new account an empty workspace to own, so a signed-in user
   * always has at least one.
   */
  async listWorkspaces(): Promise<AccountWorkspace[]> {
    return this._get<AccountWorkspace[]>("/v1/account/workspaces")
  }

  /**
   * Mint a pairing code for this device, as the signed-in user.
   *
   * This is the whole of "authorize this machine": the backend gains nothing
   * new — the same owner/admin-only endpoint the workspace UI calls — the
   * launcher just carries the code across instead of the user retyping it.
   * A member (below admin) is refused here, which is correct and is why the
   * manual code entry stays.
   */
  async createPairingCode(workspaceId: string): Promise<string> {
    const data = await this._request<{ code: string }>(
      `/v1/workspaces/${encodeURIComponent(workspaceId)}/pairing-codes`,
      { method: "POST", body: "{}" },
    )
    if (!data.code) throw new Error("PAIRING_CODE_MISSING")
    return data.code
  }

  private _get<T>(path: string): Promise<T> {
    return this._request<T>(path, { method: "GET" })
  }

  private async _request<T>(path: string, init: RequestInit): Promise<T> {
    const token = await this.bearer()
    const res = await authFetch(`${apiBase(this._deps.endpoint())}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    })
    const json = (await res.json().catch(() => null)) as {
      data?: T
      message?: string
    } | null
    if (res.status === 401) {
      // The server has the last word on whether we are still someone: drop the
      // session rather than leave the UI showing an account that cannot act.
      this._set(null)
      throw new Error("SESSION_EXPIRED")
    }
    if (!res.ok) throw new Error(json?.message || `HTTP ${res.status}`)
    return json?.data as T
  }
}

/** What both session endpoints return. */
interface SessionPayload {
  session_token?: string
  expires_at?: string
  email?: string
  display_name?: string | null
}

function sessionFrom(data: SessionPayload): AccountSession {
  return {
    kind: "workspace",
    token: data.session_token!,
    email: data.email || "",
    displayName: data.display_name ?? null,
    expiresAt: Math.floor(new Date(data.expires_at || 0).getTime() / 1000),
  }
}

/**
 * Whether this deployment serves /auth/desktop — the page a browser sign-in
 * returns through. Any answer other than "not there" counts as present: a
 * network blip must not be reported as a missing feature.
 */
async function landingPageExists(webOrigin: string): Promise<boolean> {
  try {
    const res = await authFetch(`${webOrigin}/auth/desktop`, { method: "GET" })
    return res.status !== 404
  } catch {
    return true
  }
}

function translateFirebaseError(message: string): string {
  if (REJECTION_PATTERN.test(message)) return BAD_CREDENTIALS
  if (/TOO_MANY_ATTEMPTS/i.test(message)) return TOO_MANY_ATTEMPTS
  if (/abort|fetch failed|network|ERR_/i.test(message))
    return FIREBASE_UNREACHABLE
  return message
}
