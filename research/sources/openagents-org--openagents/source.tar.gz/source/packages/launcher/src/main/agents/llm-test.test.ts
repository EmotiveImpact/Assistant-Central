import { EventEmitter } from "events"
import fs from "node:fs"
import path from "node:path"
import { describe, it, expect, beforeEach, vi } from "vitest"

/**
 * A scripted `net.request`: each call takes the next behaviour off the queue.
 * "silent" is a socket that accepts the request and then never answers — the
 * shape a stalled relay actually takes, and the only way to reach the timeout.
 */
type Behavior =
  | { kind: "ok"; status: number; body: string }
  | { kind: "error"; message: string }
  | { kind: "silent" }

let script: Behavior[] = []
let calls: Array<{
  url: string
  method: string
  headers: Record<string, string>
  body: string
}> = []

function makeFakeRequest(opts: { url: string; method: string }): EventEmitter {
  const call = {
    url: opts.url,
    method: opts.method,
    headers: {} as Record<string, string>,
    body: "",
  }
  calls.push(call)
  const req = new EventEmitter() as EventEmitter & {
    setHeader: (k: string, v: string) => void
    write: (b: string) => void
    abort: () => void
    end: () => void
  }
  req.setHeader = (k: string, v: string) => {
    call.headers[k.toLowerCase()] = v
  }
  req.write = (b: string) => {
    call.body = b
  }
  req.abort = () => {}
  req.end = () => {
    const next = script.shift() || { kind: "silent" as const }
    if (next.kind === "silent") return
    setTimeout(() => {
      if (next.kind === "error") {
        req.emit("error", new Error(next.message))
        return
      }
      const res = new EventEmitter() as EventEmitter & { statusCode: number }
      res.statusCode = next.status
      req.emit("response", res)
      setTimeout(() => {
        res.emit("data", Buffer.from(next.body, "utf-8"))
        res.emit("end")
      }, 0)
    }, 0)
  }
  return req
}

vi.mock("electron", () => ({
  net: {
    request: (opts: { url: string; method: string }) => makeFakeRequest(opts),
  },
}))

import { launcherAuthFields } from "./auth-specs"
import { withDefaultBase } from "./model-catalog"
import {
  httpRequestJson,
  httpRequestOnce,
  testLLMConnection,
} from "./llm-test"

/** A minimal OpenAI chat-completions answer. */
const CHAT_OK = (model = "m") =>
  JSON.stringify({
    model,
    choices: [{ message: { content: "Hi there, how are you?" } }],
  })
/** A minimal Anthropic messages answer. */
const MSG_OK = (model = "m") =>
  JSON.stringify({ model, content: [{ text: "Hi there, how are you?" }] })
const ok = (body: string) => ({ kind: "ok" as const, status: 200, body })

beforeEach(() => {
  script = []
  calls = []
})

describe("httpRequestJson", () => {
  it("retries once when nothing answered", async () => {
    script = [
      { kind: "error", message: "net::ERR_CONNECTION_RESET" },
      { kind: "ok", status: 200, body: '{"ok":true}' },
    ]
    const r = await httpRequestJson(
      "https://relay.example.com/v1/models",
      "GET",
      {},
      null,
    )
    expect(r.status).toBe(200)
    expect(calls).toHaveLength(2)
  })

  it("does not retry what the endpoint actually answered", async () => {
    // A 401 is the endpoint's verdict on the key. Asking twice wastes the
    // user's time and tells them nothing new.
    script = [{ kind: "ok", status: 401, body: "invalid key" }]
    const r = await httpRequestJson(
      "https://relay.example.com/v1/models",
      "GET",
      {},
      null,
    )
    expect(r.status).toBe(401)
    expect(calls).toHaveLength(1)
  })

  it("gives up after the retry rather than looping", async () => {
    script = [
      { kind: "error", message: "socket hang up" },
      { kind: "error", message: "socket hang up" },
    ]
    await expect(
      httpRequestJson("https://relay.example.com/v1/models", "GET", {}, null),
    ).rejects.toThrow(/socket hang up/)
    expect(calls).toHaveLength(2)
  })

  it("does not retry a URL that was never valid", async () => {
    await expect(httpRequestJson("not-a-url", "GET", {}, null)).rejects.toThrow(
      /Invalid URL/,
    )
    expect(calls).toHaveLength(0)
  })
})

describe("httpRequestOnce timeouts", () => {
  beforeEach(() => vi.useFakeTimers())

  it("waits longer on a POST than on a GET", async () => {
    // A GET lists models; a POST is a real completion a cold relay can sit on.
    script = [{ kind: "silent" }, { kind: "silent" }]

    const get = httpRequestOnce(
      "https://relay.example.com/v1/models",
      "GET",
      {},
      null,
    )
    const post = httpRequestOnce(
      "https://relay.example.com/v1/chat/completions",
      "POST",
      {},
      "{}",
    )
    const settled = { get: false, post: false }
    get.catch(() => (settled.get = true))
    post.catch(() => (settled.post = true))

    await vi.advanceTimersByTimeAsync(20_000)
    expect(settled).toEqual({ get: true, post: false })

    await vi.advanceTimersByTimeAsync(25_000)
    expect(settled).toEqual({ get: true, post: true })

    vi.useRealTimers()
  })
})

/**
 * Every agent that authenticates with an API key + base URL has to reach the
 * endpoint the AGENT will call — a vendor API, a relay, or a model gateway.
 *
 * The regressions these cover are all the same shape: a key variable that
 * matched no branch fell through to the generic OpenAI path and came back as
 * "No API key to test for this agent", with the key plainly in the form.
 */
describe("testLLMConnection Codex wire API", () => {
  const env = {
    OPENAI_API_KEY: "test-key",
    OPENAI_BASE_URL: "https://relay.example.com/v1",
    CODEX_MODEL: "test-model",
  }

  it.each([
    ["codex", "responses", "responses"],
    ["codex", "chat", "chat/completions"],
    ["openclaw", "responses", "chat/completions"],
  ])("routes the actual manager call for %s / %s", async (agentType, mode, endpoint) => {
    const { AgentManager } = await import("../agent-manager")
    script = [ok(endpoint === "responses" ? JSON.stringify({ output_text: "Hello" }) : CHAT_OK("test-model"))]
    // Invoke the real method without bootstrapping a daemon or reading credentials.
    const manager = Object.create(AgentManager.prototype) as InstanceType<typeof AgentManager>
    const result = await manager.testLLM({ ...env, CODEX_WIRE_API: mode }, agentType)
    expect(result.success).toBe(true)
    expect(calls).toHaveLength(1)
    expect(calls[0].url).toBe(`https://relay.example.com/v1/${endpoint}`)
  })

  it.each([
    { output_text: "Hello from Responses" },
    { output: [{ content: [{ type: "output_text", text: "Hello from Responses" }] }] },
  ])("uses Responses and reads its reply: %j", async (reply) => {
    script = [ok(JSON.stringify({ model: "test-model", ...reply }))]
    const result = await testLLMConnection(
      { ...env, CODEX_WIRE_API: "responses" },
      "codex",
    )
    expect(calls).toHaveLength(1)
    expect(calls[0].url).toBe("https://relay.example.com/v1/responses")
    expect(calls[0].method).toBe("POST")
    expect(calls[0].headers.authorization).toBe("Bearer test-key")
    expect(JSON.parse(calls[0].body)).toEqual({
      model: "test-model", input: "Say hi in 5 words.", max_output_tokens: 16,
    })
    expect(result).toEqual({
      success: true, model: "test-model", response: "Hello from Responses",
    })
  })

  it.each(["chat", "", undefined])("preserves Chat for mode %s", async (mode) => {
    script = [ok(CHAT_OK("test-model"))]
    const result = await testLLMConnection(
      { ...env, ...(mode === undefined ? {} : { CODEX_WIRE_API: mode }) },
      "codex",
    )
    expect(calls).toHaveLength(1)
    expect(calls[0].url).toBe("https://relay.example.com/v1/chat/completions")
    expect(JSON.parse(calls[0].body)).toEqual({
      model: "test-model", max_tokens: 16,
      messages: [{ role: "user", content: "Say hi in 5 words." }],
    })
    expect(result).toEqual({
      success: true, model: "test-model", response: "Hi there, how are you?",
    })
  })

  it("matches the Codex adapter's case-insensitive Responses mode", async () => {
    script = [ok(JSON.stringify({ output_text: "Hi" }))]
    const result = await testLLMConnection(
      { ...env, CODEX_WIRE_API: "RESPONSES" },
      "codex",
    )
    expect(calls).toHaveLength(1)
    expect(calls[0].url).toBe("https://relay.example.com/v1/responses")
    expect(result.response).toBe("Hi")
  })

  it("reports a rejected Responses request without falling back to Chat", async () => {
    script = [{ kind: "ok", status: 401, body: "invalid api key" }]
    const result = await testLLMConnection(
      { ...env, CODEX_WIRE_API: "responses" },
      "codex",
    )
    expect(calls).toHaveLength(1)
    expect(calls[0].url).toBe("https://relay.example.com/v1/responses")
    expect(result.success).toBe(false)
    expect(result.error).toContain("HTTP 401")
  })

  it.each(["opencode", "openclaw", undefined])(
    "ignores Codex mode for agent %s",
    async (agentType) => {
      script = [ok(CHAT_OK("test-model"))]
      const result = await testLLMConnection(
        { ...env, CODEX_WIRE_API: "responses" },
        agentType,
      )
      expect(result.success).toBe(true)
      expect(calls).toHaveLength(1)
      expect(calls[0].url).toBe("https://relay.example.com/v1/chat/completions")
      expect(JSON.parse(calls[0].body)).toHaveProperty("messages")
    },
  )

  it("discovers the model before probing Responses when no model is configured", async () => {
    script = [
      ok(JSON.stringify({ data: [{ id: "served-model" }] })),
      ok(JSON.stringify({ model: "served-model", output_text: "Hi" })),
    ]
    const result = await testLLMConnection(
      { ...env, CODEX_MODEL: "", CODEX_WIRE_API: "responses" },
      "codex",
    )
    expect(calls.map(({ method, url }) => ({ method, url }))).toEqual([
      { method: "GET", url: "https://relay.example.com/v1/models" },
      { method: "POST", url: "https://relay.example.com/v1/responses" },
    ])
    expect(JSON.parse(calls[1].body).model).toBe("served-model")
    expect(result).toEqual({ success: true, model: "served-model", response: "Hi" })
  })
})

describe("testLLMConnection routing", () => {
  // The form shows the registry's default base URL but an untouched field
  // never lands in its values, so the probe got none — and a MiMo key was
  // sent to api.openai.com and came back 401 "Incorrect API key provided".
  it("verifies a MiMo Code key with the base URL left blank against MiMo, not OpenAI", async () => {
    script = [ok(CHAT_OK("mimo-v2.6-pro"))]
    const r = await testLLMConnection(
      withDefaultBase("mimo-code", { LLM_API_KEY: "sk-mimo", LLM_MODEL: "mimo-v2.6-pro" }),
    )
    expect(r.success).toBe(true)
    expect(calls[0].url).toBe("https://api.xiaomimimo.com/v1/chat/completions")
    expect(calls[0].headers.authorization).toBe("Bearer sk-mimo")
  })

  it("keeps a base URL the user typed, and leaves agents without a default alone", () => {
    expect(
      withDefaultBase("mimo-code", { LLM_API_KEY: "k", LLM_BASE_URL: "https://token-plan-cn.xiaomimimo.com/v1" })
        .LLM_BASE_URL,
    ).toBe("https://token-plan-cn.xiaomimimo.com/v1")
    expect(withDefaultBase("opencode", { LLM_API_KEY: "k" })).toEqual({ LLM_API_KEY: "k" })
    expect(withDefaultBase("kimi", { KIMI_API_KEY: "k" }).KIMI_BASE_URL).toBe("https://api.moonshot.ai/v1")
  })

  it("probes OpenWorker's provider endpoint instead of reporting no key", async () => {
    script = [ok(CHAT_OK("deepseek-chat"))]
    const r = await testLLMConnection({
      OPENWORKER_PROVIDER: "deepseek",
      OPENWORKER_API_KEY: "sk-ow",
      OPENWORKER_MODEL: "deepseek-chat",
    })
    expect(r.success).toBe(true)
    expect(calls[0].url).toBe("https://api.deepseek.com/v1/chat/completions")
    expect(calls[0].headers.authorization).toBe("Bearer sk-ow")
  })

  it("sends OpenWorker at its base URL when one is configured", async () => {
    script = [ok(CHAT_OK())]
    await testLLMConnection({
      OPENWORKER_PROVIDER: "deepseek",
      OPENWORKER_API_KEY: "sk-ow",
      OPENWORKER_BASE_URL: "https://relay.example.com/v1",
      OPENWORKER_MODEL: "glm-5",
    })
    // The relay's own /v1 is not doubled — …/v1/v1/chat/completions is a 404
    // that reads like a dead endpoint.
    expect(calls[0].url).toBe(
      "https://relay.example.com/v1/chat/completions",
    )
  })

  it("asks a keyless local OpenWorker provider without an auth header", async () => {
    script = [ok(CHAT_OK())]
    const r = await testLLMConnection({
      OPENWORKER_PROVIDER: "ollama",
      OPENWORKER_MODEL: "llama3",
    })
    expect(r.success).toBe(true)
    expect(calls[0].url).toBe("http://localhost:11434/v1/chat/completions")
    expect(calls[0].headers.authorization).toBeUndefined()
  })

  it("probes Goose at its configured host", async () => {
    script = [ok(CHAT_OK())]
    const r = await testLLMConnection({
      GOOSE_PROVIDER: "openai",
      GOOSE_PROVIDER__API_KEY: "sk-goose",
      GOOSE_PROVIDER__HOST: "https://gw.example.com/v1",
      GOOSE_MODEL: "glm-5",
    })
    expect(r.success).toBe(true)
    expect(calls[0].url).toBe("https://gw.example.com/v1/chat/completions")
  })

  it("names the missing endpoint for a Goose provider it cannot reach", async () => {
    const r = await testLLMConnection({
      GOOSE_PROVIDER: "bedrock",
      GOOSE_PROVIDER__API_KEY: "sk-goose",
    })
    expect(r.success).toBe(false)
    expect(r.error).toMatch(/GOOSE_PROVIDER__HOST/)
    expect(r.error).not.toMatch(/No API key/i)
  })

  it("reports CodeBuddy as untestable rather than failed", async () => {
    const r = await testLLMConnection({
      CODEBUDDY_API_KEY: "sk-demo-abc",
      CODEBUDDY_MODEL: "deepseek-v4-pro",
    })
    // Not a failure: there is nothing here to test. Callers advance on this,
    // and render it neutrally — a wizard that only moved on `success` left
    // CodeBuddy users unable to finish setup at all.
    expect(r.unsupported).toBe(true)
    expect(r.reason).toBe("codebuddy")
    // The bug this replaces: a filled-in key reported as no key at all. The
    // wording now lives in the renderer's locale files, so main carries none.
    expect(r.error).toBeUndefined()
    expect(calls).toHaveLength(0)
  })

  it("marks every hosted platform the same way", async () => {
    const cases: Array<[Record<string, string>, string]> = [
      [{ CURSOR_API_KEY: "k" }, "cursor"],
      [{ AMP_API_KEY: "k" }, "amp"],
      [{ COMMAND_CODE_API_KEY: "k" }, "commandcode"],
      [{ COPILOT_GITHUB_TOKEN: "k" }, "copilot"],
      [{ CLAUDE_CODE_OAUTH_TOKEN: "k" }, "claudeOauth"],
    ]
    for (const [env, reason] of cases) {
      const r = await testLLMConnection(env)
      expect(r).toMatchObject({ success: false, unsupported: true, reason })
    }
    expect(calls).toHaveLength(0)
  })

  it("reads DEEPSEEK_API_BASE as the endpoint to probe", async () => {
    script = [ok(CHAT_OK())]
    await testLLMConnection({
      DEEPSEEK_API_KEY: "sk-ds",
      DEEPSEEK_API_BASE: "https://relay.example.com/v1",
      DEEPSEEK_MODEL: "deepseek-chat",
    })
    expect(calls[0].url).toBe("https://relay.example.com/v1/chat/completions")
  })

  it("probes DeepSeek Harness over the Anthropic API, mapping DeepSeek's OpenAI root", async () => {
    script = [ok(MSG_OK("deepseek-flash"))]
    await testLLMConnection({
      DEEPSEEK_API_KEY: "sk-ds",
      DEEPSEEK_BASE_URL: "https://api.deepseek.com",
      DEEPSEEK_MODEL: "deepseek-flash",
    })
    expect(calls[0].url).toBe("https://api.deepseek.com/anthropic/v1/messages")
  })

  it("probes a DeepSeek Harness gateway as typed", async () => {
    script = [ok(MSG_OK("deepseek-flash"))]
    await testLLMConnection({
      DEEPSEEK_API_KEY: "sk-ds",
      DEEPSEEK_BASE_URL: "https://relay.example.com/anthropic",
      DEEPSEEK_MODEL: "deepseek-flash",
    })
    expect(calls[0].url).toBe("https://relay.example.com/anthropic/v1/messages")
  })

  it("probes a versioned DeepSeek Harness gateway over chat completions", async () => {
    script = [ok(CHAT_OK("deepseek-v4-flash"))]
    await testLLMConnection({
      DEEPSEEK_API_KEY: "sk-oa",
      DEEPSEEK_BASE_URL: "https://api-gateway.openagents.org/v1",
      DEEPSEEK_MODEL: "deepseek-v4-flash",
    })
    expect(calls[0].url).toBe("https://api-gateway.openagents.org/v1/chat/completions")
  })

  it("probes Aider's endpoint once its provider is named", async () => {
    script = [ok(CHAT_OK())]
    const r = await testLLMConnection({
      AIDER_PROVIDER: "openai-compatible",
      LLM_API_KEY: "sk-aider",
      LLM_BASE_URL: "https://relay.example.com/v1",
      AIDER_MODEL: "openai/glm-5",
    })
    expect(r.success).toBe(true)
    // The LiteLLM provider prefix is stripped: the endpoint wants the bare id.
    expect(JSON.parse(calls[0].body).model).toBe("glm-5")
  })

  it("sends a relay both Anthropic auth headers", async () => {
    script = [ok(MSG_OK())]
    await testLLMConnection({
      ANTHROPIC_API_KEY: "sk-ant",
      ANTHROPIC_BASE_URL: "https://relay.example.com",
      ANTHROPIC_MODEL: "claude-sonnet-4-6",
    })
    // Which header a proxy honours is not knowable from here, and sending only
    // the wrong one is a 401 that reads as a bad key.
    expect(calls[0].headers["x-api-key"]).toBe("sk-ant")
    expect(calls[0].headers.authorization).toBe("Bearer sk-ant")
  })

  it("uses only x-api-key against Anthropic itself", async () => {
    script = [ok(MSG_OK())]
    await testLLMConnection({ ANTHROPIC_API_KEY: "sk-ant" })
    expect(calls[0].headers["x-api-key"]).toBe("sk-ant")
    expect(calls[0].headers.authorization).toBeUndefined()
  })
})

describe("testLLMConnection model handling", () => {
  it("asks the endpoint what it serves when no model is configured", async () => {
    script = [
      ok(JSON.stringify({ data: [{ id: "glm-5" }, { id: "kimi-k2.6" }] })),
      ok(CHAT_OK("glm-5")),
    ]
    const r = await testLLMConnection({
      OPENAI_API_KEY: "sk-gw",
      OPENAI_BASE_URL: "https://api-gateway.example.org/v1",
    })
    expect(r.success).toBe(true)
    expect(calls[0]).toMatchObject({
      url: "https://api-gateway.example.org/v1/models",
      method: "GET",
    })
    // Not the hardcoded gpt-4o-mini, which no gateway serves.
    expect(JSON.parse(calls[1].body).model).toBe("glm-5")
  })

  it("falls back to the vendor default when an endpoint lists nothing", async () => {
    script = [{ kind: "ok", status: 404, body: "nope" }, ok(CHAT_OK())]
    await testLLMConnection({
      OPENAI_API_KEY: "sk-gw",
      OPENAI_BASE_URL: "https://gw.example.com/v1",
    })
    expect(JSON.parse(calls[1].body).model).toBe("gpt-4o-mini")
  })

  it("does not ask a vendor's own API for a list", async () => {
    // OpenAI's catalogue is long, arbitrarily ordered, and mixed with models
    // that cannot answer a completion — its known-good default is better.
    script = [ok(CHAT_OK())]
    await testLLMConnection({ OPENAI_API_KEY: "sk-openai" })
    expect(calls).toHaveLength(1)
    expect(JSON.parse(calls[0].body).model).toBe("gpt-4o-mini")
  })

  it("skips catalogue entries that cannot answer a completion", async () => {
    script = [
      ok(
        JSON.stringify({
          data: [
            { id: "text-embedding-3-small" },
            { id: "whisper-1" },
            { id: "glm-5" },
          ],
        }),
      ),
      ok(CHAT_OK("glm-5")),
    ]
    await testLLMConnection({
      LLM_API_KEY: "sk-gw",
      LLM_BASE_URL: "https://gw.example.com/v1",
    })
    expect(JSON.parse(calls[1].body).model).toBe("glm-5")
  })

  it("does not ask for a list when the model is already chosen", async () => {
    script = [ok(CHAT_OK("glm-5"))]
    await testLLMConnection({
      LLM_API_KEY: "sk-gw",
      LLM_BASE_URL: "https://api-gateway.example.org/v1",
      LLM_MODEL: "glm-5",
    })
    expect(calls).toHaveLength(1)
    expect(calls[0].method).toBe("POST")
  })

  it("explains a rejected model instead of echoing raw JSON", async () => {
    script = [
      {
        kind: "ok",
        status: 400,
        body: JSON.stringify({
          detail:
            "Model 'gpt-4o-mini' is not available. This gateway only allows: glm-5, kimi-k2.6",
        }),
      },
    ]
    const r = await testLLMConnection({
      LLM_API_KEY: "sk-gw",
      LLM_BASE_URL: "https://api-gateway.example.org/v1",
      LLM_MODEL: "gpt-4o-mini",
    })
    expect(r.success).toBe(false)
    expect(r.error).toMatch(/doesn't serve 'gpt-4o-mini'/)
    expect(r.error).toMatch(/glm-5/)
  })

  // A reasoning model can spend the test's small token budget thinking, and
  // OpenAI refuses with this. The key and the model were both accepted.
  it("passes a model that ran out of tokens while thinking", async () => {
    script = [
      {
        kind: "ok",
        status: 400,
        body: JSON.stringify({
          error: {
            message:
              "Could not finish the message because max_tokens or model output limit was reached. Please try again with higher max_tokens.",
            type: "invalid_request_error",
          },
        }),
      },
    ]
    const r = await testLLMConnection({
      LLM_API_KEY: "sk-gw",
      LLM_BASE_URL: "https://api-gateway.example.org/v1",
      LLM_MODEL: "gpt-6-sol",
    })
    expect(r.success).toBe(true)
    expect(r.model).toBe("gpt-6-sol")
    expect(calls).toHaveLength(1)
  })
})

/**
 * The drift guard.
 *
 * Every bug this file's routing tests describe had the same cause: an agent
 * was given a credential field in the registry (or in the launcher's own auth
 * overrides) and nobody taught the connection test that the field exists. The
 * agent then fell through every branch to the generic OpenAI path, which
 * answered "No API key to test for this agent" — about a form with a key in it.
 *
 * So rather than listing the agents we happen to have fixed, walk the SAME
 * sources the Configure dialog builds its form from, fill every credential
 * field, and assert the test never claims there is no key. A new agent with a
 * new `*_API_KEY` fails here on the day it is added.
 */
describe("no agent with credential fields reports a missing key", () => {
  const registryDir = path.resolve(process.cwd(), "../../registry")
  const entries = fs
    .readdirSync(registryDir)
    .filter((f) => f.endsWith(".json") && f !== "index.json")
    .map((f) => ({
      type: f.replace(/\.json$/, ""),
      def: JSON.parse(fs.readFileSync(path.join(registryDir, f), "utf-8")),
    }))

  const isCredential = (name: string) => /_API_KEY$|_KEY$|_TOKEN$/.test(name)

  /** The fields the launcher actually renders: its override, else the registry. */
  const formFields = (type: string, def: Record<string, unknown>) =>
    (launcherAuthFields(type) ||
      (def.env_config as Array<Record<string, unknown>>) ||
      []) as Array<Record<string, unknown>>

  /** A form where every field a user could fill in IS filled in. */
  const filledEnv = (
    fields: Array<Record<string, unknown>>,
  ): Record<string, string> => {
    const env: Record<string, string> = {}
    for (const f of fields) {
      const name = String(f.name || "")
      if (!name) continue
      if (f.password || isCredential(name)) env[name] = "sk-test"
      else if (/BASE_URL$|_HOST$|_URL$|_API_BASE$/.test(name))
        env[name] = "https://relay.example.com/v1"
      else if (/PROVIDER$/.test(name))
        env[name] = String(
          f.default || (f.options as string[] | undefined)?.[0] || "openai",
        )
      else if (/MODEL/.test(name)) env[name] = "test-model"
      else if (f.default !== undefined) env[name] = String(f.default)
    }
    return env
  }

  for (const { type, def } of entries) {
    const fields = formFields(type, def)
    const hasCredential = fields.some((f) =>
      isCredential(String(f.name || "")),
    )
    const test = hasCredential ? it : it.skip
    test(`${type}`, async () => {
      // Deep enough for a model list plus the completion, whatever the route.
      script = Array.from({ length: 6 }, () => ok(CHAT_OK()))
      const r = await testLLMConnection(filledEnv(fields))
      expect(r.error || "").not.toMatch(/No API key to test/i)
    })
  }
})

/**
 * A gateway's catalogue and what its backend will actually serve are not the
 * same set. Measured against the OpenAgents credits gateway (2026-09-12),
 * roughly half of the models it advertises answer `model not found`.
 */
describe("testLLMConnection against a catalogue with dead entries", () => {
  const dead = {
    kind: "ok" as const,
    status: 404,
    body: JSON.stringify({
      detail: 'Backend API error: {"error":{"message":"model not found"}}',
    }),
  }

  it("moves on to the next advertised model when one isn't really there", async () => {
    script = [
      ok(JSON.stringify({ data: [{ id: "alibaba-qwen3-32b" }, { id: "deepseek-3.2" }] })),
      dead,
      ok(CHAT_OK("deepseek-3.2")),
    ]
    const r = await testLLMConnection({
      LLM_API_KEY: "sk-gw",
      LLM_BASE_URL: "https://api-gateway.example.org/v1",
    })
    expect(r.success).toBe(true)
    expect(r.model).toBe("deepseek-3.2")
  })

  it("blames the catalogue, not the key, when none of them resolve", async () => {
    script = [
      ok(JSON.stringify({ data: [{ id: "a" }, { id: "b" }] })),
      dead,
      dead,
      dead,
    ]
    const r = await testLLMConnection({
      LLM_API_KEY: "sk-gw",
      LLM_BASE_URL: "https://api-gateway.example.org/v1",
    })
    expect(r.success).toBe(false)
    expect(r.error).toMatch(/lists models it doesn't serve/)
    expect(r.error).toMatch(/key and the endpoint look reachable/)
  })

  it("never substitutes a model the user typed", async () => {
    // Silently testing a different model would make the verdict a lie about
    // the config actually being saved.
    script = [dead, dead]
    const r = await testLLMConnection({
      LLM_API_KEY: "sk-gw",
      LLM_BASE_URL: "https://api-gateway.example.org/v1",
      LLM_MODEL: "glm-5",
    })
    expect(r.success).toBe(false)
    expect(calls).toHaveLength(1)
    expect(r.error).toMatch(/doesn't serve 'glm-5'/)
  })

  it("stops at a bad key instead of retrying every model", async () => {
    script = [
      ok(JSON.stringify({ data: [{ id: "a" }, { id: "b" }, { id: "c" }] })),
      { kind: "ok", status: 401, body: '{"error":{"message":"invalid api key"}}' },
    ]
    const r = await testLLMConnection({
      LLM_API_KEY: "sk-bad",
      LLM_BASE_URL: "https://api-gateway.example.org/v1",
    })
    expect(r.success).toBe(false)
    expect(r.error).toMatch(/401/)
    // One list + one rejected completion. Not four.
    expect(calls).toHaveLength(2)
  })
})
