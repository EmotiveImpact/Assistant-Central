// ── Launcher self-update (electron-updater) ──
//
// Updates the Electron *app itself* from GitHub Releases. This is distinct from
// the agent-launcher npm "core library" update (see ensureCoreLibrary /
// checkCoreUpdate in index.ts) and from per-agent updates — those keep the
// runtime fresh, but historically the app shell could only be updated by
// uninstalling and reinstalling. This module gives the renderer a
// check → download → restart-to-install flow.
//
// Update metadata (latest.yml / latest-mac.yml / latest-linux.yml + .blockmap)
// must be present in the GitHub Release alongside the installers — see
// .github/workflows/desktop-build.yml.
import path from "path"
import { app, ipcMain, type BrowserWindow } from "electron"
import electronUpdater, {
  type UpdateInfo,
  type ProgressInfo,
  type UpdateDownloadedEvent,
} from "electron-updater"
import { launchWindowsUpdateInstaller } from "./windows-update-installer"
import { DEFAULT_LAUNCHER_FEED, launcherFeedUrl } from "./mirror"
import { fetchReleaseNotes } from "./release-notes"
import type { Release } from "../shared/changelog"
import {
  adoptDifferentialBaseFile,
  clearInstallAttempt,
  compareVersions,
  hasVerifiedStagedUpdate,
  purgeLegacyUpdaterCache,
  purgePendingUpdateCache,
  readUpdaterCacheDirName,
  recordInstallAttempt,
  reconcileInstallAttempt,
  redirectUpdaterCacheToAsciiPath,
} from "./updater-cache"

// updaterCacheDirName before the "OpenAgents Launcher" → "OpenAgents" rename.
const LEGACY_CACHE_DIR_NAME = "openagents-launcher-updater"

// electron-updater ships CJS; grab autoUpdater off the default export so this
// keeps working whether the bundler emits ESM-interop or a bare require().
const { autoUpdater } = electronUpdater

export type UpdaterStatus =
  | "idle"
  | "checking"
  | "available"
  | "not-available"
  | "downloading"
  | "downloaded"
  | "error"

export interface UpdaterState {
  status: UpdaterStatus
  currentVersion: string
  latestVersion: string | null
  percent: number
  bytesPerSecond: number
  releaseNotes: string | null
  error: string | null
  // false when self-update can't run (dev build, no update metadata, etc.) —
  // the renderer falls back to a "download from website" hint.
  supported: boolean
  // Platform-specific "get the latest build" link, used by the renderer's
  // download-page fallback. Resolved in main where process.platform/arch are
  // authoritative (the renderer can't reliably tell Apple Silicon from Intel).
  downloadUrl: string
  // Set when we handed a version to the installer and came back up still on the
  // old one — the in-app update silently did nothing. The renderer turns this
  // into a "download it manually" prompt instead of letting the user retry a
  // path that has already failed twice.
  installFailedVersion: string | null
  // What the offered version actually changes, fetched from the feed — the
  // bundled changelog only covers the version already running, and the feed's
  // latest.yml carries no notes of its own. Null while it is still loading, or
  // when the release published none.
  pendingRelease: Release | null
  /** The offer waits for this lookup so its first frame includes the notes. */
  pendingReleaseLoading: boolean
  // The "Download updates automatically" setting. Carried on the state rather
  // than read from settings by each component, because it decides WHICH surface
  // announces an update: on, and the banner reports the download already
  // running; off, and the prompt asks first. Two components reading it
  // separately could disagree, and the pair that disagrees is a banner
  // announcing what the prompt is still asking.
  autoDownload: boolean
}

// Where the download-page fallback points, per OS/arch. Linux has no dedicated
// endpoint yet, so it keeps the GitHub Releases page.
const GITHUB_RELEASES_URL =
  "https://github.com/openagents-org/openagents/releases"

function resolveDownloadUrl(): string {
  if (process.platform === "win32") {
    return "https://openagents.org/api/download/launcher/windows"
  }
  if (process.platform === "darwin") {
    return process.arch === "arm64"
      ? "https://openagents.org/api/download/launcher/mac"
      : "https://openagents.org/api/download/launcher/mac-intel"
  }
  return GITHUB_RELEASES_URL
}

let _state: UpdaterState = {
  status: "idle",
  currentVersion: "0.0.0",
  latestVersion: null,
  percent: 0,
  bytesPerSecond: 0,
  releaseNotes: null,
  error: null,
  supported: false,
  downloadUrl: resolveDownloadUrl(),
  installFailedVersion: null,
  pendingRelease: null,
  pendingReleaseLoading: false,
  autoDownload: true,
}

let _getWindow: () => BrowserWindow | null = () => null
let _log: (msg: string) => void = () => {}
let _ipcRegistered = false
// Reads the persisted "Automatic updates" setting. When true, background checks
// auto-download the update; installing it always waits for the user to say so.
let _isAutoUpdateEnabled: () => boolean = () => false
// Fired once a background auto-download finishes, so the main process can notify
// the user and offer a "restart to update now" affordance (tray + banner).
let _onDownloaded: (version: string) => void = () => {}
// electron-updater exposes the verified NSIS path on update-downloaded. Keep it
// so Windows can use a Unicode-safe handoff when %LOCALAPPDATA% contains a
// non-ASCII username.
let _downloadedFile: string | null = null
// Resolved staging location for downloaded packages, so a failed install can
// purge the poisoned package instead of letting electron-updater replay it.
let _cacheRoot: string | null = null
let _cacheDirName: string | null = null
// True while a user-supplied mirror is in effect, so clearing the setting can
// restore the packaged origin (electron-updater has no "unset feed" API).
let _feedOverridden = false
// The origin installers are actually coming from. Release notes are published
// beside them, so they follow the mirror rather than always hitting the default.
let _feedBase = DEFAULT_LAUNCHER_FEED
// Version whose notes we have already asked for, so the repeated checks that
// re-announce the same update don't refetch them every half hour.
let _notesRequestedFor: string | null = null
// Version we've already written an install-attempt marker for this session.
let _attemptRecordedFor: string | null = null
// Guards against two downloads of the same package running at once — the
// background auto-download and a user pressing Download can otherwise overlap.
let _downloadInFlight = false
let _availabilitySequence = 0
// Path to the updater config electron-updater will actually read:
// resources/app-update.yml when packaged, dev-app-update.yml otherwise. Falls
// back to the packaged location if the adapter shape ever changes.
function updaterConfigPath(): string {
  try {
    return (autoUpdater as unknown as { app: { appUpdateConfigPath: string } })
      .app.appUpdateConfigPath
  } catch {
    return path.join(process.resourcesPath, "app-update.yml")
  }
}

// Leave a marker saying we're handing `version` to the installer, so the next
// launch can tell a real install from a silent no-op.
function noteInstallAttempt(version: string): void {
  if (_attemptRecordedFor === version) return
  _attemptRecordedFor = version
  recordInstallAttempt(app.getPath("userData"), version)
}
// Runs right before quitAndInstall so the daemon + agent subprocesses are torn
// down first. On Windows the NSIS installer can't overwrite the app while a
// child process (the daemon) still holds a lock on files under the install dir —
// the overwrite silently fails and the relaunch comes back on the OLD version.
// Must be awaited before handing off to the installer.
let _beforeInstall: () => Promise<void> = async () => {}
// Undoes _beforeInstall when the handoff fails and we stay running: the daemon
// is already stopped at that point, so without this the user is left in a
// half-torn-down app with every agent offline and no indication why.
let _resumeAfterFailedInstall: () => Promise<void> = async () => {}

function emit(patch: Partial<UpdaterState>): void {
  _state = { ..._state, ...patch }
  const win = _getWindow()
  if (win && !win.isDestroyed()) {
    win.webContents.send("updater:event", _state)
  }
}

function normalizeReleaseNotes(
  notes: UpdateInfo["releaseNotes"],
): string | null {
  if (!notes) return null
  if (typeof notes === "string") return notes
  // Array<{ version, note }> for the cumulative-notes case.
  return notes
    .map((n) => (n.note ? `## ${n.version}\n${n.note}` : `## ${n.version}`))
    .join("\n\n")
}

/**
 * The single place a download starts. electron-updater's own `autoDownload` is
 * pinned off (see setupAutoUpdater) because it is read inside checkForUpdates(),
 * which meant the answer to "should this download by itself?" depended on
 * whichever code path had set the flag last. Opening Settings → Updates runs a
 * check that used to force it off, so a user with automatic updates ON got
 * "found v0.8.22" and then nothing — the reported behaviour exactly. Deciding
 * here, on the event, removes that coupling entirely.
 */
async function startDownload(reason: string, restoringCache = false): Promise<void> {
  if (_downloadInFlight) return
  // Already staged — a second download would just re-verify the same file.
  if (_state.status === "downloaded") return
  _downloadInFlight = true
  _log(`[updater] downloading v${_state.latestVersion ?? "?"} (${reason})`)
  if (!restoringCache) emit({ status: "downloading", percent: 0, error: null })
  try {
    await autoUpdater.downloadUpdate()
  } catch (err) {
    _log(`[updater] download failed: ${(err as Error).message}`)
    emit({ status: "error", error: (err as Error).message })
  } finally {
    _downloadInFlight = false
  }
}

/**
 * Push the current setting onto the state. Called at startup and whenever the
 * user changes it, so the renderer never has to ask a second source.
 */
export function refreshUpdatePreference(): void {
  const autoDownload = _isAutoUpdateEnabled()
  if (_state.autoDownload === autoDownload) return
  emit({ autoDownload })
}

/**
 * Fetch the offered version's notes once and fold them into the state. Failure
 * is not reported to the user: the update itself is still on offer, and a
 * missing changelog is not something they can act on.
 */
function loadPendingRelease(version: string): void {
  if (_notesRequestedFor === version) return
  _notesRequestedFor = version
  void fetchReleaseNotes(version, _feedBase, _log).catch(() => null).then((release) => {
    // A newer check may have moved on to a different version while this was in
    // flight; publishing stale notes next to a different version number would
    // be worse than publishing none.
    if (_state.latestVersion !== version) return
    emit({ pendingRelease: release, pendingReleaseLoading: false })
  })
}

function wireEvents(): void {
  autoUpdater.on("checking-for-update", () => {
    // A periodic check must not unmount an active offer or hide a staged update.
    if (["available", "downloading", "downloaded"].includes(_state.status)) return
    emit({ status: "checking", error: null })
  })
  autoUpdater.on("update-available", (info: UpdateInfo) => {
    _log(`[updater] update available: v${info.version}`)
    const sequence = ++_availabilitySequence
    const sameVersion = _state.latestVersion === info.version
    if (
      sameVersion &&
      ((_state.status === "downloaded" && _downloadedFile) ||
        (_state.status === "downloading" && _downloadInFlight))
    ) {
      return
    }
    if (!sameVersion) _downloadedFile = null
    const notesPending =
      _notesRequestedFor !== info.version || _state.pendingReleaseLoading
    const available: Partial<UpdaterState> = {
      status: "available",
      latestVersion: info.version,
      releaseNotes: normalizeReleaseNotes(info.releaseNotes),
      error: null,
      // A different version than the one that failed is worth another try —
      // clear the "install manually" hint so it doesn't stick forever.
      installFailedVersion:
        _state.installFailedVersion === info.version
          ? _state.installFailedVersion
          : null,
      // Notes belong to the version they were fetched for.
      pendingRelease:
        _state.latestVersion === info.version ? _state.pendingRelease : null,
      pendingReleaseLoading: notesPending,
    }
    // Applies to every check — background, startup, or the one Settings fires
    // when the Updates section opens. "Automatic updates" is a user setting
    // about downloads, not about which screen happened to trigger the check.
    if (_isAutoUpdateEnabled()) {
      emit(available)
      loadPendingRelease(info.version)
      void startDownload("automatic updates are on")
    } else {
      emit({ ...available, status: sameVersion ? _state.status : "checking" })
      loadPendingRelease(info.version)
      // An explicit Quit leaves the verified installer in electron-updater's
      // cache. Recover it before offering a second download on next launch.
      const hashes = info.files.map((file) => file.sha512).filter((hash): hash is string => !!hash)
      void hasVerifiedStagedUpdate(_cacheRoot, _cacheDirName, hashes).then((cached) => {
        if (sequence !== _availabilitySequence) return
        if (cached) {
          void startDownload("restoring verified cached update", true)
        } else {
          emit(available)
        }
      })
    }
  })
  autoUpdater.on("update-not-available", (info: UpdateInfo) => {
    ++_availabilitySequence
    emit({
      status: "not-available",
      latestVersion:
        compareVersions(info.version, _state.currentVersion) < 0
          ? _state.currentVersion
          : info.version,
      error: null,
      pendingRelease: null,
      pendingReleaseLoading: false,
    })
  })
  autoUpdater.on("download-progress", (p: ProgressInfo) => {
    emit({
      status: "downloading",
      percent: Math.round(p.percent),
      bytesPerSecond: Math.round(p.bytesPerSecond),
    })
  })
  autoUpdater.on("update-downloaded", (info: UpdateDownloadedEvent) => {
    ++_availabilitySequence
    _downloadedFile = info.downloadedFile
    _log(`[updater] update downloaded: v${info.version}`)
    // A restart-to-install offer needs the notes as much as the first one did —
    // a user who dismissed the banner earlier meets this one cold.
    loadPendingRelease(info.version)
    emit({
      status: "downloaded",
      percent: 100,
      latestVersion: info.version,
      releaseNotes: normalizeReleaseNotes(info.releaseNotes),
    })
    try {
      _onDownloaded(info.version)
    } catch {}
  })
  autoUpdater.on("error", (err: Error) => {
    _log(`[updater] error: ${err.message}`)
    emit({ status: "error", error: err.message })
  })
}

/**
 * The handoff failed and we are still running. Put the app back into a usable
 * state and tell the renderer to stop offering a restart that does nothing —
 * quitting into an installer that never starts is precisely the "launcher just
 * exits and nothing happens" the user hit.
 */
async function abortInstall(detail: string): Promise<void> {
  _log(`[updater] ERROR install handoff failed: ${detail}`)
  ;(app as typeof app & { isQuitting: boolean }).isQuitting = false
  // A package we could not even start must not trigger a later install.
  autoUpdater.autoInstallOnAppQuit = false
  // We never reached the installer, so the attempt marker would make the next
  // launch report a phantom failed install.
  clearInstallAttempt(app.getPath("userData"))
  _attemptRecordedFor = null
  // Keeps `status: "downloaded"`, so the banner and Settings both switch to the
  // "install it manually" variant instead of silently dropping the update.
  emit({ error: detail, installFailedVersion: _state.latestVersion })
  try {
    await _resumeAfterFailedInstall()
  } catch (err) {
    _log(`[updater] failed to resume after aborted install: ${(err as Error).message}`)
  }
}

// Tear down agents/daemon, then hand off to the installer. Shared by the
// Settings "Restart to install" button and the tray item so BOTH paths release
// the file locks that would otherwise make the Windows overwrite install fail.
// Returns false when the app should stay up because nothing was launched.
async function quitAndInstallSafely(): Promise<boolean> {
  // Mark quitting so the window `close` handler really quits (instead of hiding
  // to tray) and the before-quit teardown runs.
  ;(app as typeof app & { isQuitting: boolean }).isQuitting = true
  try {
    await _beforeInstall()
  } catch (err) {
    _log(`[updater] beforeInstall failed: ${(err as Error).message}`)
  }

  // Windows always goes through our own launcher rather than
  // NsisUpdater.doInstall(). That one spawns the installer, returns true
  // regardless, and BaseUpdater quits on the next tick — so a failure to start
  // (elevation required, AV quarantine, a mangled path) is invisible and the
  // app disappears without updating. launchWindowsUpdateInstaller confirms the
  // process is actually alive, and escalates through UAC when Windows demands
  // it, so "we quit" now implies "something is installing".
  if (process.platform === "win32") {
    if (!_downloadedFile) {
      await abortInstall("no staged installer on disk")
      return false
    }
    const launch = await launchWindowsUpdateInstaller(_downloadedFile, _log)
    if (!launch.ok) {
      await abortInstall(launch.detail)
      return false
    }
    _log(`[updater] ${launch.detail}`)
    // Only now is an attempt real. The installer runs after we exit, so this is
    // the last chance to leave a marker; the next launch compares it against
    // app.getVersion() to tell a real install from a silent no-op.
    if (_state.latestVersion) noteInstallAttempt(_state.latestVersion)
    // Stop BaseUpdater's on-quit hook from launching a second copy of the same
    // installer through the path we deliberately bypassed.
    autoUpdater.autoInstallOnAppQuit = false
    app.quit()
    return true
  }

  if (_state.latestVersion) noteInstallAttempt(_state.latestVersion)
  // Give the OS a tick to release the just-killed child processes' handles
  // before the installer tries to overwrite the app directory.
  setImmediate(() => autoUpdater.quitAndInstall(false, true))
  return true
}

function registerIpc(): void {
  if (_ipcRegistered) return
  _ipcRegistered = true

  ipcMain.handle("updater:get-state", () => _state)

  ipcMain.handle("updater:check", async () => {
    if (!_state.supported) return _state
    try {
      // Whether a found update downloads by itself is decided in the
      // update-available handler, from the live setting — not here.
      await autoUpdater.checkForUpdates()
    } catch (err) {
      emit({ status: "error", error: (err as Error).message })
    }
    return _state
  })

  ipcMain.handle("updater:download", async () => {
    if (!_state.supported) return _state
    await startDownload("user pressed Download")
    return _state
  })

  ipcMain.handle("updater:install", async () => {
    if (!_state.supported || _state.status !== "downloaded") return false
    return await quitAndInstallSafely()
  })
}

// Provider options that must hold for every feed we point at, mirror or not.
// Keep in sync with `build.publish` in package.json, which supplies the same
// options to the packaged app-update.yml when no mirror is set.
//
// Differential downloads ask for the changed blocks of an installer. By default
// electron-updater batches them into one multi-range request and expects a
// multipart/byteranges reply — which S3-backed origins (ours is R2 behind
// Cloudflare) don't produce; they answer with the whole object instead, and the
// client streams the entire installer only to fail parsing it and then download
// it a second time in full. One range per request is slower but universally
// supported, and still moves a fraction of the bytes.
const FEED_OPTIONS = { useMultipleRangeRequest: false } as const

/**
 * Point electron-updater at a mirror of the release feed. Called at startup and
 * whenever the user edits the setting, so switching mirrors doesn't need a
 * restart. A blank/invalid value keeps the built-in origin from app-update.yml.
 */
export function applyUpdateFeedUrl(override: unknown): void {
  if (!_state.supported) return
  const url = launcherFeedUrl(override)
  try {
    if (url) {
      autoUpdater.setFeedURL({ provider: "generic", url, ...FEED_OPTIONS })
      _feedBase = url
      _log(`[updater] using update feed mirror: ${url}`)
    } else if (_feedOverridden) {
      // Switching back to the default: electron-updater has no "unset feed"
      // call, so restore the packaged origin explicitly.
      autoUpdater.setFeedURL({
        provider: "generic",
        url: DEFAULT_LAUNCHER_FEED,
        ...FEED_OPTIONS,
      })
      _feedBase = DEFAULT_LAUNCHER_FEED
      _log(`[updater] using default update feed: ${DEFAULT_LAUNCHER_FEED}`)
    }
    _feedOverridden = url !== null
  } catch (err) {
    _log(`[updater] failed to apply update feed: ${(err as Error).message}`)
  }
}

export function setupAutoUpdater(opts: {
  getWindow: () => BrowserWindow | null
  log: (msg: string) => void
  isAutoUpdateEnabled: () => boolean
  onDownloaded: (version: string) => void
  beforeInstall: () => Promise<void>
  /** Bring the daemon back up when a handoff failed and we stay running. */
  resumeAfterFailedInstall?: () => Promise<void>
  /** Persisted `updateFeedUrl` — blank means use the packaged origin. */
  feedUrlOverride?: unknown
}): void {
  _getWindow = opts.getWindow
  _log = opts.log
  _isAutoUpdateEnabled = opts.isAutoUpdateEnabled
  _onDownloaded = opts.onDownloaded
  _beforeInstall = opts.beforeInstall
  if (opts.resumeAfterFailedInstall)
    _resumeAfterFailedInstall = opts.resumeAfterFailedInstall
  _state.currentVersion = app.getVersion()
  _state.autoDownload = _isAutoUpdateEnabled()

  // Unpackaged builds get the SAME update flow as a release: electron-updater
  // reads dev-app-update.yml (repo root) once forceDevUpdateConfig is set, so
  // `npm run dev` checks the real release feed. This used to bail out with a
  // `supported: false` state and its own UI variant — which meant the update
  // banner, notifications and wording could not be exercised without cutting an
  // installer, so the one branch nobody could test was the one users saw.
  //
  // Only check + download are meaningful here; quitAndInstall can't replace a
  // dev tree, which is fine — everything up to "ready to install" is what needs
  // verifying.
  if (!app.isPackaged) {
    autoUpdater.forceDevUpdateConfig = true
    _log("[updater] dev build: checking the real release feed via dev-app-update.yml")
  }

  // electron-updater's Linux installer replaces an AppImage. A packaged deb
  // has no APPIMAGE path to replace, so expose the manual download fallback
  // instead of offering a restart that cannot install anything.
  emit({
    supported: !(process.platform === "linux" && app.isPackaged && !process.env.APPIMAGE),
  })

  // Move the staging cache off a non-ASCII path BEFORE any check runs —
  // AppUpdater memoizes the resolved cache dir on first use. On a Chinese
  // Windows username the default %LOCALAPPDATA% location is what makes the
  // installer handoff fail in the first place.
  let previousRoot: string | null = null
  try {
    previousRoot = (autoUpdater as unknown as { app: { baseCachePath: string } })
      .app.baseCachePath
  } catch {}

  _cacheRoot = redirectUpdaterCacheToAsciiPath(autoUpdater, _log)
  const redirected = _cacheRoot !== null
  if (!_cacheRoot) _cacheRoot = previousRoot
  // Ask the adapter for the config path rather than assuming resourcesPath —
  // it resolves to dev-app-update.yml in an unpackaged build, and the cache dir
  // name differs there on purpose.
  _cacheDirName =
    readUpdaterCacheDirName(updaterConfigPath()) ?? app.getName()

  // Existing installs on a non-ASCII profile already have a staged package in
  // the old location. Nothing reads it now that the cache moved, so it's a
  // ~100MB orphan — and on these machines it's specifically a package that
  // failed to install. Reclaim the space.
  // The app was renamed, so electron-updater now caches under a new directory
  // name; the old one is dead weight on every install that predates 1.0.7.
  purgeLegacyUpdaterCache([_cacheRoot, previousRoot], LEGACY_CACHE_DIR_NAME, _log)

  if (redirected && previousRoot && _cacheDirName) {
    purgePendingUpdateCache(previousRoot, _cacheDirName, _log)
    // The staged package is disposable; the installer the NSIS setup stashed
    // beside it is not — it's the base a differential download builds on, and
    // it only ever lands on the old path. Bring it across before checking.
    adoptDifferentialBaseFile(previousRoot, _cacheRoot, _cacheDirName, _log)
  }

  // Did the update we handed to the installer last time actually land? A
  // package that fails to install stays in the cache, and every later check
  // revalidates it and re-emits `update-downloaded` without downloading
  // anything — so one broken install turns into an endless stream of "update
  // ready" prompts for a version the user can never reach.
  const outcome = reconcileInstallAttempt(
    app.getPath("userData"),
    _state.currentVersion,
  )
  if (outcome.kind === "succeeded") {
    _log(`[updater] confirmed running v${_state.currentVersion} after install`)
  } else if (outcome.kind === "failed") {
    _log(
      `[updater] install of v${outcome.version} did not take effect (still on v${_state.currentVersion}, attempt ${outcome.attempts})`,
    )
    // A cancelled or unfinished installer is not evidence that the verified
    // package is corrupt. Keep it so the next launch can resume from cache.
    // One failure can be a user cancelling the UAC prompt. Two in a row means
    // the in-app path is broken on this machine, so stop pretending it works
    // and let the renderer offer a manual download instead.
    if (outcome.attempts >= 2) emit({ installFailedVersion: outcome.version })
  }

  // Pinned off for the whole process lifetime. electron-updater reads this
  // inside checkForUpdates(), which made the download decision depend on
  // whichever caller set it last; startDownload() owns that decision now.
  autoUpdater.autoDownload = false
  // A normal quit preserves the staged package for the next launch. Only an
  // explicit "Restart & install" starts the installer.
  autoUpdater.autoInstallOnAppQuit = false
  // Differential downloads are left ON (electron-updater's default). Nearly all
  // of a ~140 MB update is the unchanged Electron framework, so the delta
  // downloader — which copies every unchanged block out of the installer
  // already on disk and range-requests only the rest — moves ~20 MB instead.
  //
  // This was pinned off for a while because the published .blockmap didn't
  // describe the published installer byte-for-byte (the macOS zip is repacked
  // with ditto after signing, the Windows binaries are re-signed by SignPath),
  // and reassembling from a stale blockmap fails the sha512 check. CI now
  // rebuilds each blockmap from the exact bytes it publishes and refuses to
  // release when the two disagree, which removes that failure at the source.
  // Everything else — a cold cache, a missing blockmap, a dropped range
  // request — makes electron-updater fall back to a full download on its own,
  // so the worst case is the behaviour we had before.
  autoUpdater.logger = {
    info: (m: unknown) => _log(`[updater] ${String(m)}`),
    warn: (m: unknown) => _log(`[updater] WARN ${String(m)}`),
    error: (m: unknown) => _log(`[updater] ERROR ${String(m)}`),
    debug: () => {},
  }
  wireEvents()
  registerIpc()
  // After wireEvents so a bad mirror surfaces through the normal error path.
  applyUpdateFeedUrl(opts.feedUrlOverride)
}

// Fired on launch and on an interval. "Automatic updates" ON makes the
// update-available handler download in the background and surface a "restart to
// update now" banner/tray item via _onDownloaded; OFF still checks and still
// emits `update-available`, so the renderer asks about that version and
// downloads only on the user's click. Installation is always explicit.
//
// Returns false when the check itself did not complete (offline, DNS, a VPN
// still coming up), so the caller can retry instead of leaving the user with no
// update prompt until the next scheduled check.
export async function checkForUpdatesOnStartup(): Promise<boolean> {
  if (!_state.supported) return false
  try {
    return (await autoUpdater.checkForUpdates()) !== null
  } catch (err) {
    _log(`[updater] update check failed: ${(err as Error).message}`)
    return false
  }
}

// Current updater state — used by the tray to decide whether to show a
// "restart to update" item.
export function getUpdaterState(): UpdaterState {
  return _state
}

// Quit and install a downloaded update immediately (tray / banner "restart
// now"). No-op unless a package is actually downloaded and ready.
export function installDownloadedUpdate(): boolean {
  if (!_state.supported || _state.status !== "downloaded") return false
  void quitAndInstallSafely()
  return true
}
