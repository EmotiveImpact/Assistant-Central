﻿// Copyright (c) Microsoft. All rights reserved.

// Background Responses with Tools — Long-running operations with persistence
//
// This sample demonstrates how to use background responses with ChatClientAgent
// for long-running operations. It shows polling for completion using continuation
// tokens, function calling during background operations, and persisting/restoring
// agent state between polling cycles.

#pragma warning disable CA1050 // Declare types in namespaces

using System.ComponentModel;
using System.Text.Json;
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

var endpoint = Environment.GetEnvironmentVariable("FOUNDRY_PROJECT_ENDPOINT") ?? throw new InvalidOperationException("FOUNDRY_PROJECT_ENDPOINT is not set.");
var deploymentName = Environment.GetEnvironmentVariable("FOUNDRY_MODEL") ?? "gpt-5.4-mini";

var stateStore = new Dictionary<string, JsonElement?>();

// WARNING: DefaultAzureCredential is convenient for development but requires careful consideration in production.
// In production, consider using a specific credential (e.g., ManagedIdentityCredential) to avoid
// latency issues, unintended credential probing, and potential security risks from fallback mechanisms.
AIAgent agent = new AIProjectClient(
    new Uri(endpoint),
    new DefaultAzureCredential())
     .AsAIAgent(
        model: deploymentName,
        name: "SpaceNovelWriter",
        instructions: "You are a space novel writer. Always research relevant facts and generate character profiles for the main characters before writing novels." +
                      "Write complete chapters without asking for approval or feedback. Do not ask the user about tone, style, pace, or format preferences - just write the novel based on the request.",
        tools: [AIFunctionFactory.Create(ResearchSpaceFactsAsync), AIFunctionFactory.Create(GenerateCharacterProfilesAsync)]);

// Enable background responses (only supported by {Azure}OpenAI Responses at this time).
AgentRunOptions options = new() { AllowBackgroundResponses = true };

AgentSession session = await agent.CreateSessionAsync();

// Start the initial run.
AgentResponse response = await agent.RunAsync("Write a short story about a team of astronauts exploring an uncharted galaxy.", session, options);

// Poll for background responses until complete.
while (response.ContinuationToken is not null)
{
    await PersistAgentState(agent, session, response.ContinuationToken);

    await Task.Delay(TimeSpan.FromSeconds(10));

    var (restoredSession, continuationToken) = await RestoreAgentState(agent);

    options.ContinuationToken = continuationToken;
    response = await agent.RunAsync(restoredSession, options);
}

Console.WriteLine(response.Text);

async Task PersistAgentState(AIAgent agent, AgentSession? session, ResponseContinuationToken? continuationToken)
{
    stateStore["session"] = await agent.SerializeSessionAsync(session!);
    stateStore["continuationToken"] = JsonSerializer.SerializeToElement(continuationToken, AgentAbstractionsJsonUtilities.DefaultOptions.GetTypeInfo(typeof(ResponseContinuationToken)));
}

async Task<(AgentSession Session, ResponseContinuationToken? ContinuationToken)> RestoreAgentState(AIAgent agent)
{
    JsonElement serializedSession = stateStore["session"] ?? throw new InvalidOperationException("No serialized session found in state store.");
    JsonElement? serializedToken = stateStore["continuationToken"];

    AgentSession session = await agent.DeserializeSessionAsync(serializedSession);
    ResponseContinuationToken? continuationToken = (ResponseContinuationToken?)serializedToken?.Deserialize(AgentAbstractionsJsonUtilities.DefaultOptions.GetTypeInfo(typeof(ResponseContinuationToken)));

    return (session, continuationToken);
}

[Description("Researches relevant space facts and scientific information for writing a science fiction novel")]
async Task<string> ResearchSpaceFactsAsync(string topic)
{
    Console.WriteLine($"[ResearchSpaceFacts] Researching topic: {topic}");

    // Simulate a research operation
    await Task.Delay(TimeSpan.FromSeconds(10));

    string result = topic.ToUpperInvariant() switch
    {
        var t when t.Contains("GALAXY") => "Research findings: Galaxies contain billions of stars. Uncharted galaxies may have unique stellar formations, exotic matter, and unexplored phenomena like dark energy concentrations.",
        var t when t.Contains("SPACE") || t.Contains("TRAVEL") => "Research findings: Interstellar travel requires advanced propulsion systems. Challenges include radiation exposure, life support, and navigation through unknown space.",
        var t when t.Contains("ASTRONAUT") => "Research findings: Astronauts undergo rigorous training in zero-gravity environments, emergency protocols, spacecraft systems, and team dynamics for long-duration missions.",
        _ => $"Research findings: General space exploration facts related to {topic}. Deep space missions require advanced technology, crew resilience, and contingency planning for unknown scenarios."
    };

    Console.WriteLine("[ResearchSpaceFacts] Research complete");
    return result;
}

[Description("Generates character profiles for the main astronaut characters in the novel")]
async Task<IEnumerable<string>> GenerateCharacterProfilesAsync()
{
    Console.WriteLine("[GenerateCharacterProfiles] Generating character profiles...");

    // Simulate a character generation operation
    await Task.Delay(TimeSpan.FromSeconds(10));

    string[] profiles = [
        "Captain Elena Voss: A seasoned mission commander with 15 years of experience. Strong-willed and decisive, she struggles with the weight of responsibility for her crew. Former military pilot turned astronaut.",
            "Dr. James Chen: Chief science officer and astrophysicist. Brilliant but socially awkward, he finds solace in data and discovery. His curiosity often pushes the mission into uncharted territory.",
            "Lieutenant Maya Torres: Navigation specialist and youngest crew member. Optimistic and tech-savvy, she brings fresh perspective and innovative problem-solving to challenges.",
            "Commander Marcus Rivera: Chief engineer with expertise in spacecraft systems. Pragmatic and resourceful, he can fix almost anything with limited resources. Values crew safety above all.",
            "Dr. Amara Okafor: Medical officer and psychologist. Empathetic and observant, she helps maintain crew morale and mental health during the long journey. Expert in space medicine."
    ];

    Console.WriteLine($"[GenerateCharacterProfiles] Generated {profiles.Length} character profiles");
    return profiles;
}
