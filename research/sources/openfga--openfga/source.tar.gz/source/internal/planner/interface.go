package planner

//go:generate mockgen -package=mocks -destination=../mocks/mock_planner.go github.com/openfga/openfga/internal/planner Manager,Selector

import (
	"time"

	"github.com/openfga/openfga/pkg/storage/cache/keys"
)

// Selector defines the interface for managing strategy selection and stats for a single key.
type Selector interface {
	Select(resolvers map[string]*PlanConfig) *PlanConfig
	UpdateStats(plan *PlanConfig, duration time.Duration)
}

// Manager defines the interface for creating and managing plans for different keys.
type Manager interface {
	GetPlanSelector(key keys.Key) Selector
	Stop()
}
