# retalk JSON standard

retalk's command-line interface and Python library exchange data as JSON in a
single, stable shape. This document is the contract: tools that produce or
consume retalk data should follow it.

## Conventions

- **Line-delimited JSON (NDJSON).** Commands that emit zero or more records
  print one JSON object per line on **stdout**, UTF-8, no surrounding array.
- **stdout is data; stderr is not.** Identity banners, progress, and errors go
  to stderr and are never part of the JSON stream.
- **All ids are 32 lowercase hex characters.** Both user ids and message ids
  use this form, but they are unrelated things that merely share a shape:
  a **user id** is a fingerprint (hash) of a user's public keys, while a
  **message id** is a random value the sender mints for one message. Neither
  the message id nor the user id is a secret, and a message id is not derived
  from any key — do not treat one as the other.
- **Be liberal in what you accept.** Consumers should ignore unknown keys so
  the format can grow without breaking them.

## Objects

### Message

Emitted by `retalk receive` -- one object per decrypted message -- and returned
by `User.receive()` (one dict per message). `retalk history` replays saved
copies (kept by `receive --save`) in this same shape, oldest first.

| field  | type   | description |
|--------|--------|-------------|
| `id`   | string | the message's unique id: a random value the sender mints for this message (not derived from any key, not a user id). Stable across resends, so safe for de-duplication. |
| `from` | string | the sender's user id (a key fingerprint, not the message id). |
| `name` | string | display label: your saved peer name; else the sender's self-chosen name prefixed `~` (unverified); else `""`. |
| `text` | string | the decrypted message body. |
| `group` | string | *(group mail only)* the group's name, as the sender knows it. |
| `group_id` | string | *(group mail only)* the group's stable 32-hex id — thread on this, names can drift. |

```json
{"id":"7d1f...c0","from":"1041c25c...","name":"bob","text":"hello"}
{"id":"9a2e...11","from":"1041c25c...","name":"bob","group":"team","group_id":"5f0c...9d","text":"standup in 5"}
```

A group message is an ordinary pairwise message whose encrypted envelope also
carries the sender's roster; each member receives their own copy (client-side
fan-out — the relay sees nothing group-shaped). `retalk history` adds the same
two fields on saved group rows.

Leaving a group emits a **control record** to each member instead of a chat
message — `receive` prints it as
`{"id", "from", "name", "kind": "group_leave", "group_id"}` and the client
removes the sender from that group's roster. Like contact records, a consumer
must not mistake it for chat: there is no `text` field.

There is no timestamp field: message timing is metadata the relay sees, not
part of the authenticated message, so it is deliberately not surfaced here.

`receive` also emits [shared-contact](#shared-contact) records (`retalk share`)
in the same stream; a consumer that only wants chat messages keeps the records
with a `text` field and ignores those with `"kind": "contact"`.

### Send receipt

Emitted by `retalk send` -- exactly one object -- and returned by `User.send()`
as the `id` string.

| field | type   | description |
|-------|--------|-------------|
| `id`  | string | the id assigned to the message just sent; matches the `id` the recipient will see. |
| `to`  | string | the recipient's user id. |

```json
{"id":"7d1f...c0","to":"38b151a1..."}
```

When sending to a group (`retalk send --group NAME`), the single receipt
describes the whole fan-out instead:

| field | type | description |
|-------|------|-------------|
| `id` | string | the shared thread id carried by every member's copy; matches the `id` each member receives. |
| `group` | string | the group's name, as you know it. |
| `group_id` | string | the group's stable 32-hex id. |
| `sent` | number | members whose copy was handed to the relay. |
| `failed` | number | members whose copy could not be sent; one reason per member goes to stderr, and the command exits with code `2`. |

```json
{"id":"9a2e...11","group":"team","group_id":"5f0c...9d","sent":2,"failed":1}
```

The fan-out only starts after one successful relay contact, so if the relay
itself is unreachable the command fails with no JSON at all — a partial
receipt (`failed > 0`) always means the relay was up and some members'
copies went through.

### Contact

Emitted by `retalk contacts --json` -- one object per saved peer (created with
`retalk add`), sorted by name. The same object is the **contact card** that
`retalk contacts --show CONTACT --json` prints, `retalk share` sends (inside a
shared-contact record, below), and `retalk import` ingests -- so a contact can
be copied between identities verbatim.

| field          | type    | description |
|----------------|---------|-------------|
| `name`         | string  | your local name for the peer; never leaves your machine. |
| `fingerprint`  | string  | the peer's user id (32-hex key fingerprint). |
| `identity_key` | string  | the peer's base64 identity key, recorded by `retalk verify`; `""` until verified. |
| `signing_key`  | string  | the peer's base64 signing key, recorded by `retalk verify`; `""` until verified. |
| `verified`     | boolean | `true` once the peer's keys have been recorded and checked against the fingerprint (via `retalk verify`); `false` for an add-only contact. |

```json
{"name":"bob","fingerprint":"1041c25c...","identity_key":"vGY3...=","signing_key":"Kcx2...=","verified":true}
```

An unverified contact (added but not yet verified) has empty `identity_key` and
`signing_key` and `"verified": false`. Messaging still works -- the keys are
fetched and checked against the fingerprint on the fly; `retalk verify` just
makes that explicit and records the result.

### Shared contact

Emitted by `retalk receive` -- and returned by `User.receive()` -- when a peer
sends you a contact with `retalk share`, in place of a Message. It carries the
distinguishing field `"kind": "contact"`; a chat message has no `kind` and a
`text` field instead, so the two are told apart by which of `text`/`card` is
present.

| field  | type   | description |
|--------|--------|-------------|
| `id`   | string | the message id (as for a Message). |
| `from` | string | the sender's user id -- the peer who shared the contact, not the contact being shared. |
| `name` | string | display label for the **sender** (as for a Message): your saved name for them, else their `~`-prefixed self-chosen name, else `""`. |
| `kind` | string | always `"contact"`. |
| `card` | object | the shared contact as a [Contact](#contact) object: the introduced user's `fingerprint`, recommended `name` (nickname), and `identity_key`/`signing_key` (`""` when the sharer had not verified them). |

```json
{"id":"7d1f...c0","from":"38b151a1...","name":"alice","kind":"contact","card":{"name":"bob","fingerprint":"1041c25c...","identity_key":"vGY3...=","signing_key":"Kcx2...=","verified":true}}
```

`retalk import` saves the `card` as a local peer, re-checking any keys against
the `fingerprint` (a card whose keys do not hash to it is refused, never
trusted). The recipient is free to keep the recommended `name` or choose
another (`import --as NAME`). `retalk receive` also stages these records in a
local contact-inbox, from which `retalk import --inbox` promotes them into the
saved peers (and removes them) -- see the CLI help for that workflow.

### Contact request (invite codes)

Sent by `retalk request` — the encrypted body a requester sends when
redeeming an invite code; consumed by the inviter's `retalk invite watch`,
never printed raw:

    {"id": "<32-hex>", "kind": "contact_request", "code": "<invite code>",
     "card": {<the requester's own Contact card, verified: true>}}

`retalk invite watch` emits one NDJSON record per handled request:

| record | shape |
|--------|-------|
| acceptance | `{"kind": "contact_accepted", "code", "from", "name", "card"}` |
| rejection | `{"kind": "contact_request_rejected", "from", "reason"}` |

`reason` is one of `unknown-code`, `revoked`, `expired`, `consumed`,
`card-mismatch`. The code value is never echoed in rejections. A valid code
proves the sender was authorised by whoever issued it, not that the keys
belong to a particular human — see the invite-code section of the README.

`retalk request` prints an ordinary send receipt (`{"id", "to"}`);
acceptance is deliberately not observable from the requester's side.

### Share receipt

Emitted by `retalk share` -- exactly one object -- and returned by
`User.share()` as the `id` string.

| field    | type   | description |
|----------|--------|-------------|
| `id`     | string | the id of the share message just sent; matches the `id` the recipient sees. |
| `to`     | string | the recipient's user id (who you introduced the contact *to*). |
| `shared` | string | the shared contact's user id (who you introduced). |

```json
{"id":"7d1f...c0","to":"38b151a1...","shared":"1041c25c..."}
```

## Notes for consumers

- `receive` prints **zero** lines when there is nothing to read; check for
  empty output, not for an error.
- To follow a conversation, match a send receipt's `id` against the `id` of a
  later received message.
