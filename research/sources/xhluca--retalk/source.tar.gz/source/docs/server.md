# Server behavior and trust model

The retalk server is a relay. It has two jobs:

1. Hold encrypted messages in recipient mailboxes until clients poll.
2. Serve a public-key directory for users who have published keys.

The server does not encrypt, decrypt, create identities, or decide which keys
to trust. Clients do that.

This page explains what the server stores, what it can see, why requests are
authenticated, and what a hostile server can still do.

## Configuration reference

Every setting has a command-line flag and a matching environment variable; the
flag wins when both are given. This is the canonical list — the deployment
guides below only show these in context.

**`retalk-server`** (the relay):

| flag | env var | default | meaning |
|------|---------|---------|---------|
| `--host` | `RETALK_SERVER_HOST` | `0.0.0.0` | interface to bind (`0.0.0.0` = all, `127.0.0.1` = this machine only) |
| `--port` | `RETALK_SERVER_PORT` | `8766` | TCP port to bind |
| `--audience` | `RETALK_SERVER_AUDIENCE` | `http://HOST:PORT` | public URL clients connect to; request signatures are bound to it, so it must equal each client's relay URL exactly. A comma-separated list accepts several URLs (any entry verifies), keeping an old URL valid while a domain moves |
| `--db` | `RETALK_SERVER_DB` | `server.db` | SQLite database path |
| `--max-body` | `RETALK_SERVER_MAX_BODY` | `1048576` | max request body in bytes; larger requests get HTTP 413 |
| `--rate-limit` | `RETALK_SERVER_RATE_LIMIT` | `0` | max requests per caller fingerprint per minute (`0` = disabled); over the cap gets HTTP 429 |
| `--timeout` | `RETALK_SERVER_TIMEOUT` | `30` | per-connection socket timeout in seconds (drops slow/idle clients) |
| `--max-mailbox` | `RETALK_SERVER_MAX_MAILBOX` | `0` (unlimited) | max undelivered messages per recipient; see [Mailbox cap](#mailbox-cap) |
| `--max-mailbox-per-sender` | `RETALK_SERVER_MAX_MAILBOX_PER_SENDER` | `0` (unlimited) | max undelivered messages a single sender may hold in one recipient's mailbox; only applies when `--max-mailbox` is set |
| `--admin-password` | `RETALK_SERVER_ADMIN_PASSWORD` | (unset) | password for the `/admin` API-key endpoint; unset disables `/admin`; see [Closing the relay](#closing-the-relay-api-keys) |
| `--require-api-key` | `RETALK_SERVER_REQUIRE_API_KEY` | off | require a valid API key on every tool request (HTTP 401 otherwise); see [Closing the relay](#closing-the-relay-api-keys) |
| `--max-refused` | `RETALK_SERVER_MAX_REFUSED` | `1000` | max negative-acks (refused message hashes) kept per recipient before the oldest are evicted; see [Refusing mail (negative acks)](#refusing-mail-negative-acks) |
| `--refused-ttl` | `RETALK_SERVER_REFUSED_TTL` | `604800` (7 days) | seconds a negative-ack lives before it expires and is pruned (`0` = no expiry); see [Refusing mail (negative acks)](#refusing-mail-negative-acks) |

`--host`/`--port` are where the process *listens*; `--audience` is the public
URL clients *reach it at*. They coincide locally, but behind a TLS proxy the
proxy listens publicly and forwards to a local `--host`/`--port`, so
`--audience` must be set to the public `https://` URL.

**`retalk`** (the client):

| flag | env var | meaning |
|------|---------|---------|
| `--relay` | `RETALK_RELAY` | relay URL to talk to (must equal the server's `--audience`); `init` can save one per identity |
| `--user` / `-u` | `RETALK_USER` | which identity to act as (`~/.retalk/NAME/`) |
| `--dir` | — | use an identity in an explicit directory instead of by user name |
| `--passphrase` | `RETALK_PASSPHRASE` | unlocks the identity's keys at rest |
| `--no-passphrase` | — | open/create an identity with no passphrase (file-permission protected only) |

## Running it on the internet

The server speaks plain HTTP on a local port. To expose it publicly, put it
behind something that terminates TLS and forwards to that port:

- [huggingface.md](server/huggingface.md) — host it for free on a Hugging Face
  Docker Space: a public HTTPS URL with no domain, firewall, or TLS setup.
  Quickest zero-cost option; the free tier has no persistent disk and sleeps
  when idle.
- [cloudflare.md](server/cloudflare.md) — Cloudflare Tunnel, free quick
  tunnels or a stable hostname on your own domain. No firewall changes.
- [gcp.md](server/gcp.md) — running the server on a small Google Cloud
  VM (free-tier sized), with stop/delete and cost notes.

The examples assume the local demo from the README:

- server at `http://127.0.0.1:8766`
- "Alice" identity in `./alice`
- `RETALK_RELAY=http://127.0.0.1:8766`
- `RETALK_PASSPHRASE=alice-secret`

## Database tables

The schema lives in `src/retalk/server.py`.

`users` stores:

- user ID,
- public identity key,
- public signing key,
- public fallback key.

There are no accounts, passwords, bearer tokens, or private keys.

`otks` stores:

- public one-time prekeys,
- the user that owns each key,
- whether each key has been claimed.

The private halves stay in the user's encrypted local store.

`messages` stores:

- sender ID,
- recipient ID,
- timestamp,
- message type,
- base64 ciphertext.

Rows are deleted as soon as `read_messages` delivers them to the recipient.

`nonces` stores recent request nonces so copied requests cannot be replayed.
Old entries are purged automatically.

`refused` stores negative acks (see [Refusing mail](#refusing-mail-negative-acks)):

- the recipient who refused,
- the refused message's ciphertext hash,
- the recipient's signature over that refusal (the proof handed to senders),
- a timestamp (used to evict the oldest past the per-recipient cap).

## Mailbox cap

By default a recipient's mailbox is unbounded, so an open relay can be filled
by anyone who can reach it — a denial-of-service lever. The mailbox cap bounds
how much undelivered mail a recipient can accumulate.

| flag | env var | default | meaning |
|------|---------|---------|---------|
| `--max-mailbox` | `RETALK_SERVER_MAX_MAILBOX` | `0` (unlimited) | max undelivered messages per recipient |
| `--max-mailbox-per-sender` | `RETALK_SERVER_MAX_MAILBOX_PER_SENDER` | `0` (unlimited) | max undelivered messages one sender may hold in a single recipient's mailbox |

Behavior:

- The default `0` is unlimited, so caps are off unless you set one.
- `send_message` counts a recipient's undelivered messages *before* inserting.
  At or over `--max-mailbox`, the send is **rejected** with HTTP 400 and
  `{"error": "mailbox full: ..."}`. It is **reject-not-evict**: existing mail
  is never dropped to make room.
- `--max-mailbox-per-sender` is a smaller sub-cap on how many of those
  messages may come from one sender, so a single sender cannot fill a mailbox
  and crowd everyone else out. It only takes effect when `--max-mailbox` is
  set, and produces a `mailbox full for sender: ...` error.

A rejection is safe for delivery. The sender keeps every unacknowledged
message in its local outbox and resends later (the same mechanism that
survives a dropped server, see *The server database is disposable*). So
at-least-once delivery survives a "mailbox full" rejection: once the recipient
polls and drains the mailbox, the held-back messages get through on the next
flush.

## Refusing mail (negative acks)

Senders resend unacknowledged outbox mail, which is what makes delivery survive
a dropped server. But a recipient who *refuses* a message (a blocked or, in
peers-only mode, an unknown sender — both decided client-side) would otherwise
see it re-uploaded on every resend. The `nack` tool lets the recipient stop
that at the relay:

1. On dropping a message, the recipient calls `nack` with the message's
   ciphertext hash and a signature over `nack|<recipient>|<hash>`. No
   decryption happens and no one-time key is spent.
2. The relay verifies the signature and records `(recipient, hash, signature)`
   in the `refused` table.
3. On any later `send_message` to that recipient with the same ciphertext, the
   relay does not store it; it returns `{"refused": true, "hash": ..., "sig":
   ...}` with the recipient's signature.
4. The sender verifies that signature against the recipient's signing key and
   **deletes** the message from its outbox, so it stops resending — even a
   sender that only ever `send`s and never `receive`s.

This keeps the relay **untrusted**. It cannot forge a refusal: the proof is the
recipient's own signature, and a sender that receives an unsigned or invalid
one keeps the message live. A hostile relay could only *drop* messages, which
it can always do. The cost is that the relay learns a message was refused (it
stores the hash) — it still never sees plaintext, private keys, or the
recipient's block list, which stays client-side.

Because a recipient can record arbitrary hashes, the `refused` table is bounded
two ways:

- **By age** — `--refused-ttl` (default 7 days): an entry past its TTL stops
  blocking and is pruned (server-wide) on the next `nack`, so the table shrinks
  over time instead of only at the cap.
- **By count** — `--max-refused` (default 1000 per recipient): once exceeded,
  the oldest entries are evicted.

Either bound expiring an entry just means a very old refused message could be
re-uploaded once more and re-dropped (re-recording the refusal); it is never a
correctness problem.

## Closing the relay (API keys)

By default the relay is **open**: anyone who can reach it can publish keys and
send/receive. That is fine for a public relay, but you may want to limit *who
may use this relay at all* — e.g. only your own agents. retalk has an optional,
opt-in access layer: an admin password unlocks an `/admin` endpoint that mints
**API keys**, and `--require-api-key` makes every tool request carry one.

This is **access control, not identity.** The end-to-end crypto is unchanged: a
client still signs every request with its own key, and an API key never lets
anyone read mail or impersonate a user. The worst a leaked key does is let an
outsider *use the relay* — i.e. drop you back to the open-relay default — until
you disable it. So treat it as a coarse gate, sent over TLS like everything
else. (This is the built-in form of restricting a closed deployment with
reverse-proxy auth; see [auth.md](auth.md) on why it doesn't contradict the
"no tokens" identity model.)

### Turning it on (safe order)

`--admin-password` and `--require-api-key` are independent on purpose. Enable
them in this order so you don't lock yourself out:

1. Start with an admin password (enforcement still off):
   ```sh
   RETALK_SERVER_ADMIN_PASSWORD=... retalk-server --audience https://relay.example.com
   ```
2. Mint and distribute keys via `/admin` (below).
3. Restart with enforcement on:
   ```sh
   RETALK_SERVER_ADMIN_PASSWORD=... RETALK_SERVER_REQUIRE_API_KEY=1 \
     retalk-server --audience https://relay.example.com
   ```

Setting the password alone only enables `/admin`; it does **not** start
rejecting clients. Flip `--require-api-key` before issuing any keys and every
client breaks until you do.

### Managing keys over HTTP

`/admin` is gated by HTTP Basic auth (any username, the admin password).
`GET /admin` shows a small page; the actions are JSON `POST`s, scriptable with
curl:

```sh
PW=...                                   # the admin password
URL=https://relay.example.com

# create a key — the raw key is returned ONCE; only its hash is stored
curl -u admin:$PW -X POST $URL/admin -d '{"action":"create","label":"alice"}'

# list keys (hashes + labels + status, never the raw key)
curl -u admin:$PW -X POST $URL/admin -d '{"action":"list"}'

# disable / re-enable / delete a key by its key_hash
curl -u admin:$PW -X POST $URL/admin -d '{"action":"disable","key_hash":"..."}'
curl -u admin:$PW -X POST $URL/admin -d '{"action":"enable","key_hash":"..."}'
curl -u admin:$PW -X POST $URL/admin -d '{"action":"delete","key_hash":"..."}'
```

If the relay sits under a path prefix (e.g. `https://host/retalk/`), `/admin`
is matched by its suffix, so `https://host/retalk/admin` works too.

### Giving a client its key

A client sends the key as `Authorization: Bearer <key>`. With the CLI:

```sh
retalk init --user alice --relay https://relay.example.com --api-key <key>
# saved in the identity; or pass --api-key per command, or set RETALK_API_KEY
```

### Security notes

- Keys are stored **hashed** (sha256); a stolen database yields no usable keys.
- Use **multiple labelled keys** so you can revoke one client without rotating
  everyone — just disable or delete its key.
- The key and the admin password are reusable secrets carried over **TLS**;
  never send them over plain HTTP.
- Rotate/disable a key if exposed — but its blast radius is only "use of the
  relay," never identity or message content.

## What the server sees

The server sees metadata:

- who messages whom,
- when messages are sent and received,
- how often users communicate,
- message sizes,
- public key material,
- which message ciphertexts a recipient refused (the hashes in `refused`).

This is an accepted leak in v1. End-to-end encryption protects message
content, not the social graph. The refused hashes reveal *that* a recipient
turned a message away, but not its content nor the recipient's block list
(which never leaves the client).

The server does not see:

- plaintext,
- private keys,
- users' self-chosen display names,
- your local peer names,
- reusable credentials.

It also cannot safely substitute keys. A user ID is the fingerprint of the
user's public keys. Clients recompute that fingerprint for every key lookup
and refuse mismatches with `PIN MISMATCH`.

## The server database is disposable

The durable state that matters lives on clients:

- identities,
- private keys,
- Olm sessions,
- saved peers,
- unacknowledged outgoing messages.

If the server loses its database, clients can recover:

1. The next command notices missing public keys.
2. The client republishes its public keys.
3. Senders re-upload unacknowledged outbox messages.
4. Recipients ignore duplicates they already processed.

The server is useful, but it is not the root of identity or trust.

## Inspect the local demo

While the README demo is running:

```sh
sqlite3 server.db '.tables'
# api_keys  messages  nonces  otks  refused  users

sqlite3 server.db 'SELECT id, substr(identity_key,1,16) FROM users'
# public keys only

sqlite3 server.db 'SELECT sender, recipient, substr(body,1,32) FROM messages'
# base64 ciphertext; delivered rows disappear
```

## One-time prekeys

One-time prekeys let someone start an encrypted session with you while you
are offline.

The flow:

1. You generate a batch of one-time keypairs.
2. You keep the private halves in your encrypted local store.
3. You upload the public halves to the server.
4. A sender claims one public prekey when starting a new session with you.
5. The sender uses it for the first encrypted handshake message.
6. You later consume the matching private half when receiving that message.

The server stores public halves only. A public prekey lets someone encrypt a
handshake to the owner. It does not let the server read messages or
impersonate the sender.

The worst a hostile server can do with prekeys is deny service: refuse to
serve them, drain them, or serve the fallback key instead. It still cannot
decrypt the resulting messages without private keys.

See [olm.md](olm.md) for the full explanation.

Quick local check:

```python
import vodozemac as v

acct = v.Account()
acct.generate_one_time_keys(2)

print({k: p.to_base64() for k, p in acct.one_time_keys.items()})
# Public halves, safe to upload.

print(acct.pickle(b"0" * 32)[:24], "...")
# Encrypted local account data. Private halves do not leave the account.
```

## Nonces

Every server request is signed. A signature proves the request is genuine,
but an exact copy of a genuine request is also genuine unless the server
detects replay.

That is what nonces are for.

Each request includes a fresh random nonce. The nonce is covered by the
signature, so an attacker cannot replace it. The server remembers recently
seen nonces. If the same nonce appears again, the request is rejected as a
replay.

The table stays small because signatures also include timestamps. Requests
older than about 2.5 minutes are rejected, so nonces only need to be kept for
that short window.

Replay example:

```python
from retalk import User

u = User("http://127.0.0.1:8766", "alice-secret", store="alice/store.db")
wire = {"auth": u._auth_fields("read_messages", {})}

print(u._call_raw("read_messages", wire))
# First copy works.

u._call_raw("read_messages", wire)
# RuntimeError: server error from read_messages: replay detected: nonce already used
```

## Why requests are authenticated

The server cannot read ciphertext, but unauthenticated access would still be
dangerous.

Without authentication:

- Anyone could drain your mailbox by calling `read_messages` as your ID. They
  could not decrypt the messages, but the server would delete them before you
  received them.
- Anyone could submit ciphertext labeled as another sender. Recipients would
  waste keys and CPU on forgeries, and delivery failures would be harder to
  understand.

An unauthenticated request is rejected:

```sh
curl -s -X POST http://127.0.0.1:8766 -d '{"tool":"read_messages","args":{}}'
# {"error": "read_messages() missing 1 required positional argument: 'auth'"}
```

## How authentication works

Every request carries an `auth` object:

- user ID,
- public identity key,
- public signing key,
- timestamp,
- nonce,
- Ed25519 signature.

The signature covers the tool name, this server's public URL, the user ID,
the timestamp, the nonce, and a hash of the request arguments.

The server checks that:

- the public keys hash to the claimed user ID,
- the timestamp is fresh,
- the signature is valid,
- the nonce has not been used before.

There is no registration step. Publishing keys creates the server-side
mailbox. Full details and the exact wire format are in [auth.md](auth.md).

Example auth object:

```python
import json
from retalk import User

u = User("http://127.0.0.1:8766", "alice-secret", store="alice/store.db")
print(json.dumps(u._auth_fields("read_messages", {}), indent=2))
```

Shape:

```json
{
  "fingerprint": "1247d297...",
  "identity_key": "fkF/kOCL...",
  "signing_key": "Kcx2OupV...",
  "timestamp": "1781731882",
  "nonce": "c0ffee...",
  "signature": "mF90aaQz..."
}
```

Nothing in that object is secret. The private signing key is needed to
produce `signature`, but it is not sent.

ID squatting is not useful. To use an ID, the caller must produce signatures
from keys that hash to that ID.

Open access is the default. Anyone who can reach the server can publish keys
and get a mailbox. For a closed deployment, restrict access with a firewall
or reverse-proxy authentication.

## Display names

The server sees no display names.

There are two kinds:

- **Self-chosen name**: stored inside encrypted messages. Recipients can read
  it, but it is unverified, so clients display it as `~name`.
- **Peer name**: your local label for a user ID, created with
  `retalk add <id> --peer bob`. It never leaves your machine and overrides the
  sender's self-chosen name.

Trust IDs and saved peer names, not self-chosen names.

Example:

```sh
retalk receive --peer alice --dir ./bob
# ~"alice": hello

retalk add "$ALICE_ID" --peer boss --dir ./bob
retalk receive --peer boss --dir ./bob
# "boss": are we still on for tomorrow?
```

## Hardening against abuse

Authentication proves who a request comes from, but an open relay is still
exposed to denial-of-service from clients: huge request bodies, connections
that dribble bytes to tie up worker threads, and floods of valid signed
requests. Three built-in limits blunt these. They are tuned to be invisible
to normal clients, so the defaults are safe to leave on.

- **Request body-size cap** (`--max-body` / `RETALK_SERVER_MAX_BODY`,
  default 1 MiB). The server reads the `Content-Length` header first and, if
  it exceeds the cap, rejects the request with HTTP 413 *without reading the
  body* — so an attacker cannot make the server buffer an oversized payload.
  A normal request (even a `publish_keys` call carrying a batch of one-time
  keys) is a few kilobytes, well under the default.

- **Socket timeout** (`--timeout` / `RETALK_SERVER_TIMEOUT`, default 30s).
  Each connection gets a read timeout, so a slow or idle client (a
  "slowloris" that opens a connection and sends bytes one at a time, or never
  finishes its request) is dropped instead of holding a worker thread open
  indefinitely. The window is generous enough that a real client on a slow
  link is unaffected.

- **Per-fingerprint rate limit** (`--rate-limit` / `RETALK_SERVER_RATE_LIMIT`,
  default `0` = disabled). When set to *N*, a caller may make at most *N*
  requests per minute, counted per authenticated `fingerprint`. Over the cap
  returns HTTP 429. The counter is an in-memory sliding window guarded by a
  lock (the server is multithreaded) and prunes old entries, so it adds
  negligible overhead and bounded memory. It is off by default so existing
  deployments and tests are unaffected; turn it on for internet-facing
  servers. Because the limit is keyed on the caller's own fingerprint, it
  throttles per identity rather than per IP, and a caller cannot evade it
  without minting a fresh keypair (which still cannot read another user's
  mailbox).

These caps reduce the cost of abuse but do not replace a reverse proxy.
For internet exposure, also terminate TLS and apply network-level rate
limiting and connection limits at the proxy (see the deployment guides
above).

## Hostile server behavior

- **Read message bodies:** fails. The server stores ciphertext only.
- **Read private keys:** fails. Private keys never leave clients.
- **Swap public keys to man-in-the-middle a user:** clients detect the
  fingerprint mismatch and refuse with `PIN MISMATCH`.
- **Forge a message from "Alice":** fails. Message decryption is bound to
  "Alice"'s identity key.
- **Capture credentials usable elsewhere:** fails. There are no bearer tokens,
  and signatures are bound to this server URL.
- **Replay an old request:** rejected by nonce or timestamp checks.
- **Replay old ciphertext:** rejected by the Olm ratchet. Duplicates are
  re-acked and dropped.
- **Drop or delay messages:** possible. Senders keep unacknowledged ciphertext
  in an outbox and resend later.
- **Lose the database:** recoverable. Clients republish keys and resend
  unacknowledged messages.
- **Drain one-time prekeys:** possible denial-of-service pressure.
  `maintain()` replenishes keys, and fallback keys keep new sessions
  available.
- **Serve fallback keys while withholding one-time keys:** weakens forward
  secrecy for new sessions until fallback rotation. Daily rotation bounds the
  exposure.
- **Watch metadata:** possible and accepted in v1. Padding and cover traffic
  are future work.
