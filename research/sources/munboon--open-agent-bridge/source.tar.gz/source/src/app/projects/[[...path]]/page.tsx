export {default} from '../../page';
