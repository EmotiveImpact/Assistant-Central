
### OpenID

This module allows users to verify their identity with a third-party
service. The third-party service does need to be matrix-aware in that it
will need to know to resolve matrix homeservers to exchange the user's
token for identity information, using the [OpenID section of the
Server-Server API](/server-server-api/#openid).

{{% http-api spec="client-server" api="openid" %}}
